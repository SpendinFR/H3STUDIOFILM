"""V10.94 central Retake: 63 Gemma frames + 10 H3 frames on EACH side.

This affects ONLY selections that span the normal half-clip seam. Gemma writes
natural before/action/after choreography on a 63f token-aligned core; H3 sees
a separate 83f token-aligned render window, with the action seconds shifted by
exactly 10 frames. The technical margins are discarded at both seams. The V88
single-seam paths (prompt, latent slicing and stitching) are NOT modified.
"""
from __future__ import annotations
from pathlib import Path
import re
import subprocess
import retouches_precise_half_v82 as half
from retouches_llm_prompt_v74 import SHOT_HEADER, SHOT_RE, _seconds
from retouches_llm_prompt_half_v82 import _grid

FPS=24
RENDER_TOKENS=25
CORE_TOKENS=19
CORE_FRAMES=63
EDGE_FRAMES=10
RENDER_FRAMES=83


def select_window(total_latent:int,total_frames:int,begin:float,end:float)->tuple[dict,dict]:
    """Plan exact 10f + 63f + 10f, all aligned with the RAW token cadence.

    Avoid independently guessing the MP4 origin: token-origin rounding must
    produce *exactly* 10 video frames on BOTH sides. Fail rather than shift the
    user's action by a frame or crop one of their selected seconds.
    """
    if half._window_frames_from_latent(total_latent)!=total_frames:
        raise ValueError('Retake central : RAW et clip MP4 non alignés')
    if half._window_frames_from_latent(CORE_TOKENS)!=CORE_FRAMES or half._window_frames_from_latent(RENDER_TOKENS)!=RENDER_FRAMES:
        raise RuntimeError('Retake central : cadence de 63/83 images H3 invalide')
    first=max(0,min(total_frames-1,int(round(begin*FPS))))
    last=max(first+1,min(total_frames,int(round(end*FPS))))
    if last-first>CORE_FRAMES-6:
        raise ValueError('Retake central : plage trop longue pour conserver la continuité avant et après le geste.')
    if total_latent<RENDER_TOKENS+2:
        raise ValueError('Retake central : clip trop court pour deux raccords et deux marges de dix images.')
    ideal=(first+last)/2
    candidates=[]
    for token in range(3,total_latent-CORE_TOKENS-2):
        render_token=token-3
        core_origin=round(token*17/5)
        render_origin=round(render_token*17/5)
        core_end=core_origin+CORE_FRAMES
        render_end=render_origin+RENDER_FRAMES
        pre=core_origin-render_origin
        post=render_end-core_end
        if pre!=EDGE_FRAMES or post!=EDGE_FRAMES:
            continue
        if not (0<render_origin<core_origin<first<last<core_end<render_end<total_frames):
            continue
        # The V83 beat grid must have before and after shots for natural lead-in/out.
        if first-core_origin<3 or core_end-last<3:
            continue
        candidates.append((abs((core_origin+core_end)/2-ideal), token, core_origin, core_end,
                           render_token, render_origin, render_end))
    if not candidates:
        raise ValueError('Retake central : impossible de cadrer cette sélection avec deux marges RAW exactes de 10 images.')
    _,token,core_origin,core_end,render_token,render_origin,render_end=min(candidates)
    core={
        'start_latent':token,'latent_t':CORE_TOKENS,
        'origin_frame':core_origin,'end_frame':core_end,'frames':CORE_FRAMES,
        'duration':CORE_FRAMES/FPS,'first_frame':first,'last_frame':last,
        'local_first':first-core_origin,'local_last':last-core_origin,
        'start':(first-core_origin)/FPS,'end':(last-core_origin)/FPS,
        'global_offset':core_origin/FPS,'seam_mode':'center_two_seams',
    }
    render={**core,
        'start_latent':render_token,'latent_t':RENDER_TOKENS,
        'origin_frame':render_origin,'end_frame':render_end,'frames':RENDER_FRAMES,
        'duration':RENDER_FRAMES/FPS,
        'local_first':first-render_origin,'local_last':last-render_origin,
        'start':(first-render_origin)/FPS,'end':(last-render_origin)/FPS,
        'global_offset':render_origin/FPS,
        'preroll_frames':EDGE_FRAMES,'postroll_frames':EDGE_FRAMES,
        'stitch_start_frame':core_origin,'stitch_frames':CORE_FRAMES,
    }
    if (render['origin_frame']+EDGE_FRAMES!=core['origin_frame'] or
            render['end_frame']-EDGE_FRAMES!=core['end_frame'] or
            render['local_first']-EDGE_FRAMES!=core['local_first'] or
            render['local_last']-EDGE_FRAMES!=core['local_last']):
        raise RuntimeError('Retake central : décalage masque/latent/référence non aligné')
    return core,render


def verify_gemma_descriptions(gemma_prompt:str)->None:
    """Central mode only: reject a literal storyboard role instead of a gesture.

    Keep the V10.83 prompt author untouched. This checks its result before H3,
    including descriptions beginning with the separator em-dash.
    """
    prefix, mark, _ = gemma_prompt.partition('\nLOCAL TAKE:')
    if not mark:
        raise ValueError('Retake central : prompt local incomplet')
    headers = list(SHOT_HEADER.finditer(prefix))
    if not headers:
        raise ValueError('Retake central : aucun mouvement décrit')
    for i, header in enumerate(headers):
        desc = prefix[header.end():headers[i+1].start() if i+1 < len(headers) else len(prefix)]
        desc = desc.strip().lstrip('—–-: ').strip()
        if len(desc) < 14 or re.fullmatch(
            r'(?:TRANSITION\s+(?:AVANT|APR[ÈE]S)|ACTION)[.!?…\s]*',
            desc, flags=re.I,
        ):
            raise RuntimeError('Gemma : Shot sans description de mouvement ; génération refusée')




def prepare_prompt(gemma_prompt:str,core:dict,render:dict)->str:
    """Preserve V83/V93 Gemma descriptions, map 63f -> 83f for H3 only.

    Expand the FIRST natural pre-action beat backwards by 10 frames and the
    LAST natural continuation beat forwards by 10 frames. Shift all internal
    beats by 10, including the requested action; never add invented Shots.
    """
    verify_gemma_descriptions(gemma_prompt)
    pre=int(render['preroll_frames']);post=int(render['postroll_frames'])
    core_frames=int(core['frames']);render_frames=int(render['frames'])
    if (pre!=10 or post!=10 or render_frames!=pre+core_frames+post or
        int(render['origin_frame'])+pre!=int(core['origin_frame']) or
        int(render['end_frame'])-post!=int(core['end_frame'])):
        raise ValueError('Retake central : fenêtres H3 et Gemma mal alignées')
    prefix,delimiter,_=gemma_prompt.partition('\nLOCAL TAKE:')
    if not delimiter:
        raise ValueError('Retake central : metadata Gemma absente')
    headers=list(SHOT_HEADER.finditer(prefix))
    occurrences=list(SHOT_RE.finditer(prefix))
    grid=_grid(core)
    if len(headers)!=len(grid) or len(occurrences)!=len(grid) or len(headers)<3:
        raise ValueError('Retake central : attendu 3 mouvements de continuité / action / reprise')
    if (grid[0][0]!='TRANSITION AVANT' or grid[-1][0]!='TRANSITION APRÈS'):
        raise ValueError('Retake central : mouvement avant ou après le geste absent')
    rewritten=[]
    previous_end=0
    for i,(role,a,b) in enumerate(grid):
        h=headers[i]
        if int(h.group(1))!=i+1:
            raise ValueError('Retake central : numérotation Gemma incompatible')
        start_frame=round(_seconds(h.group(2))*FPS)
        end_frame=round(_seconds(h.group(3))*FPS)
        if (start_frame!=round(a*FPS) or end_frame!=round(b*FPS) or start_frame!=previous_end):
            raise ValueError('Retake central : la grille Gemma ne correspond pas au RAW')
        desc=prefix[h.end(): headers[i+1].start() if i+1<len(headers) else len(prefix)].strip()
        # Keep the entire descriptive text, without renaming or re-authoring.
        begin=0 if i==0 else start_frame+pre
        finish=render_frames if i==len(grid)-1 else end_frame+pre
        rewritten.append(f'[Shot {i+1}] {begin/FPS:.3f}–{finish/FPS:.3f}s {desc}')
        previous_end=end_frame
    if previous_end!=core_frames:
        raise ValueError('Retake central : Gemma n’a pas terminé ses 63 images')
    leading=prefix[:headers[0].start()]
    offset=render['origin_frame']/FPS
    action_a=render['local_first']/FPS
    action_b=render['local_last']/FPS
    metadata=(f'LOCAL TAKE: exactly {render_frames/FPS:.3f}s, from original '
        f'{offset:.3f}–{offset+render_frames/FPS:.3f}s. '
        f'Action assigned within the local take at {action_a:.3f}–{action_b:.3f}s. '
        'Distinct [Shot]s are continuous motion beats, never camera cuts. '
        'Do not generate beyond the local take duration. Preserve visual identity and physical continuity.')
    return leading+'\n'.join(rewritten)+'\n'+metadata


def _run(cmd:list[str],name:str,output:Path,timeout:int=360)->None:
    proc=subprocess.run(cmd,capture_output=True,text=True,timeout=timeout)
    if proc.returncode or not output.is_file():
        raise RuntimeError('Retake central : '+name+' échoué : '+proc.stderr[-1300:])


def stitch(original:Path,generated:Path,target:Path,core:dict,render:dict,total_frames:int,comfy:Path)->Path:
    """One encode, two V88-equivalent 4-frame fades; preserve original audio."""
    core_a=int(core['origin_frame']); core_b=int(core['end_frame'])
    core_n=int(core['frames']); pre=int(render['preroll_frames'])
    gen_n=int(render['frames'])
    if not (0<core_a<core_b<total_frames and core_b-core_a==core_n):
        raise ValueError('Retake central : raccords hors bornes')
    if not (pre>=4 and int(render['postroll_frames'])>=4 and gen_n==pre+core_n+int(render['postroll_frames'])):
        raise ValueError('Retake central : marges techniques incorrectes')
    generated=half._normalize_generated_frames(generated,gen_n,comfy)
    fade=4
    # V88 original->new blend in the FIRST 4 kept frames;
    # V88 new->original blend in the LAST 4 kept frames.
    old_new=f'min(1,(N+1)/{fade})'
    filters=[
        f'[0:v]trim=start_frame=0:end_frame={core_a},setpts=PTS-STARTPTS,format=yuv420p[head]',
        f'[0:v]trim=start_frame={core_a}:end_frame={core_a+fade},setpts=PTS-STARTPTS,format=yuv420p[oldin]',
        f'[1:v]trim=start_frame={pre}:end_frame={pre+fade},setpts=PTS-STARTPTS,format=yuv420p[newin]',
        f"[oldin][newin]blend=all_expr='A*(1-({old_new}))+B*({old_new})'[fadein]",
        f'[1:v]trim=start_frame={pre+fade}:end_frame={pre+core_n-fade},setpts=PTS-STARTPTS,format=yuv420p[body]',
        f'[1:v]trim=start_frame={pre+core_n-fade}:end_frame={pre+core_n},setpts=PTS-STARTPTS,format=yuv420p[newout]',
        f'[0:v]trim=start_frame={core_b-fade}:end_frame={core_b},setpts=PTS-STARTPTS,format=yuv420p[oldout]',
        f"[newout][oldout]blend=all_expr='A*(1-({old_new}))+B*({old_new})'[fadeout]",
        f'[0:v]trim=start_frame={core_b}:end_frame={total_frames},setpts=PTS-STARTPTS,format=yuv420p[tail]',
        '[head][fadein][body][fadeout][tail]concat=n=5:v=1:a=0[outv]',
    ]
    target.parent.mkdir(parents=True,exist_ok=True)
    cmd=[half._bin(comfy,'ffmpeg'),'-hide_banner','-loglevel','error','-y',
         '-i',str(original),'-i',str(generated),'-filter_complex',';'.join(filters),
         '-map','[outv]','-map','0:a:0?',
         '-c:v','libx264','-preset','veryfast','-crf','17','-pix_fmt','yuv420p',
         '-c:a','aac','-ar','44100','-frames:v',str(total_frames),str(target)]
    _run(cmd,'deux raccords en un seul passage',target)
    if half._frame_count(target,comfy)!=total_frames:
        target.unlink(missing_ok=True)
        raise RuntimeError('Retake central : nombre d’images final incorrect')
    return target
