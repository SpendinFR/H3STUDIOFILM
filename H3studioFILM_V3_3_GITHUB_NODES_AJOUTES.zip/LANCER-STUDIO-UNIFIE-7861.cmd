@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-H3Studio-UNIFIE-7861.ps1"
if errorlevel 1 (
 echo.
 echo Le Studio unifie n'a pas demarre. Lis le message ci-dessus.
 pause
)
