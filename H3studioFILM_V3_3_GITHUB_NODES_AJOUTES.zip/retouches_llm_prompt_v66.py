"""V10.66 H3 visual-retake prompt writer: reuses FilmMaker's established LLM
loading, chat and unloading functions. H3's original RAW video/latent (not this
text) is the visual reference. This module never runs pip or installs models.
"""
from __future__ import annotations
import os
import re
import shutil
import subprocess
import time
from pathlib import Path

SYSTEM = """You are MiniMax H3's existing-video retake director.
Write a COMPLETE, SINGLE, CONTINUOUS SHOT prompt in natural cinematic ENGLISH, not
an editing checklist and not isolated instructions for an invented scene.
The genuine original footage is the ground truth, including framing, actor
identity, clothing, set, lighting, camera, direction, and environmental action.
Your only historical description is the old shot prompt: it might be incomplete
and may mention a movement that the user is asking you to replace.

STRUCTURE YOUR OUTPUT AS [Shot 1], THEN A COHERENT CINEMATIC DESCRIPTION OF:
A. The unchanged original beginning from 0 seconds up to the EDIT WINDOW start.
   Never invent specific movement you cannot know from the historical prompt.
B. From the edit start: the preparation, momentum and onset of the requested
   gesture or emotional change, with physical contact, body mechanics and gaze.
C. The actual requested action/emotion with clear visual evidence, within the
   specified timing. Keep the original performer, scene, shot and camera.
D. BEFORE the exact edit end, a natural easing/transition/rejoining phase that
   puts the performer at a pose/motion compatible with the unedited original
   footage immediately after the edit. The recovery must fit INSIDE the window.
E. After the window, continue the UNCHANGED original scene through its real end;
   DO NOT write a new ending or replay the modified gesture later.

The five phases form ONE continuous original shot with natural transitions:
NO CUTS, no fades to black, no camera reset or additional actors.
Treat all supplied timestamps as immutable, use their exact three-decimal values,
and explicitly state how the action is rejoined before the edit ends.
If the window is too short to fit both a believable change and recovery, choose
short natural movement rather than inventing an impossible extended gesture.
The edit window is the only time H3 is permitted to replace pixels; the rest
is original footage, not content to regenerate.
Do not invent facts about the original clip not contained in the source prompt.
Output ONLY [Shot 1] and one ready-to-send H3 full-shot description. No metadata,
no markdown, no reasoning, no advice, no fictional second shot."""


def ensure_ollama_running(film, *, timeout=28.0):
    """Use the same `ollama serve` startup method as FilmMaker's PowerShell.

    Does NOT install software, pull a model, change CUDA, or replace Python.
    Leaves the daemon running just like FilmMaker. The specific Gemma model is
    explicitly unloaded by FilmMaker after writing the prompt.
    """
    url = film.rt.OLLAMA_URL + '/api/tags'
    try:
        return film.rt.http_json(url, timeout=3)
    except Exception as exc:
        start_exc = exc
    exe=shutil.which('ollama.exe') or shutil.which('ollama')
    if not exe and os.name=='nt':
        candidates=[Path(os.environ.get('LOCALAPPDATA',''))/'Programs'/'Ollama'/'ollama.exe',
                    Path(os.environ.get('PROGRAMFILES','C:/Program Files'))/'Ollama'/'ollama.exe']
        exe=next((str(p) for p in candidates if p.is_file()),None)
    if not exe:
        raise RuntimeError('Retouches : Ollama est indisponible : ollama.exe introuvable. '
                           'Aucun modèle ni logiciel ne sera installé.') from start_exc
    kwargs={'stdin':subprocess.DEVNULL,'stdout':subprocess.DEVNULL,
            'stderr':subprocess.DEVNULL,'cwd':str(Path(exe).resolve().parent)}
    if os.name=='nt':
        kwargs['creationflags']=getattr(subprocess,'CREATE_NO_WINDOW',0)
    print('[RETOUCHES] Ollama arrêté : lancement automatique de ollama serve...',flush=True)
    try:
        proc=subprocess.Popen([exe,'serve'],**kwargs)
    except OSError as exc:
        raise RuntimeError('Impossible de lancer Ollama automatiquement : '+str(exc)) from exc
    end=time.monotonic()+float(timeout)
    last=None
    while time.monotonic()<end:
        try:
            tags=film.rt.http_json(url,timeout=3)
            print('[RETOUCHES] Ollama prêt, modèle non encore chargé.',flush=True)
            return tags
        except Exception as exc:
            last=exc
        if proc.poll() is not None:
            # It can exit because an existing Ollama instance took the port.
            # Try one more time; never terminate external processes.
            try:return film.rt.http_json(url,timeout=3)
            except Exception:break
        time.sleep(1)
    raise RuntimeError('Ollama ne répond pas après démarrage automatique : '
                       +str(last or 'processus terminé'))


def choose_backend(film):
    """Select ONLY the pre-installed Gemma 4 26B in Ollama (FilmMaker backend).

    Never fallback to Qwen3.8 27B / llama-server; no installation or download.
    Fail closed if Ollama or Gemma 26B is unavailable.
    """
    # The FilmMaker's actual model naming from select_text_backend():
    #   gemma4:26b-a4b-it-q4_K_M
    tags = ensure_ollama_running(film)
    names = film.installed_model_names(tags)
    # Prefer the exact GGUF/quant used by the existing Film Studio; accept
    # alternate 26B tags if a compatible variant is already installed.
    preferred = 'gemma4:26b-a4b-it-q4_k_m'
    model = next((n for n in names if n.casefold() == preferred), None)
    if model is None:
        model = next((n for n in names if n.casefold().startswith('gemma4:26b')), None)
    if not model:
        raise RuntimeError(
            'Retouches : Gemma 4 26B Ollama introuvable. '
            'Modele attendu : gemma4:26b-a4b-it-q4_K_M. '
            'Modeles Ollama presents : ' + (', '.join(names) or '(aucun)') + '. '
            'Qwen 27B interdit pour ce mode, rien ne sera telecharge.'
        )
    backend = film._ollama_backend(model)
    if backend.get('provider') != 'ollama':
        raise RuntimeError('Retouches : backend Ollama attendu, generation annulee.')
    print('[RETOUCHES] Modele de prompt : ' + model + ' | Ollama | PAS de Qwen 27B', flush=True)
    return backend


def build_request(mode,performance_type,request,source_prompt,start,end,duration):
    kind = 'precise scene retake' if mode=='precise' else ('actor action performance' if performance_type=='action' else 'actor emotional performance')
    span=end-start
    # H3 must see a COMPLETE shot, but only the user window may be regenerated.
    # Plan preparation, main beat, recovery and alignment wholly inside the edit.
    prep=start+span*.16
    action_end=start+span*.58
    recovery=start+span*.82
    return (f'TASK: {kind}. FULL ORIGINAL CONTINUOUS SHOT REWRITE, one [Shot 1].\n'
            f'USER REQUEST (MUST VISIBLY OCCUR): {request}\n'
            f'WHOLE ORIGINAL SHOT: 0.000s–{duration:.3f}s.\n'
            f'EXACT EDIT WINDOW: {start:.3f}s–{end:.3f}s. DO NOT change the timing.\n'
            f'EDIT WINDOW: {start:.3f}s to {end:.3f}s, original clip {duration:.3f}s.\n'
            f'SHOT TIMELINE FOR YOUR SINGLE CONTINUOUS H3 PROMPT:\n'
            f'0.000s–{start:.3f}s: ORIGINAL opening, no edited action. Do not hallucinate what is not known.\n'
            f'{start:.3f}s–{prep:.3f}s: MOTIVATED PREPARATION for the request from the initial real pose.\n'
            f'{prep:.3f}s–{action_end:.3f}s: REQUESTED ACTION/EMOTION must be CLEARLY VISIBLE; anatomically plausible.\n'
            f'{action_end:.3f}s–{recovery:.3f}s: follow-through and transition back toward original continuing action.\n'
            f'{recovery:.3f}s–{end:.3f}s: COMPLETE THE REJOIN by the window end; match original pose, camera and motion at the seam.\n'
            f'{end:.3f}s–{duration:.3f}s: ORIGINAL CONTINUATION AND ORIGINAL ENDING, exactly unchanged.\n'
            'Never add a cut, insert a new scene, or continue the edit outside the window. '
            'Do not say "edit this video"; describe the actual continuous shot as a film. '
            'Keep the original sound; no invented dialogue. '
            'Do not claim you have watched the original frames; it is supplied to H3 as the actual source video.\n'
            'HISTORICAL SHOT DESCRIPTION (only use what is grounded here; motions may be superseded):\n'
            + str(source_prompt or '(no historical description supplied)')[:4000])


def assemble(original_request, result, start, end, duration):
    result=str(result or '').strip()
    result=re.sub(r'^```(?:[\w-]+)?\s*|\s*```$','',result).strip()
    if not result or len(result)<80:
        raise RuntimeError('LLM retouches : prompt absent ou trop court ; H3 non lancé')
    if len(result)>9000:
        raise RuntimeError('LLM retouches : prompt trop long ; H3 non lancé')
    if '[Shot 1]' not in result:result='[Shot 1] '+result
    # Timeline authority stays outside the model-generated text. User-facing
    # window and graph mask use precisely the same numbers, without drift.
    return (f'ORIGINAL CONTINUOUS SHOT: 0.000s–{duration:.3f}s.\n'
            f'Only {start:.3f}s–{end:.3f}s is regenerated from original video. '
            f'Existing start 0.000s–{start:.3f}s and continuation {end:.3f}s–{duration:.3f}s remain unchanged.\n'
            f'EXACT REQUEST: {original_request.strip()}\n'
            + result + '\n'
            f'CRITICAL SEAM: complete any transition and rejoin the genuine original action '
            f'BEFORE {end:.3f}s; after that the original video continues unchanged. '
            'One uninterrupted shot, same original person, framing, location and soundtrack.')



def write_prompt(*,mode,performance_type,request,source_prompt,start,end,duration,gpu_prepare):
    if mode!='precise' and (mode!='performance' or performance_type not in ('action','emotion')):
        raise ValueError('Retake LLM réservé aux retouches visuelles, pas au dialogue')
    if not(0<=start<end<=duration+.03):raise ValueError('Intervalle retake invalide')
    import h3film_studio_v3 as film  # reuse *existing* FilmMaker LLM backend
    gpu_prepare()                     # release H3 memory before loading Gemma 4 26B
    backend=choose_backend(film)
    output=None
    try:
        output=film.director_text(backend,SYSTEM,build_request(mode,performance_type,request,source_prompt,start,end,duration),
                                 label='RETOUCH DIRECTOR GEMMA 4 26B / OLLAMA',num_ctx=8192,num_predict=1050)
    finally:
        # H3 must not coexist with Gemma 26B loaded on a 16GB card.
        # FilmMaker owns/knows its own process; never kill external PIDs.
        try:
            film.unload_text_backend(backend,label='Avant retouche H3')
        finally:
            film.release_all_text_models_for_h3(label='Retouches : H3 prend le GPU')
    return assemble(request,output,start,end,duration),'LLM directeur FilmMaker · '+str(backend.get('display') or backend.get('model'))
