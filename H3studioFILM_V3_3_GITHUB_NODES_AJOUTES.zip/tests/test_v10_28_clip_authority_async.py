"""V10.28: real browser proof authority async preview cannot race approval.

No ComfyUI / H3 / Ollama execution. This specifically exercises the UI
sequence that previously displayed 'Synchronisation des références...' forever
until an early Validate click threw in collectClipEdits().
"""
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]


def test_preview_is_awaited_and_preserves_typed_text():
    pytest.importorskip('playwright.sync_api')
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1440,'height':900})
        errors=[]
        page.on('pageerror',lambda err:errors.append(str(err)))
        html=(ROOT/'studio_ui/index.html').read_text(encoding='utf8').replace('<script src="/studio.js"></script>','')
        page.set_content(html)
        page.add_script_tag(content=(ROOT/'studio_ui/studio.js').read_text(encoding='utf8'))
        page.evaluate('''() => {
          const original='REFERENCE AUTHORITY — these Picture inputs are authoritative:\\n<Subject 1> is Nyx.\\n\\n**[Shot 1] 0:00–5.0**\\nNyx turns.';
          clipDraft={id:'clip-r',text:original,originalPrefix:null,previewPrefix:null,
            previewNonce:0,authorityReady:false,initialized:false,bankDeletes:[],bankNames:[],refs:[]};
          document.getElementById('questionArea').innerHTML=`
            <button id="approveReviewTop">Valider</button><button id="approveReview">Valider aussi</button>
            <pre id="clipAuthorityText">Synchronisation des références…</pre>
            <p id="refAuthoritySync">Synchronisation des références…</p>
            <button id="retryClipAuthority" class="hidden">Ressayer</button>
            <textarea id="clipEditText">${original}</textarea><div id="clipEditRefs"></div><div id="clipRefCount"></div>`;
          window.fetch=async (url,options)=>{
            if(url==='/api/reference-preview'){
              await new Promise(resolve=>setTimeout(resolve,250));
              return {ok:true,json:async()=>({text:original,prefix:'REFERENCE AUTHORITY — these Picture inputs are authoritative:\\n<Subject 1> is Nyx.',original_prefix:'REFERENCE AUTHORITY — these Picture inputs are authoritative:\\n<Subject 1> is Nyx.',subjects:[],resolved_names:[]})};
            }
            return {ok:true,json:async()=>({ok:true})};
          };
        }''')
        page.evaluate('''() => {
          window.testingPromise=previewClipAuthority();
          document.getElementById('clipEditText').value+='\\nNew creative detail';
          window.waitForValidation=ensureClipAuthorityReady();
        }''')
        assert page.locator('#approveReviewTop').is_disabled()
        page.evaluate('Promise.all([window.testingPromise,window.waitForValidation])')
        assert page.locator('#approveReviewTop').is_enabled()
        assert page.locator('#approveReview').is_enabled()
        assert page.locator('#clipEditText').input_value().endswith('New creative detail')
        assert 'REFERENCE AUTHORITY' not in page.locator('#clipEditText').input_value()
        assert 'REFERENCE AUTHORITY' in page.locator('#clipAuthorityText').inner_text()
        assert not errors,errors
        browser.close()


def test_preview_error_shows_retry_and_does_not_allow_validation():
    pytest.importorskip('playwright.sync_api')
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1300,'height':760})
        html=(ROOT/'studio_ui/index.html').read_text(encoding='utf8').replace('<script src="/studio.js"></script>','')
        page.set_content(html)
        page.add_script_tag(content=(ROOT/'studio_ui/studio.js').read_text(encoding='utf8'))
        page.evaluate('''() => {
          clipDraft={id:'clip-r',text:'Creative',originalPrefix:null,previewPrefix:null,
            previewNonce:0,authorityReady:false,initialized:false,bankDeletes:[],bankNames:[],refs:[]};
          document.getElementById('questionArea').innerHTML=`
            <button id="approveReviewTop">Valider</button><button id="approveReview">Valider aussi</button>
            <pre id="clipAuthorityText">Synchronisation des références…</pre>
            <p id="refAuthoritySync">Synchronisation des références…</p>
            <button id="retryClipAuthority" class="hidden">Ressayer</button>
            <textarea id="clipEditText">Creative</textarea><div id="clipEditRefs"></div><div id="clipRefCount"></div>`;
          window.fetch=async()=>({ok:false,status:400,json:async()=>({error:'Serveur de références indisponible'})});
        }''')
        page.evaluate('previewClipAuthority().catch(()=>null)')
        assert page.locator('#approveReviewTop').is_disabled()
        assert page.locator('#retryClipAuthority').is_visible()
        assert 'Serveur de références indisponible' in page.locator('#refAuthoritySync').inner_text()
        browser.close()
