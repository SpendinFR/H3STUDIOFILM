"""V10.4 CPU-only regressions: human gate, stop, orphan guard and UI."""
import json, tempfile, threading, time, unittest, urllib.request
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import studio_bridge as bridge
import studio_web as web
import h3_runtime_simple as runtime
from http.server import ThreadingHTTPServer

class StopContract(unittest.TestCase):
    def test_stop_signal_short_circuits_checkpoint(self):
        with tempfile.TemporaryDirectory() as td:
            old=bridge.DIR;bridge.DIR=Path(td)
            try:
                (bridge.DIR/'stop.request').write_text('1')
                with self.assertRaises(bridge.StudioStop):bridge.checkpoint('plans','Plan 1')
                with self.assertRaises(bridge.StudioStop):bridge.pause_boundary()
            finally:bridge.DIR=old

    def test_gpu_timeout_excludes_human_raw_review(self):
        class EndNow(BaseException):pass
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);waiting=root/'clip_0002.waiting.json';waiting.write_text('{}')
            begun=time.monotonic()
            with patch.object(runtime,'http_json',return_value={}), \
                 patch.object(runtime,'_prompt_is_still_queued',return_value=True):
                def done():
                    if time.monotonic()-begun>=2.1:raise EndNow()
                with self.assertRaises(EndNow):
                    runtime.wait_for_disk_video('fake-id',root,'VISIBLE',time.time(),
                        max_seconds=1,review_wait_path=waiting,abort_check=done)

    def test_old_worker_guard(self):
        with tempfile.TemporaryDirectory() as td:
            folder=Path(td);(folder/'run.json').write_text('{"pid":54321,"running":true}')
            with patch.object(web,'sessions_for_resume',return_value=[folder]), \
                 patch.object(web,'process_alive',return_value=True):
                found=web.older_running_productions()
                self.assertEqual(found[0]['pid'],54321)
                with self.assertRaisesRegex(ValueError,'54321'):
                    web.start_film({'prompt':'test','duration':'1m'})

    def test_stop_endpoint_raises_signal_and_requests_global_emergency_cleanup(self):
        class Running:
            def poll(self):return None
        with tempfile.TemporaryDirectory() as td:
            session=Path(td);(session/'active_prompt.json').write_text('{}')
            with web.LOCK:
                old=dict(web.STATE)
                web.STATE.update(session=session,proc=Running(),started=time.time())
            srv=ThreadingHTTPServer(('127.0.0.1',0),web.Handler)
            worker=threading.Thread(target=srv.serve_forever,daemon=True);worker.start()
            try:
                with patch.object(web,'emergency_stop_all',return_value=[]) as cleanup:
                    url=f'http://127.0.0.1:{srv.server_port}/api/stop'
                    req=urllib.request.Request(url,data=b'{}',headers={'Content-Type':'application/json'},method='POST')
                    with urllib.request.urlopen(req,timeout=5) as reply:
                        self.assertTrue(json.load(reply)['ok'])
                    cleanup.assert_called_once_with()
                self.assertTrue((session/'stop.request').exists())
            finally:
                srv.shutdown();srv.server_close();worker.join(3)
                with web.LOCK:web.STATE.clear();web.STATE.update(old)

    def test_sidebar_closed_and_stop_visible(self):
        root=Path(__file__).resolve().parents[1]/'studio_ui'
        html=(root/'index.html').read_text('utf-8')
        js=(root/'studio.js').read_text('utf-8')
        self.assertIn('class="topProductionControls"',html)
        self.assertIn('id="projectsMenuBtn"',html)
        self.assertIn('id="stopRenderBtn"',html)
        self.assertIn("setProjectsMenu(false)",js)
        self.assertIn("'/api/stop'",js)

if __name__=='__main__':unittest.main()
