import pathlib, sys, unittest
from unittest import mock
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_engine as re

class V1038(unittest.TestCase):
    def tearDown(self):
        with re.LOCK:
            re.RUNNING.clear()
    def test_remove_person_can_start_without_reference(self):
        payload={'mode':'remove_person','source':{'type':'upload','id':'0'*32},'target':'woman','instructions':'x'}
        with mock.patch.object(re.threading,'Thread') as T:
            T.return_value.start=lambda:None
            result=re.start(payload,payload['source'],lambda s: pathlib.Path('video.mp4'),lambda: pathlib.Path('.'),None)
        self.assertEqual(result['status'],'queued')
    def test_math_repair_never_fabricates_missing_a(self):
        info={'ComfyMathExpression':{'input':{'required':{'expression':['STRING',{'default':''}],'a':['FLOAT',{'default':0}]},'optional':{}}}}
        graph={'1':{'class_type':'ComfyMathExpression','inputs':{'expression':'round(a*24)'}}}
        re._repair_math_inputs(graph,info)
        self.assertNotIn('a',graph['1']['inputs'])

if __name__=='__main__':
    unittest.main()
