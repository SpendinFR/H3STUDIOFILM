"""Regression tests on the exact ComfyUI autogrow naming and isolated retouches."""
from pathlib import Path
import sys, tempfile, unittest
from unittest import mock
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_engine as re
from retouches_workflow_compat import flatten_to_api


def spec(**kwargs):
    return {'input':{'required':kwargs,'optional':{}}}

class V39GraphContracts(unittest.TestCase):
    def test_dynamic_values_a_exact_author_socket_name(self):
        ui={'nodes':[
          {'id':132,'type':'PrimitiveFloat','widgets_values_named':{'value':5},'inputs':[]},
          {'id':131,'type':'ComfyMathExpression','widgets_values_named':{'expression':'round(a*24)'},'inputs':[{'name':'values.a','link':261}]},
          {'id':92,'type':'SaveVideo','widgets_values_named':{'filename_prefix':'video/final'},'inputs':[{'name':'video','link':262}]},
        ],'links':[[261,132,0,131,0,'FLOAT'],[262,131,0,92,0,'VIDEO']]}
        info={'PrimitiveFloat':spec(value=['FLOAT',{'default':5}]),'ComfyMathExpression':spec(expression=['STRING',{}],values=['AUTOGROW',{}]),'SaveVideo':spec(video=['VIDEO'],filename_prefix=['STRING',{}])}
        graph=re.convert_graph(ui,info)
        self.assertEqual(graph['131']['inputs']['values.a'],['132',0])
        self.assertNotIn('a',graph['131']['inputs'])
        re._repair_math_inputs(graph,info)
        self.assertEqual(graph['131']['inputs']['values.a'],['132',0])

    def test_dynamic_ref_images_input_survives_ui_conversion(self):
        ui={'nodes':[
          {'id':1,'type':'LoadImage','widgets_values_named':{'image':'actor.png'},'inputs':[]},
          {'id':2,'type':'MiniMaxH3ReferenceToVideo','widgets_values_named':{'prompt':'<Picture 1>'},'inputs':[{'name':'ref_images.ref_image_0','link':10}]},
          {'id':3,'type':'SaveVideo','widgets_values_named':{'filename_prefix':'final'},'inputs':[{'name':'video','link':11}]}
        ],'links':[[10,1,0,2,0,'IMAGE'],[11,2,0,3,0,'VIDEO']]}
        info={'LoadImage':spec(image=['STRING',{}]),'MiniMaxH3ReferenceToVideo':spec(prompt=['STRING',{}],ref_images=['AUTOGROW',{}]),'SaveVideo':spec(video=['VIDEO'],filename_prefix=['STRING',{}])}
        graph=re.convert_graph(ui,info)
        self.assertEqual(graph['2']['inputs']['ref_images.ref_image_0'],['1',0])

    def test_crossview_subgraph_scalar_default_preserved(self):
        ui={'nodes':[
          {'id':1,'type':'demo-subgraph','widgets_values_named':{'angle':15.0},'inputs':[{'name':'angle','link':None}]},
          {'id':2,'type':'SaveVideo','widgets_values_named':{'filename_prefix':'final'},'inputs':[{'name':'video','link':200}]}
        ],'links':[[200,1,0,2,0,'VIDEO']],
        'definitions':{'subgraphs':[{'id':'demo-subgraph','inputs':[{'name':'angle','type':'FLOAT','default':0}],
              'nodes':[], 'links':[{'id':21,'origin_id':-10,'origin_slot':0,'target_id':-20,'target_slot':0}],
              'outputs':[{'name':'video','linkIds':[21]}]}]}}
        info={'SaveVideo':spec(video=['VIDEO'],filename_prefix=['STRING',{}]),'PrimitiveFloat':spec(value=['FLOAT',{}])}
        graph=flatten_to_api(ui,info,re._widget_inputs)
        self.assertEqual(graph['1_default_0']['inputs']['value'],15.0)
        self.assertEqual(graph['2']['inputs']['video'],['1_default_0',0])

    def test_ui_progress_and_result_player(self):
        html=(ROOT/'studio_ui/index.html').read_text(encoding='utf-8')
        js=(ROOT/'studio_ui/studio-retouches.js').read_text(encoding='utf-8')
        self.assertIn('retActiveJob',html)
        self.assertIn('retouchResultBox',js)
        self.assertIn('jobFingerprint',js)

if __name__=='__main__':unittest.main()
