"""Real Chromium/browser checks against Studio V10.9 assets served by studio_web."""
from pathlib import Path
import urllib.request
from http.server import ThreadingHTTPServer
from threading import Thread
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import studio_web as web
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]

def test_server_css():
    server=ThreadingHTTPServer(('127.0.0.1',0), web.Handler)
    th=Thread(target=server.serve_forever, daemon=True)
    th.start()
    try:
        with urllib.request.urlopen(f'http://127.0.0.1:{server.server_port}/studio-v10-9.css') as r:
            assert r.status==200
            assert 'text/css' in r.headers.get('Content-Type','')
            assert '.workspace.hidden' in r.read().decode()
    finally:
        server.shutdown();server.server_close();th.join(3)


def test_browser():
    errors=[]
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1536,'height':900})
        page.on('pageerror',lambda err:errors.append(str(err)))
        # Avoid depending on a user's actual ComfyUI installation or running generation.
        # Chromium sandbox denies loopback browsing; use the exact served HTML/CSS/JS bytes
        # as a document to exercise browser layout and event handlers. HTTP is tested above.
        html=(ROOT/'studio_ui'/'index.html').read_text()
        html=html.replace('<script src="/studio.js"></script>','')
        page.set_content(html)
        for sheet in ('studio.css','studio-v10-2.css','studio-v10-3.css','studio-v10-4.css','studio-v10-5.css','studio-v10-6.css','studio-v10-7.css','studio-v10-8.css','studio-v10-9.css'):
            page.add_style_tag(content=(ROOT/'studio_ui'/sheet).read_text())
        page.add_script_tag(content=(ROOT/'studio_ui'/'studio.js').read_text())
        for name,panel in [('Scénario','story'),('Références','library'),('Journal','activity'),('Direction','workspace')]:
            page.get_by_role('button',name=name,exact=True).first.click()
            assert page.locator('#'+panel).evaluate("el=>getComputedStyle(el).display")!='none',name
            for other in ('workspace','story','library','activity'):
                if other!=panel: assert page.locator('#'+other).evaluate("el=>getComputedStyle(el).display")=='none',(name,other)
        # Journal real-time: preserve user's chosen event as new entries arrive.
        result=page.evaluate('''() => {
          const events=Array.from({length:34},(_,i)=>({at:1700000034-i,title:'Event '+(34-i),detail:'lorem ipsum dolor sit amet '.repeat(4)}));
          historyPanel({history:events.slice().reverse()},'test');
          let pane=document.querySelector('#historyStream');pane.scrollTop=450;
          const oldScroll=pane.scrollTop;
          const target=[...pane.querySelectorAll('.historyEntry')].find(e=>e.getBoundingClientRect().bottom>pane.getBoundingClientRect().top+5);
          const key=target.dataset.eventKey, y=target.getBoundingClientRect().top;
          const extra={at:1700000035,title:'Newest event',detail:'updated'};
          historyPanel({history:[...events.slice().reverse(),extra]},'test');
          const match=[...pane.querySelectorAll('.historyEntry')].find(e=>e.dataset.eventKey===key);
          return {dy:match.getBoundingClientRect().top-y,before:oldScroll,after:pane.scrollTop,entries:pane.children.length};
        }''')
        assert abs(result['dy'])<3,result
        assert result['after']>result['before'],result
        # New V10.10 UX: fixed reference order; pencil opens the name and semantic role.
        refs=page.evaluate('''() => {
           clipDraft={id:'test',text:'H3 prompt',originalPrefix:'',previewPrefix:'',refs:[
             {media:'image',index:0,name:'Matt',subjectKey:'matt',kind:'character',role:'canonical_identity',visualType:'person'},
             {media:'image',index:1,name:'Nyx',subjectKey:'nyx',kind:'character',role:'film_appearance',visualType:'person'},
             {media:'audio',index:0,name:'Matt',kind:'voice'}
           ]};
           document.getElementById('questionArea').innerHTML='<div id="clipRefCount"></div><div id="clipEditRefs"></div><textarea id="clipEditText">H3 prompt</textarea>';
           renderClipRefEditor();
           const noArrows=document.querySelectorAll('.refMove').length===0;
           document.querySelector('.refPencil[data-ri="1"]').click();
           const canEdit=!!document.querySelector('.refNameInput');
           return {noArrows,canEdit,order:clipDraft.refs.map(x=>x.name)};
        }''')
        assert refs['noArrows'] and refs['canEdit'],refs
        assert refs['order']==['Matt','Nyx','Matt'],refs
        assert not errors,errors
        browser.close()

if __name__=='__main__':
 test_server_css();test_browser();print('BROWSER V10.9 OK tabs journal ref-order no javascript errors')
