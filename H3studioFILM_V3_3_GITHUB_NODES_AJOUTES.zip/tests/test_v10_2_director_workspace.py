"""V10.2: structured reviews / UI contracts / non-destructive history."""
from pathlib import Path
from unittest.mock import patch
import tempfile, threading, json, time, os
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import studio_bridge as studio
import studio_web as web


def await_json(path, timeout=2):
    stop=time.monotonic()+timeout
    while time.monotonic()<stop:
        if path.is_file():
            try:return json.loads(path.read_text('utf-8'))
            except (OSError,ValueError):pass
        time.sleep(.01)
    raise AssertionError(f'missing {path}')


def test_content_review_supports_validate_modify_redo_without_console():
    old=studio.DIR
    try:
        with tempfile.TemporaryDirectory() as tmp:
            studio.DIR=Path(tmp)/'session';studio.DIR.mkdir();(studio.DIR/'answers').mkdir()
            studio._write('config.json',{'reviews':{'content':True},'auto_answers':False})
            for action in ('continue','revise','redo'):
                result=[]
                th=threading.Thread(target=lambda:result.append(studio.checkpoint('content','Proposition du Content Director',{'text':'### PITCH\nMon film.','content':{'parts':[]}},allow_revise=True)))
                th.start()
                q=await_json(studio.DIR/'review.json')
                assert q['kind']=='content'
                assert q['allow_redo'] is True
                assert q['payload']['text'].startswith('### PITCH')
                studio._write('answers/'+q['id']+'.json',{'action':action,'feedback':'Plus de dialogues' if action=='revise' else ''})
                th.join(3);assert not th.is_alive()
                assert result[0]['action']==action
                journal=studio._get('history.json',[])
                assert any(e.get('action')==action for e in journal)
    finally:
        studio.DIR=old


def test_structured_reference_choices_transfer_without_powershell():
    old=studio.DIR
    try:
        with tempfile.TemporaryDirectory() as tmp:
            studio.DIR=Path(tmp);(studio.DIR/'answers').mkdir()
            studio._write('config.json',{'initial_answers':[], 'reviews':{}})
            result=[]
            def runner():result.append(studio.ask_input('> ',context={'title':'Personnage Nyx','description':'Référence Krea','options':[{'label':'Créer avec Krea','value':'c'}]}))
            th=threading.Thread(target=runner);th.start()
            q=await_json(studio.DIR/'question.json')
            assert q['context']['title']=='Personnage Nyx'
            assert q['context']['options'][0]['value']=='c'
            studio._write('answers/'+q['id']+'.json',{'value':'c'})
            th.join(3);assert result==['c']
    finally:studio.DIR=old


def test_studio_default_enables_content_review_auto_does_not():
    old=web.SESSIONS
    try:
        with tempfile.TemporaryDirectory() as tmp:
            web.SESSIONS=Path(tmp)
            with patch.object(web,'_launch_session',side_effect=lambda folder,prompt,**kw:{'folder':str(folder)}):
                s=web.start_film({'prompt':'Un récit','duration':'1m','mode':'studio'})
                a=web.json_get(Path(s['folder'])/'config.json',{})
                assert a['reviews']['content'] is True
                s=web.start_film({'prompt':'Un récit','duration':'1m','mode':'auto'})
                b=web.json_get(Path(s['folder'])/'config.json',{})
                assert b['reviews']['content'] is False
    finally:web.SESSIONS=old


def test_page_features_and_bridge_boundary_not_modified():
    root=Path(__file__).resolve().parents[1]
    html=(root/'studio_ui'/'index.html').read_text('utf-8')
    js=(root/'studio_ui'/'studio.js').read_text('utf-8')
    py=(root/'h3film_studio_v3.py').read_text('utf-8')
    assert html.index('id="directorDesk"')<html.index('id="liveDirector"')
    assert html.index('id="questionArea"')<html.index('id="liveDirector"')
    assert 'studio-v10-2.css' in html
    assert 'id="historyStream"' in html
    # Newer director workspace uses a separate technical-journal page, not the old short console.
    assert 'id="fullLog"' in html
    assert 'id="activity"' in html
    for term in ['redoProposal','showReviewEdit','richText','historyPanel','decisionOption','decisionPrimary']:
        assert term in js
    assert "studio.checkpoint('content'" in py
    assert "studio_ui_choice(" in py
    assert (root/'custom_nodes'/'H3RawLatentPersist'/'__init__.py').is_file()


def test_archive_retrieves_actual_validated_proposal_and_project_history():
    with tempfile.TemporaryDirectory() as tmp:
        fake=Path(tmp)
        target=fake/'output'/'H3FilmSimple'/'projectA'
        (target/'preproduction').mkdir(parents=True)
        (target/'_studio').mkdir()
        (target/'preproduction'/'review_00.txt').write_text('### PITCH\nActe original avec Nyx',encoding='utf-8')
        web.write_json(target/'_studio'/'history.json',[{'title':'Content Director','action':'continue'}])
        with patch.object(web,'comfy_path',return_value=fake):
            project=web.project_data('projectA')
        assert len(project['proposal_history'])==1
        assert 'Acte original' in project['proposal_history'][0]['text']
        assert project['history'][0]['action']=='continue'


def test_stylesheet_still_available_through_http_handler():
    from urllib.request import urlopen
    server=web.ThreadingHTTPServer(('127.0.0.1',0),web.Handler)
    th=threading.Thread(target=server.serve_forever,daemon=True);th.start()
    try:
        with urlopen(f'http://127.0.0.1:{server.server_address[1]}/studio-v10-2.css',timeout=3) as f:
            result=f.read().decode('utf-8')
            assert f.status==200
            assert '.directorDesk' in result
    finally:
        server.shutdown();server.server_close()
