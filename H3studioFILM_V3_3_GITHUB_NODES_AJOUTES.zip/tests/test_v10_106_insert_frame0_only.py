"""V10.106 - video-only first-visible-frame patch; all model paths unchanged."""
from pathlib import Path
import sys
import hashlib
import shutil
import subprocess

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import retouches_insert_preroll_v101 as lead


def test_v105_model_and_retake_files_byte_identical():
    baseline=Path('/mnt/data/H3Film_STUDIO_V10_105_INSERT_BRANCHEMENTS_REELS_VERIFIES.zip')
    if not baseline.exists():
        pytest.skip('V10.105 archive not present')
    import zipfile
    root=Path(__file__).resolve().parents[1]
    changed={'retouches_insert_preroll_v101.py', 'LANCER-RETOUCHES-V10_106.cmd',
             'LIRE-V10_106.txt', 'tests/test_v10_106_insert_frame0_only.py',
             'tests/test_v10_101_insert_preroll.py', 'tests/test_v10_105_actual_insert_routing.py'}
    with zipfile.ZipFile(baseline) as z:
        files=[n for n in z.namelist() if not n.endswith('/')]
        for name in files:
            if name not in changed and not name.startswith('__pycache__/'):
                local=root/name
                if not local.exists():
                    # old zip may include cached Python objects that are irrelevant
                    if '/__pycache__/' in name or '/.pytest_cache/' in name or name.startswith('.pytest_cache/'):
                        continue
                    raise AssertionError(f'Missing original file: {name}')
                assert hashlib.sha256(local.read_bytes()).digest()==hashlib.sha256(z.read(name)).digest(),name


def _raw_first_frames(path, num=3):
    """Decode as RGB to compare actual visible frames, not metadata."""
    proc=subprocess.run(['ffmpeg','-v','error','-i',str(path),'-frames:v',str(num),
                         '-f','rawvideo','-pix_fmt','rgb24','-'],
                        capture_output=True,check=True,timeout=45)
    size=128*96*3
    assert len(proc.stdout)==num*size
    return [proc.stdout[i*size:(i+1)*size] for i in range(num)]


def test_final_frame0_is_frame1_and_audio_duration_retained(tmp_path):
    if not (shutil.which('ffmpeg') and shutil.which('ffprobe')):
        pytest.skip('Requires ffmpeg and ffprobe')
    comfy=tmp_path/'ComfyUI'; comfy.mkdir()
    # 141 H3 frames. A bright Krea-like patch occurs only on the first visible
    # frame (index 17) and must be skipped without affecting frame 18 onward.
    simulated=tmp_path/'generated.mp4'
    subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
                    'testsrc2=size=128x96:rate=24:duration=5.875',
                    '-vf',"drawbox=x=0:y=0:w=96:h=96:color=white:t=fill:enable='eq(n,17)'",
                    '-frames:v','141','-c:v','libx264','-crf','14',str(simulated)],
                   check=True,timeout=45)
    source=tmp_path/'original.mp4'
    subprocess.run(['ffmpeg','-v','error','-y','-f','lavfi','-i',
                    'testsrc2=size=128x96:rate=24:duration=5.166667',
                    '-f','lavfi','-i','sine=frequency=660:sample_rate=44100:duration=5.166667',
                    '-frames:v','124','-c:v','libx264','-c:a','aac','-shortest',str(source)],
                   check=True,timeout=45)
    dest=tmp_path/'final.mp4'
    lead.strip_warmup(simulated,source,dest,124,comfy)
    assert lead.frame_count(dest,comfy)==124
    first,second,third=_raw_first_frames(dest)
    import numpy as np
    diff=np.abs(np.frombuffer(first,dtype='uint8').astype('int16')-
                np.frombuffer(second,dtype='uint8').astype('int16'))
    assert diff.mean()<2.0, f'First two decoded frames differ: {diff.mean()}'
    # The final video begins with image 18, not with the Krea-contaminated 17.
    original_frames=_raw_first_frames(simulated,19)
    assert first!=original_frames[17]
    assert first!=third  # rest of animation was NOT frozen
    audio=subprocess.run(['ffprobe','-v','error','-select_streams','a:0',
                          '-show_entries','stream=index','-of','csv=p=0',str(dest)],
                         capture_output=True,text=True,check=True,timeout=30)
    assert audio.stdout.strip()

