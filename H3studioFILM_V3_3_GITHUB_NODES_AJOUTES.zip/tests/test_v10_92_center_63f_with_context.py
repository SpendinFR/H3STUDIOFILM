"""V10.94: V83 63f semantic prompt; 10+10f H3 technical margins."""
from pathlib import Path
from unittest.mock import patch
import hashlib, subprocess, tempfile, unittest
import torch
import retouches_precise_center_v90 as center
import retouches_precise_half_v82 as half
import retouches_llm_prompt_half_v82 as gemma

BASE=Path(__file__).resolve().parents[1]


def authored(w):
    text={
        'TRANSITION AVANT': 'Elle conserve naturellement son regard vers son écran.',
        'ACTION': 'Elle lève brusquement la main droite devant sa tête, puis la redescend.',
        'TRANSITION APRÈS': 'Elle termine son geste et se tourne lentement face caméra.',
    }
    shots='\n'.join(f'[Shot {n}] {a:.3f}–{b:.3f}s {text[role]}' for n,(role,a,b) in enumerate(gemma._grid(w),1))
    return gemma._assemble('La streameuse est assise devant son écran.',shots,w)

class PlanAndPrompt(unittest.TestCase):
    def test_original_modules_are_untouched(self):
        known={
            'retouches_llm_prompt_half_v82.py':'c028265a4e005b1d4215a1041be419f0107320de728ffa1977d7e41fe910ee30',
            'retouches_precise_half_v82.py':'543792e521ac872dd37cce069e51fad67a4492b240cfe82045942064dd24c36f',
            'retouches_preroll_prompt_v88.py':'2dc56bf5aa42d7d96c321758d90e42c19ed19590e9de1b822fb30c730505fbf7',
        }
        for name,sha in known.items():
            self.assertEqual(hashlib.sha256((BASE/name).read_bytes()).hexdigest(),sha)

    def test_simple_cases_unchanged(self):
        first=half.select_window(37,124,0,1.5)
        last=half.select_window(37,124,3.5,4.5)
        self.assertEqual(half.render_window_with_preroll(first,37,124)['frames'],63)
        self.assertEqual(half.render_window_with_preroll(last,37,124)['frames'],73)

    def test_middle_is_63_with_10_10_padding_and_correct_times(self):
        for a,b in ((2.,3.),(2.4,2.8),(1.9,3.3)):
            with self.subTest(selection=(a,b)):
                core,render=center.select_window(37,124,a,b)
                self.assertEqual((core['frames'],render['frames']),(63,83))
                self.assertEqual((render['latent_t'],render['preroll_frames'],render['postroll_frames']),(25,10,10))
                self.assertEqual(render['origin_frame']+10,core['origin_frame'])
                self.assertEqual(core['end_frame']+10,render['end_frame'])
                self.assertEqual(render['first_frame'],core['first_frame'])
                self.assertEqual(render['last_frame'],core['last_frame'])
                self.assertAlmostEqual(render['start'],(round(a*24)-render['origin_frame'])/24)
                self.assertAlmostEqual(render['end'],(round(b*24)-render['origin_frame'])/24)
                # Actual H3 prompt is DIRECT output of the V83 author on the
                # exact 63f H3/reference window: no adapters or extra shots.
                out=authored(core)
                self.assertIn('LOCAL TAKE: exactly 2.625s',out)
                self.assertEqual(out.count('Elle lève brusquement'),1)
                self.assertIn('Action assigned within the local take at ',out)
                self.assertNotIn('TRANSITION AVANT',out)
                self.assertNotIn('TRANSITION APRÈS',out)
                self.assertEqual(round(render['global_offset']*24)+round(render['start']*24),round(a*24))
                self.assertEqual(round(render['global_offset']*24)+round(render['end']*24),round(b*24))

    def test_too_long_fails_without_silent_clip(self):
        with self.assertRaisesRegex(ValueError,'plage trop longue|impossible de cadrer'):
            center.select_window(37,124,1.0,3.5)

    def test_full_raw_source_unchanged(self):
        core,render=center.select_window(37,124,2,3)
        members=[{'tensor':torch.arange(37,dtype=torch.float32).view(1,1,37,1,1),'device':'cpu'},
                 {'tensor':torch.arange(400,dtype=torch.float32).view(1,1,1,400),'device':'cpu'}]
        latent={'samples':{'members':members},'noise_mask':None}
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'source.pt';torch.save(latent,p)
            before=hashlib.sha256(p.read_bytes()).digest()
            clone=half.write_window(latent,p,'central_25_tokens',render)
            loaded=torch.load(clone,weights_only=True)['samples']['members'][0]['tensor']
            self.assertEqual(loaded.shape[2],25)
            self.assertEqual(int(loaded[0,0,0,0,0].item()),render['start_latent'])
            self.assertEqual(hashlib.sha256(p.read_bytes()).digest(),before)

class RealVideo(unittest.TestCase):
    def make(self,path,frames,src='testsrc2=size=96x64:rate=24',audio=False):
        cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi','-i',src]
        if audio:cmd+=['-f','lavfi','-i','sine=frequency=440:sample_rate=44100']
        cmd+=['-frames:v',str(frames),'-c:v','libx264','-pix_fmt','yuv420p']
        if audio:cmd+=['-c:a','aac','-shortest']
        cmd.append(str(path))
        run=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
        self.assertEqual(run.returncode,0,run.stderr)

    def test_v88_blend_both_sides_real_ffmpeg(self):
        core,render=center.select_window(37,124,2,3)
        with tempfile.TemporaryDirectory() as td:
            p=Path(td);source=p/'original.mp4';generated=p/'h3_83.mp4';target=p/'final.mp4'
            self.make(source,124,audio=True)
            self.make(generated,83,'color=c=white:size=96x64:rate=24')
            center.stitch(source,generated,target,core,render,124,p)
            self.assertEqual(half._frame_count(target,p),124)
            proc=subprocess.run(['ffprobe','-v','error','-select_streams','a:0','-show_entries','stream=codec_type','-of','csv=p=0',str(target)],capture_output=True,text=True)
            self.assertEqual(proc.stdout.strip(),'audio')

    def test_pipeline_dispatch_uses_v83_format_central_writer_and_h3_63(self):
        import retouches_next as engine
        core,render=center.select_window(37,124,2,3)
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);comfy=d/'ComfyUI';(comfy/'input').mkdir(parents=True)
            source=d/'src.mp4';gen=d/'raw.mp4';raw=d/'clip_0001_RAW_LATENT.pt'
            self.make(source,124)
            self.make(gen,83,'color=c=white:size=96x64:rate=24')
            tensor={'samples':{'members':[{'tensor':torch.zeros(1,1,37,1,1),'device':'cpu'},
                                          {'tensor':torch.zeros(1,1,1,400),'device':'cpu'}]},'noise_mask':None}
            torch.save(tensor,raw)
            ident='a'*32
            captured=[]
            def graph_mock(info,mode,project,clip,source,ident,settings,instruction,rect,**kw):
                captured.append((settings,kw,half._frame_count(comfy/'input'/kw['conditioning_video_name'],comfy)))
                return {'902':{'class_type':'H3RetouchMaskV58','inputs':{}},
                        '159':{'class_type':'H3StudioImageToVideo','inputs':{'ref_video_files':kw['conditioning_video_name']}}}
            def api(uri,payload=None,timeout=None):
                if uri=='/object_info':return {key:{} for key in engine.REQUIRED}
                if uri=='/prompt':return {'prompt_id':'test92'}
                if uri=='/history/test92':return {'test92':{'status':{'status_str':'success'},'outputs':{'191':{}}}}
                raise AssertionError(uri)
            with patch.object(engine,'ROOT',d/'jobs'),patch.object(engine,'JOBS',d/'jobs'/'jobs'), \
                 patch.object(engine,'RESULTS',d/'jobs'/'results'), \
                 patch.object(engine,'_project',return_value=(source,raw)), \
                 patch.object(engine,'_metadata',return_value={'fps':24,'duration':124/24,'frames':124,'width':96,'height':64}), \
                 patch.object(engine,'_authoring_context',return_value=('[Shot 1] 0–5.167s source',[],[])), \
                 patch.object(engine,'build_graph',side_effect=graph_mock), \
                 patch.object(engine.legacy,'comfy_json',side_effect=api), \
                 patch.object(engine,'_history_output',return_value=gen), \
                 patch.object(engine,'_measured_visual_change',return_value=30.0), \
                 patch.object(engine.rt,'query_gpu_vram',return_value=None), \
                 patch('retouches_llm_prompt_center_v93.write_prompt',return_value=(authored(core),'V83 grammar, central instructions')) as gemma_writer, \
                 patch.object(engine.time,'sleep'):
                engine._save({'id':ident,'project':'demo','clip':'1','mode':'precise',
                             'instruction':'Elle lève la main droite','performance_type':'action',
                             'selected':True,'start':2.0,'end':3.0,'test_clip':False,'region':None})
                engine._run(ident,lambda project:d,lambda:comfy)
                state=engine.job(ident)
                self.assertEqual(state['status'],'complete',state.get('error'))
                self.assertEqual(len(captured),1)
                self.assertEqual(gemma_writer.call_args.kwargs['window'],core)
                settings,kw,ref_frames=captured[0]
                self.assertEqual(settings['frames'],83)
                self.assertEqual(settings['duration'],83/24)
                self.assertIn('exactly 3.458s',kw['revised_prompt'])
                self.assertEqual(kw['revised_prompt'],center.prepare_prompt(authored(core),core,render))
                self.assertIn('Action assigned within the local take at 1.292–2.292s',kw['revised_prompt'])
                self.assertEqual(settings['start'],render['start'])
                self.assertEqual(settings['end'],render['end'])
                self.assertEqual(ref_frames,83)
                self.assertEqual(half._frame_count(d/'jobs'/'results'/(ident+'.mp4'),comfy),124)
                self.assertFalse((raw.parent/(kw['latent_name']+'.pt')).exists())

if __name__=='__main__':unittest.main()
