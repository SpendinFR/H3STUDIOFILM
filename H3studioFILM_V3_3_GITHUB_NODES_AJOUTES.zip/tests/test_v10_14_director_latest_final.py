"""V10.14: careful manual-director edits + newest cumulative FINAL UI."""
import json
from pathlib import Path
import pytest
import studio_web as web
import h3film_studio_v3 as film

ROOT=Path(__file__).resolve().parents[1]


def content_fixture():
    return {
        'title':'Un film','concept':'Le monde','duration_text':'00:30',
        'parts':[{'part':1,'kind':'ACTE','name':'Acte I','start':'00:00','end':'00:30',
                  'start_seconds':0,'end_seconds':30,'duration_seconds':30,
                  'function':'Situation','development':'Des personnages'}]
    }


def test_direct_edit_content_adds_act_and_opt_in_scene_counts():
    content=content_fixture()
    original=json.loads(json.dumps(content))
    edited=film._studio_content_payload(content)
    edited['parts']=[
      {'kind':'ACTE','name':'Acte I','start':'00:00','end':'00:15','scene_count':2,'development':'Mise en place'},
      {'kind':'ACTE','name':'Acte II','start':'00:15','end':'00:30','scene_count':1,'development':'Résolution'},
    ]
    review={'kind':'content','payload':{'content':content}}
    assert web.validate_director_text_edit(review,json.dumps(edited,ensure_ascii=False)) == {'parts':2}
    parsed=film._parse_studio_content_json_revision(json.dumps(edited),content,30,'','', '')
    assert [p['scene_count'] for p in parsed['parts']]==[2,1]
    assert [p['start_seconds'] for p in parsed['parts']]==[0,15]
    # The original is not mutated by editing/validation.
    assert content==original
    edited['parts'][1]['start']='00:20' # a 5s gap is a genuine blocking error
    with pytest.raises(ValueError,match='frontières|intervalle|JSON'):
        web.validate_director_text_edit(review,json.dumps(edited))


def test_content_default_scene_count_is_not_imposed():
    content=content_fixture()
    edited=film._studio_content_payload(content)
    result=film._parse_studio_content_json_revision(json.dumps(edited),content,30,'','','')
    assert len(result['parts'])==1 and 'scene_count' not in result['parts'][0]


def test_invalid_content_edit_has_actionable_feedback_and_never_autocorrects():
    review={'kind':'content','payload':{'content':content_fixture()}}
    with pytest.raises(ValueError,match='JSON|virgules'):
        web.validate_director_text_edit(review,'{"parts": [}')
    with pytest.raises(ValueError,match='parts'):
        web.validate_director_text_edit(review,'{"title":"one"}')


def test_scene_edit_count_inherits_explicit_restriction():
    part={'part':1,'kind':'ACTE','name':'Acte I','start':'00:00','end':'00:15',
          'start_seconds':0,'end_seconds':15,'duration_seconds':15,'scene_count':2}
    original='SCÈNE 1 — 00:00 → 00:15\nLieu: salon\nDescription: le chat saute.'
    existing=film.parse_scene_output(original,part,1)
    review={'kind':'scenes','payload':{'part':part,'scenes':existing}}
    with pytest.raises(ValueError,match='scene_count=2'):
        web.validate_director_text_edit(review,original)
    edited='SCÈNE 1 — 00:00 → 00:05\nLieu: salon\nDescription: le chat saute.\n\nSCÈNE 2 — 00:05 → 00:15\nLieu: salon\nDescription: il court.'
    assert web.validate_director_text_edit(review,edited)=={'scenes':2}


def test_plan_edit_preserves_duration_and_warns_clearly():
    scene={'scene':1,'duration_seconds':15,'start_seconds':0,'end_seconds':15}
    one='PLAN 1\nSHOT 1 0–5\nVue: large\nAction: le chat arrive.'
    review={'kind':'plans','payload':{'scene':scene}}
    with pytest.raises(ValueError,match='3 plans de 5s'):
        web.validate_director_text_edit(review,one)
    three='\n\n'.join(f'PLAN {i}\nSHOT 1 0–5\nVue: large\nAction: mouvement {i}.' for i in range(1,4))
    assert web.validate_director_text_edit(review,three)=={'plans':3}


def test_project_api_exposes_last_cumulative_final_without_dropping_clips(tmp_path,monkeypatch):
    p=tmp_path/'film';(p/'_studio').mkdir(parents=True)
    clips={'0001':{'video':'hd1.mp4','final':'join1.mp4','refs':[],'voices':[],'raw':'raw1.mp4'},
           '0002':{'video':'hd2.mp4','final':'join2.mp4','refs':[],'voices':[],'raw':'raw2.mp4'}}
    (p/'_studio'/'clips.json').write_text(json.dumps({'clips':clips}),encoding='utf-8')
    monkeypatch.setattr(web,'load_project',lambda name: p if name=='film' else None)
    monkeypatch.setattr(web,'media_uri',lambda ann: ('/media/mock/'+str(ann)) if ann else '')
    result=web.project_data('film')
    assert result['clips']['0001']['final_url']=='/media/mock/join1.mp4'
    assert result['clips']['0002']['final_url']=='/media/mock/join2.mp4'
    assert len(result['clips'])==2


def test_v14_browser_project_modes_direct_edit_and_latest_final():
    pytest.importorskip('playwright.sync_api')
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1320,'height':900})
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        html=(ROOT/'studio_ui/index.html').read_text(encoding='utf-8').replace('<script src="/studio.js"></script>','')
        page.set_content(html)
        for sheet in ('studio.css','studio-v10-9.css','studio-v10-10.css','studio-v10-14.css'):
            page.add_style_tag(content=(ROOT/'studio_ui'/sheet).read_text(encoding='utf-8'))
        page.add_script_tag(content=(ROOT/'studio_ui/studio.js').read_text(encoding='utf-8'))
        page.locator('#newProject').click()
        page.locator('#mode').select_option('auto')
        assert all(not page.locator('#'+k).is_checked() for k in ('reviewScenes','reviewPlans','reviewClips','reviewRaw'))
        assert page.locator('#reviewScenes').is_disabled()
        page.locator('#mode').select_option('studio')
        assert page.locator('#reviewScenes').is_checked()
        page.evaluate("for(const id of ['modelAll','modelContent','modelScene','modelPlan','modelClip'])document.getElementById(id).innerHTML='<option value=\"llm\">LLM</option>'")
        page.locator('#modelAll').select_option('llm')
        assert all(page.locator('#model'+k).input_value()=='llm' for k in ('Content','Scene','Plan','Clip'))
        page.locator('#independentModels').check()
        assert page.locator('#individualModels').is_visible()
        assert page.locator('#director').evaluate('(x)=>x.tagName') == 'TEXTAREA'
        page.evaluate('''() => {
          projectName='testfilm';project={name:'testfilm',clips:{
           '0001':{final_url:'/output/final1.mp4'},'0002':{final_url:'/output/final2.mp4'}
          }};renderLatestFinal();
        }''')
        assert page.locator('#latestFinalInfo').inner_text().startswith('Clip 2')
        assert page.locator('#latestFinalVideo').get_attribute('src')=='/output/final2.mp4'
        page.evaluate('''() => {document.getElementById('latestFinalVideo').currentTime=0;renderLatestFinal()}''')
        assert page.locator('#latestFinalVideo').get_attribute('src')=='/output/final2.mp4'
        page.evaluate('''() => {project.clips['0003']={final_url:'/output/final3.mp4'};renderLatestFinal()}''')
        assert page.locator('#latestFinalInfo').inner_text().startswith('Clip 3')
        page.evaluate('''() => {projectName='anotherfilm';project={name:'anotherfilm',clips:{}};renderLatestFinal()}''')
        assert page.locator('#latestFinalPlayerBox').is_hidden()
        assert not errors,errors
        browser.close()


def test_v14_browser_invalid_director_edit_keeps_draft_and_allows_restore():
    pytest.importorskip('playwright.sync_api')
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1320,'height':900})
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.on('dialog',lambda d:d.accept())
        html=(ROOT/'studio_ui/index.html').read_text(encoding='utf-8').replace('<script src="/studio.js"></script>','')
        page.set_content(html)
        page.add_script_tag(content=(ROOT/'studio_ui/studio.js').read_text(encoding='utf-8'))
        page.evaluate('''() => {
          const info={id:'content-17',kind:'content',title:'Le film',allow_revise:true,
            payload:{text:'Résumé lisible',content:{title:'Film',concept:'Une aventure',duration_text:'00:30',parts:[
              {part:1,name:'Acte I',kind:'ACTE',start:'00:00',end:'00:30',duration_seconds:30,development:'Un voyage'}
            ]}}};
          state={review:info,running:true,project:{name:'testfilm'}};
          projectName='testfilm';project={name:'testfilm'};
          window.fetch=async(url,config)=>{
            if(url==='/api/review')return {ok:false,status:400,json:async()=>({error:'Partie 2 : trou temporel de 5 secondes. Corrige le début en 00:15.'})};
            return {ok:true,status:200,json:async()=>({ollama:[],special:[]})};
          };
          actionPanel(state);
        }''')
        assert page.locator('#directorDirectText').is_visible()
        page.locator('#directorDirectText').fill('Résumé lisible, mais deux actes au lieu d’un.')
        edited=page.locator('#directorDirectText').input_value()
        page.locator('#approveReview').click()
        page.locator('#directorEditError').wait_for(state='visible')
        assert 'Partie 2' in page.locator('#directorEditError').inner_text()
        assert page.locator('#directorDirectText').input_value()==edited
        page.locator('#restoreDirectorSource').click()
        assert page.locator('#directorDirectText').input_value()=='Résumé lisible'
        page.locator('#undoDirectorRestore').click()
        assert page.locator('#directorDirectText').input_value()==edited
        assert not errors,errors
        browser.close()
