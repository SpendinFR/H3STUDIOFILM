"""V10.91: only central mode changes. Genuine ffmpeg integration and routing."""
from pathlib import Path
import hashlib
import re
import subprocess
import tempfile
import unittest
from unittest.mock import patch
from zipfile import ZipFile
import cv2
import numpy as np
import retouches_precise_center_v90 as center
import retouches_precise_half_v82 as half
import retouches_llm_prompt_half_v82 as gemma

BASE=Path(__file__).resolve().parents[1]
REFERENCE=Path('/mnt/data/H3Film_STUDIO_V10_90_V83_PROMPT_V88_DOUBLE_RACCORD_EXACT.zip')


def good_prompt(window):
    descriptions={'TRANSITION AVANT':'Elle regarde son écran avant de se tourner avec un petit sourire.',
                  'ACTION':'Elle lève vivement la main droite devant sa tête puis la redescend.',
                  'TRANSITION APRÈS':'Elle revient naturellement vers la caméra en continuant à parler.'}
    shots='\n'.join(f'[Shot {n}] {a:.3f}–{b:.3f}s {descriptions[r]}'
                    for n,(r,a,b) in enumerate(gemma._grid(window),1))
    return gemma._assemble('La streameuse est face à la caméra dans sa chambre.',shots,window)

class PromptRegression(unittest.TestCase):
    def test_original_files_are_byte_exact(self):
        with ZipFile(REFERENCE) as z:
            for filename in ('retouches_llm_prompt_half_v82.py','retouches_precise_half_v82.py',
                             'retouches_preroll_prompt_v88.py'):
                self.assertEqual(hashlib.sha256((BASE/filename).read_bytes()).digest(),
                                 hashlib.sha256(z.read(filename)).digest())

    def test_gemma_has_63_frames_h3_83_without_added_post_shot(self):
        core,render=center.select_window(37,124,2.,3.)
        local=good_prompt(core)
        self.assertEqual(core['frames'],63)
        self.assertEqual(render['frames'],83)
        self.assertEqual(render['preroll_frames'],10)
        self.assertEqual(render['postroll_frames'],10)
        self.assertEqual(len(re.findall(r'\[Shot \d+\]',local)),3)
        self.assertIn('exactly 2.625s',local)
        h3=center.prepare_prompt(local,core,render)
        self.assertEqual(len(re.findall(r'\[Shot \d+\]',h3)),3)
        self.assertIn('exactly 3.458s',h3)
        self.assertIn('Action assigned within the local take at 1.292–2.292s',h3)
        self.assertNotIn('[Shot 5]',h3)
        for phrase in ('Elle regarde son écran','Elle lève vivement','Elle revient naturellement'):
            self.assertEqual(h3.count(phrase),local.count(phrase))

    def test_bad_placeholder_with_em_dash_rejected(self):
        core,_=center.select_window(37,124,2,3)
        out=good_prompt(core)
        out=out.replace('Elle regarde son écran avant de se tourner avec un petit sourire.', '— TRANSITION AVANT')
        with self.assertRaisesRegex(RuntimeError,'sans description'):
            center.verify_gemma_descriptions(out)

    def test_half_clips_match_known_working_frames(self):
        a=half.select_window(37,124,0,1.5)
        b=half.select_window(37,124,3.5,4.5)
        self.assertEqual((a['frames'],half.render_window_with_preroll(a,37,124)['frames']),(63,63))
        self.assertEqual((b['frames'],half.render_window_with_preroll(b,37,124)['frames']),(63,73))

class VideoIntegration(unittest.TestCase):
    @staticmethod
    def create_file(file:Path,color:str,n:int,with_audio:bool=False):
        cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi','-i',
             f'color=c={color}:size=128x96:rate=24']
        if with_audio:
            cmd+=['-f','lavfi','-i','sine=frequency=440:sample_rate=44100']
        cmd+=['-frames:v',str(n),'-c:v','libx264','-pix_fmt','yuv420p']
        if with_audio:
            cmd+=['-c:a','aac','-shortest']
        cmd+=[str(file)]
        r=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
        if r.returncode:raise RuntimeError(r.stderr)

    @staticmethod
    def sample(file:Path):
        cap=cv2.VideoCapture(str(file))
        out=[]
        while True:
            ok,frame=cap.read()
            if not ok:break
            out.append(float(frame[:,:,1].mean()))
        cap.release()
        return out

    def test_two_v88_fades_in_one_pass_and_original_outside(self):
        core,render=center.select_window(37,124,2,3)
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)
            src=p/'src.mp4';gen=p/'h3.mp4';dest=p/'out.mp4'
            self.create_file(src,'gray',124,True)
            self.create_file(gen,'white',83)
            center.stitch(src,gen,dest,core,render,124,p)
            self.assertEqual(half._frame_count(dest,p),124)
            srcluma=self.sample(src);y=self.sample(dest)
            self.assertEqual(len(y),124)
            start=core['origin_frame'];end=core['end_frame']
            for index in (0,2,start-2,end+2,122):
                self.assertLess(abs(y[index]-srcluma[index]),5,index)
            self.assertGreater(y[start+6],225)
            in_blend=[y[start+i] for i in range(4)]
            out_blend=[y[end-4+i] for i in range(4)]
            self.assertEqual(in_blend,sorted(in_blend))
            self.assertEqual(out_blend,sorted(out_blend,reverse=True))
            proc=subprocess.run(['ffprobe','-v','error','-select_streams','a:0','-show_entries',
                'stream=codec_type','-of','default=noprint_wrappers=1',str(dest)],
                capture_output=True,text=True,timeout=30)
            self.assertIn('audio',proc.stdout)

if __name__=='__main__':unittest.main()
