"""V10.18 regression: real ComfyUI-style isolated interpreter entrypoints.

`python -I` intentionally excludes the script directory and ignores PYTHONPATH.
Former tests inserted project ROOT in sys.path, hiding two Windows-only crashes.
"""
from pathlib import Path
import subprocess
import sys
import textwrap

ROOT = Path(__file__).resolve().parents[1]


def isolated(script: str):
    proc = subprocess.run(
        [sys.executable, '-I', '-c', textwrap.dedent(script), str(ROOT)],
        cwd=ROOT,
        capture_output=True,
        text=True,
        timeout=25,
    )
    assert proc.returncode == 0, f'Python -I returned {proc.returncode}:\n{proc.stdout}\n{proc.stderr}'
    assert 'ModuleNotFoundError' not in proc.stdout + proc.stderr
    return proc.stdout


def test_film_engine_loads_all_studio_helpers_in_isolated_python():
    isolated('''
        import importlib.util, pathlib, sys
        root = pathlib.Path(sys.argv[1])
        assert str(root) not in sys.path  # reproduces embedded ComfyUI
        spec = importlib.util.spec_from_file_location('h3_film_isolated', root / 'h3film_studio_v3.py')
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        timeline = mod.studio_refbank_module('studio_timeline_extension')
        emergency = mod.studio_refbank_module('studio_emergency_stop')
        assert callable(timeline.read_pending)
        assert callable(timeline.extension_part)
        assert callable(emergency.emergency_stop)
        assert mod.studio_refbank_module('studio_timeline_extension') is timeline
        assert mod.studio_refbank_module() is mod.studio_refbank_module('studio_refbank_edits')
        print('ISOLATED ENGINE OK')
    ''')


def test_web_server_ctrl_c_loads_emergency_helper_under_isolated_python():
    result = isolated('''
        import importlib.util, pathlib, sys
        root = pathlib.Path(sys.argv[1])
        assert str(root) not in sys.path
        spec = importlib.util.spec_from_file_location('web_isolated', root / 'studio_web.py')
        web = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(web)
        emergency = web.studio_local_helper('studio_emergency_stop')
        called = []
        emergency.emergency_stop = lambda: called.append('cleanup') or []
        web.restore_running_session = lambda: None
        class FakeServer:
            def __init__(self, *a, **kw): pass
            def serve_forever(self): raise KeyboardInterrupt
            def server_close(self): called.append('closed')
        web.ThreadingHTTPServer = FakeServer
        sys.argv = ['studio_web.py']
        web.main()
        assert called == ['cleanup', 'closed'], called
        assert web.studio_local_helper('studio_timeline_extension').pending_path(root).name == 'timeline_extension_pending.json'
        print('ISOLATED WEB CTRL+C OK')
    ''')
    assert 'Ctrl+C : arrêt général demandé' in result


def test_web_extension_endpoint_loads_helper_before_active_check_in_isolated_python():
    isolated('''
        import importlib.util, pathlib, sys
        root = pathlib.Path(sys.argv[1])
        spec = importlib.util.spec_from_file_location('web_endpoint_isolated', root / 'studio_web.py')
        web = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(web)
        class Req:
            path = '/api/extend-timeline'
            def body(self): return {}
            def send_data(self, data, status=200):
                self.status, self.result = status, data
        req = Req()
        web.Handler.do_POST(req)
        assert req.status == 400 and 'Production inactive' in req.result.get('error', ''), req.result
        print('ISOLATED WEB TIMELINE OK')
    ''')


def test_engine_main_preflights_helpers_before_comfy_connection():
    isolated('''
        import importlib.util, pathlib, sys
        root = pathlib.Path(sys.argv[1])
        spec = importlib.util.spec_from_file_location('engine_launch_isolated', root / 'h3film_studio_v3.py')
        film = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(film)
        reached = []
        def stop_at_comfy():
            reached.append('comfy')
            raise RuntimeError('EXPECTED_AFTER_PREFLIGHT')
        film.rt.find_comfy_dir = stop_at_comfy
        try:
            film.main()
        except RuntimeError as exc:
            assert str(exc) == 'EXPECTED_AFTER_PREFLIGHT'
        else:
            raise AssertionError('Expected first ComfyUI call')
        assert reached == ['comfy']
        print('ISOLATED NEW FILM START OK')
    ''')


def test_real_server_start_and_sigint_in_isolated_interpreter():
    """Exercise the HTTP listener and signal handling, not only fake serve_forever."""
    import os
    import signal
    import socket
    import time
    if not hasattr(signal, 'SIGINT'):
        return
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0))
        port = sock.getsockname()[1]
    script = textwrap.dedent('''
        import importlib.util, pathlib, sys
        root = pathlib.Path(sys.argv[1]); port = sys.argv[2]
        spec = importlib.util.spec_from_file_location('web_live_isolated', root/'studio_web.py')
        web = importlib.util.module_from_spec(spec);spec.loader.exec_module(web)
        emergency = web.studio_local_helper('studio_emergency_stop')
        emergency.emergency_stop = lambda: []  # Never kill genuine user services in a regression test.
        web.restore_running_session = lambda: None
        sys.argv = ['studio_web.py','--port',port]
        web.main()
    ''')
    proc = subprocess.Popen(
        [sys.executable, '-I', '-u', '-c', script, str(ROOT), str(port)],
        cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
    )
    try:
        for _ in range(80):
            if proc.poll() is not None:
                raise AssertionError('Studio web exited before accepting connections')
            try:
                with socket.create_connection(('127.0.0.1', port), timeout=.2):
                    break
            except OSError:
                time.sleep(.05)
        else:
            raise AssertionError('Studio web did not listen')
        proc.send_signal(signal.SIGINT)
        stdout, stderr = proc.communicate(timeout=12)
        assert proc.returncode == 0, (proc.returncode, stdout, stderr)
        assert 'Ctrl+C : arrêt général demandé' in stdout, stdout
        assert 'Traceback' not in stdout + stderr
    finally:
        if proc.poll() is None:
            proc.kill()
            proc.communicate(timeout=5)
