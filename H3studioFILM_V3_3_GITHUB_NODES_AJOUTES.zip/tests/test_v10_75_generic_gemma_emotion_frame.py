"""V10.75: universal Gemma director wording + no automatic emotion face ROI.
No GPU, dependencies installation, Ollama, ComfyUI or file writes beyond temp cache.
"""
import inspect, hashlib, unittest, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_llm_prompt_v74 as prompts
import retouches_next as engine

class UniversalRetakeTest(unittest.TestCase):
    def test_no_case_specific_examples_sent_to_gemma(self):
        case_words=('main gauche', 'doigt de la main', 'pointer vers', 'l’écran', 'l\'écran', '1.293s', 'tristesse', 'sadness')
        for term in case_words:
            self.assertNotIn(term.casefold(), prompts.SYSTEM.casefold(),term)
        examples=[
            ('un chat suit une balle', 'une moto stationnée devant une gare'),
            ('le skateur pivote plus lentement', 'un personnage marche vers une sortie'),
        ]
        for request,original in examples:
            for mode,ptype in [('performance','action'),('performance','emotion')]:
                with self.subTest(request=request,mode=ptype):
                    user=prompts.build_request(mode,ptype,request,original,0.420,3.180,6.417)
                    self.assertIn(request,user)
                    self.assertIn(original,user)
                    self.assertIn('0.420–3.180s',user)
                    for term in case_words:
                        self.assertNotIn(term.casefold(),user.casefold(),term)
    def test_existing_interpretation_remains_generic(self):
        self.assertEqual(prompts.requested_operation('ajoute un personnage'), 'add')
        self.assertEqual(prompts.requested_operation('remplace la réplique'), 'replace')
        self.assertEqual(prompts.requested_operation('changer sa vitesse'), 'infer')
    def test_emotion_default_spatial_full_and_face_detection_not_called(self):
        self.assertEqual(engine._auto_rect('performance','une personne pleure'),(0,0,100,100))
        self.assertTrue(engine._full_clip_h3_for_performance('performance','emotion'))
        run=inspect.getsource(engine._run)
        self.assertIn("in ('action','emotion')",run)
        self.assertIn('rect=(0.,0.,100.,100.)',run)
        self.assertNotIn('_auto_actor_rect(',run)
        self.assertNotIn('def _auto_actor_rect(',inspect.getsource(engine))
        # Explicit region is validated and converted earlier; must not be overwritten
        self.assertIn("if region is not None:",run)
        self.assertIn('rect=(x,y,w,h)',run)
        self.assertIn("else:\n            # No LLM or VLM",run)
    def test_untouched_engines_and_filmstudio(self):
        prior=Path('/mnt/data/work_v1074')
        for name in ('h3film_studio_v3.py','studio_web.py','studio_retouches.py',
                     'retouches_engine.py','retouches_masked_core.py',
                     'retouches_roycho_complete_v63.py','workflows/H3Studio_1920_API_CLEAN.json',
                     'retouches_new_insert_guide.py'):
            self.assertEqual((ROOT/name).read_bytes(),(prior/name).read_bytes(),name)
        cmd=(ROOT/'LANCER-RETOUCHES-V10_75.cmd').read_text('utf-8')
        self.assertIn('studio_web.py',cmd)
        self.assertNotIn('pip install',cmd)

if __name__=='__main__': unittest.main()
