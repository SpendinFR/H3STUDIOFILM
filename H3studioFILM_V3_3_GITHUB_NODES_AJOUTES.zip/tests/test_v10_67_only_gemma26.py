import pathlib, unittest, sys
from unittest.mock import Mock, patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
import retouches_llm_prompt_v66 as mod

class TestGemmaOnly(unittest.TestCase):
    class Film:
        rt = Mock(OLLAMA_URL='http://127.0.0.1:11434')
        @staticmethod
        def installed_model_names(tags): return [x['name'] for x in tags['models']]
        @staticmethod
        def _ollama_backend(model): return {'provider':'ollama', 'model':model,'display':model}
        @staticmethod
        def _llama_backend(*args): raise AssertionError('llama-server forbidden')
    def test_exact_existing_gemma26_preferred(self):
        self.Film.rt.http_json.return_value={'models':[{'name':'qwen3.8:27b'}, {'name':'gemma4:26b-a4b-it-q4_K_M'}, {'name':'gemma4:26b-other'}]}
        backend=mod.choose_backend(self.Film)
        self.assertEqual(backend['model'],'gemma4:26b-a4b-it-q4_K_M')
        self.assertEqual(backend['provider'],'ollama')
    def test_no_qwen_fallback(self):
        self.Film.rt.http_json.return_value={'models':[{'name':'qwen3.8:27b'}, {'name':'gemma4:12b'}]}
        with self.assertRaisesRegex(RuntimeError,'Qwen 27B interdit'): mod.choose_backend(self.Film)
    def test_ollama_offline_never_launch_llama_cpp(self):
        self.Film.rt.http_json.side_effect=ConnectionError('offline')
        with self.assertRaisesRegex(RuntimeError,'Ollama est indisponible'):mod.choose_backend(self.Film)
        self.Film.rt.http_json.side_effect=None
    def test_exact_film_studio_contract(self):
        studio=(pathlib.Path(__file__).resolve().parents[1]/'h3film_studio_v3.py').read_text('utf-8')
        self.assertIn('gemma4:26b-a4b-it-q4_K_M',studio)
        path=pathlib.Path(__file__).resolve().parents[1]/'retouches_llm_prompt_v66.py'
        text=path.read_text('utf-8')
        self.assertIn('film.director_text',text)
        self.assertIn('film.unload_text_backend',text)
        self.assertNotIn("return film._llama_backend(",text)
        self.assertNotIn('H3RETOUCH_LLM_MODEL',text)
    def test_standalone_launcher_without_dependency_install(self):
        root=pathlib.Path(__file__).resolve().parents[1]
        text=(root/'LANCER-RETOUCHES-V10_67.cmd').read_text('utf-8')
        self.assertIn('python_embeded',text)
        self.assertIn('INSTALLER-NOUVEAUX-MOTEURS-V10_66.ps1',text)
        self.assertNotIn('pip install',text)
        self.assertNotIn('DiffSynth-Studio',text)

if __name__=='__main__':unittest.main()
