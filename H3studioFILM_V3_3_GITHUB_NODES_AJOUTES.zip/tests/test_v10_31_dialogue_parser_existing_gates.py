"""V10.31: improve ONLY the existing dialogue checker, not H3 renderer.

The studio already checks at clip validation, before each RAW, and after a
retake. These tests target malformed/missing shot timing and one-shot pacing.
"""
from pathlib import Path
import pytest
import studio_dialogue_budget as budget

LONG = 'Tu sais...Je ne sais pas comment je vais faire, je suis bloqué actuellement tu penses qu\'on doit y arriver?'
SHORT = 'Je suis bloqué, on fait comment ?'

@pytest.mark.parametrize('header', [
    '**[Shot 1] 0:00–5.0s**',
    '[Shot 1] 0:00-5.0',
    '**[Shot 1] (0:00–5.0s)**',
    '**[Shot 1] 0:00 — 5,0s**',
    '[Shot 1] 00:00–00:05',
])
def test_one_shot_five_seconds_counts_fifteen_words(header):
    prompt=header+'\nBrad Pitt :\n<d>[French] '+LONG+'</d>'
    found=budget.check(prompt)
    assert len(found)==1
    assert found[0]['shot']==1
    assert found[0]['words']==20
    assert found[0]['max_words']==15

@pytest.mark.parametrize('header', [
    '**[Shot 1] 0:00–2.5s**',
    '[Shot 1] 0:00–2.5',
    '**[Shot 1] (0:00–2.5s)**',
])
def test_half_shot_counts_seven_words(header):
    prompt=header+'\n<d>[French] '+LONG+'</d>\n**[Shot 2] 2.5–5.0s**'
    assert budget.check(prompt)[0]['max_words']==7

@pytest.mark.parametrize('prompt', [
    '**[Shot 1] incorrect timing**\n<d>[French] '+SHORT+'</d>',
    '**[Shot 1] 0:00–9.0**\n<d>[French] '+SHORT+'</d>',
    '**[Shot 1] 0:00–5.0**\n<d>[French] '+SHORT,
])
def test_unreadable_header_or_dialogue_tag_must_not_disappear(prompt):
    assert budget.check(prompt)

def test_no_shot_header_keeps_existing_five_second_fallback():
    assert budget.check('<d>[French] '+LONG+'</d>')[0]['max_words']==15
    assert budget.check('<d>[French] '+SHORT+'</d>')==[]

def test_short_spoken_line_does_not_trigger_a_rewrite():
    assert budget.check('**[Shot 1] 0:00–5.0**\n<d>[French] '+SHORT+'</d>') == []

def test_existing_checks_run_after_edit_and_retake_before_renderer():
    path=Path(__file__).resolve().parents[1]/'h3film_studio_v3.py'
    src=path.read_text(encoding='utf8')
    assert "h3_prompt, last_dialogue_issues = _auto_dialogue_gate(h3_prompt,'avant RAW/H3')" in src
    assert "h3_prompt, retake_dialogue_issues=_auto_dialogue_gate(h3_prompt,'retake RAW')" in src
    assert "if dialogue_gate.check(h3_prompt):" in src
    assert "if isinstance(exc, dialogue_gate.DialogueBudgetError):" in src
    assert 'assert_safe_for_h3' not in src  # no second validator grafted onto H3 renderer
    assert src.index("_auto_dialogue_gate(h3_prompt,'avant RAW/H3')") < src.index('video_ann, raw_ann, cumulative_final_ann, used_mc = render_clip(')
