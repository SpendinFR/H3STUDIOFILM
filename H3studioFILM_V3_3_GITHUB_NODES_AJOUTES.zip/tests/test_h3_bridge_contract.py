"""CPU-only custom-node contract tests with tiny fake Comfy modules."""
import importlib.util, json, sys, tempfile, threading, time, types, unittest
from pathlib import Path
import torch

class NestedTensor:
    def __init__(self, members): self.members=tuple(members)
    def unbind(self): return self.members
class Interrupted(Exception):pass

class Contract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        comfy=types.ModuleType('comfy');nested=types.ModuleType('comfy.nested_tensor');nested.NestedTensor=NestedTensor
        mm=types.ModuleType('comfy.model_management');mm.InterruptProcessingException=Interrupted;mm.get_torch_device=lambda:torch.device('cpu')
        folder=types.ModuleType('folder_paths')
        cls.work=tempfile.TemporaryDirectory()
        folder.get_output_directory=lambda:cls.work.name
        comfy.nested_tensor=nested;comfy.model_management=mm
        for key,obj in [('comfy',comfy),('comfy.nested_tensor',nested),('comfy.model_management',mm),('folder_paths',folder)]:sys.modules[key]=obj
        path=Path(__file__).resolve().parents[1]/'custom_nodes'/'H3RawLatentPersist'/'__init__.py'
        spec=importlib.util.spec_from_file_location('filmbridge_contract',path)
        cls.node=importlib.util.module_from_spec(spec);spec.loader.exec_module(cls.node)
    @classmethod
    def tearDownClass(cls):cls.work.cleanup()
    def latent(self):
        return {'samples':NestedTensor((torch.zeros((1,4,5,68,120)),torch.zeros((1,2,2,20))))}
    def test_visual_refs_removed_audio_and_mc_kept(self):
        src=torch.ones(1,2,1,40,72)
        conditioning=[['embedding',{'minimax_refs':[
            {'kind':'image','latent':src},
            {'kind':'video','latent':src},
            {'kind':'video_audio','latent':src},
            {'kind':'audio','id':'voice_1'},
        ],'minimax_keyframes':[{'latent':src}],'minimax_hard_video':[{'latent':src}],'extra':'unchanged'}]]
        (out,)=self.node.H3RefineResizeConditioningDropVisualRefs().run(conditioning,self.latent())
        self.assertEqual([r['kind'] for r in out[0][1]['minimax_refs']],['audio'])
        self.assertEqual(tuple(out[0][1]['minimax_keyframes'][0]['latent'].shape[-2:]),(68,120))
        self.assertEqual(tuple(out[0][1]['minimax_hard_video'][0]['latent'].shape[-2:]),(68,120))
        self.assertEqual(out[0][1]['extra'],'unchanged')
        self.assertEqual(len(conditioning[0][1]['minimax_refs']),4)
    def test_raw_gate_approval_and_rejection(self):
        plugin=self.node;root=Path(self.work.name)/'H3FilmSimple'/'demo'/'_studio'/'gates'
        gate=plugin.H3RawSavedStudioGate()
        for action in ('approve','redo'):
            source=self.latent();result=[]
            def work():
                try:result.append(gate.run(source,object(),'demo',4))
                except Interrupted:result.append('interrupted')
            t=threading.Thread(target=work);t.start()
            path=root/'clip_0004.waiting.json'
            for i in range(100):
                if path.exists():break
                time.sleep(.01)
            self.assertTrue(path.exists())
            (root/'clip_0004.decision.json').write_text(json.dumps({'action':action,'feedback':'Corriger angle'}),encoding='utf-8')
            t.join(3);self.assertFalse(t.is_alive());self.assertFalse(path.exists())
            if action=='approve':self.assertIs(result[0][0],source)
            else:
                self.assertEqual(result,['interrupted'])
                self.assertEqual(json.loads((root/'clip_0004.redo.json').read_text())['feedback'],'Corriger angle')
    def test_raw_gate_stop_does_not_start_refine(self):
        plugin=self.node
        root=Path(self.work.name)/'H3FilmSimple'/'stoptest'/'_studio'/'gates'
        gate=plugin.H3RawSavedStudioGate();result=[]
        def work():
            try:result.append(gate.run(self.latent(),object(),'stoptest',8))
            except Interrupted:result.append('interrupted')
        t=threading.Thread(target=work);t.start()
        waiting=root/'clip_0008.waiting.json'
        for _ in range(100):
            if waiting.is_file():break
            time.sleep(.01)
        self.assertTrue(waiting.exists())
        (root/'stop.request').write_text('1')
        t.join(4)
        self.assertFalse(t.is_alive())
        self.assertEqual(result,['interrupted'])
        self.assertFalse(waiting.exists())
        self.assertFalse((root/'clip_0008.redo.json').exists())

    def test_raw_latent_roundtrip_cpu(self):
        value=self.latent()
        (same,)=self.node.H3StoreRawLatentExact().run(value,'demo','clip_004_RAW_LATENT')
        self.assertIs(same,value)
        (restored,)=self.node.H3LoadRawLatentExact().run('demo','clip_004_RAW_LATENT')
        self.assertEqual(tuple(restored['samples'].unbind()[0].shape),(1,4,5,68,120))
        self.assertEqual(tuple(restored['samples'].unbind()[1].shape),(1,2,2,20))

if __name__=='__main__':unittest.main()
