"""Offline safety/contract tests for the isolated new RAW-only Retouches addon."""
import importlib.util
from pathlib import Path
import json
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_next as new

class NextEnginesTests(unittest.TestCase):
    def test_expected_engines_present(self):
        self.assertEqual(set(new.MODES), {'extend','performance','precise','insert'})

    def test_snapshot_is_raw_only(self):
        full=json.loads(new.SOURCE_COPY.read_text(encoding='utf-8'))
        sub=new._snapshot_gui()
        t={x['type'] for x in sub['nodes']}
        self.assertIn('H3StudioImageToVideo',t)
        self.assertIn('SaveVideo',t)
        self.assertIn('SamplerCustomAdvanced',t)
        self.assertNotIn('MinimaxH3LatentUpscaler3D',t)
        self.assertNotIn('H3V15ProjectStoreHDTail',t)
        self.assertNotIn('H3VisibleJoinMatch',t)
        self.assertEqual(len(full['nodes']),45)
        self.assertLess(len(sub['nodes']),len(full['nodes']))

    def test_auto_placement(self):
        self.assertEqual(new._auto_rect('insert','à gauche'),(4,13,48,74))
        self.assertEqual(new._auto_rect('insert','à droite'),(48,13,48,74))
        self.assertEqual(new._auto_rect('precise','corrige le plan'),(0,0,100,100))

    def test_raw_source_required(self):
        with self.assertRaisesRegex(ValueError,'RAW'):
            new.start({'mode':'precise','instruction':'corrige cette main','source':{'type':'upload','id':'no'}},lambda x:None,lambda x:Path('missing'))

    def test_pt_path_is_not_a_client_supplied_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            comfy=Path(tmp)/'ComfyUI';out=comfy/'output'/'H3FilmSimple'/'Demo'
            (out/'_studio').mkdir(parents=True)
            (out/'_state').mkdir(parents=True)
            (comfy/'output'/'clip.mp4').write_bytes(b'video')
            (out/'_studio'/'clips.json').write_text(json.dumps({'clips':{'1':{'raw':'clip.mp4'}}}))
            with self.assertRaisesRegex(ValueError,'Latent RAW exact absent'):
                new._project('Demo','1',lambda x:out,comfy)
            (out/'_state'/'clip_0001_RAW_LATENT.pt').write_bytes(b'RAW test')
            src,latent=new._project('Demo','1',lambda x:out,comfy)
            self.assertEqual(src,comfy/'output'/'clip.mp4')
            self.assertEqual(latent,out/'_state'/'clip_0001_RAW_LATENT.pt')

if __name__=='__main__':unittest.main()
