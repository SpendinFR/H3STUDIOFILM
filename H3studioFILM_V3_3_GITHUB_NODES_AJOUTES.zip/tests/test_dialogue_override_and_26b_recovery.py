"""Regression tests: no silent zero-word speech blockers, exact Gemma model selection."""
import ast
import os
from typing import Any
from pathlib import Path
import studio_dialogue_budget as dialogue

ROOT=Path(__file__).resolve().parents[1]

def test_silent_malformed_shot_must_not_block_speech_budget():
    text='[Shot 1] 0-2.5s\n<d>[Français] Salut !</d>\n[Shot 2] 2.5-2.5s\nCamera moves.'
    assert dialogue.check(text)==[]

def test_spoken_malformed_shot_still_warns():
    text='[Shot 1] 0-0s\n<d>[Français] Je suis là</d>'
    assert dialogue.check(text) and dialogue.check(text)[0]['max_words']==0

def test_empty_spoken_words_do_not_block_on_bad_shot_window():
    assert dialogue.check('[Shot 2] 4-4s\n<d></d>')==[]

def _engine_funcs():
    tree=ast.parse((ROOT/'h3film_studio_v3.py').read_text('utf-8'))
    subset=ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in
                   ('installed_model_names','select_text_backend','choose_text_model')],type_ignores=[])
    compiled=compile(ast.fix_missing_locations(subset),str(ROOT/'h3film_studio_v3.py'),'exec')
    namespace={'os':os,'Any':Any,'_ollama_backend':lambda s:{'model':s},'_llama_backend':lambda s:{'model':s},
               '_QWEN38_CTX':24576}
    exec(compiled,namespace)
    return namespace

def test_selected_gemma26_cannot_silently_fall_back_to_12b(monkeypatch):
    f=_engine_funcs()['select_text_backend']
    monkeypatch.setenv('H3FILM_CLIP_MODEL','gemma4:26b-a4b-it-q4_K_M')
    monkeypatch.delenv('H3FILM_TEXT_MODEL',raising=False)
    installed={'models':[{'name':'gemma4:12b'}]}
    try:
        f(installed,env_var='H3FILM_CLIP_MODEL')
    except RuntimeError as exc:
        assert 'n\'est pas installé' in str(exc)
    else:
        raise AssertionError('26B fell back silently to 12B')

def test_selected_gemma26_is_preserved_when_installed(monkeypatch):
    f=_engine_funcs()['select_text_backend']
    monkeypatch.setenv('H3FILM_CLIP_MODEL','gemma4:26b-a4b-it-q4_K_M')
    monkeypatch.delenv('H3FILM_TEXT_MODEL',raising=False)
    installed={'models':[{'name':'gemma4:12b'},{'name':'gemma4:26b-a4b-it-q4_K_M'}]}
    assert f(installed,env_var='H3FILM_CLIP_MODEL')['model']=='gemma4:26b-a4b-it-q4_K_M'

def test_direct_human_override_wiring_does_not_change_renderer():
    src=(ROOT/'h3film_studio_v3.py').read_text('utf-8')
    assert "if correction_verdict.get('action')=='continue':" in src
    assert 'dialogue_override_approved=True' in src
    assert 'if dialogue_override_approved:' in src
    assert 'dialogue_budget_human_override' in src
    assert 'SamplerCustomAdvanced' in src  # original renderer remains
