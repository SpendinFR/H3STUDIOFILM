"""Regression: keep the generated 63-frame half, but do not replace unrelated original lead-in."""
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path
import retouches_precise_half_v82 as half

class JoinPlanningTests(unittest.TestCase):
    def test_late_unchanged_original_until_near_edit(self):
        w=half.select_window(37,124,3.6,4.5)
        self.assertEqual(w['origin_frame'],61)
        self.assertEqual(w['end_frame'],124)
        j=half._join_frames(w,124)
        self.assertEqual(j['frame'],round(3.6*24)-12)
        self.assertGreater(j['frame'],61)
        self.assertEqual(j['generated_start'],j['frame']-61)
        self.assertEqual(j['fade'],4)

    def test_early_keeps_original_single_exit_join(self):
        w=half.select_window(37,124,0,1.5)
        j=half._join_frames(w,124)
        self.assertEqual(j['frame'],63)
        self.assertEqual(j['generated_start'],0)

    def test_invalid_window_fails_closed(self):
        w=half.select_window(37,124,3.6,4.5)
        w['first_frame']=30
        with self.assertRaisesRegex(ValueError,'sélection hors'):
            half._join_frames(w,124)

@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'ffmpeg absent')
class JoinVideoTests(unittest.TestCase):
    def clip(self,p,frames,color):
        c=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi','-i',
           f'color=c={color}:size=96x64:rate=24', '-frames:v',str(frames),
           '-c:v','libx264','-crf','0','-pix_fmt','yuv420p',str(p)]
        q=subprocess.run(c,capture_output=True,text=True,timeout=60)
        self.assertEqual(q.returncode,0,q.stderr)
    def frame_luma(self,p,n):
        cmd=['ffmpeg','-hide_banner','-loglevel','error','-i',str(p),
             '-vf',f'select=eq(n\\,{n})','-vsync','0','-frames:v','1',
             '-f','rawvideo','-pix_fmt','gray','-']
        q=subprocess.run(cmd,capture_output=True,timeout=60)
        self.assertEqual(q.returncode,0,q.stderr)
        return sum(q.stdout)/len(q.stdout)
    def test_late_stitch_preserves_original_frames_through_frame_73(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d);src=d/'src.mp4';gen=d/'gen.mp4';out=d/'out.mp4'
            self.clip(src,124,'gray');self.clip(gen,63,'white')
            w=half.select_window(37,124,3.6,4.5)
            half.stitch(src,gen,out,w,124,d/'comfy')
            self.assertEqual(half._frame_count(out,d/'comfy'),124)
            # Even though H3 regenerated frames 61..., preserve original through 73.
            src_luma=self.frame_luma(src,70)
            for index in (60,61,68,73):
                self.assertLess(abs(self.frame_luma(out,index)-src_luma),3,index)
            weights=[self.frame_luma(out,n) for n in (74,75,76,77)]
            self.assertEqual(weights,sorted(weights))
            self.assertGreater(self.frame_luma(out,90),220)
    def test_early_stitch_maintains_63_frame_original_seam(self):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d);src=d/'src.mp4';gen=d/'gen.mp4';out=d/'out.mp4'
            self.clip(src,124,'gray');self.clip(gen,63,'white')
            w=half.select_window(37,124,0,1.5)
            half.stitch(src,gen,out,w,124,d/'comfy')
            self.assertEqual(half._frame_count(out,d/'comfy'),124)
            self.assertGreater(self.frame_luma(out,55),220)
            self.assertLess(abs(self.frame_luma(out,75)-self.frame_luma(src,75)),3)

if __name__=='__main__':unittest.main()
