"""V10.37: video-object tracking and continuous-shot graph contracts."""
import json
import pathlib
import sys
import tempfile
import unittest
from unittest import mock

ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_engine as re
from retouches_workflow_compat import flatten_to_api


def spec(**required):
    return {'input':{'required':{k:v for k,v in required.items()},'optional':{}}}


def mock_h3_info():
    fields={
        'UNETLoader':'unet_name weight_dtype', 'CLIPLoader':'clip_name type device',
        'VAELoader':'vae_name', 'LanPaint_VideoMaskEditor':'video keyframes audio_mask',
        'MiniMaxH3ImageToVideo':'clip vae prompt width height length',
        'LanPaint_AVEncode':'video vae audio_vae mask audio_mask',
        'LanPaint_AVDecode':'samples video vae audio_vae mask audio_mask blend_overlap audio_crossfade',
        'BasicGuider':'model conditioning', 'RandomNoise':'noise_seed',
        'BasicScheduler':'model scheduler steps denoise', 'KSamplerSelect':'sampler_name',
        'LanPaint_SamplerCustomAdvanced':'noise guider sampler sigmas latent_image LanPaint_NumSteps LanPaint_Lambda LanPaint_StepSize LanPaint_PromptMode LanPaint_Info',
        'SaveVideo':'video filename_prefix format', 'CheckpointLoaderSimple':'ckpt_name',
        'GetVideoComponents':'video', 'ImageFromBatch':'image batch_index length',
        'SAM3_Detect':'model image conditioning positive_coords negative_coords threshold refine_iterations individual_masks',
        'SAM3_VideoTrack':'images model initial_mask conditioning max_objects detection_threshold detect_interval',
        'SAM3_TrackToMask':'track_data object_indices', 'CLIPTextEncode':'clip text',
        'InvertMask':'mask', 'MaskToImage':'mask', 'SaveImage':'images filename_prefix',
    }
    return {t:{'input':{'required':{k:['STRING',{'default':''}] for k in names.split()},'optional':{}}} for t,names in fields.items()}


class TrackingContracts(unittest.TestCase):
    def test_sam3_tracks_local_object_without_a_static_mask(self):
        info=mock_h3_info()
        with mock.patch.object(re.subprocess,'run',side_effect=OSError('no ffprobe')):
            graph=re._native_lanpaint_graph(info,'local_edit',pathlib.Path('x.mp4'),{'target':'red backpack'})
        self.assertEqual(graph['7']['inputs']['mask'],['21',0])
        self.assertEqual(graph['13']['inputs']['mask'],['21',0])
        self.assertEqual(graph['20']['inputs']['initial_mask'],['19',0])
        self.assertEqual(graph['20']['inputs']['images'],['16',0])
        self.assertEqual(graph['18']['inputs']['text'],'red backpack')
        self.assertEqual(graph['5']['inputs']['keyframes'] if 'keyframes' in graph['5']['inputs'] else '{}','{}')

    def test_lanpaint_sam_prompt_is_not_overwritten_by_generation_prompt(self):
        info=mock_h3_info()
        with mock.patch.object(re.subprocess,'run',side_effect=OSError('no ffprobe')):
            graph=re._native_lanpaint_graph(info,'local_edit',pathlib.Path('source.mp4'),{'target':'red backpack'})
        with tempfile.TemporaryDirectory() as temp:
            directory=pathlib.Path(temp);(directory/'input').mkdir()
            src=directory/'source.mp4';src.write_bytes(b'0000ftyp'+b'x'*20)
            re._inject(graph,'local_edit',{'target':'red backpack','instructions':'Turn the bag blue'},directory,'e'*32,src,None)
        self.assertEqual(graph['18']['inputs']['text'],'red backpack')
        self.assertIn('Turn the bag blue',graph['6']['inputs']['prompt'])

    def test_background_uses_inverted_person_track(self):
        info=mock_h3_info()
        with mock.patch.object(re.subprocess,'run',side_effect=OSError('no ffprobe')):
            graph=re._native_lanpaint_graph(info,'replace_background',pathlib.Path('x.mp4'),{'target':'woman in front'})
        self.assertEqual(graph['22']['inputs']['mask'],['21',0])
        self.assertEqual(graph['7']['inputs']['mask'],['22',0])
        self.assertEqual(graph['13']['inputs']['mask'],['22',0])

    def test_user_can_select_once_without_description(self):
        info=mock_h3_info()
        with mock.patch.object(re.subprocess,'run',side_effect=OSError('no ffprobe')):
            graph=re._native_lanpaint_graph(info,'local_edit',pathlib.Path('x.mp4'),{'region':[.1,.2,.3,.4]})
        point=json.loads(graph['19']['inputs']['positive_coords'])[0]
        self.assertEqual(point,{'x':216,'y':192})
        self.assertNotIn('18',graph)

    def test_swap_math_variadic_socket_compiles(self):
        nodes=[{'id':1,'type':'PrimitiveFloat','widgets_values_named':{'value':5},'inputs':[]},
               {'id':2,'type':'ComfyMathExpression','widgets_values_named':{'expression':'round(a * 24)'},'inputs':[{'name':'values.a','link':10}]},
               {'id':3,'type':'SaveVideo','widgets_values_named':{},'inputs':[{'name':'video','link':11}]}]
        ui={'nodes':nodes,'links':[[10,1,0,2,0,'FLOAT'],[11,2,1,3,0,'VIDEO']]}
        info={'PrimitiveFloat':spec(value=['FLOAT',{'default':0}]),'ComfyMathExpression':spec(expression=['STRING',{'default':''}],a=['FLOAT',{'default':0}]),'SaveVideo':spec(video=['VIDEO'])}
        graph=re.convert_graph(ui,info)
        self.assertEqual(graph['2']['inputs']['a'],['1',0])

    def test_subgraph_uuid_and_set_get_compile(self):
        ui={'nodes':[
            {'id':1,'type':'LoadVideo','widgets_values_named':{'file':'source.mp4'},'inputs':[]},
            {'id':2,'type':'a-sub-graph','inputs':[{'name':'source','link':1}]},
            {'id':3,'type':'SaveVideo','inputs':[{'name':'video','link':2}]}],
            'links':[[1,1,0,2,0,'VIDEO'],[2,2,0,3,0,'VIDEO']],
            'definitions':{'subgraphs':[{
                'id':'a-sub-graph','nodes':[
                    {'id':10,'type':'SetNode','widgets_values':['sourceVar'],'inputs':[{'name':'video','link':11}]},
                    {'id':11,'type':'GetNode','widgets_values':['sourceVar'],'inputs':[]}],
                'links':[{'id':11,'origin_id':-10,'origin_slot':0,'target_id':10,'target_slot':0},
                         {'id':12,'origin_id':11,'origin_slot':0,'target_id':-20,'target_slot':0}],
                'outputs':[{'name':'video','linkIds':[12]}]
            }]}}
        info={'LoadVideo':spec(file=['STRING',{'default':'source.mp4'}]),'SaveVideo':spec(video=['VIDEO'])}
        graph=flatten_to_api(ui,info,re._widget_inputs)
        self.assertEqual(graph['3']['inputs']['video'],['1',0])
        self.assertEqual(set(graph),{'1','3'})

    def test_user_interface_has_shot_controls_and_no_status_panel(self):
        html=(ROOT/'studio_ui/index.html').read_text(encoding='utf-8')
        js=(ROOT/'studio_ui/studio-retouches.js').read_text(encoding='utf-8')
        self.assertIn('retShotStart',html)
        self.assertIn('retShotEnd',html)
        self.assertNotIn('retouchDependencies',html)
        self.assertIn('shot_start',js)
        self.assertIn('SAM3 le suit',js)

if __name__=='__main__':unittest.main()
