from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]


def test_new_clip_editor_starts_ready_without_network_preview():
    pytest.importorskip('playwright.sync_api')
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1366,'height':800})
        html=(ROOT/'studio_ui/index.html').read_text(encoding='utf-8').replace('<script src="/studio.js"></script>','')
        page.set_content(html)
        page.add_script_tag(content=(ROOT/'studio_ui/studio.js').read_text(encoding='utf-8'))
        errors=[]
        page.on('pageerror',lambda err:errors.append(str(err)))
        page.evaluate('''() => {
          const prefix='REFERENCE AUTHORITY — these Picture inputs are authoritative:\\n<Subject 1> is Nyx.';
          document.getElementById('questionArea').innerHTML=`
            <button id="approveReviewTop">Valider</button><button id="approveReview">Valider aussi</button>
            <pre id="clipAuthorityText"></pre><p id="refAuthoritySync"></p>
            <button id="retryClipAuthority" class="hidden">Ressayer</button>
            <textarea id="clipEditText"></textarea><div id="clipEditRefs"></div><div id="clipRefCount"></div>
            <button id="chooseBankRef"></button><button id="openKreaClip"></button>
            <input id="addClipImage" type="file"><input id="addClipAudio" type="file">`;
          initLoraPicker=()=>{};loadAvailableLoras=async()=>{};
          window.previewCalls=0;
          request=async(url)=>{if(url==='/api/reference-preview')window.previewCalls++;return {names:[]}};
          document.getElementById('clipEditText').value=prefix+'\\n\\n**[Shot 1] 0:00–5.0**\\nNyx smiles.';
          wireClipEditor({kind:'clips',id:'c29',payload:{text:document.getElementById('clipEditText').value,authority_prefix:prefix,refs:[],audio_refs:[]}});
        }''')
        assert page.locator('#approveReviewTop').is_enabled()
        assert 'REFERENCE AUTHORITY' in page.locator('#clipAuthorityText').inner_text()
        assert page.locator('#clipEditText').input_value().startswith('**[Shot 1]')
        assert page.evaluate('window.previewCalls')==0
        page.evaluate("document.getElementById('clipEditText').value+='\\nMore words.'")
        payload=page.evaluate('collectClipEdits()')
        assert payload['creative_text'].endswith('More words.')
        assert payload['text'].startswith('REFERENCE AUTHORITY')
        assert not errors,errors
        browser.close()


def test_old_prefix_mismatch_does_not_take_fast_path():
    pytest.importorskip('playwright.sync_api')
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page=browser.new_page()
        page.set_content('<!doctype html><body></body>')
        page.add_script_tag(content=(ROOT/'studio_ui/studio.js').read_text(encoding='utf-8'))
        result=page.evaluate('''() => buildClipDraft({id:'old',payload:{text:'REFERENCE AUTHORITY — older prefix\\n\\n**[Shot 1] 0:00–5.0**',authority_prefix:'REFERENCE AUTHORITY — current prefix'}}).authorityReady''')
        assert result is False
        browser.close()
