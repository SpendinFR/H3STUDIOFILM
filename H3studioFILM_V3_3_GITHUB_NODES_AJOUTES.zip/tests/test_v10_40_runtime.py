"""Actual regression checks for retouch graph shaping, targeted interruption, and FFmpeg."""
import json, pathlib, sys, tempfile, unittest, subprocess
from unittest import mock
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
import retouches_engine as eng
from retouches_workflow_compat import flatten_to_api
from test_v10_37_tracking import mock_h3_info

class Runtime40(unittest.TestCase):
    def test_lanpaint_fast_is_cheaper_than_full(self):
        info=mock_h3_info()
        with mock.patch.object(eng.subprocess,'run',side_effect=OSError('ffprobe unavailable')):
            quick=eng._native_lanpaint_graph(info,'local_edit',pathlib.Path('none.mp4'),{'target':'microphone','quality':'test'})
            full=eng._native_lanpaint_graph(info,'local_edit',pathlib.Path('none.mp4'),{'target':'microphone','quality':'quality'})
        self.assertEqual(quick['10']['inputs']['steps'],8)
        self.assertEqual(quick['12']['inputs']['LanPaint_NumSteps'],1)
        self.assertEqual(full['10']['inputs']['steps'],20)
        self.assertEqual(full['12']['inputs']['LanPaint_NumSteps'],5)

    def test_author_geometry_uses_portrait_source_not_widescreen_selector(self):
        graph={'115':{'class_type':'ResolutionSelector','inputs':{'aspect_ratio':'16:9','megapixels':.4}},
               '136':{'class_type':'MiniMaxH3ReferenceToVideo','inputs':{'width':['115',0],'height':['115',1],'length':124}},
               '92':{'class_type':'SaveVideo','inputs':{'video':['136',0]}}}
        with mock.patch.object(eng,'_video_metadata',return_value={'width':768,'height':1344,'frames':124,'fps':24,'duration':5.2}):
            eng._align_author_geometry(graph,pathlib.Path('portrait.mp4'),'swap_person')
        self.assertEqual(graph['136']['inputs']['width'],768)
        self.assertEqual(graph['136']['inputs']['height'],1344)
        self.assertNotIn('115',graph)

    def test_stop_only_targets_its_own_prompt(self):
        target='a'*32
        row={'id':target,'status':'rendering','prompt_id':'abc'}
        with mock.patch.object(eng,'job',return_value=row), mock.patch.object(eng,'_write_job'),mock.patch.object(eng,'comfy_json') as http:
            x=eng.stop(target)
            self.assertEqual(x['status'],'cancelling')
            self.assertEqual(http.call_args_list[0].args,('/queue',{'delete':['abc']}))
            self.assertEqual(http.call_args_list[1].args,('/interrupt',{'prompt_id':'abc'}))
            self.assertNotIn(('interrupt',{}),[x.args for x in http.call_args_list])
        eng.CANCELLED.discard(target)

    def test_crossview_subgraph_unlinked_moge_creates_model_loader(self):
        ui={'nodes':[{'id':1,'type':'nested','inputs':[{'name':'moge_model','link':None}]},
                      {'id':2,'type':'SaveVideo','inputs':[{'name':'video','link':4}]}],
            'links':[[4,1,0,2,0,'VIDEO']],
            'definitions':{'subgraphs':[{'id':'nested','inputs':[{'name':'moge_model','type':'MOGE_MODEL'}],
                                        'nodes':[], 'links':[[42,-10,0,-20,0,'MOGE_MODEL']],
                                        'outputs':[{'name':'video','linkIds':[42]}]}]}}
        info={'SaveVideo':{'input':{'required':{'video':['VIDEO']},'optional':{}}},
              'LoadMoGeModel':{'input':{'required':{'model_name':[['moge_2_vitl_normal_fp16.safetensors']]},'optional':{}}}}
        graph=flatten_to_api(ui,info,eng._widget_inputs)
        self.assertEqual(graph['1_auto_moge_0']['inputs']['model_name'],'moge_2_vitl_normal_fp16.safetensors')

    def test_ffmpeg_exact_frame_count_and_portrait(self):
        with tempfile.TemporaryDirectory() as temp:
            root=pathlib.Path(temp);source=root/'source.mp4'
            command=['ffmpeg','-v','error','-y','-f','lavfi','-i','testsrc2=size=224x384:rate=24',
                     '-f','lavfi','-i','sine=frequency=440:sample_rate=32000','-frames:v','55',
                     '-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',str(source)]
            proc=subprocess.run(command,capture_output=True,text=True,timeout=30)
            self.assertEqual(proc.returncode,0,proc.stderr)
            with mock.patch.object(eng,'JOBS_ROOT',root/'jobs'):
                out=eng._prepare_shot(source,{'mode':'local_edit','shot_start':0,'shot_end':0},root,'f'*32)
            m=eng._video_metadata(out)
            self.assertEqual(m['frames'],56)
            self.assertLess(m['width'],m['height'])

if __name__=='__main__':unittest.main()
