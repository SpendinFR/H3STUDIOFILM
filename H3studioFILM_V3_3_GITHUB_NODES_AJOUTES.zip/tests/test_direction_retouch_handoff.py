"""Offline regression tests: no ComfyUI, Ollama, GPU, or user files modified."""
from __future__ import annotations
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import h3film_studio_v3 as film
import studio_web as web
import retouches_next


def node(typ,**inputs):return {'class_type':typ,'inputs':inputs,'_meta':{'title':''}}

def fake_hd_graph():
    g={
       '159':node('H3StudioImageToVideo',prompt='test',v2v_video_file='',motion_context_file=''),
       '180':node('ManualSigmas',sigmas='0.9035, 0.8, 0.63, 0.31, 0'),
       '176':node('BasicScheduler',model=['127',0],steps=8),
       '183':node('LTXVSeparateAVLatent',av_latent=['gate',0]),
       '184':node('MinimaxH3LatentUpscaler3D',latent=['183',0],mode='target dimensions',**{'mode.width':1920,'mode.height':1080,'align':32}),
       '185':node('LTXVConcatAVLatent',video_latent=['184',0],audio_latent=['183',1]),
       '186':node('H3RefineResizeConditioningDropVisualRefs',conditioning=['159',0],target_latent=['185',0]),
       '205':node('H3V15ProjectHardLock',latent=['185',0],conditioning=['186',0],project_name='testproj'),
       '181':node('BasicGuider',model=['127',0],conditioning=['186',0]),
       '187':node('SamplerCustomAdvanced',guider=['181',0],latent_image=['205',0],sigmas=['180',0]),
       '206':node('H3V15ProjectStoreHDTail',latent=['187',0],project_name='testproj'),
       '202':node('H3RawCacheRestore',latent=['206',0]),
       '122':node('VAEDecode',samples=['202',0],vae=['119',0]),
       '121':node('VAEDecodeAudio',samples=['202',0],vae=['120',0]),
       '119':node('VAELoader',vae_name='video'), '120':node('VAELoader',vae_name='audio'),
       '130':node('CreateVideo',images=['122',0],audio=['121',0]),
       '92':node('SaveVideo',video=['130',0],filename_prefix='H3FilmSimple/testproj/clips/clip_0001_VISIBLE_1920'),
       '127':node('UNETLoader',unet_name='model'),
       '207':node('SamplerCustomAdvanced',latent_image=['159',1],sigmas=['176',0]),
       '201':node('H3RawCacheHold',latent=['207',0]),
       'gate':node('H3RawSavedStudioGate',latent=['201',0],raw_video_saved=['rawsave',0]),
       'rawsave':node('SaveVideo',video=['130',0]),
    }
    for key,name in {'159':'H3 STUDIO V12','183':'Split AV latent','202':'RESTAURE CACHE RAW','205':'HARDLOCK HD', '187':'REFINE 4 SIGMA'}.items():
        g[key]['_meta']['title']=name
    return g


def test_opt_in_hd_without_raw_resample():
    with TemporaryDirectory() as root:
        comfy=Path(root)/'ComfyUI'; project=comfy/'output'/'H3FilmSimple'/'testproj'
        raw=project/'raw';raw.mkdir(parents=True)
        (raw/'clip_0001_RAW_MC_00001_.mp4').write_bytes(b'orig' * 1024)
        approved=Path(root)/'approved.mp4';approved.write_bytes(b'approved' * 1024)
        req=project/'_studio'/'gates'/'clip_0001.retouch.requested.json'
        req.parent.mkdir(parents=True);req.write_text('{}')
        graph=fake_hd_graph();seen=[]
        def enqueue(g,client):
            seen.append(g)
            assert sum(v['class_type']=='SamplerCustomAdvanced' for v in g.values())==1
            assert sum(v['class_type']=='H3RawSavedStudioGate' for v in g.values())==0
            assert any(n['class_type']=='H3StudioImageToVideo' and n['inputs'].get('v2v_video_file') for n in g.values())
            return 'mock-pid'
        def write_video(*args,**kw):
            folder,prefix=args[1],args[2];folder.mkdir(parents=True,exist_ok=True)
            (folder/(prefix+'_00001_.mp4')).write_bytes(b'mp4mock' * 2048)
        schema={k:{'input':{'required':({'v2v_video_file':['STRING']} if k=='H3StudioImageToVideo' else {})}} for k in ['H3StudioImageToVideo','H3V15ProjectHardLock','MinimaxH3LatentUpscaler3D','SamplerCustomAdvanced','H3V15ProjectStoreHDTail']}
        with patch.object(film.rt,'http_json',return_value=schema),patch.object(film.rt,'queue_graph',side_effect=enqueue),patch.object(film.rt,'wait_for_disk_video',side_effect=write_video),patch.object(film.rt,'comfy_hard_free'),patch.object(film,'_restore_validated_audio') as audio_fix:
            hd,new_raw,final,mc=film._render_approved_retouch_hd(graph,'159','92',comfy,'testproj',1,'client','',False,(1920,1080),raw,'clip_0001_RAW_MC',req,approved)
        assert new_raw.find('RAW_RETOUCHED_')>=0
        assert hd.find('VISIBLE_1920')>=0 and hd==final
        assert not req.exists()
        assert len(seen)==1
        audio_fix.assert_called_once()
        assert audio_fix.call_args.kwargs['approved'].name.startswith('clip_0001_RAW_RETOUCHED_')
        assert (project/'_studio'/'gates'/'clip_0001.retouch.handoff.json').is_file()
        assert (project/'raw'/'clip_0001_RAW_MC_00001_.mp4').read_bytes()==b'orig'*1024


def test_web_pending_and_approval():
    with TemporaryDirectory() as root:
        comfy=Path(root)/'ComfyUI'; project=comfy/'output'/'H3FilmSimple'/'testproj';project.mkdir(parents=True)
        gate=project/'_studio'/'gates';gate.mkdir(parents=True)
        raw=project/'raw';raw.mkdir();(raw/'clip_0001_RAW_MC_00001_.mp4').write_bytes(b'x'*2048)
        latent=project/'_state';latent.mkdir();(latent/'clip_0001_RAW_LATENT.pt').write_bytes(b'latent')
        session=Path(root)/'studio_sessions'/'session_test';session.mkdir(parents=True)
        web.write_json(session/'active_project.json',{'name':'testproj'})
        web.write_json(session/'stage.json',{'stage':'raw_retouch'})
        web.write_json(gate/'clip_0001.retouch.requested.json',{'session':session.name,'project':'testproj','clip':1,'requested_at':10})
        approved=Path(root)/'approved.mp4';approved.write_bytes(b'x'*2048)
        class Worker:
            def poll(self):return None
        with patch.object(web,'output_dir',return_value=comfy/'output'/'H3FilmSimple'),patch.dict(web.STATE,{'session':session,'proc':Worker()}),patch.object(web.studio_retouch_review,'approved_file',return_value=approved),patch.object(web.retouches_next,'job',return_value={'created_at':20}):
            pending=web.pending_film_retouch('testproj',1)
            assert pending and pending['session']==session
            data=web.project_data('testproj')
            assert data['clips']['1']['raw_pt_present'] and data['clips']['1']['pending_retouch']
            result={'state':'approved','project':'testproj','clip':'1'}
            assert web.publish_film_retouch_approval('new','a'*32,result)
            assert (gate/'clip_0001.retouch.approved.json').is_file()


def test_native_pending_source():
    with TemporaryDirectory() as root:
        comfy=Path(root)/'ComfyUI';project=comfy/'output'/'H3FilmSimple'/'testproj';(project/'_studio'/'gates').mkdir(parents=True)
        (project/'_state').mkdir();(project/'_state'/'clip_0001_RAW_LATENT.pt').write_bytes(b'pt')
        (project/'raw').mkdir();(project/'raw'/'clip_0001_RAW_MC_00001_.mp4').write_bytes(b'mp4')
        session_dir=Path(retouches_next.__file__).resolve().parent/'studio_sessions'/'unit_test_handoff_mock'
        session_dir.mkdir(parents=True,exist_ok=True)
        try:
            (session_dir/'stage.json').write_text(json.dumps({'stage':'raw_retouch'}))
            (project/'_studio'/'gates'/'clip_0001.retouch.requested.json').write_text(json.dumps({'session':session_dir.name,'clip':1,'project':'testproj'}))
            source,latent=retouches_next._project('testproj','1',lambda _n:project,comfy)
            assert source.name.endswith('.mp4') and latent.name.endswith('.pt')
        finally:
            import shutil
            shutil.rmtree(session_dir,ignore_errors=True)

if __name__=='__main__':
    test_opt_in_hd_without_raw_resample()
    test_web_pending_and_approval()
    test_native_pending_source()
    print('OK: H3 retouched HD graph 4sigma (no 8-step sampler), pending RAW, safe approval, native RAW source')
