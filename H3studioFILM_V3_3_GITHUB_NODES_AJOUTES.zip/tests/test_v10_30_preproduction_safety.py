"""Reproducers from real V10.29 report. No GPU, Ollama or ComfyUI needed."""
from pathlib import Path
from unittest.mock import patch
import pytest
import h3film_studio_v3 as film


def _walk(tmp_path, answers, items=None):
    project=tmp_path/'project'; project.mkdir()
    events=[]
    items=items or [{'category':'main_character','name':'La streameuse','description':'streamer'}]
    def choose(title, description, choices, **kwargs):
        events.append((title, choices))
        return next(answers)
    with patch.object(film,'studio_reference_plan',return_value=items), \
         patch.object(film,'studio_ui_choice',side_effect=choose), \
         patch.object(film,'studio_reference_image_prompt',return_value='a coherent streamer') as writer, \
         patch.object(film,'render_krea_reference') as render, \
         patch.object(film,'release_all_text_models_for_h3') as unload, \
         patch.object(film.studio,'publish'):
        ret=film.studio_reference_preproduction({}, {}, [], tmp_path, {}, 'test', project)
        return ret, events, writer, render, unload


@pytest.mark.parametrize('answers', [
    ['', 'c', '__BACK_TO_KREA_CHOICES__', ''],
    ['', 'i', 'style', '__BACK_TO_KREA_CHOICES__', ''],
    ['', 'i', '__BACK_TO_KREA_CHOICES__', ''],
])
def test_back_then_no_reference_never_calls_gpu_or_writer(tmp_path, answers):
    result, events, writer, render, unload=_walk(tmp_path,iter(answers))
    assert result[0]==[]
    assert render.call_count==writer.call_count==unload.call_count==0
    assert len([t for t,_ in events if t.startswith('PERSONNAGE PRINCIPAL')])==2
    assert (tmp_path/'project'/'refs'/'static_refs.json').exists()


def test_skip_first_item_does_not_keep_krea_intent_for_next_item(tmp_path):
    items=[{'category':'main_character','name':'La streameuse'},
           {'category':'decor','name':'studio'}]
    result, events, writer, render, unload=_walk(
        tmp_path,iter(['','i','transform','__BACK_TO_KREA_CHOICES__','','']),items)
    assert result[0]==[]
    assert render.call_count==unload.call_count==writer.call_count==0
    assert len([t for t,_ in events if t.startswith('DÉCOR')])==1


def test_krea_gpu_ready_without_busy_memory_keeps_original_flow():
    with patch.object(film.rt,'query_gpu_vram',return_value={'used':2000,'free':14000,'total':16000}) as stats, \
         patch.object(film.time,'sleep') as wait:
        film.ensure_krea_gpu_ready(label='Krea')
    assert stats.call_count==1
    wait.assert_not_called()


def test_krea_gpu_waits_for_actual_release_and_does_not_clear_queue():
    readings=[{'used':14500,'free':1500,'total':16000},
              {'used':13000,'free':3000,'total':16000},
              {'used':2500,'free':13500,'total':16000}]
    with patch.object(film.rt,'query_gpu_vram',side_effect=readings), \
         patch.object(film.time,'sleep') as wait, \
         patch.object(film.rt,'http_json') as network:
        film.ensure_krea_gpu_ready(label='Krea',polls=2,interval=0.1)
    assert wait.call_count==2
    network.assert_not_called()


def test_krea_gpu_still_saturated_blocks_before_render_without_interrupt():
    with patch.object(film.rt,'query_gpu_vram',return_value={'used':14500,'free':1500,'total':16000}), \
         patch.object(film.time,'sleep'), \
         patch.object(film.rt,'http_json',return_value={'queue_running':[1],'queue_pending':[1]}) as network:
        with pytest.raises(RuntimeError,match='VRAM encore saturée') as exc:
            film.ensure_krea_gpu_ready(label='Krea',polls=2,interval=0)
    assert '1 actif(s)' in str(exc.value)
    assert network.call_args.args[0].endswith('/queue')
    assert len(network.call_args.args)==1


def test_text_krea_writer_is_byte_equivalent_to_v1019_system_and_payload():
    # New IMAGE roles must never leak into classic txt2img.
    with patch.object(film,'director_text',return_value='the prompt') as call:
        film.studio_reference_image_prompt({}, {'name':'Nyx','category':'main_character'},
                                            {'world_environment':'city'},'')
    assert 'mode' not in call.call_args.args[2]
    assert 'S-REF' not in call.call_args.args[1]
