"""Regression tests for the independent workflow installer, offline only."""
import io
import json
import tempfile
from pathlib import Path
from unittest import TestCase, main, mock
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import retouches_engine as r

class InstallWorkflowsTests(TestCase):
    def test_three_workflows_downloaded_without_dict_hash_error(self):
        payload=json.dumps({'nodes':[{'id':1,'type':'LoadVideo'}],'links':[]}).encode()
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            with mock.patch.object(r,'WF_DIR',root), mock.patch.object(r,'workflow_path',side_effect=lambda mode: root/r.WORKFLOWS[mode]['file']), mock.patch.object(r.urllib.request,'urlopen',side_effect=lambda request,timeout: io.BytesIO(payload)) as opener:
                result=r.install_workflows()
            self.assertEqual(len(result['workflows']),3)
            self.assertEqual([x['status'] for x in result['workflows']],['installé']*3)
            self.assertEqual(opener.call_count,3)
            self.assertTrue((root/'remove_person.json').exists())
            self.assertTrue((root/'swap_person.json').exists())
            self.assertTrue((root/'move_camera.json').exists())

    def test_existing_workflows_are_not_downloaded(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            for m in ('remove_person','swap_person','move_camera'):
                (root/r.WORKFLOWS[m]['file']).write_text('{"nodes":[{"id":1,"type":"SaveVideo"}]}')
            with mock.patch.object(r,'WF_DIR',root), mock.patch.object(r,'workflow_path',side_effect=lambda mode: root/r.WORKFLOWS[mode]['file']), mock.patch.object(r.urllib.request,'urlopen') as opener:
                result=r.install_workflows()
            self.assertEqual(len(result['workflows']),3)
            self.assertTrue(all(x['status']=='existant' for x in result['workflows']))
            opener.assert_not_called()

    def test_bad_json_cannot_mark_workflow_as_installed(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            with mock.patch.object(r,'WF_DIR',root), mock.patch.object(r,'workflow_path',side_effect=lambda mode: root/r.WORKFLOWS[mode]['file']), mock.patch.object(r.urllib.request,'urlopen',side_effect=lambda request,timeout: io.BytesIO(b'<html>not json</html>')):
                result=r.install_workflows()
            self.assertTrue(all(x['status']=='erreur' for x in result['workflows']))
            self.assertEqual(list(root.glob('*.json')),[])

    def test_one_bad_download_does_not_block_the_others(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)
            count=[0]
            def download(req,timeout):
                count[0]+=1
                if count[0]==1:raise OSError('network blocked')
                return io.BytesIO(b'{"nodes":[{"id":1,"type":"SaveVideo"}]}')
            with mock.patch.object(r,'WF_DIR',root), mock.patch.object(r,'workflow_path',side_effect=lambda mode: root/r.WORKFLOWS[mode]['file']), mock.patch.object(r.urllib.request,'urlopen',side_effect=download):
                result=r.install_workflows()
            self.assertEqual([x['status'] for x in result['workflows']],['erreur','installé','installé'])
            self.assertEqual(count[0],3)

if __name__=='__main__':main()
