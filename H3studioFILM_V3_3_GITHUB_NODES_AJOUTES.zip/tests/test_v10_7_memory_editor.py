"""V10.7 CPU-only tests. No GPU, ComfyUI, Ollama or external llama-server."""
import json, tempfile, unittest, sys, threading, urllib.request, time
from http.server import ThreadingHTTPServer
from pathlib import Path
from unittest.mock import patch,call
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import h3film_studio_v3 as film
import studio_web as web

class V107(unittest.TestCase):
    def test_frees_all_models_not_just_clip_backend(self):
        rows=[{'models':[{'name':'gemma4:26b'}]}, {'models':[]}]
        def ps(url,*a,**kw):
            if url.endswith('/api/ps'):return rows.pop(0) if rows else {'models':[]}
            raise AssertionError(url)
        with patch.object(film,'stop_llama_server') as stop,patch.object(film.rt,'unload_all_ollama_models') as unload, \
             patch.object(film.rt,'unload_ollama_model') as unload_one,patch.object(film.rt,'http_json',side_effect=ps), \
             patch.object(film.rt,'print_gpu_vram'),patch.object(film.studio,'enabled',return_value=False),patch.object(film.time,'sleep'):
            film.release_all_text_models_for_h3(label='Before H3')
            stop.assert_called_once_with('Before H3')
            unload.assert_called_once()
            unload_one.assert_called_with('gemma4:26b')
    def test_external_llama_server_causes_safe_refusal(self):
        with patch.object(film,'stop_llama_server'), patch('socket.create_connection') as conn, \
             patch.object(film.rt,'unload_all_ollama_models') as unload:
            with self.assertRaisesRegex(RuntimeError,'llama-server est encore actif'):
                film.release_all_text_models_for_h3(label='Before RAW')
            unload.assert_not_called()

    def test_direct_prompt_edit_without_refs_change_is_exact(self):
        refs=[{'kind':'character','subject_name':'Matt','subject_key':'matt','role':'canonical_identity','picture_order':1,'annotated':'p.png [input]','strength':1.0}]
        old=film.reference_prompt_prefix(refs)+'\n\nShot with Matt'
        edits={'text':'Totally user-edited exact H3 prompt','refs':[{'media':'image','index':0,'name':'Matt'}]}
        with tempfile.TemporaryDirectory() as td:
            prompt,r,a=film.apply_clip_studio_edits({'edits':edits},old,refs,[],Path(td))
        self.assertEqual(prompt,edits['text'])
        self.assertEqual(r,refs)
        self.assertEqual(a,[])
    def test_image_audio_import_rename_remove_and_picture_renumber(self):
        with tempfile.TemporaryDirectory() as td:
            comfy=Path(td);inp=comfy/'input';inp.mkdir()
            (inp/'matt.png').write_bytes(b'image');(inp/'ambient.wav').write_bytes(b'audio')
            old=[{'kind':'character','subject_name':'Matt','subject_key':'matt','role':'canonical_identity','picture_order':1,'annotated':'matt.png [input]','strength':1.0}]
            oldtext=film.reference_prompt_prefix(old)+'\n\nH3 camera move'
            edits={'text':oldtext,'refs':[{'media':'image','path':str(inp/'matt.png'),'name':'New Matt'}, {'media':'audio','path':str(inp/'ambient.wav'),'name':'Narrator'}]}
            prompt,images,audios=film.apply_clip_studio_edits({'edits':edits},oldtext,old,[],comfy)
            self.assertEqual(len(images),1);self.assertEqual(images[0]['picture_order'],1)
            self.assertEqual(images[0]['subject_name'],'New Matt')
            self.assertEqual(audios[0]['subject_name'],'Narrator')
            self.assertIn('<Picture 1>',prompt)
            self.assertIn('New Matt',prompt)
            self.assertNotIn('<Subject 1> is Matt.',prompt)
            self.assertIn('H3 camera move',prompt)
            self.assertIn('ambient.wav [input]',audios[0]['annotated'])
            # removal: explicit empty refs means NONE, not unchanged
            cleared,images,audios=film.apply_clip_studio_edits({'edits':{'text':oldtext,'refs':[]}},oldtext,old,[],comfy)
            self.assertEqual(images,[])
            self.assertEqual(audios,[])
            self.assertEqual(cleared,'H3 camera move')
    def test_ref_paths_outside_comfy_input_are_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            comfy=Path(td)/'comfy';(comfy/'input').mkdir(parents=True)
            external=Path(td)/'outside.png';external.write_bytes(b'test')
            with self.assertRaisesRegex(ValueError,'ComfyUI/input'):
                film.apply_clip_studio_edits({'edits':{'text':'Prompt','refs':[{'media':'image','path':str(external),'name':'X'}]}},'Prompt',[],[],comfy)
    def test_post_review_persists_exact_clip_edits(self):
        with tempfile.TemporaryDirectory() as td:
            session=Path(td);web.write_json(session/'review.json',{'id':'r1','kind':'clips','payload':{'text':'Original'}})
            old_state=dict(web.STATE)
            with web.LOCK:web.STATE['session']=session
            srv=ThreadingHTTPServer(('127.0.0.1',0),web.Handler)
            thread=threading.Thread(target=srv.serve_forever,daemon=True);thread.start()
            try:
                edits={'text':'Modified exact prompt','refs':[{'media':'image','index':0,'name':'A'}]}
                req=urllib.request.Request(f'http://127.0.0.1:{srv.server_port}/api/review',method='POST',
                   data=json.dumps({'id':'r1','action':'continue','edits':edits}).encode(),headers={'Content-Type':'application/json'})
                with urllib.request.urlopen(req,timeout=6) as res:self.assertTrue(json.load(res)['ok'])
                ans=web.json_get(session/'answers'/'r1.json',{})
                self.assertEqual(ans['edits'],edits)
            finally:
                srv.shutdown();srv.server_close();thread.join(2)
                with web.LOCK:web.STATE.clear();web.STATE.update(old_state)
    def test_frontend_prompt_editor_and_right_journal(self):
        root=Path(__file__).resolve().parents[1]/'studio_ui'
        html=(root/'index.html').read_text('utf-8')
        js=(root/'studio.js').read_text('utf-8')
        css=(root/'studio-v10-7.css').read_text('utf-8')
        self.assertIn('class="directorJournal"',html)
        self.assertIn('id="reviewClips" checked',html)
        self.assertIn('clipEditText',js)
        self.assertIn('chooseBankImage',js)
        self.assertIn('collectClipEdits',js)
        self.assertIn('focusDirector()',js)
        self.assertIn('grid-template-columns:0 minmax(0,1fr) minmax(265px,310px)',css)
    def test_latest_retake_context_not_stale_original(self):
        core=(Path(__file__).resolve().parents[1]/'h3film_studio_v3.py').read_text('utf-8')
        self.assertIn('rejected_h3_prompt=h3_prompt',core)
        self.assertIn('h3_prompt=str(retake_state[\'previous_prompt\'])',core)
        self.assertIn('release_all_text_models_for_h3(label=f"Avant nouveau RAW',core)
if __name__=='__main__': unittest.main()
