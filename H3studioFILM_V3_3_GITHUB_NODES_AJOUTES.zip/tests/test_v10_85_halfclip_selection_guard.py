"""Regression tests for the removed 39-frame guard and selected half-clip routing."""
from pathlib import Path
import unittest
import retouches_precise_half_v82 as half

class TestV1085(unittest.TestCase):
    def test_early_1711ms_is_allowed_as_halfclip(self):
        w=half.select_window(37,124,0.0,1.711)
        self.assertEqual((w['frames'],w['origin_frame'],w['local_first']), (63,0,0))
        self.assertEqual(w['last_frame'],41)
        self.assertEqual(w['seam_mode'],'suffix_only')

    def test_late_1711ms_is_allowed_as_halfclip(self):
        w=half.select_window(37,124,3.3,5.011)
        self.assertEqual(w['frames'],63)
        self.assertEqual(w['end_frame'],124)
        self.assertEqual(w['seam_mode'],'prefix_only')

    def test_cross_half_request_rejected_not_cropped(self):
        with self.assertRaisesRegex(ValueError,'chevauche'):
            half.select_window(37,124,1.8,3.4)

    def test_oversized_selection_rejected_not_routed_global(self):
        with self.assertRaisesRegex(ValueError,'chevauche|dépasse'):
            half.select_window(37,124,0.,3.0)

    def test_old_guard_removed_and_halfclip_always_for_selected(self):
        code=(Path(__file__).resolve().parents[1]/'retouches_next.py').read_text(encoding='utf-8')
        self.assertNotIn('Limite actuelle : 39 images / 1,625s',code)
        self.assertNotIn("row.get('selected') and (end-start)<=meta['duration']/2+0.05",code)
        self.assertIn("and row.get('selected')):",code)

    def test_essai_raw_guard_preserved(self):
        code=(Path(__file__).resolve().parents[1]/'retouches_next.py').read_text(encoding='utf-8')
        self.assertIn('Essai RAW 39 images réservé aux 1,6 premières secondes',code)

if __name__=='__main__':
    unittest.main()
