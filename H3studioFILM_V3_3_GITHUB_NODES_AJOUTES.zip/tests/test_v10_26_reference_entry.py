"""Regression tests at the Content -> Reference Planner transition.
No ComfyUI, Ollama or GPU is required.
"""
from pathlib import Path
from unittest.mock import patch
import h3film_studio_v3 as film


def _run_preproduction(tmp_path, answers, item=None):
    project = tmp_path / 'project'
    project.mkdir()
    actions = []
    events = []
    item = item or {'category': 'main_character', 'name': 'Nyx', 'description': 'Woman with dark hair'}
    def choose(title, desc, opts, **kwargs):
        actions.append(title)
        return next(answers)
    with patch.object(film, 'studio_reference_plan', return_value=[item]), \
         patch.object(film, 'studio_ui_choice', side_effect=choose), \
         patch.object(film.studio, 'publish', side_effect=lambda *a,**k: events.append(a)), \
         patch.object(film, 'render_krea_reference') as render, \
         patch.object(film, 'studio_reference_image_prompt') as writer:
        result = film.studio_reference_preproduction({}, {}, [], tmp_path, {}, 'demo', project)
    return actions, events, result, render, writer


def test_content_to_reference_planner_publishes_status_before_model_returns(tmp_path):
    project = tmp_path/'project'; project.mkdir()
    with patch.object(film, 'studio_reference_plan', return_value=[]) as planner, \
         patch.object(film.studio, 'publish') as publish:
        film.studio_reference_preproduction({}, {}, [], tmp_path, {}, 'demo', project)
    assert planner.call_count == 1
    assert publish.call_args_list[0].args[0] == 'reference_planning'
    assert any(x.args[0] == 'references_ready' for x in publish.call_args_list)
    assert (project/'preproduction'/'reference_plan.json').is_file()


def test_back_from_krea_mode_returns_to_reference_choice_without_hanging(tmp_path):
    actions, events, result, render, writer = _run_preproduction(
        tmp_path, iter(['', 'i', '__BACK_TO_KREA_CHOICES__', '']))
    assert len([x for x in actions if x.startswith('PERSONNAGE PRINCIPAL')]) == 2
    assert any(x.startswith('Mode Krea + image source') for x in actions)
    assert render.call_count == 0
    assert writer.call_count == 0
    assert result[0] == []


def test_empty_mode_choice_exits_to_reference_choice(tmp_path):
    actions, _, _, render, _ = _run_preproduction(tmp_path, iter(['', 'i', '', '']))
    assert len(actions) == 4
    assert render.call_count == 0


def test_back_from_image_source_returns_to_initial_choice(tmp_path):
    actions, _, _, render, _ = _run_preproduction(
        tmp_path, iter(['', 'i', 'style', '__BACK_TO_KREA_CHOICES__', '']))
    assert len([x for x in actions if x.startswith('PERSONNAGE PRINCIPAL')]) == 2
    assert render.call_count == 0


def test_text_krea_prompt_writer_does_not_receive_new_style_metadata():
    item = {'category':'decor','name':'Classroom'}
    with patch.object(film, 'director_text', return_value='A classroom') as director:
        result = film.studio_reference_image_prompt({}, item, {'world_environment':'school'}, '')
    assert result == 'A classroom'
    args = director.call_args.args
    assert '"mode"' not in args[2]
    assert '"source_image_role"' not in args[2]
    assert 'En mode STYLE' not in args[1]


def test_style_prompt_writer_receives_mode_and_world():
    item = {'category':'element','name':'Pen'}
    with patch.object(film, 'director_text', return_value='A pen') as director:
        film.studio_reference_image_prompt({}, item, {'world_environment':'school'}, 'modern pen', mode='style')
    import json
    payload = json.loads(director.call_args.args[2])
    assert payload['mode'] == 'style'
    assert payload['bible']['world_environment'] == 'school'
    assert payload['source_image_role'] == 'style_only_not_subject'
