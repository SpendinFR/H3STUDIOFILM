"""V10.24 regressions: classic Krea, preproduction back, edited dialogues reviewed.

These tests never start a GPU render or touch existing H3/ComfyUI workflows.
"""
import hashlib
from pathlib import Path
from unittest.mock import patch
import h3film_studio_v3 as film

ROOT=Path(__file__).resolve().parents[1]


def test_classic_krea_workflow_unchanged_from_v19():
    # Immutable reference from the delivered V10.19/V10.23 classic txt2img workflow.
    old='e9cb3c2ac928124d97f826801a141f656469f31fd9a7223b205564a8aefbe539'
    assert hashlib.sha256((ROOT/'workflows'/'Krea_reference.json').read_bytes()).hexdigest()==old


def test_preproduction_back_from_precisions_returns_to_choice_and_does_not_render(tmp_path):
    project_dir=tmp_path/'movie';project_dir.mkdir()
    item={'category':'main_character','name':'L Homme','description':'An adult male'}
    calls=[]
    answers=iter(['', 'c','__BACK_TO_KREA_CHOICES__', 'c','pink shirt', 'n'])
    def choice(title,description,options,**kw):
        calls.append(title)
        return next(answers)
    fake_img=tmp_path/'fake.png';fake_img.write_bytes(b'fake')
    with patch.object(film,'studio_reference_plan',return_value=[item]), \
         patch.object(film,'studio_ui_choice',side_effect=choice), \
         patch.object(film,'studio_reference_image_prompt',return_value='a person in a pink shirt') as writer, \
         patch.object(film,'release_all_text_models_for_h3'), \
         patch.object(film,'render_krea_reference',return_value=fake_img) as render, \
         patch.object(film,'_open_image_preview'), \
         patch.object(film.studio,'publish'):
        film.studio_reference_preproduction({}, {}, [], tmp_path, {}, 'demo', project_dir)
    assert sum('Précisions Krea' in t for t in calls)==2
    assert sum('PERSONNAGE PRINCIPAL —' in t for t in calls)==2
    assert writer.call_count==1
    assert render.call_count==1
    assert render.call_args.kwargs['source_image'] is None
    assert calls[-1].startswith('Image Krea')


def test_director_revised_dialogues_are_presented_for_approval_before_render():
    src=(ROOT/'h3film_studio_v3.py').read_text(encoding='utf8')
    ui=(ROOT/'studio_ui'/'studio.js').read_text(encoding='utf8')
    assert 'initial_dialogue_auto_modified = clip_prompt != initial_dialogue_before' in src
    assert 'force=initial_dialogue_auto_modified' in src
    assert "h3_prompt = _show_corrected_dialogue(dialogue_before_validation,h3_prompt,'validation')" in src
    assert "h3_prompt=_show_corrected_dialogue(final_before_gate,h3_prompt,'avant H3')" in src
    assert "force=True" in src[src.index('def _show_corrected_dialogue'):src.index('# An already requested RAW retake')]
    assert src.index("h3_prompt=_show_corrected_dialogue(final_before_gate,h3_prompt,'avant H3')") < src.index('video_ann, raw_ann, cumulative_final_ann, used_mc = render_clip(')
    assert "'dialogue_previous':before" in src
    assert "dialogue_gate.check(candidate)" in src
    assert 'dialogueAutoInfo' in ui and 'Avant :' in ui and 'Après :' in ui
    assert 'backKreaPrecisions' in ui and '__BACK_TO_KREA_CHOICES__' in src


def test_preproduction_krea_source_mode_choice_is_available_and_forwarded(tmp_path):
    project_dir=tmp_path/'movie';project_dir.mkdir()
    item={'category':'decor','name':'Salle de classe','description':'A classroom'}
    calls=[]
    answers=iter(['', 'i','style','f','/tmp/source.png','modern classroom', 'n'])
    def choice(title,description,options,**kw):
        calls.append(title)
        return next(answers)
    fake_img=tmp_path/'fake.png';fake_img.write_bytes(b'fake')
    source=Path('/tmp/source.png');source.write_bytes(b'x')
    with patch.object(film,'studio_reference_plan',return_value=[item]),          patch.object(film,'studio_ui_choice',side_effect=choice),          patch.object(film,'studio_reference_image_prompt',return_value='modern classroom photo') as writer,          patch.object(film,'release_all_text_models_for_h3'),          patch.object(film,'render_krea_reference',return_value=fake_img) as render,          patch.object(film,'_open_image_preview'),          patch.object(film.studio,'publish'):
        film.studio_reference_preproduction({}, {'world_environment':'late afternoon school'}, [], tmp_path, {}, 'demo', project_dir)
    assert any('Mode Krea + image source' in t for t in calls)
    assert any('Image source pour' in t for t in calls)
    assert writer.call_args.kwargs['mode']=='style'
    assert render.call_args.kwargs['mode']=='style'
    assert render.call_args.kwargs['source_image']==source


def test_question_sheet_has_back_button_for_source_choice_and_mode_step():
    ui=(ROOT/'studio_ui'/'studio.js').read_text(encoding='utf8')
    src=(ROOT/'h3film_studio_v3.py').read_text(encoding='utf8')
    assert 'backKreaSourceChoice' in ui
    assert '__BACK_TO_KREA_CHOICES__' in ui
    assert 'Mode Krea + image source' in src
