import pathlib, sys, tempfile, unittest
from unittest.mock import patch
from PIL import Image
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_clean_plate as c
import retouches_masked_core as m
import retouches_engine as e


def fake_objectinfo():
    info={}
    kinds={
        'LoadImage':['image'], 'LoadImageMask':['image','channel'],
        'UNETLoader':['unet_name','weight_dtype'],
        'CLIPLoader':['clip_name','type','device'], 'VAELoader':['vae_name'],
        'CLIPTextEncode':['clip','text'], 'ConditioningZeroOut':['conditioning'],
        'VAEEncodeForInpaint':['pixels','vae','mask','grow_mask_by'],
        'LanPaint_KSampler':['model','seed','steps','cfg','sampler_name','scheduler','positive','negative',
                             'latent_image','denoise','LanPaint_NumSteps','LanPaint_PromptMode',
                             'Inpainting_mode','LanPaint_Info'],
        'VAEDecode':['samples','vae'], 'SaveImage':['images','filename_prefix']}
    for n,keys in kinds.items():
        info[n]={'input':{'required':{k:['STRING',{}] for k in keys}}}
    info['UNETLoader']['input']['required']['unet_name']=['COMBO',{'options':[c.KREA_MODEL]}]
    info['CLIPLoader']['input']['required']['clip_name']=['COMBO',{'options':[c.KREA_CLIP]}]
    info['VAELoader']['input']['required']['vae_name']=['COMBO',{'options':[c.KREA_VAE]}]
    return info

class CleanPlate(unittest.TestCase):
    def test_krea2_lanpaint_graph_uses_generative_masked_inpaint(self):
        g=c.graph(fake_objectinfo(),'first.png','mask.png','woman','a'*32)
        self.assertEqual(g['8']['class_type'],'VAEEncodeForInpaint')
        self.assertEqual(g['9']['class_type'],'LanPaint_KSampler')
        self.assertEqual(g['9']['inputs']['latent_image'],['8',0])
        self.assertEqual(g['3']['inputs']['unet_name'],c.KREA_MODEL)
        self.assertEqual(g['6']['inputs']['clip'],['4',0])
        self.assertIn('woman',g['6']['inputs']['text'])
        self.assertFalse(any(n['class_type']=='ImageCompositeMasked' for n in g.values()))

    def test_missing_model_prevents_run(self):
        info=fake_objectinfo()
        info['UNETLoader']['input']['required']['unet_name'][1]['options']=[]
        # Empty options can occur with a stale ComfyUI schema. A strong missing test uses another value.
        info['UNETLoader']['input']['required']['unet_name'][1]['options']=['unrelated.safetensors']
        with self.assertRaisesRegex(RuntimeError,'krea2_turbo'):
            c.validate(info)

    def test_remove_precheck_does_not_require_clean_plate(self):
        with patch.object(m,'_make',side_effect=lambda i,t,**a:{'class_type':t,'inputs':a}):
            g=m.build({},'remove_person','src.mp4',None,'woman','remove her','Singularity_ref2va.safetensors',
                      frames=22,width=736,height=1280)
        self.assertNotIn('32',g)
        self.assertNotIn('ref_images.ref_image_0',g['33']['inputs'])
        self.assertEqual(g['10']['class_type'],'SaveImage')

    def test_generator_stages_png_after_mocked_comfy_output(self):
        with tempfile.TemporaryDirectory() as td:
            root=pathlib.Path(td); (root/'input').mkdir();(root/'output').mkdir()
            src=root/'source.mp4';src.touch()
            tracked=root/'tracked.png'
            Image.new('L',(96,64),0).save(tracked)
            with Image.open(tracked) as msk:
                msk.paste(255,(20,10,65,60));msk.save(tracked)
            generated=root/'output'/'fake_gen.png'
            Image.new('RGB',(96,64),(28,71,135)).save(generated)
            submitted=[]
            def submit(g):submitted.append(g);return {'prompt_id':'synthetic'}
            history={'outputs':{'11':{'images':[{'filename':'fake_gen.png','subfolder':'','type':'output'}]}}}
            with patch.object(c,'extract_frame',side_effect=lambda source,dst: Image.new('RGB',(96,64),(212,140,30)).save(dst) or dst):
                out=c.prepare(src,[tracked],'a'*32,root,fake_objectinfo(),'woman',submit,lambda pid:history)
            self.assertTrue(out.is_file())
            with Image.open(out) as generated:
                self.assertEqual(generated.size,(96,64))
            self.assertEqual(submitted[0]['9']['class_type'],'LanPaint_KSampler')
            self.assertTrue((root/'input'/('retouches_'+'a'*32+'_initial_mask.png')).is_file())

    def test_original_studio_and_crossview_untouched(self):
        self.assertIn('build_crossview_graph',e._run.__code__.co_names)

if __name__=='__main__':unittest.main()
