"""V10.77: short Action/Emotion prompts; stable V10.75 RAW graph, no installer/IO."""
import hashlib, json, sys, unittest, copy
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_llm_prompt_short_v77 as short
import retouches_next as engine

SOURCE="""[Shot 1] 0.000–2.500s Dans un jardin, une danseuse tourne lentement.
[Shot 2] 2.500–5.167s Elle avance vers la sortie.
**look_caméra_et_lumière :** plan moyen, lumière du soir.
**soundscape_global :** musique douce."""
SCENE='Danseuse dans un jardin, plan moyen, lumière du soir, musique douce.'
ACTION='La danseuse effectue une rotation vive du bras droit pendant son déplacement, en continuant son mouvement de danse.'
EMOTION='Sa respiration se tend, son regard devient inquiet et ses épaules se contractent visiblement.'

class TestV1077(unittest.TestCase):
    def test_user_timings_and_source_only_sent_to_gemma(self):
        for typ in ('action','emotion'):
            instruction=short.build_request(typ,'regarde la porte',SOURCE,.417,1.578,5.167)
            self.assertIn('0.417–1.578s',instruction)
            self.assertIn(SOURCE,instruction)
            self.assertIn('regarde la porte',instruction)

    def test_generated_h3_action_prompt_short(self):
        gemma='SCENE_CONTEXT: '+SCENE+'\nCHANGE: '+ACTION
        prompt=short.assemble('action','fait un geste',gemma,.417,1.578,5.167)
        self.assertIn('<Video 1>',prompt)
        self.assertIn(ACTION,prompt)
        self.assertIn('0.417–1.578s',prompt)
        self.assertIn('0.000–5.167s',prompt)
        self.assertNotIn('[Shot',prompt)
        self.assertNotIn(SOURCE,prompt)
        self.assertNotIn('Keep unaffected actions and dialogue',prompt)
        self.assertLess(len(prompt),1250)

    def test_generated_h3_emotion_prompt_does_not_protect_old_actor_play(self):
        gemma='SCENE_CONTEXT: '+SCENE+'\nCHANGE: '+EMOTION
        prompt=short.assemble('emotion','emotion changée',gemma,.417,1.578,5.167)
        self.assertIn('NEW TAKE — EMOTIONAL PERFORMANCE',prompt)
        self.assertIn(EMOTION,prompt)
        self.assertNotIn('Keep unaffected actions and dialogue',prompt)
        self.assertNotIn('Preserve original facial expressions',prompt)
        self.assertIn('not the original facial acting',prompt)
        self.assertIn('0.000–5.167s',prompt)
        self.assertNotIn(SOURCE,prompt)
        self.assertNotIn('[Shot',prompt)
        self.assertLess(len(prompt),1250)

    def test_bad_gemma_output_fails_before_h3(self):
        for bad in ('SCENE_CONTEXT: lieu seulement',
                'SCENE_CONTEXT: '+SCENE+'\nCHANGE: trop court',
                'SCENE_CONTEXT: '+SCENE+'\nCHANGE: '+ACTION+'\n[Shot 1] 0–5 Elle marche',
                'SCENE_CONTEXT: '+SCENE+'\nCHANGE: '+('a'*461)):
            with self.subTest(bad=bad[:60]):
                with self.assertRaises(ValueError):short.parse_output(bad)

    def test_gemma_backend_filmstudio_unloads_even_after_error(self):
        import h3film_studio_v3 as film
        called=[]
        fake={'display':'gemma4:26b-a4b-it-q4_K_M','provider':'ollama'}
        with patch.object(short.stable,'choose_backend',return_value=fake),\
             patch.object(film,'director_text',return_value='SCENE_CONTEXT: '+SCENE+'\nCHANGE: '+ACTION),\
             patch.object(film,'unload_text_backend',side_effect=lambda *a,**k:called.append('unload')),\
             patch.object(film,'release_all_text_models_for_h3',side_effect=lambda *a,**k:called.append('free')):
            prompt,label=short.write_prompt(mode='performance',performance_type='action',request='fait un geste',
                source_prompt=SOURCE,start=.417,end=1.578,duration=5.167,gpu_prepare=lambda:called.append('prepare'))
        self.assertEqual(called,['prepare','unload','free'])
        self.assertIn(ACTION,prompt)
        self.assertIn('Gemma 26B',label)

    def test_safety_no_new_nodes_software_installer_or_python_deps(self):
        base=Path('/mnt/data/_v75')
        original=set(p.relative_to(base).as_posix() for p in base.rglob('*') if p.is_file())
        result=set(p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file())
        for name in ('h3film_studio_v3.py','studio_web.py','retouches_engine.py','studio_retouches.py',
                     'retouches_masked_core.py','retouches_roycho_complete_v63.py',
                     'workflows/H3Studio_1920_API_CLEAN.json',
                     'retouches_new_insert_guide.py','INSTALLER-NOUVEAUX-MOTEURS-V10_66.ps1',
                     'custom_nodes/H3StudioRetouchExtras/__init__.py'):
            self.assertEqual((base/name).read_bytes(),(ROOT/name).read_bytes(),name)
        old_nodes={x for x in original if x.startswith('custom_nodes/')}
        new_nodes={x for x in result if x.startswith('custom_nodes/')}
        self.assertEqual(old_nodes,new_nodes)
        cmd=(ROOT/'LANCER-RETOUCHES-V10_77.cmd').read_text('utf-8')
        self.assertIn('studio_web.py',cmd)
        self.assertNotIn('pip install',cmd)
        self.assertNotIn('INSTALLER-DIFFSYNTH',cmd.upper())
        self.assertNotIn('H3RetouchEmotionLatentFreedomV76', (ROOT/'retouches_next.py').read_text('utf-8'))

    def test_same_mask_scheduler_reference_as_v75(self):
        self.assertTrue(engine._full_clip_h3_for_performance('performance','action'))
        self.assertTrue(engine._full_clip_h3_for_performance('performance','emotion'))
        self.assertFalse(engine._full_clip_h3_for_performance('performance','dialogue'))
        self.assertEqual(engine._auto_rect('performance','très anxieux'),(0,0,100,100))
        text=(ROOT/'retouches_next.py').read_text('utf-8')
        self.assertIn("import retouches_llm_prompt_short_v77 as llm_writer",text)
        self.assertIn("import retouches_llm_prompt_v74 as llm_writer",text)
        self.assertIn("graph['207']['inputs']['latent_image']=['906',0] if mode=='insert' else ['902',0]",text)
        self.assertIn("'track':kind",text)
        self.assertIn("'ref_video_files'",text)
        self.assertIn("'v2v_denoise'",text)

if __name__=='__main__':unittest.main()
