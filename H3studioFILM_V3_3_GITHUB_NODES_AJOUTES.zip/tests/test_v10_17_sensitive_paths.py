"""V10.17: protect voice identities, VLM scope, timeline and Krea wiring."""
import copy
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from unittest.mock import patch

import pytest
import h3film_studio_v3 as film
import studio_timeline_extension as ext


TWO_SPEAKERS = '''**[Shot 1] 0.00–2.50**
Nyx (S1) says: <d>Follow that cable, now.</d>
**[Shot 2] 2.50–5.00**
Matt (S2) says: <d>I can see it clearly.</d>'''


def test_multispeaker_shots_are_independent_voice_windows(tmp_path):
    calls=[]
    def fake_stage(*args,**kwargs):
        calls.append((args[4],kwargs['segment_start_s'],kwargs['segment_duration_s']))
        return {'kind':'voice','subject_name':args[4]}
    with patch.object(film,'stage_dynamic_voice_ref',side_effect=fake_stage):
        bank=film.maybe_capture_voice_reference({'voices':{},'history':[]},TWO_SPEAKERS,
          {'characters':'Nyx, Matt'},{},['Nyx','Matt'],['Nyx','Matt'],
          tmp_path/'video.mp4',False,tmp_path,'demo',4)
    assert calls==[('Nyx',0,2.5),('Matt',2.5,2.5)]
    assert set(bank['voices'])=={'Nyx','Matt'}
    assert all(row['kind']!='voice_deferred' for row in bank['history'])


def test_multispeaker_does_not_fabricate_window_from_nondialogue():
    prompt='''**[Shot 1] 0.00–2.50**
Nyx looks at Matt.\n**[Shot 2] 2.50–5.00**
Matt speaks but no actual quote follows.'''
    assert film.clean_single_speaker_shot_segments(prompt,['Nyx','Matt'],{}, {},['Nyx','Matt'])==[]


def test_h3_shot_ranges_accept_decimal_and_last_block():
    parsed=film._h3_prompt_shot_windows(TWO_SPEAKERS)
    assert [(a,b) for a,b,_ in parsed]==[(0,2.5),(2.5,5)]


def test_appearance_windows_never_skip_visual_identity_check():
    paths=[Path(f'obs_{i:02d}_t{i/2:.3f}s.jpg') for i in range(10)]
    shots='''**[Shot 1] 0.00–2.50** Nyx watches the screen.
**[Shot 2] 2.50–5.00** Matt runs away.'''
    seen=[]
    def visual(model,system,user,images,**kw):
        seen.append(list(images))
        return {'confidence':'LOW','usable_image_numbers':[]}
    with patch.object(film.rt,'ollama_json_images',side_effect=visual):
        result=film.select_character_appearance_frames('vision','Nyx',paths,{}, {},shots,
            candidate_characters=['Nyx','Matt'])
    assert result==[] and seen
    assert all(float(f.name.split('_t')[1].split('s.')[0])<=2.65 for f in seen[0])
    assert len(seen[0])<=3


def test_appearance_high_confidence_selects_target_within_window():
    paths=[Path(f'obs_{i:02d}_t{i/2:.3f}s.jpg') for i in range(10)]
    with patch.object(film.rt,'ollama_json_images',return_value={
        'confidence':'HIGH','usable_image_numbers':[2]}):
        chosen=film.select_character_appearance_frames('vision','Matt',paths,{}, {},TWO_SPEAKERS,
            candidate_characters=['Nyx','Matt'])
    assert len(chosen)==1
    assert 2.35<=film._observer_frame_timestamp(chosen[0])<=5.0


def test_visual_state_gate_checks_identity_match(monkeypatch):
    frame=[Path('frame.jpg')]
    monkeypatch.setattr(film.rt,'ollama_json_images',lambda *a,**kw:{
        'accept':True,'quality':'GOOD','visibility':'CLEAR','identity_match':False,'best_image_number':1})
    assert not film.assess_character_appearance_visual('vision','Nyx','jacket',frame,{},{}).get('accept')
    monkeypatch.setattr(film.rt,'ollama_json_images',lambda *a,**kw:{
        'accept':True,'quality':'GOOD','visibility':'CLEAR','identity_match':True,'best_image_number':1})
    assert film.assess_character_appearance_visual('vision','Nyx','jacket',frame,{},{}).get('accept')


def test_extension_trims_only_unrendered_suffix_and_has_no_side_effects():
    content={'parts':[
      {'part':1,'kind':'ACTE','name':'one','start_seconds':0,'end_seconds':30,
       'duration_seconds':30,'start':'00:00','end':'00:30'},
      {'part':2,'kind':'ACTE','name':'two','start_seconds':30,'end_seconds':60,
       'duration_seconds':30,'start':'00:30','end':'01:00'}]}
    scenes=[{'scene':i+1,'start_seconds':i*15,'end_seconds':(i+1)*15} for i in range(4)]
    before=copy.deepcopy((content,scenes))
    new,part=ext.extension_part(content,scenes,2,60,'Nouvelle progression',film.tc)
    assert new['requested_duration_seconds']==120
    assert part['start_seconds']==30 and part['end_seconds']==120
    assert len(new['parts'])==2 and new['parts'][0]['end_seconds']==30
    assert (content,scenes)==before


def test_extension_mid_act_only_preserves_rendered_prefix():
    c={'parts':[{'part':1,'kind':'ACTE','start_seconds':0,'end_seconds':60,
       'duration_seconds':60,'start':'00:00','end':'01:00'}]}
    scenes=[{'scene':i+1,'start_seconds':i*20,'end_seconds':(i+1)*20} for i in range(3)]
    new,part=ext.extension_part(c,scenes,1,30,'Ralentir',film.tc)
    assert len(new['parts'])==2 and new['parts'][0]['end_seconds']==20
    assert part['start_seconds']==20 and part['end_seconds']==90


def test_extension_requires_full_valid_temporal_scene_coverage():
    part={'start_seconds':20,'end_seconds':60}
    good=[{'scene':2,'start_seconds':20,'end_seconds':40},
          {'scene':3,'start_seconds':40,'end_seconds':60}]
    ext.validate_future_scenes(good,part,2)
    bad=copy.deepcopy(good);bad[1]['start_seconds']=45
    with pytest.raises(ValueError,match='trou'):
        ext.validate_future_scenes(bad,part,2)


def test_extension_pending_rejects_bad_duration(tmp_path):
    path=ext.pending_path(tmp_path)
    ext.atomic_json(path,{'extra_seconds':23,'instructions':'Réorganiser'})
    with pytest.raises(ValueError,match='multiple'):
        ext.read_pending(tmp_path)


def test_krea_image_workflow_has_separate_primary_latent_route():
    base=json.loads(film.KREA_REFERENCE_WORKFLOW.read_text(encoding='utf8'))
    image=json.loads(film.KREA_REFERENCE_IMG_WORKFLOW.read_text(encoding='utf8'))
    assert len(image['nodes'])==len(base['nodes'])+3
    assert next(x for x in base['links'] if x[0]==79)[1]==57
    assert next(x for x in image['links'] if x[0]==79)[1]==93
    assert {node['type'] for node in image['nodes']}-{node['type'] for node in base['nodes']}=={'LoadImage','VAEEncode'}
    assert next(x for x in image['links'] if x[0]==156)[1]==58


def test_krea_reference_img2img_api_keeps_text_to_image_unmodified(tmp_path,monkeypatch):
    api_template={
        '29':{'class_type':'SaveImage','inputs':{'images':['56',0],'filename_prefix':'Krea'},},
        '56':{'class_type':'VAEDecode','inputs':{'samples':['77',0],'vae':['58',0]}},
        '77':{'class_type':'KSampler','inputs':{'latent_image':['54',0],'seed':1,'denoise':0.3}},
        '54':{'class_type':'KSampler','inputs':{'latent_image':['93',0],'positive':['51',0],'seed':2,'denoise':1.0}},
        '93':{'class_type':'VAEEncode','inputs':{'pixels':['92',0],'vae':['58',0]}},
        '92':{'class_type':'ImageScale','inputs':{'image':['91',0]}},
        '91':{'class_type':'LoadImage','inputs':{'image':'placeholder'}},
        '58':{'class_type':'VAELoader','inputs':{'vae_name':'qwen_image_vae.safetensors'}},
        '51':{'class_type':'CLIPTextEncode','inputs':{'text':'old'}},
    }
    # The real project file is untouched, image path is duplicated under comfy/input.
    src=tmp_path/'source.jpg';src.write_bytes(b'jpeg-test')
    output=tmp_path/'result.png';output.write_bytes(b'png-test')
    captured=[]
    def fake_queue(api,*a):
        captured.append(copy.deepcopy(api));return 'id'
    monkeypatch.setattr(film.rt,'gui_to_api',lambda gui,obj:copy.deepcopy(api_template))
    monkeypatch.setattr(film.rt,'comfy_hard_free',lambda *a,**kw:None)
    monkeypatch.setattr(film.rt,'queue_graph',fake_queue)
    monkeypatch.setattr(film,'_wait_comfy_image',lambda *a,**kw:{'filename':'result.png'})
    monkeypatch.setattr(film.rt,'annotated_name',lambda item:'result.png [output]')
    monkeypatch.setattr(film.rt,'annotated_to_path',lambda comfy,ann:output)
    path=film.render_krea_reference(tmp_path,{},'demo','Nyx','main_character','Keep Nyx in a blue jacket',1,source_image=src)
    assert path==output
    assert captured[0]['54']['inputs']['denoise']==0.55
    assert captured[0]['77']['inputs']['denoise']==0.3
    assert captured[0]['91']['inputs']['image'].startswith('H3FilmSimple/demo/studio_krea_sources/')
    assert captured[0]['93']['inputs']['vae']==['58',0]


def test_actual_h3_shot_clock_notation_routes_voice_and_frames():
    # This is the production notation from previous Clip Director prompts.
    prompt = """**[Shot 1] 0:00–2.5s**
Nyx (S1) says: <d>Follow that cable, now.</d>
**[Shot 2] 2.5s–5.0s**
Matt (S2) says: <d>I can see it clearly.</d>"""
    assert [(a,b) for a,b,_ in film._h3_prompt_shot_windows(prompt)] == [(0.,2.5),(2.5,5.)]
    windows=film.clean_single_speaker_shot_segments(prompt,['Nyx','Matt'],{}, {},['Nyx','Matt'])
    assert [(w['speaker'],w['start'],w['end']) for w in windows]==[('Nyx',0,2.5),('Matt',2.5,5)]


def test_world_ambient_is_runtime_owned_and_not_copied_into_retake():
    pitch=film.world_ambient_mini_pitch({'world_environment':'Year 2099. A neon city with elevated highways.'},[])
    assert pitch.startswith('**World ambience')
    body='**description_multimodale_intégrée :**\nNyx walks through the night market.'
    full='REFERENCE AUTHORITY — technical mapping\n<Subject 1> is Nyx.\n\n'+pitch+'\n\n'+body
    assert film.creative_clip_body(full)==body
    assert film.creative_clip_body(body)==body
    assert 'Year 2099.' in film.world_ambient_mini_pitch({'world_environment':'Year 2099.'},
                 [{'kind':'decor','role':'canonical_environment','subject_name':'Market'}])
    assert film.creative_clip_body(pitch+'\n\n'+body)==body


def test_resume_does_not_reuse_plans_from_replaced_future_scenes():
    engine=Path(film.__file__).read_text(encoding='utf8')
    assert 'invalidated_future_plan_start = scene_cursor + 1' in engine
    assert 'scene_index < invalidated_future_plan_start' in engine
