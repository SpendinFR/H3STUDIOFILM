"""Krea insert guide generation contracts, no GPU or model weights required."""
from pathlib import Path
from unittest.mock import patch
import sys,unittest,tempfile
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_new_insert_guide as g

class InsertGuideTests(unittest.TestCase):
 def test_mask_is_selected_rectangle_not_whole_frame(self):
  with tempfile.TemporaryDirectory() as d:
   d=Path(d);src=d/'original.png';dst=d/'selection.png'
   Image.new('RGB',(100,100),(20,30,40)).save(src)
   g.make_mask(src,dst,(20,30,40,20))
   with Image.open(dst) as im:
    self.assertEqual(im.getpixel((0,0)),(0,0,0))
    self.assertEqual(im.getpixel((35,40)),(255,255,255))
    self.assertEqual(im.getpixel((65,60)),(0,0,0))
 def test_krea_graph_neutral_only_and_no_reference(self):
  import retouches_llm_prompt_insert_v104 as writer
  parts=('Une streameuse dans son studio.', 'Une araignée descend et remonte.',
         'Intégration dans le décor.')
  neutral=writer.make_krea_prompt(parts)
  fake={'6':{'inputs':{'text':'old figurative text'}} ,
        '9':{'inputs':{'seed':1,'LanPaint_Info':'original'}},
        '11':{'inputs':{'filename_prefix':'legacy'}}}
  with patch.object(g.prior,'validate'),patch.object(g.prior,'graph',return_value=fake):
   graph=g.build_graph({},'frame.png','mask.png','une araignée','a'*32,guide_prompt=neutral)
  self.assertIn('NON-FIGURATIVE',graph['6']['inputs']['text'])
  self.assertNotIn('araignée',graph['6']['inputs']['text'])
  self.assertNotIn('streameuse',graph['6']['inputs']['text'])
  self.assertIn('new_insert',graph['11']['inputs']['filename_prefix'])
  with patch.object(g.prior,'validate'),patch.object(g.prior,'graph',return_value=fake):
   with self.assertRaises(ValueError):
    g.build_graph({},'frame.png','mask.png','une araignée','a'*32)
 def test_refuse_unchanged_image_before_expensive_h3(self):
  with tempfile.TemporaryDirectory() as d:
   d=Path(d);original=d/'original.png';new=d/'generated.png';mask=d/'mask.png'
   Image.new('RGB',(100,100),(20,30,40)).save(original)
   Image.new('RGB',(100,100),(20,30,40)).save(new)
   g.make_mask(original,mask,(25,25,50,50))
   with self.assertRaises(RuntimeError):g.verify_visual_change(original,new,mask)
   with Image.open(new) as im:
    im=im.copy();im.paste((240,50,30),(45,45,65,65));im.save(new)
   self.assertGreater(g.verify_visual_change(original,new,mask),4.)
if __name__=='__main__':unittest.main()
