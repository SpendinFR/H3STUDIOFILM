"""V10.13: added film appearances are bound to canonical Subjects; audio voice/object routing is UI-only."""
import json
import hashlib
from pathlib import Path
import pytest
import h3film_studio_v3 as film


def _fixtures(tmp_path):
    comfy=tmp_path/'comfy';inp=comfy/'input';inp.mkdir(parents=True)
    for name in ('matt.png','nyx.png','appearance.png','drone.png','voice.wav','motor.wav'):
        (inp/name).write_bytes(b'FAKE:'+name.encode())
    project=tmp_path/'project';(project/'refs').mkdir(parents=True)
    def image(name,key,kind,role,file,i):
        return {'kind':kind,'role':role,'subject_name':name,'subject_key':key,'picture_order':i,
                'annotated':file+' [input]','path':str(inp/file),'strength':1.0}
    matt=image('Matt','matt','character','canonical_identity','matt.png',1)
    nyx=image('Nyx','nyx','character','canonical_identity','nyx.png',2)
    drone=image('Drone','drone','object','continuing_object','drone.png',3)
    refs=[matt,nyx,drone]
    voice={'kind':'voice','subject_name':'Matt','annotated':'voice.wav [input]','path':str(inp/'voice.wav'),'strength':1.0}
    (project/'refs'/'static_refs.json').write_text(json.dumps(refs),encoding='utf-8')
    (project/'refs'/'ref_bank.json').write_text(json.dumps({'character_appearance':{},'history':[]}),encoding='utf-8')
    prompt=film.reference_prompt_prefix(refs,[voice])+'\n\n**Director :**\nOriginal direction.\n\n**description_multimodale_intégrée :**\nNyx reaches out.'
    spec=[{'media':'image','index':i,'name':r['subject_name']} for i,r in enumerate(refs)]
    spec.append({'media':'audio','index':0,'name':'Matt','audio_use':'voice','audio_target':'Matt'})
    return comfy,inp,project,refs,[voice],prompt,spec


def test_added_nyx_appearance_links_canonical_subject_and_can_commit_bank(tmp_path):
    comfy,inp,project,refs,auds,prompt,spec=_fixtures(tmp_path)
    spec.insert(3,{'media':'image','path':str(inp/'appearance.png'),'name':'Portrait récent de Nyx',
                   'visual_type':'appearance','bank_target':'Nyx','bank_scope':'bank'})
    modified,images,audio=film.apply_clip_studio_edits({'edits':{'text':prompt,'refs':spec}},prompt,refs,auds,comfy,project,commit=False)
    assert len(images)==4
    assert images[-1]['role']=='film_appearance'
    assert images[-1]['subject_key']==images[1]['subject_key']=='nyx'
    assert film.reference_subject_numbers(images)==[1,2,3,2]
    assert '<Picture 4> is the latest rendered-film appearance state for the same <Subject 2>' in modified
    assert modified.count('VOICE REFERENCE AUTHORITY —')==1
    assert modified.count('**Director :**')==1
    assert not json.loads((project/'refs'/'ref_bank.json').read_text())['character_appearance']
    committed,im2,_=film.apply_clip_studio_edits({'edits':{'text':prompt,'refs':spec}},prompt,refs,auds,comfy,project,commit=True)
    assert committed==modified and im2==images
    bank=json.loads((project/'refs'/'ref_bank.json').read_text())
    assert bank['character_appearance']['Nyx']['subject_key']=='nyx'
    assert bank['character_appearance']['Nyx']['role']=='film_appearance'
    assert len(bank['history'])==1
    # Protected identity and old files left intact.
    assert (inp/'nyx.png').is_file() and (inp/'appearance.png').is_file()
    assert len(json.loads((project/'refs'/'static_refs.json').read_text()))==3


def test_unlinked_appearance_rejected_without_bank_mutation(tmp_path):
    comfy,inp,project,refs,auds,prompt,spec=_fixtures(tmp_path)
    spec.append({'media':'image','path':str(inp/'appearance.png'),'name':'Unknown','visual_type':'appearance','bank_target':'Unknown','bank_scope':'bank'})
    with pytest.raises(ValueError,match='Personnage canonique introuvable'):
        film.apply_clip_studio_edits({'edits':{'text':prompt,'refs':spec}},prompt,refs,auds,comfy,project,commit=True)
    assert json.loads((project/'refs'/'ref_bank.json').read_text())['character_appearance']=={}
    spec[-1]['bank_target']=''
    with pytest.raises(ValueError,match='Choisis le personnage canonique'):
        film.apply_clip_studio_edits({'edits':{'text':prompt,'refs':spec}},prompt,refs,auds,comfy,project,commit=False)


def test_audio_object_and_voice_authority_are_distinct_and_renumber_correctly(tmp_path):
    comfy,inp,project,refs,auds,prompt,spec=_fixtures(tmp_path)
    spec.append({'media':'audio','path':str(inp/'motor.wav'),'name':'Moteur du drone','audio_use':'object_sound','audio_target':'Drone'})
    edited,images,output_audio=film.apply_clip_studio_edits({'edits':{'text':prompt,'refs':spec}},prompt,refs,auds,comfy,project,commit=False)
    assert len(output_audio)==2 and output_audio[1]['studio_audio_use']=='object_sound'
    assert '<Audio 1> is the voice-timbre reference for <Subject 1> (Matt)' in edited
    assert 'SOUND REFERENCE AUTHORITY' in edited
    assert '<Audio 2> is the sound reference for <Subject 3> (Drone)' in edited
    assert 'do not treat <Audio 2> as a character voice' in edited
    assert edited.count('**Director :**')==1
    assert edited.count('VOICE REFERENCE AUTHORITY')==1
    # No mutation to persistent automatic voice bank even if audio changed.
    before={p.name:hashlib.sha256(p.read_bytes()).digest() for p in (project/'refs').iterdir()}
    _,_,_=film.apply_clip_studio_edits({'edits':{'text':prompt,'refs':spec}},prompt,refs,auds,comfy,project,commit=True)
    assert before=={p.name:hashlib.sha256(p.read_bytes()).digest() for p in (project/'refs').iterdir()}
    # A pre-existing voice is still unchanged with no user edits.
    untouched,_,_=film.apply_clip_studio_edits({'edits':{'text':prompt,'refs':spec[:4]}},prompt,refs,auds,comfy,project,commit=False)
    assert untouched==prompt


def test_object_sound_can_be_reassigned_to_voice_without_stale_sound_block(tmp_path):
    comfy,inp,project,refs,auds,prompt,spec=_fixtures(tmp_path)
    spec[-1]={'media':'audio','index':0,'name':'Nyx','audio_use':'voice','audio_target':'Nyx'}
    result,_,out=film.apply_clip_studio_edits({'edits':{'text':prompt,'refs':spec}},prompt,refs,auds,comfy,project,commit=False)
    assert '<Audio 1> is the voice-timbre reference for <Subject 2> (Nyx)' in result
    assert 'SOUND REFERENCE AUTHORITY' not in result
    assert out[0]['subject_name']=='Nyx'


def test_http_preview_matches_final_commit_for_new_appearance_and_object_sound(tmp_path):
    import threading
    from http.server import ThreadingHTTPServer
    from urllib.request import Request, urlopen
    from unittest.mock import patch
    import studio_web as web
    comfy,inp,project,refs,auds,prompt,spec=_fixtures(tmp_path)
    session=tmp_path/'sessions'/'s';session.mkdir(parents=True)
    web.write_json(session/'review.json',{'id':'r-13','kind':'clips','payload':{'text':prompt,'refs':refs,'audio_refs':auds}})
    web.write_json(session/'active_project.json',{'name':'project'})
    spec.insert(3,{'media':'image','path':str(inp/'appearance.png'),'name':'Nyx',
                   'visual_type':'appearance','bank_target':'Nyx','bank_scope':'bank'})
    spec.append({'media':'audio','path':str(inp/'motor.wav'),'name':'Drone',
                 'audio_use':'object_sound','audio_target':'Drone'})
    with patch.object(web,'active_folder',return_value=session),\
         patch.object(web,'comfy_path',return_value=comfy),\
         patch.object(web,'load_project',return_value=project):
        server=ThreadingHTTPServer(('127.0.0.1',0),web.Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            def preview(body):
                data=json.dumps({'id':'r-13','body':body,'refs':spec}).encode()
                request=Request(f'http://127.0.0.1:{server.server_port}/api/reference-preview',data=data,
                                method='POST',headers={'Content-Type':'application/json'})
                with urlopen(request,timeout=10) as r:return json.load(r)
            first=preview(prompt)
            assert first['subjects']==[1,2,3,2]
            assert '<Picture 4> is the latest rendered-film appearance state for the same <Subject 2>' in first['text']
            assert '<Audio 2> is the sound reference for <Subject 3> (Drone)' in first['text']
            assert '<Audio 1> is the voice-timbre reference for <Subject 1> (Matt)' in first['text']
            body=prompt[len(film.reference_prompt_prefix(refs,auds)):].strip()+'\n\nCamera gently moves.'
            second=preview(body)
            final,_,_=film.apply_clip_studio_edits({'edits':{'text':prompt+'\n\nCamera gently moves.','refs':spec}},
                                                    prompt,refs,auds,comfy,project,commit=False)
            assert second['text']==final
        finally:
            server.shutdown();server.server_close();thread.join(timeout=5)
