"""V10.93: central prompt instructs natural before/after; simple seams byte-identical."""
from pathlib import Path
from unittest.mock import patch
import hashlib, re, tempfile, unittest
import retouches_precise_center_v90 as center
import retouches_llm_prompt_half_v82 as gemma_v83
import retouches_llm_prompt_center_v93 as central_writer

HOME=Path(__file__).resolve().parents[1]


def valid_model_answer(window):
    descriptions={
        'TRANSITION AVANT':'Elle garde brièvement les yeux vers son écran puis tourne doucement la tête.',
        'ACTION':'Elle lève rapidement la main droite devant son visage et la redescend.',
        'TRANSITION APRÈS':'Elle repose son bras, fixe son écran et reprend naturellement son activité.',
    }
    shots='\n'.join(f'[Shot {n}] {a:.3f}–{b:.3f}s — {descriptions[role]}'
                    for n,(role,a,b) in enumerate(gemma_v83._grid(window),1))
    return ('SCENE_CONTEXT: La streameuse est assise devant son écran et garde sa posture.\n'
            'NEW_TAKE:\n'+shots)

class CenterNatural(unittest.TestCase):
    def test_working_code_is_byte_exact_from_v92(self):
        import zipfile
        with zipfile.ZipFile('/mnt/data/H3Film_STUDIO_V10_92_RETAKE_CENTRAL_TIMELINE_63F_FIX.zip') as z:
            for name in ('retouches_llm_prompt_half_v82.py','retouches_precise_half_v82.py',
                         'retouches_preroll_prompt_v88.py'):
                self.assertEqual((HOME/name).read_bytes(),z.read(name),name)

    def test_natural_action_grid_and_source_context(self):
        window,_=center.select_window(37,124,2.0,3.0)
        out=central_writer._instruction(
            request='Elle lève rapidement la main droite puis la redescend.',
            source_prompt='[Shot 1] 0.000–5.167s La femme regarde son écran, rit, puis se tourne vers la caméra.',
            window=window)
        self.assertIn('le bref mouvement original qui précède',out)
        self.assertIn('reprend naturellement son attitude',out)
        self.assertIn('Elle lève rapidement la main droite',out)
        self.assertIn('La femme regarde son écran, rit',out)
        self.assertNotIn('— TRANSITION AVANT',out)
        self.assertNotIn('— TRANSITION APRÈS',out)
        self.assertIn('GESTE DEMANDÉ (TEMPS LOCAL) : 0.875–1.875s',out)
        self.assertEqual(len(re.findall(r'(?m)^\[Shot \d\]',out)),3)

    def test_mock_gemma_retries_empty_transitions_then_returns_good(self):
        window,_=center.select_window(37,124,2.0,3.0)
        calls=[]
        def fake_director(_backend,system,instruction,**kwargs):
            calls.append((system,instruction))
            answer=valid_model_answer(window)
            if len(calls)==1:
                answer=re.sub(r'(?<=— )Elle garde brièvement les yeux vers son écran puis tourne doucement la tête\.',
                              'TRANSITION AVANT',answer)
            return answer
        with patch('h3film_studio_v3.director_text',side_effect=fake_director), \
             patch('h3film_studio_v3.unload_text_backend') as unload, \
             patch.object(gemma_v83.inherited,'choose_backend',return_value='MOCK'):
            output,method=central_writer.write_prompt(mode='precise',performance_type='action',
                request='Elle lève la main droite',source_prompt='Une femme regarde son écran',
                window=window,gpu_prepare=lambda:None)
        self.assertEqual(len(calls),2)
        self.assertEqual(len(re.findall(r'(?m)^\[Shot \d+\]', output)),3)
        self.assertIn('exactly 2.625s',output)
        self.assertIn('Action assigned within the local take at 0.875–1.875s',output)
        self.assertIn('Elle garde brièvement les yeux',output)
        self.assertIn('Elle repose son bras',output)
        self.assertNotIn('TRANSITION AVANT',output)
        self.assertNotIn('TRANSITION APRÈS',output)
        self.assertIn('Retake HALF-CLIP',method)
        unload.assert_called_once()

    def test_all_placeholder_responses_fail_without_h3(self):
        window,_=center.select_window(37,124,2.0,3.0)
        answer=valid_model_answer(window).replace(
            'Elle garde brièvement les yeux vers son écran puis tourne doucement la tête.',
            'TRANSITION AVANT')
        with patch('h3film_studio_v3.director_text',return_value=answer) as backend, \
             patch('h3film_studio_v3.unload_text_backend'), \
             patch.object(gemma_v83.inherited,'choose_backend',return_value='MOCK'):
            with self.assertRaisesRegex(RuntimeError,'trois tentatives'):
                central_writer.write_prompt(mode='precise',performance_type='action',
                    request='Elle lève la main',source_prompt='',window=window,gpu_prepare=lambda:None)
            self.assertEqual(backend.call_count,3)

if __name__=='__main__':unittest.main()
