"""V10.101 isolated insertion warm-up: no changes to Retake, Performance or prompts."""
from pathlib import Path
import sys, hashlib, subprocess
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pytest, torch
import retouches_insert_preroll_v101 as lead
import retouches_roycho_complete_v63 as roycho
import retouches_next as n

BASE = Path('/mnt/data/h3v97_work')
ROOT = Path(__file__).resolve().parents[1]


def test_retake_performance_and_preroll_files_unchanged():
    base=Path('/mnt/data/v101')
    if not base.exists():
        pytest.skip('Old V10.101 baseline is not mounted')
    for name in (
        'retouches_llm_prompt_v74.py','retouches_llm_prompt_half_v82.py',
        'retouches_llm_prompt_center_v93.py','retouches_precise_half_v82.py',
        'retouches_precise_center_v90.py','retouches_performance_native_v96.py',
        'studio_ui/studio-new-retouches.js',
    ):
        assert (ROOT/name).read_bytes() == (base/name).read_bytes(), name


def test_insert_h3_clock_exact():
    normal={'start':0.,'end':1.17,'duration':124/24.,'frames':124}
    prepared=lead.seconds_for_h3(normal)
    assert prepared['frames']==141
    assert prepared['duration']==141/24
    assert prepared['end']==pytest.approx(1.17+17/24)
    assert prepared['start']==0
    assert normal['frames']==124
    with pytest.raises(ValueError): lead.seconds_for_h3(dict(normal,frames=123))


def test_mask_tracking_latent_only(tmp_path):
    # This artificial .pt has the same H3 persistence schema as a real RAW.
    t=37
    v=torch.arange(t).reshape(1,1,t,1,1).repeat(1,24,1,2,3).float()
    a=torch.zeros((1,8,2,20))
    origin=tmp_path/'clip_0001_RAW_LATENT.pt'
    saved={'version':1,'samples':{'nested':True,'members':[
        {'tensor':v,'shape':tuple(v.shape),'device':'cpu'},
        {'tensor':a,'shape':tuple(a.shape),'device':'cpu'}]},
           'extras':{},'noise_mask':None}
    torch.save(saved,origin)
    output=lead.stage_latent(origin,'clip_0001_RAW_LATENT__insertmask_deadbeef',124)
    prepared=torch.load(output,weights_only=True)
    after=prepared['samples']['members'][0]['tensor']
    assert after.shape[2]==42
    assert (after[:,:,:5]==v[:,:,:5]).all()
    assert (after[:,:,5:]==v).all()
    assert prepared['samples']['members'][1]['tensor'].shape==a.shape
    assert prepared['version']==saved['version']
    assert torch.load(origin,weights_only=True)['samples']['members'][0]['tensor'].shape[2]==37


def test_roycho_graph_receives_padded_video_mask_and_guide_at_zero():
    required={
      'H3LoadRawLatentExact','H3RoychoAnimatedMaskV62','LoadVideo','GetVideoComponents',
      'MVEx_MaskCleanup','MVEx_SubjectCrop','MVEx_MaskToLatentSpace','MVEx_SubjectUncrop',
      'VAELoader','CLIPLoader','UNETLoader','MiniMaxH3SigmaShift','VAEEncode','GetImageSizeAndCount',
      'SetLatentNoiseMask','VAEEncodeAudio','LTXVConcatAVLatent','MiniMaxH3ReferenceToVideo',
      'BasicGuider','RandomNoise','BasicScheduler','KSamplerSelect','SamplerCustomAdvanced',
      'LTXVSeparateAVLatent','VAEDecode','CreateVideo','SaveVideo','LoadImage',
      'H3RoychoCropGuideV64','MiniMaxH3AddGuide'}
    sec=lead.seconds_for_h3({'start':0.,'end':1.17,'duration':124/24.,'frames':124})
    graph=roycho.build({k:{} for k in required}, ident='f'*32,
        source=Path('/comfy/output/h3retouch_insert_preroll/work.mp4'),
        source_filename='h3new_work_insert_preroll.mp4',
        project='film',clip='1',seconds=sec,
        instruction='Une araignée grimpe le long de la vitre',rect=(10,10,45,45),
        latent_name='clip_0001_RAW_LATENT__insertmask_deadbeef',guide_image_name='guide.png')
    assert graph['901']['inputs']['latent_name'].endswith('__insertmask_deadbeef')
    assert graph['902']['inputs']['source_video'].endswith('work.mp4')
    assert graph['902']['inputs']['start_seconds']==0
    assert graph['902']['inputs']['end_seconds']==pytest.approx(1.17+17/24)
    assert graph['45']['inputs']['frame_idx']==0
    assert graph['44']['inputs']['frame_index']==0
    assert graph['2']['inputs']['video']==['1',0]
    assert graph['38']['inputs']['latent_image']==['31',0]


def test_mp4_input_output_roundtrip_audio_unchanged(tmp_path):
    # A self-contained, cheap synthetic video: 124 -> 141 -> 124 frames.
    import shutil
    if not (shutil.which('ffmpeg') and shutil.which('ffprobe')):
        pytest.skip('FFmpeg not available')
    comfy=tmp_path/'comfy'; (comfy/'input').mkdir(parents=True)
    (comfy/'output').mkdir()
    source=tmp_path/'source.mp4'
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y',
        '-f','lavfi','-i','testsrc2=size=128x96:rate=24',
        '-f','lavfi','-i','sine=frequency=440:sample_rate=44100',
        '-frames:v','124','-c:v','libx264','-preset','ultrafast',
        '-c:a','aac','-shortest',str(source)]
    subprocess.run(cmd,check=True,timeout=45)
    padded,inp=lead.stage_source(source,comfy,'a'*32,124)
    assert lead.frame_count(padded,comfy)==141
    assert (comfy/'input'/inp).exists()
    target=tmp_path/'final.mp4'
    lead.strip_warmup(padded,source,target,124,comfy)
    assert lead.frame_count(target,comfy)==124
    f=subprocess.run(['ffprobe','-v','error','-select_streams','a:0','-show_entries','stream=index','-of','csv=p=0',str(target)],capture_output=True,text=True)
    assert f.stdout.strip()


def test_node_gate_for_insert_and_performance_still_independent():
    assert 'H3RetouchMaskV58' in n._mode_required_nodes('precise')
    assert 'H3RetouchMaskV58' not in n._mode_required_nodes('insert')
    assert 'H3RetouchMaskV58' not in n._mode_required_nodes('performance')
