"""Reproduce V10.11's real Windows `python -I` failure and Picture != Subject."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_isolated_refbank_web_and_worker(tmp_path):
    code = r'''
import importlib.util, json, sys
from pathlib import Path
root=Path(sys.argv[1]);tmp=Path(sys.argv[2]);comfy=tmp/'comfy';inputs=comfy/'input';inputs.mkdir(parents=True)
for x in ('matt.png','old_appearance.png','nyx.png'):(inputs/x).write_bytes(b'fake')
project=tmp/'project';refsdir=project/'refs';refsdir.mkdir(parents=True)
def ref(name,key,role,file):
 return {'kind':'character','role':role,'subject_name':name,'subject_key':key,'picture_order':0,'annotated':file+' [input]','path':str(inputs/file),'strength':1.0}
matt=ref('Matt','canon_matt','canonical_identity','matt.png')
wrong=ref('Matt','canon_matt','film_appearance','old_appearance.png')
nyx=ref('Nyx','canon_nyx','canonical_identity','nyx.png')
refs=[matt,wrong,nyx]
for i,r in enumerate(refs,1):r['picture_order']=i
(refsdir/'static_refs.json').write_text(json.dumps([matt,nyx]),encoding='utf-8')
(refsdir/'ref_bank.json').write_text(json.dumps({'character_appearance':{'Matt':wrong},'history':[]}),encoding='utf-8')
def load(name,file):
 spec=importlib.util.spec_from_file_location(name,root/file)
 module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
film=load('h3film_reference_preview', 'h3film_studio_v3.py')
web=load('studio_web','studio_web.py')
original=film.reference_prompt_prefix(refs)+'\n\n**description_multimodale_intégrée :**\nNyx waves.'
spec=[{'media':'image','index':0,'name':'Matt'},{'media':'image','index':1,'name':'Nyx','bank_target':'Nyx','bank_scope':'bank'},{'media':'image','index':2,'name':'Nyx'}]
text,images,_=film.apply_clip_studio_edits({'edits':{'text':original,'refs':spec}},original,refs,[],comfy,project,commit=False)
assert 'is the latest rendered-film appearance state for the same <Subject 2>' in text,text
assert '<Subject 2> is Nyx. <Picture 3> defines' in text,text
assert 'is the latest rendered-film appearance state for the same <Subject 1>' not in text
assert film.reference_subject_numbers(images)==[1,2,2]
assert web.reference_preview_engine().studio_refbank_module().existing_character_names(project)==['Matt','Nyx']
print('ISOLATED_MODE_OK; SUBJECTS=1,2,2; PREVIEW_OK')
'''
    proc=subprocess.run([sys.executable,'-I','-c',code,str(ROOT),str(tmp_path)],capture_output=True,text=True,timeout=30)
    assert proc.returncode==0,(proc.stdout,proc.stderr)
    assert 'ISOLATED_MODE_OK' in proc.stdout


def test_web_preview_returns_authoritative_subjects(tmp_path):
    import h3film_studio_v3 as film
    import studio_web as web
    from unittest.mock import patch
    from http.server import ThreadingHTTPServer
    from urllib.request import Request,urlopen
    import threading
    comfy=tmp_path/'comfy';(comfy/'input').mkdir(parents=True)
    project=tmp_path/'project';(project/'refs').mkdir(parents=True)
    def ref(name,key,role,file):
        path=comfy/'input'/file;path.write_bytes(b'x')
        return {'kind':'character','role':role,'subject_name':name,'subject_key':key,'picture_order':0,'annotated':file+' [input]','path':str(path),'strength':1.0}
    matt=ref('Matt','matt','canonical_identity','matt.png')
    wrong=ref('Matt','matt','film_appearance','wrong.png')
    nyx=ref('Nyx','nyx','canonical_identity','nyx.png')
    refs=[matt,wrong,nyx]
    for i,r in enumerate(refs,1):r['picture_order']=i
    (project/'refs'/'static_refs.json').write_text(json.dumps([matt,nyx]))
    (project/'refs'/'ref_bank.json').write_text(json.dumps({'character_appearance':{'Matt':wrong}}))
    old=film.reference_prompt_prefix(refs)+'\n\n**Director :**\nExisting look'
    session=tmp_path/'sessions'/'one';session.mkdir(parents=True)
    web.write_json(session/'review.json',{'id':'r','kind':'clips','payload':{'text':old,'refs':refs,'audio_refs':[]}})
    web.write_json(session/'active_project.json',{'name':'project'})
    with patch.object(web,'active_folder',return_value=session),patch.object(web,'comfy_path',return_value=comfy),patch.object(web,'load_project',return_value=project):
        server=ThreadingHTTPServer(('127.0.0.1',0),web.Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            spec=[{'media':'image','index':0,'name':'Matt'},{'media':'image','index':1,'name':'Nyx','bank_scope':'bank','bank_target':'Nyx'},{'media':'image','index':2,'name':'Nyx'}]
            payload={'id':'r','body':old,'refs':spec}
            req=Request(f'http://127.0.0.1:{server.server_port}/api/reference-preview',method='POST',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
            with urlopen(req,timeout=8) as resp:result=json.load(resp)
            assert result['subjects']==[1,2,2]
            assert result['resolved_names']==['Matt','Nyx','Nyx']
            assert result['text'].count('REFERENCE AUTHORITY —')==1
            assert '<Picture 2> is the latest rendered-film appearance state for the same <Subject 2>' in result['text']
            assert '<Subject 2> is Nyx. <Picture 3>' in result['text']
        finally:
            server.shutdown();server.server_close();thread.join(timeout=5)


def test_stale_appearance_key_rejoins_canonical_subject(tmp_path):
    import h3film_studio_v3 as film
    folder=tmp_path/'p'/'refs';folder.mkdir(parents=True)
    comfy=tmp_path/'c';inp=comfy/'input';inp.mkdir(parents=True)
    def ref(name,key,role,file):
        path=inp/file;path.write_bytes(b'x')
        return {'kind':'character','role':role,'subject_name':name,'subject_key':key,'picture_order':0,'annotated':file+' [input]','path':str(path)}
    matt=ref('Matt','matt_canonical','canonical_identity','matt.png')
    nyx_app=ref('Nyx','old_stale_key','film_appearance','appearance.png')
    nyx=ref('Nyx','nyx_canonical','canonical_identity','nyx.png')
    refs=[matt,nyx_app,nyx]
    for i,r in enumerate(refs,1):r['picture_order']=i
    (folder/'static_refs.json').write_text(json.dumps([matt,nyx]))
    (folder/'ref_bank.json').write_text(json.dumps({'character_appearance':{'Nyx':nyx_app}}))
    old=film.reference_prompt_prefix(refs)+'\n\nCreative'
    spec=[{'media':'image','index':i,'name':r['subject_name']} for i,r in enumerate(refs)]
    prompt,changed,_=film.apply_clip_studio_edits({'edits':{'text':old,'refs':spec}},old,refs,[],comfy,folder.parent,commit=False)
    assert film.reference_subject_numbers(changed)==[1,2,2]
    assert changed[1]['subject_key']==nyx['subject_key']
    assert '<Picture 2> is the latest rendered-film appearance state for the same <Subject 2>' in prompt
