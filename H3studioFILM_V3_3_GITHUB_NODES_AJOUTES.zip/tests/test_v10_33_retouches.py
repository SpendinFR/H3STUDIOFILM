"""Offline contracts for the optional, separate H3 retouch engines."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import retouches_engine as r

class RetouchEngineContracts(unittest.TestCase):
    def test_bypass_in_ui_graph(self):
        ui={'nodes':[
          {'id':1,'type':'UNETLoader','mode':0,'inputs':[],'widgets_values_named':{'unet_name':'base.safetensors'}},
          {'id':2,'type':'LoraLoaderModelOnly','mode':4,'inputs':[{'name':'model','type':'MODEL','link':1}]},
          {'id':3,'type':'BasicGuider','mode':0,'inputs':[{'name':'model','type':'MODEL','link':2}]},
        ],'links':[[1,1,0,2,0,'MODEL'],[2,2,0,3,0,'MODEL']]}
        info={'UNETLoader':{'input':{'required':{'unet_name':[['base.safetensors']]}}},
              'BasicGuider':{'input':{'required':{'model':['MODEL']}}}}
        graph=r.convert_graph(ui,info)
        self.assertNotIn('2',graph)
        self.assertEqual(graph['3']['inputs']['model'],['1',0])

    def test_inject_character_ref_and_lora_without_touching_optional(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);(root/'input').mkdir()
            vid=root/'in.mp4';vid.write_bytes(b'0000ftyp' + b'0'*20)
            img=root/'actor.png';img.write_bytes(b'\x89PNG\r\n\x1a\n')
            graph={str(i):{'class_type':t,'inputs':dict(inputs)} for i,t,inputs in [
                (1,'LoadVideo',{'file':'old.mp4'}),(2,'LoadImage',{'image':'original.png'}),
                (3,'CLIPTextEncode',{'text':'old'}),
                (4,'LoraLoaderModelOnly',{'lora_name':'h3_character_swap_pro4500_1000.safetensors','strength_model':.3}),
                (5,'SaveVideo',{'filename_prefix':'video/test'})]}
            r._inject(graph,'swap_person',{'target':'woman in red coat','instructions':'Keep motion.'},root,'a'*32,vid,img)
            self.assertTrue((root/'input'/graph['1']['inputs']['file']).is_file())
            self.assertTrue((root/'input'/graph['2']['inputs']['image']).is_file())
            self.assertIn('woman in red coat',graph['3']['inputs']['text'])
            self.assertEqual(graph['4']['inputs']['strength_model'],1.0)
            self.assertIn('a'*32,graph['5']['inputs']['filename_prefix'])

    def test_person_remover_only_publishes_clean_video(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);(root/'input').mkdir()
            vid=root/'clip.mp4';vid.write_bytes(b'0000ftyp'+b'0'*20)
            img=root/'clean.png';img.write_bytes(b'\x89PNG\r\n\x1a\n')
            graph={'1':{'class_type':'LoadVideo','inputs':{'file':'old.mp4'}},
                   '2':{'class_type':'LoadImage','inputs':{'image':'clean.png'}},
                   '3':{'class_type':'CLIPTextEncode','inputs':{'text':'man in gray shirt'}},
                   '4':{'class_type':'H3RelayPersonRemover','inputs':{'prompt':'old'}},
                   '5':{'class_type':'SaveVideo','inputs':{'filename_prefix':'person-remover-v1/clean'}},
                   '6':{'class_type':'SaveVideo','inputs':{'filename_prefix':'person-remover-v1/mask-preview'}}}
            r._inject(graph,'remove_person',{'target':'man in dark coat'},root,'b'*32,vid,img)
            self.assertNotIn('6',graph)
            self.assertEqual(graph['3']['inputs']['text'],'man in dark coat')
            self.assertIn('man in dark coat',graph['4']['inputs']['prompt'])

    def test_singularity_preferred_when_user_wants_one_base_everywhere(self):
        names=['Minimax-h3_Singularity_ref2va_Pruned_v1.3_int8.safetensors',
               'minimax_h3_ref2va_pruned_nvfp4.safetensors']
        info={'UNETLoader':{'input':{'required':{'unet_name':[names]}}}}
        self.assertEqual(r._select_h3_model(info,'remove_person'),names[0])
        self.assertEqual(r._select_h3_model(info,'swap_person'),names[0])
        self.assertEqual(r._select_h3_model(info,'move_camera'),names[0])
        g={'1':{'class_type':'UNETLoader','inputs':{'unet_name':'minimax_h3_ref2va_pruned_int8_convrot.safetensors','weight_dtype':'default'}}}
        r._apply_h3_model(g,'swap_person',r._select_h3_model(info,'swap_person'))
        self.assertEqual(g['1']['inputs']['unet_name'],names[0])

    def test_lanpaint_can_try_ref2va_fallback_when_fl2va_missing(self):
        names=['Minimax-h3_Singularity_ref2va_Pruned_v1.3_int8.safetensors',
               'minimax_h3_ref2va_pruned_nvfp4.safetensors']
        info={'UNETLoader':{'input':{'required':{'unet_name':[names]}}}}
        self.assertEqual(r._select_h3_model(info,'local_edit'),names[0])
        self.assertEqual(r._select_h3_model(info,'replace_background'),names[0])
        names.append('minimax_h3_fl2va_pruned_nvfp4.safetensors')
        self.assertEqual(r._select_h3_model(info,'local_edit'),names[0])
        self.assertEqual(r._select_h3_model(info,'local_edit','fl2va'),names[-1])
        self.assertEqual(r._select_h3_model(info,'replace_background','fl2va'),names[-1])
        names.remove('minimax_h3_fl2va_pruned_nvfp4.safetensors')
        self.assertIsNone(r._select_h3_model(info,'local_edit','fl2va'))

    def test_singularity_model_allowed_when_nvfp4_unavailable(self):
        sing='Minimax-h3_Singularity_ref2va_Pruned_v1.3_int8.safetensors'
        info={'UNETLoader':{'input':{'required':{'unet_name':[[sing]]}}}}
        self.assertEqual(r._select_h3_model(info,'remove_person'),sing)

    def test_legacy_workflow_fallback_is_read_only(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            cur=root/'H3Film_STUDIO_V10_35_RETOUCHES'/'H3Film_STUDIO_V10_35_RETOUCHES'
            older=root/'H3Film_STUDIO_V10_34_RETOUCHES_SINGULARITY'/'H3Film_STUDIO_V10_34_RETOUCHES_SINGULARITY'
            (cur/'retouches_workflows').mkdir(parents=True)
            (older/'retouches_workflows').mkdir(parents=True)
            previous=older/'retouches_workflows'/'swap_person.json'
            previous.write_text('{"nodes":[]}',encoding='utf-8')
            with mock.patch.object(r,'HERE',cur),mock.patch.object(r,'WF_DIR',cur/'retouches_workflows'):
                self.assertEqual(r.workflow_path('swap_person'),previous)
                self.assertEqual(previous.read_text(),'{"nodes":[]}')

    def test_no_launch_without_reference(self):
        with self.assertRaisesRegex(ValueError,'référence'):
            r.start({'mode':'swap_person','target':'actor'}, {'type':'upload','id':'x'},lambda _:None,lambda:None,None)

if __name__=='__main__':unittest.main()
