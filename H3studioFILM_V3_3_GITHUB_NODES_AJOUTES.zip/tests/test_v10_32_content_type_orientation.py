"""V10.32 integration contracts: select only Director prompts and render dimensions.

No GPU/ComfyUI is needed. The old Film 16:9 path must remain unchanged.
"""
import copy, json
from pathlib import Path
from unittest.mock import patch
import pytest
import studio_content_types as teams
import h3film_studio_v3 as film
import studio_web

ROOT=Path(__file__).resolve().parents[1]


def test_official_film_prompts_exact():
    contents=teams.read_team(ROOT,'film')
    assert set(contents)==set(teams.ROLES)
    for role,raw in contents.items():
        assert raw == (ROOT/'prompts'/f'{role}_DIRECTOR.txt').read_text(encoding='utf-8')


def test_all_content_type_options_are_in_create_ui_and_posted():
    html=(ROOT/'studio_ui/index.html').read_text(encoding='utf-8')
    js=(ROOT/'studio_ui/studio.js').read_text(encoding='utf-8')
    assert len(teams.TYPES)==11
    for name in teams.TYPES:assert f'value="{name}"' in html
    assert 'id="contentType"' in html and 'id="orientation"' in html
    assert 'content_type:$(\'contentType\').value' in js
    assert 'orientation:$(\'orientation\').value' in js
    assert 'value="landscape"' in html and 'value="portrait"' in html


def test_not_installed_team_fails_explicitly_no_fallback(tmp_path):
    with pytest.raises(FileNotFoundError,match='non installée'):
        teams.read_team(tmp_path,'publicite')
    with pytest.raises(ValueError,match='inconnu'):
        teams.normalize_type('anything')


def test_team_load_and_frozen_resume_does_not_follow_archive_changes(tmp_path):
    base=tmp_path/'director_teams'/'musique'/'nested';base.mkdir(parents=True)
    for role in teams.ROLES:(base/(role+'_DIRECTOR.txt')).write_text(role+' '+('original '*100),encoding='utf-8')
    project=tmp_path/'film_project';project.mkdir()
    original=teams.project_team(tmp_path,project,'musique',False)
    assert all('original' in raw for raw in original.values())
    for role in teams.ROLES:(base/(role+'_DIRECTOR.txt')).write_text(role+' '+('changed '*100),encoding='utf-8')
    assert teams.project_team(tmp_path,project,'musique',True)==original
    with pytest.raises(RuntimeError,match='correspond'):
        teams.project_team(tmp_path,project,'sport',True)


def test_portrait_mutates_only_upscaler_in_private_graph():
    base={'a':{'class_type':'MinimaxH3LatentUpscaler3D','inputs':{'mode':'target dimensions','mode.width':1920,'mode.height':1080,'align':32}},
          'b':{'class_type':'H3StudioImageToVideo','inputs':{'width':1152,'height':640,'motion_context_file':''}},
          'c':{'class_type':'H3V15ProjectHardLock','inputs':{'name':'example'}}}
    saved=json.dumps(base,sort_keys=True)
    landscape=copy.deepcopy(base)
    film.set_render_orientation(landscape,(1920,1080))
    assert json.dumps(landscape,sort_keys=True)==saved
    portrait=copy.deepcopy(base)
    film.set_render_orientation(portrait,(1080,1920))
    assert portrait['a']['inputs']['mode.width']==1080
    assert portrait['a']['inputs']['mode.height']==1920
    assert portrait['b']==base['b'] and portrait['c']==base['c']
    assert json.dumps(base,sort_keys=True)==saved
    with pytest.raises(ValueError):film.set_render_orientation(portrait,(1024,1024))


def test_prompt_snapshot_is_not_required_for_legacy_film_resume(tmp_path):
    contents=teams.read_team(ROOT,'film')
    assert teams.project_team(ROOT,tmp_path,'film',True)==contents


def test_http_refuses_uninstalled_team_without_starting_worker(tmp_path):
    data={'prompt':'a short film','duration':'10s','content_type':'sport','orientation':'landscape'}
    with patch.object(studio_web,'older_running_productions',return_value=[]), \
         patch.object(studio_web,'studio_local_helper',return_value=teams), \
         patch.object(teams,'prompt_files',side_effect=FileNotFoundError('missing team')):
        with pytest.raises(FileNotFoundError,match='missing team'):
            studio_web.start_film(data)
