"""The DOM must show actual grouped Subject IDs after a native preview response."""
from pathlib import Path
import pytest

ROOT=Path(__file__).resolve().parents[1]

def test_browser_subject_labels_sync_after_reassign():
    pytest.importorskip('playwright.sync_api')
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1380,'height':900})
        errors=[]
        page.on('pageerror',lambda error:errors.append(str(error)))
        html=(ROOT/'studio_ui/index.html').read_text(encoding='utf-8').replace('<script src="/studio.js"></script>','')
        page.set_content(html)
        page.add_script_tag(content=(ROOT/'studio_ui/studio.js').read_text(encoding='utf-8'))
        page.evaluate('''() => {
          clipDraft={id:'r',text:'CREATIVE',originalPrefix:'',previewPrefix:'',previewNonce:0,
            bankDeletes:[],bankNames:['Matt','Nyx'],refs:[
             {media:'image',index:0,name:'Matt',originalName:'Matt',kind:'character',role:'canonical_identity',subjectKey:'matt',visualType:'person',bankScope:'clip'},
             {media:'image',index:1,name:'Nyx',originalName:'Matt',kind:'character',role:'film_appearance',subjectKey:'matt',visualType:'person',bankScope:'bank',bankTarget:'Nyx'},
             {media:'image',index:2,name:'Nyx',originalName:'Nyx',kind:'character',role:'canonical_identity',subjectKey:'nyx',visualType:'person',bankScope:'clip'}]};
          document.getElementById('questionArea').innerHTML='<div id="clipRefCount"></div><div id="clipEditRefs"></div><div id="refAuthoritySync"></div><pre id="clipAuthorityText"></pre><textarea id="clipEditText">CREATIVE</textarea>';
          window.fetch=async()=>({ok:true,json:async()=>({text:'REFERENCE AUTHORITY — ...\\n<Subject 2> is Nyx. <Picture 3> canonical. <Picture 2> is appearance for same <Subject 2>.\\n\\nCREATIVE',prefix:'REFERENCE AUTHORITY — ...\\n<Subject 2> is Nyx. <Picture 3> canonical. <Picture 2> is appearance for same <Subject 2>.',original_prefix:'',subjects:[1,2,2],resolved_names:['Matt','Nyx','Nyx']})});
          renderClipRefEditor();
        }''')
        page.evaluate('previewClipAuthority()')
        assert page.locator('.clipEditRef .refEditFields small').all_text_contents()==[
            'PICTURE 1 · SUBJECT 1','PICTURE 2 · SUBJECT 2','PICTURE 3 · SUBJECT 2']
        assert 'same <Subject 2>' in page.locator('#clipAuthorityText').inner_text()
        assert page.locator('#clipEditText').input_value() == 'CREATIVE'
        assert '✓ Bloc Picture / Subject / Audio synchronisé' in page.locator('#refAuthoritySync').inner_text()
        assert not errors,errors
        browser.close()
