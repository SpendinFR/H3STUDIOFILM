import unittest
import retouches_precise_half_v82 as half
import retouches_llm_prompt_half_v82 as prompt

class HalfClipTests(unittest.TestCase):
    def test_selects_first_half_for_early_edit(self):
        w=half.select_window(total_latent=37,total_frames=124,begin=0.8,end=1.2)
        self.assertEqual(w['origin_frame'],0)
        self.assertEqual(w['seam_mode'],'suffix_only')
        self.assertEqual(w['frames'],63)
    def test_selects_second_half_for_late_edit(self):
        w=half.select_window(total_latent=37,total_frames=124,begin=4.0,end=4.5)
        self.assertEqual(w['seam_mode'],'prefix_only')
        self.assertEqual(w['end_frame'],124)
        self.assertEqual(w['frames'],63)
        self.assertAlmostEqual(w['global_offset'],61/24,places=3)
    def test_prompt_uses_local_times_only(self):
        w={'global_offset':61/24,'duration':63/24,'start':1.458,'end':1.958,
           'local_first':35,'local_last':47,'frames':63}
        txt=prompt._instruction(request='Elle serre le poing.',source_prompt='[Shot 1] 0.000–2.500s A. [Shot 2] 2.500–5.167s B.',window=w)
        self.assertIn('LOCAL SOURCE WINDOW IN THE ORIGINAL CLIP: 2.542–5.167s',txt)
        self.assertIn('[Shot 1] 0.000–1.458s',txt)
        self.assertIn('[Shot 2] 1.458–1.958s',txt)
        self.assertIn('[Shot 3] 1.958–2.625s',txt)
        self.assertNotIn('2.500–5.167s — ACTION',txt)

if __name__=='__main__':
    unittest.main()
