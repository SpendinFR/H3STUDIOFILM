"""V10.15 regression checks for real UI regressions reported with screenshots."""
import json
from pathlib import Path
import h3film_studio_v3 as film
import studio_web as web

ROOT=Path(__file__).resolve().parents[1]

def test_manually_added_character_can_receive_appearance_before_refbank_commit(tmp_path):
    comfy=tmp_path/'ComfyUI'; inp=comfy/'input';inp.mkdir(parents=True)
    for f in ('nyx.png','costume.png'):(inp/f).write_bytes(b'image')
    project=tmp_path/'project';(project/'refs').mkdir(parents=True)
    (project/'refs'/'static_refs.json').write_text('[]')
    (project/'refs'/'ref_bank.json').write_text('{}')
    first={'kind':'manual','role':'manual','subject_name':'Nyx','subject_key':'studio_nyx',
           'annotated':'nyx.png [input]','path':str(inp/'nyx.png'),'picture_order':1,'strength':1}
    prompt=film.reference_prompt_prefix([first],[])+'\n\n**description_multimodale_intégrée :**\nNyx avance.'
    spec=[{'media':'image','index':0,'name':'Nyx','visual_type':'person','bank_scope':'clip'},
          {'media':'image','path':str(inp/'costume.png'),'name':'Nyx','visual_type':'appearance','bank_target':'Nyx','bank_scope':'clip'}]
    merged,photos,_=film.apply_clip_studio_edits({'edits':{'text':prompt,'refs':spec}},prompt,[first],[],comfy,project,commit=False)
    assert [r['role'] for r in photos]==['canonical_identity','film_appearance']
    assert photos[0]['subject_key']==photos[1]['subject_key']
    assert film.reference_subject_numbers(photos)==[1,1]
    assert 'Picture 2' in merged
    assert json.loads((project/'refs'/'ref_bank.json').read_text())=={}


def test_completed_checkpoint_exposed_independently_from_session(tmp_path,monkeypatch):
    p=tmp_path/'film';(p/'_studio').mkdir(parents=True)
    (p/'_studio'/'resume_state.json').write_text(json.dumps({'completed':True,'completed_clip':4}))
    monkeypatch.setattr(web,'load_project',lambda name:p)
    data=web.project_data('film')
    assert data['resume_state']['completed'] is True


def test_latest_final_within_main_column_after_clip_details():
    html=(ROOT/'studio_ui/index.html').read_text(encoding='utf-8')
    assert html.count('id="latestFinalSection"')==1
    assert html.index('id="latestFinalSection"')>html.index('class="detailGrid"')
    assert html.index('id="latestFinalSection"')<html.index('</main>')
    assert 'studio-v10-15.css' in html


def test_browser_edits_both_status_and_appearance_picker():
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page=b.new_page(viewport={'width':1450,'height':900})
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        page.set_content((ROOT/'studio_ui/index.html').read_text().replace('<script src="/studio.js"></script>',''))
        for n in ('studio.css','studio-v10-8.css','studio-v10-9.css','studio-v10-10.css','studio-v10-14.css','studio-v10-15.css'):
            page.add_style_tag(content=(ROOT/'studio_ui'/n).read_text())
        page.add_script_tag(content=(ROOT/'studio_ui/studio.js').read_text())
        page.locator('#newProject').click()
        checkbox=page.locator('#independentModels').bounding_box()
        assert checkbox['width']<24 and checkbox['height']<24
        page.locator('#createModal [data-close]').first.click()
        page.evaluate("window.confirm=()=>true;window.fetch=async(url,opts)=>{if(url==='/api/review'){window.sent=JSON.parse(opts.body);return {ok:true,json:async()=>({ok:true})}}return {ok:true,json:async()=>({names:[],ollama:[],special:[]})}};")
        review={'id':'c-1','kind':'content','title':'Résumé','allow_revise':True,'payload':{'text':'PITCH / SYNOPSIS\nUn seul acte.','content':{'parts':[{'part':1,'duration_seconds':20}]}}}
        page.evaluate('''(review)=>{state={running:true,project:{name:'demo'},review};projectName='demo';project={name:'demo'};actionPanel(state)}''',review)
        assert page.locator('#directorDirectText').input_value()=='PITCH / SYNOPSIS\nUn seul acte.'
        page.locator('#directorDirectText').fill('PITCH / SYNOPSIS\nDeux actes, même durée.')
        page.locator('#applyDirectorDraft').click()
        page.wait_for_timeout(150)
        sent=page.evaluate('window.sent')
        assert sent['action']=='revise' and sent['edits'] is None and 'Deux actes' in sent['feedback']
        # Completion derives from selected project's actual resume_state.
        page.evaluate("project={name:'demo',resume_state:{completed:true}};state={project:{name:'demo'},running:false,stage:{}};actionPanel(state)")
        assert 'projet terminé' in page.locator('#deskTitle').inner_text()
        assert page.locator('#questionArea').inner_text().count('montage exporté')==1
        # Local manual identity is a valid target for the new appearance image.
        page.evaluate('''() => {let clipEditor=document.createElement('div');clipEditor.id='clipEditRefs';document.body.appendChild(clipEditor);const counter=document.createElement('div');counter.id='clipRefCount';document.body.appendChild(counter);clipDraft={id:'x',refs:[
           {media:'image',name:'Nyx',kind:'manual',visualType:'person',originalName:'Nyx',index:0},
           {media:'image',name:'Nouvelle tenue',kind:'manual',visualType:'appearance',editing:true,path:'/mock.png'}
        ],bankNames:[],bankDeletes:[]};renderClipRefEditor()}''')
        assert 'Nyx' in page.locator('.refBankTarget option').all_text_contents()
        assert not errors,errors
        b.close()
