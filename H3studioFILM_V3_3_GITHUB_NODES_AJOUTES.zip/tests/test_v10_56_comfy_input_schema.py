"""Regression: real ComfyUI H3 schema rejects motion_context_frames=0 even without context."""
from __future__ import annotations
import copy
import unittest
from pathlib import Path
from unittest.mock import patch
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_next as newer


def schema():
    return {
        'H3StudioImageToVideo': {'input': {'required': {
            'motion_context_frames': ['INT',{'default':22,'min':1,'max':39}],
            'motion_context_audio_frames': ['INT',{'default':22,'min':1,'max':39}],
            'length': ['INT',{'default':124,'min':5,'max':3600}],
            'width': ['INT',{'default':1152,'min':128,'max':3000}],
            'height': ['INT',{'default':640,'min':128,'max':3000}],
        }}},
        'SamplerCustomAdvanced':{'input':{}}, 'SaveVideo':{'input':{}},
        'RandomNoise':{'input':{}}, 'H3LoadRawLatentExact':{'input':{}},
        'H3RetouchRawMask': {'input':{'required':{
            'start_pct':['FLOAT',{'min':0.0,'max':100.0}],
            'end_pct':['FLOAT',{'min':0.0,'max':100.0}],
            'x_pct':['FLOAT',{'min':0.0,'max':100.0}],
            'y_pct':['FLOAT',{'min':0.0,'max':100.0}],
            'w_pct':['FLOAT',{'min':0.0,'max':100.0}],
            'h_pct':['FLOAT',{'min':0.0,'max':100.0}],
        }}},
    }

class InputBounds(unittest.TestCase):
    def test_no_motion_context_never_zero(self):
        values={'motion_context_frames':0,'motion_context_audio_frames':0}
        newer._h3_context_off(values,schema())
        self.assertEqual(values['motion_context_file'],'')
        self.assertEqual(values['motion_context_frames'],22)
        self.assertEqual(values['motion_context_audio_frames'],22)
        self.assertFalse(values['motion_context_reuse_latent'])

    def test_explicit_zero_is_rejected_before_comfy(self):
        graph={'159':{'class_type':'H3StudioImageToVideo','inputs':{'motion_context_frames':0,'motion_context_audio_frames':22}}}
        with self.assertRaisesRegex(ValueError,'motion_context_frames = 0'):
            newer._preflight_h3_numeric_inputs(graph,schema())

    @unittest.skip('V10.63: test synthétique V56 incompatible avec le graphe indépendant Roycho; remplacé par V63 contracts')
    def test_new_graph_all_four_engines_and_quick(self):
        def faux_graph(*_):
            return {'159':{'class_type':'H3StudioImageToVideo','inputs':{'prompt':'','width':1152,'height':640}},
                    '207':{'class_type':'SamplerCustomAdvanced','inputs':{'latent_image':['159',1]}},
                    '191':{'class_type':'SaveVideo','inputs':{'filename_prefix':'original'}},
                    '129':{'class_type':'RandomNoise','inputs':{'noise_seed':7}}}
        seconds={'start':1.0,'end':2.0,'duration':124/24,'frames':124}
        with patch.object(newer,'_snapshot_gui',return_value={}),\
             patch.object(newer.rt,'gui_to_api',side_effect=faux_graph),\
             patch.object(newer.rt,'patch_models',return_value=None),\
             patch.object(newer.rt,'reset_h3_optional_inputs',return_value=None),\
             patch.object(newer,'_metadata',return_value={'width':1152,'height':640,'frames':124,'duration':124/24}):
            for mode in newer.MODES:
                for quick in (False,True):
                    with self.subTest(mode=mode,quick=quick):
                        graph=newer.build_graph(schema(),mode,'Demo','1',Path('source.mp4'),
                                'f'*32,seconds,'Elle se tourne vers la caméra.',(0,0,100,100),test_clip=quick)
                        h3=graph['159']['inputs']
                        self.assertGreaterEqual(h3['motion_context_frames'],1)
                        self.assertGreaterEqual(h3['motion_context_audio_frames'],1)
                        self.assertEqual(h3['length'],56 if (quick and mode=='extend') else (141 if mode=='extend' else (22 if quick else 124)))
                        if mode!='extend':
                            self.assertEqual(h3['motion_context_file'],'')
                            self.assertEqual(graph['207']['inputs']['latent_image'],['902',0])
                        newer._preflight_h3_numeric_inputs(graph,schema())

if __name__=='__main__': unittest.main()
