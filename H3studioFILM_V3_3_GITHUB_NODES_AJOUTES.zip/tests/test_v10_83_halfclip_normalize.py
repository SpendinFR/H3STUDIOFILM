import shutil, subprocess, tempfile, unittest
from pathlib import Path

import retouches_precise_half_v82 as half


@unittest.skipUnless(shutil.which("ffmpeg") and shutil.which("ffprobe"), "ffmpeg absent")
class NormalizeHalfClipTests(unittest.TestCase):
    def _make(self,path,frames,color):
        cmd=["ffmpeg","-hide_banner","-loglevel","error","-y","-f","lavfi","-i",f"color=c={color}:size=96x64:rate=24",
             "-frames:v",str(frames),"-c:v","libx264","-pix_fmt","yuv420p",str(path)]
        p=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
        self.assertEqual(p.returncode,0,p.stderr)

    def test_trim_longer_generated_clip(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td)
            src=td/'g.mp4'; self._make(src,65,'red')
            out=half._normalize_generated_frames(src,63,td/'comfy')
            self.assertEqual(half._frame_count(out,td/'comfy'),63)

    def test_pad_shorter_generated_clip(self):
        with tempfile.TemporaryDirectory() as td:
            td=Path(td)
            src=td/'g.mp4'; self._make(src,61,'blue')
            out=half._normalize_generated_frames(src,63,td/'comfy')
            self.assertEqual(half._frame_count(out,td/'comfy'),63)

if __name__=='__main__':
    unittest.main()
