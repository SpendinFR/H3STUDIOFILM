"""Specific safety regression tests for deterministic RAW performance and insertion windows."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import sys
import torch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_next as n
import retouches_new_windowing as w

class ExplicitPerformance(unittest.TestCase):
    def test_all_three_templates_no_llm(self):
        original='[Shot 2] old phrase <d>[French]Ne bouge pas.</d>\n**look_caméra_et_lumière :** low light'
        with patch.object(n.urllib.request,'urlopen',side_effect=AssertionError('No LLM calls')):
            texts={}
            for t,value in [('action','Elle lève la main droite.'),('emotion','Elle est terrorisée.'),('dialogue','Je t’avais prévenu.')]:
                texts[t],method=n._rewrite_shot('performance',value,original,0,5,performance_type=t)
                self.assertIn(value,texts[t]);self.assertIn(t,method)
                self.assertNotIn('Ne bouge pas',texts[t])
        self.assertNotIn('<d>',texts['action'])
        self.assertNotIn('<d>',texts['emotion'])
        self.assertIn('<d>[French]Je t’avais prévenu.</d>',texts['dialogue'])
        self.assertNotIn('elle dit :',texts['dialogue'].lower())

    def test_mode_affects_audio_denoise(self):
        schema=json.loads((ROOT/'retouches_new_workflows'/'TEST_COMFY_SCHEMA.json').read_text('utf-8')) if (ROOT/'retouches_new_workflows'/'TEST_COMFY_SCHEMA.json').exists() else None
        if schema is None:
            from test_v10_56_comfy_input_schema import schema as schema_function
            schema=schema_function()
        # Instead test graph source logic through static match: no heuristic french keyword routing.
        txt=(ROOT/'retouches_next.py').read_text('utf-8')
        self.assertIn("performance_type=='dialogue'",txt)
        self.assertNotIn("any(s in instruction.lower()",txt)
        self.assertIn("'performance_type':performance_type",txt)
        html=(ROOT/'studio_ui/index.html').read_text('utf-8')
        for t in ('action','emotion','dialogue'):
            self.assertIn(f'data-perf-type="{t}"',html)
        js=(ROOT/'studio_ui/studio-new-retouches.js').read_text('utf-8')
        self.assertIn('performance_type:performanceType',js)

class Windowing(unittest.TestCase):
    def test_plan_124_frames(self):
        starts=w.plan_windows(37)
        self.assertEqual(starts[0],0)
        self.assertEqual(starts[-1],25)
        cuts=w.cut_points(starts,124)
        self.assertEqual(sum(b-a for a,b in cuts),124)
        self.assertTrue(all(0<=a<b<=39 for a,b in cuts))

    def test_original_latent_never_modified(self):
        with tempfile.TemporaryDirectory() as td:
            latent=Path(td)/'original.pt'
            saved={'version':2,'samples':{'nested':True,'members':[
                {'tensor':torch.zeros(1,4,37,4,5), 'shape':(1,4,37,4,5),'device':'cpu'},
                {'tensor':torch.zeros(1,4,2,123), 'shape':(1,4,2,123),'device':'cpu'}]},'noise_mask':None}
            torch.save(saved,latent)
            out=w.write_window(saved,latent,'temp_2',25)
            self.assertEqual(out,Path(td)/'temp_2.pt')
            sample=torch.load(out,weights_only=True)['samples']['members']
            self.assertEqual(sample[0]['tensor'].shape[2],12)
            self.assertGreater(sample[1]['tensor'].shape[-1],0)
            self.assertEqual(saved['samples']['members'][0]['tensor'].shape[2],37)
            self.assertEqual(torch.load(latent,weights_only=True)['samples']['members'][0]['tensor'].shape[2],37)

if __name__=='__main__':unittest.main()
