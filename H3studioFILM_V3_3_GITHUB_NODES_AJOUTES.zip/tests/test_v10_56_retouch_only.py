"""Focused, dependency-free regressions for V10.56 based on pristine V10.52."""
import pathlib
import sys
import tempfile
import subprocess
from unittest.mock import patch
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_masked_core as masked
import retouches_engine as engine

class TestRetouchOnlyV1056(unittest.TestCase):
    def graph(self,mode):
        with patch.object(masked,'_make',side_effect=lambda obj,t,**inp:{'class_type':t,'inputs':inp}):
            return masked.build({},mode,'clip.mp4','reference.png' if mode in ('swap_person','remove_person') else None,
                 'person','', 'minimax_h3_singularity_ref2va_pruned_v1.3_int8.safetensors',
                 frames=124,width=736,height=1280)

    def test_swap_actual_mask_dilated_and_copied_with_crop(self):
        g=self.graph('swap_person')
        self.assertEqual(g['44']['class_type'],'GrowMask')
        self.assertGreaterEqual(g['44']['inputs']['expand'],15)
        self.assertEqual(g['9']['inputs']['mask'],['44',0])
        self.assertEqual(g['25']['inputs']['masks'],['44',0])
        self.assertEqual(g['41']['inputs']['cropped_masks'],['25',1])
        self.assertEqual(g['28']['inputs']['masks'],['25',1])
        self.assertEqual(g['11']['inputs']['method'],'components')
        self.assertEqual(g['7']['inputs']['detect_interval'],6)
        self.assertEqual(g['36']['inputs']['steps'],8)
        self.assertEqual(g['37']['inputs']['sampler_name'],'euler')
        self.assertEqual(g['24']['inputs']['lora_name'],'h3_character_swap_pro4500_1000.safetensors') if '24' in g else None
    def test_remove_green_mask_and_h3_mask_same(self):
        g=self.graph('remove_person')
        self.assertEqual(g['44']['class_type'],'GrowMask')
        self.assertEqual(g['9']['inputs']['mask'],['44',0])
        self.assertEqual(g['28']['inputs']['masks'],['44',0])
        self.assertNotIn('25',g)
        self.assertNotIn('41',g)
        self.assertEqual(g['36']['inputs']['steps'],12)
        self.assertEqual(g['37']['inputs']['sampler_name'],'er_sde')
    def test_untouched_modes_have_no_new_nodes(self):
        for mode in ('local_edit','replace_background'):
            g=self.graph(mode)
            self.assertNotIn('44',g)
            self.assertEqual(g['7']['inputs']['detect_interval'],12)
    def test_timing_native_5sec_trimmed_precisely(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d)
            orig=root/'source.mp4'; render=root/'render.mp4'
            def make(path,seconds):
                r=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',
                    '-f','lavfi','-i',f'testsrc=size=128x128:rate=24:duration={seconds}',
                    '-c:v','libx264','-pix_fmt','yuv420p',str(path)],capture_output=True,text=True,timeout=35)
                if r.returncode:raise RuntimeError(r.stderr[-500:])
            make(orig,5)
            make(render,124/24)
            self.assertEqual(engine._video_metadata(orig)['frames'],120)
            self.assertEqual(engine._video_metadata(render)['frames'],124)
            self.assertTrue(engine._restore_source_length(render,orig,{'mode':'swap_person'}))
            self.assertEqual(engine._video_metadata(render)['frames'],120)
            self.assertAlmostEqual(engine._video_metadata(render)['duration'],5.0,places=2)
            self.assertFalse(engine._restore_source_length(render,orig,{'mode':'swap_person'}))
    def test_rejects_shortened_5sec_and_never_glues_original_actor_back(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);orig=root/'source.mp4';short=root/'short.mp4'
            for path,seconds in ((orig,5.0),(short,4.5)):
                r=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi','-i',
                    f'color=c=white:size=128x128:rate=24:duration={seconds}',
                    '-c:v','libx264',str(path)],capture_output=True,text=True,timeout=35)
                if r.returncode:raise RuntimeError(r.stderr)
            with self.assertRaisesRegex(RuntimeError,'incomplet'):
                engine._restore_source_length(short,orig,{'mode':'swap_person'})
            self.assertEqual(engine._video_metadata(short)['frames'],108)
            self.assertFalse(engine._restore_source_length(short,orig,{'mode':'replace_background'}))

if __name__=='__main__':unittest.main()
