"""Static data-flow regression for actual workflow JSON (not a hand-drawn graph)."""
import json, sys
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_next as n
class WorkflowStatic(unittest.TestCase):
    def test_production_source_has_model_and_sampler(self):
        gui=n._snapshot_gui()
        nodes={str(a['id']):a for a in gui['nodes']}
        links={z[0]:z for z in gui['links']}
        for node_id in ('127','173','174','175','176','178','179','207','159','191','129'):
            self.assertIn(node_id,nodes)
        self.assertEqual(nodes['174']['type'],'MiniMaxH3SigmaShift')
        old_model_input=next(v for v in nodes['174']['inputs'] if v['name']=='model')
        self.assertEqual(str(links[old_model_input['link']][1]),'224')
    def test_inpaint_uses_exact_raw_loader_and_separate_copy(self):
        source=(ROOT/'retouches_next.py').read_text()
        self.assertIn("'902']={'class_type':'H3RetouchMaskV58'",source)
        self.assertIn("graph['207']['inputs']['latent_image']=['902',0]",source)
        self.assertIn("graph['901']={'class_type':'H3LoadRawLatentExact'",source)
        self.assertNotIn("graph['902']={'class_type':'H3RetouchRawMask'",source)
if __name__=='__main__':unittest.main()
