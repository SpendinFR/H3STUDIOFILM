"""V10.90 regression proof: unchanged V83 author, unchanged V88 seam and preroll."""
import hashlib
import re
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path
from zipfile import ZipFile
from unittest.mock import patch

import torch
import retouches_llm_prompt_half_v82 as writer
import retouches_precise_half_v82 as half
import retouches_precise_center_v90 as center

PACKAGE=Path(__file__).resolve().parents[1]
DATA=PACKAGE.parent
V83=DATA/'H3Film_STUDIO_V10_83_RETAKE_HALF_CLIP_FRAMECOUNT_FIX.zip'
V88=DATA/'H3Film_STUDIO_V10_88_RETAKE_PROMPT_GEMMA_63F_RESTORE.zip'


def prompt_for_window(w):
    desc={
        'TRANSITION AVANT':'Elle regarde son écran en souriant, puis tourne doucement la tête.',
        'ACTION':'Elle lève la main droite vers sa tête, puis la redescend.',
        'TRANSITION APRÈS':'Elle regarde de nouveau son audience en continuant de parler.',
    }
    shots='\n'.join(f'[Shot {i}] {a:.3f}–{b:.3f}s {desc[role]}'
                    for i,(role,a,b) in enumerate(writer._grid(w),1))
    return writer._assemble('La streameuse parle doucement face à sa caméra.',shots,w)


class ByteIdentity(unittest.TestCase):
    def test_exact_v83_writer_and_v88_stitch_code(self):
        expected={
            'retouches_llm_prompt_half_v82.py':'c028265a4e005b1d4215a1041be419f0107320de728ffa1977d7e41fe910ee30',
            'retouches_precise_half_v82.py':'543792e521ac872dd37cce069e51fad67a4492b240cfe82045942064dd24c36f',
            'retouches_preroll_prompt_v88.py':'2dc56bf5aa42d7d96c321758d90e42c19ed19590e9de1b822fb30c730505fbf7',
        }
        for name,value in expected.items():
            self.assertEqual(hashlib.sha256((PACKAGE/name).read_bytes()).hexdigest(),value,name)
        # When the original archives are present, also compare bytes directly.
        for original,local in ((V83,'retouches_llm_prompt_half_v82.py'),
                               (V88,'retouches_precise_half_v82.py'),
                               (V88,'retouches_preroll_prompt_v88.py')):
            if original.exists():
                with ZipFile(original) as z:
                    self.assertEqual((PACKAGE/local).read_bytes(),z.read(local))

    def test_center_local_prompt_uses_only_v83_authored_63_frames(self):
        core,render=center.select_window(37,124,2,3)
        self.assertEqual((core['frames'],render['frames']),(63,83))
        self.assertEqual(render['preroll_frames']+render['postroll_frames'],20)
        local=prompt_for_window(core)
        self.assertIn('exactly 2.625s',local)
        self.assertIn('Action assigned within the local take at 0.875–1.875s',local)
        h3=center.prepare_prompt(local,core,render)
        self.assertIn('exactly 3.458s',h3)
        self.assertIn('Action assigned within the local take at 1.292–2.292s',h3)
        self.assertEqual(h3.count('Elle lève la main droite'),1)
        self.assertEqual(h3.count('Elle regarde de nouveau son audience'),1)
        self.assertEqual(h3.count('Elle regarde son écran en souriant'),1)
        self.assertEqual(len(re.findall(r'\[Shot \d+\]',h3)),3)
        self.assertTrue(core['origin_frame']<int(2*24)<int(3*24)<core['end_frame'])

    def test_original_v88_mode_unchanged(self):
        halfw=half.select_window(37,124,3.6,4.5)
        render=half.render_window_with_preroll(halfw,37,124)
        self.assertEqual((halfw['frames'],render['frames'],render['preroll_frames']),(63,73,10))
        from retouches_preroll_prompt_v88 import prepare_for_h3
        self.assertIn('exactly 3.042s',prepare_for_h3(prompt_for_window(halfw),halfw,render))
        early=half.select_window(37,124,0,1.5)
        earlyr=half.render_window_with_preroll(early,37,124)
        self.assertEqual((early['frames'],earlyr['frames']),(63,63))

    def test_latent_exact_h3_core_staging(self):
        core,render=center.select_window(37,124,2,3)
        tensors={'samples':{'members':[{'tensor':torch.arange(37,dtype=torch.float32).view(1,1,37,1,1),'device':'cpu'},
                                       {'tensor':torch.arange(400,dtype=torch.float32).view(1,1,1,400),'device':'cpu'}]},'noise_mask':None}
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);src=root/'base.pt';torch.save(tensors,src)
            before=hashlib.sha256(src.read_bytes()).hexdigest()
            dest=half.write_window(tensors,src,'center',render)
            data=torch.load(dest,weights_only=True)['samples']['members'][0]['tensor']
            self.assertEqual(data.shape[2],25)
            self.assertEqual(int(data.flatten()[0].item()),render['start_latent'])
            self.assertEqual(hashlib.sha256(src.read_bytes()).hexdigest(),before)


@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'ffmpeg absent')
class RealVideo(unittest.TestCase):
    def make(self,p,n,filter):
        args=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi','-i',filter,
              '-frames:v',str(n),'-c:v','libx264','-pix_fmt','yuv420p',str(p)]
        r=subprocess.run(args,capture_output=True,text=True,timeout=45)
        self.assertEqual(r.returncode,0,r.stderr)

    def test_actual_two_seams_ffmpeg_and_original_integrity(self):
        core,render=center.select_window(37,124,2,3)
        with tempfile.TemporaryDirectory() as t:
            d=Path(t);comfy=d/'comfy';(comfy/'input').mkdir(parents=True)
            source=d/'source.mp4';raw=d/'generated83.mp4';target=d/'final.mp4'
            self.make(source,124,'testsrc2=size=96x64:rate=24')
            self.make(raw,83,'color=c=white:size=96x64:rate=24')
            hash_before=hashlib.sha256(source.read_bytes()).hexdigest()
            ref=half.stage_reference(source,comfy,'a'*32,render)
            self.assertEqual(half._frame_count(comfy/'input'/ref,comfy),83)
            center.stitch(source,raw,target,core,render,124,comfy)
            self.assertEqual(half._frame_count(target,comfy),124)
            self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(),hash_before)

    def test_center_retake_full_mock_h3_routing(self):
        import retouches_next as engine
        core,render=center.select_window(37,124,2,3)
        with tempfile.TemporaryDirectory() as t:
            d=Path(t);comfy=d/'comfy';(comfy/'input').mkdir(parents=True)
            source=d/'source.mp4';raw=d/'generated83.mp4';latent=d/'clip_0001_RAW_LATENT.pt'
            self.make(source,124,'testsrc2=size=96x64:rate=24')
            self.make(raw,83,'color=c=white:size=96x64:rate=24')
            payload={'samples':{'members':[{'tensor':torch.zeros(1,1,37,1,1),'device':'cpu'},
                                           {'tensor':torch.zeros(1,1,1,400),'device':'cpu'}]},'noise_mask':None}
            torch.save(payload,latent)
            ident='d'*32
            graph_args=[]
            def graph_mock(info,mode,project,clip,source,ident,settings,instruction,rect,**kwargs):
                graph_args.append((settings,kwargs))
                return {'902':{'class_type':'H3RetouchMaskV58','inputs':{}},
                        '159':{'class_type':'H3StudioImageToVideo','inputs':{'ref_video_files':kwargs['conditioning_video_name']}}}
            def api(endpoint,payload=None,timeout=None):
                if endpoint=='/object_info':return {name:{} for name in engine.REQUIRED}
                if endpoint=='/prompt':return {'prompt_id':'central_test'}
                if endpoint=='/history/central_test':return {'central_test':{'status':{'status_str':'success'},'outputs':{'191':{}}}}
                raise AssertionError(endpoint)
            with patch.object(engine,'ROOT',d/'jobs_root'),patch.object(engine,'JOBS',d/'jobs_root'/'jobs'), \
                 patch.object(engine,'RESULTS',d/'jobs_root'/'results'), \
                 patch.object(engine,'_project',return_value=(source,latent)), \
                 patch.object(engine,'_metadata',return_value={'fps':24,'duration':124/24,'frames':124,'width':96,'height':64}), \
                 patch.object(engine,'_authoring_context',return_value=('[Shot 1] 0–5.167s Original',[],[])), \
                 patch.object(engine,'build_graph',side_effect=graph_mock), \
                 patch.object(engine.legacy,'comfy_json',side_effect=api), \
                 patch.object(engine,'_history_output',return_value=raw), \
                 patch.object(engine,'_measured_visual_change',return_value=20.0), \
                 patch.object(engine.rt,'query_gpu_vram',return_value=None), \
                 patch('retouches_llm_prompt_center_v93.write_prompt',return_value=(prompt_for_window(core),'V83 literal')), \
                 patch.object(engine.time,'sleep'):
                engine._save({'id':ident,'project':'test','clip':'1','mode':'precise',
                    'instruction':'Elle lève la main droite','performance_type':'action',
                    'selected':True,'start':2.0,'end':3.0,'test_clip':False,'region':None})
                engine._run(ident,lambda project:d,lambda:comfy)
                job=engine.job(ident)
                self.assertEqual(job['status'],'complete',job.get('error'))
                self.assertEqual(len(graph_args),1)
                settings,kwargs=graph_args[0]
                self.assertEqual(settings['frames'],83)
                self.assertIn('__center_',kwargs['latent_name'])
                self.assertIn('exactly 3.458s',kwargs['revised_prompt'])
                gemma_prompt=(d/'jobs_root'/ident/'gemma_center_63f_part1.txt').read_text('utf8')
                self.assertIn('exactly 2.625s',gemma_prompt)
                self.assertEqual(half._frame_count(d/'jobs_root'/'results'/(ident+'.mp4'),comfy),124)
                self.assertFalse((latent.parent/(kwargs['latent_name']+'.pt')).exists())

if __name__=='__main__': unittest.main()
