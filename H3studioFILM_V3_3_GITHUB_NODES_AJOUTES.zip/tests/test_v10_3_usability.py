"""No-GPU regressions for the Director workspace, UI and render contract."""
from pathlib import Path
import json
import zipfile
import os
import sys
import tempfile
import unittest
from unittest.mock import patch

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))
import studio_web as web
import studio_bridge as bridge

class V103(unittest.TestCase):
    def test_v9_exact_h3_graph(self):
        previous=Path('/mnt/data/H3Film_STUDIO_OFF_FINAL_CLEAN_H3_1920_API_CLEAN_V9_RAW_MAX_REFINE_NO_VISUAL_REFS.zip')
        if previous.exists():
            with zipfile.ZipFile(previous) as z:
                self.assertEqual((BASE/'workflows/H3Studio_1920_API_CLEAN.json').read_bytes(),z.read('workflows/H3Studio_1920_API_CLEAN.json'))
        txt=(BASE/'h3_runtime_simple.py').read_text(encoding='utf-8')
        self.assertIn('h3["ref_image_size"] = "max"',txt)
        self.assertIn('CONT_FRAME_COUNT = 141',txt)
        self.assertIn('FIRST_FRAME_COUNT = 124',txt)
        raw=(BASE/'h3film_studio_v3.py').read_text(encoding='utf-8')
        self.assertIn('RAW 8 steps',raw)
        self.assertIn('refine 4 sigma',raw)
    def test_progress_and_exact_krea_reference(self):
        py=(BASE/'h3film_studio_v3.py').read_text(encoding='utf-8')
        self.assertIn("image=image_path,progress=progress",py)
        self.assertIn("'image_path':str(image) if isinstance(image,(str,Path)) else ''",py)
        js=(BASE/'studio_ui/studio.js').read_text(encoding='utf-8')
        self.assertIn('ctx.image_url',js)
        self.assertIn('progress.remaining',js)
        self.assertIn('Références :',js)
    def test_forced_review_when_raw_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            old=bridge.DIR
            try:
                bridge.DIR=Path(td)
                (bridge.DIR/'answers').mkdir()
                bridge._write('config.json',{'reviews':{'clips':False}})
                # Normal clip validation auto-continues.
                self.assertEqual(bridge.checkpoint('clips','Ordinaire')['action'],'continue')
                import threading,time
                response=[]
                t=threading.Thread(target=lambda:response.append(bridge.checkpoint('clips','Correction',{'text':'new'},force=True)))
                t.start()
                for i in range(100):
                    q=bridge._get('review.json')
                    if q and q.get('title')=='Correction':break
                    time.sleep(.01)
                else:self.fail('force review not installed')
                bridge._write(f"answers/{q['id']}.json",{'action':'continue'})
                t.join(5)
                self.assertFalse(t.is_alive())
                self.assertEqual(response[0]['action'],'continue')
            finally:
                bridge.DIR=old
    def test_project_title_is_saved_and_shown(self):
        js=(BASE/'studio_ui/studio.js').read_text(encoding='utf-8')
        html=(BASE/'studio_ui/index.html').read_text(encoding='utf-8')
        self.assertIn('id="filmName"',html)
        self.assertIn("title:$('filmName').value",js)
        self.assertIn('project.project_info?.title',js)
    def test_video_retry_and_log_scroll(self):
        js=(BASE/'studio_ui/studio.js').read_text(encoding='utf-8')
        self.assertIn("$('video').addEventListener('error'",js)
        self.assertIn('setLogText(logs.log',js)
        self.assertIn('const prevTop=log.scrollTop',js)
        self.assertIn('videoAttempts>=8',js)
    def test_status_current_krea_url(self):
        with tempfile.TemporaryDirectory() as td:
            comfy=Path(td); p=comfy/'output'/'H3FilmSimple'/'project';p.mkdir(parents=True)
            image=p/'studio_krea'/'test.png';image.parent.mkdir();image.write_bytes(b'png')
            u=web.media_uri
            with patch.object(web,'comfy_path',return_value=comfy):
                self.assertEqual(u(str(image)),'/media/output/H3FilmSimple/project/studio_krea/test.png')
    def test_html_css_endpoint(self):
        html=(BASE/'studio_ui/index.html').read_text(encoding='utf-8')
        server=(BASE/'studio_web.py').read_text(encoding='utf-8')
        self.assertIn('/studio-v10-3.css',html)
        self.assertIn("'/studio-v10-3.css'",server)
        self.assertIn('id="projectsMenuBtn"',html)
    def test_director_failure_never_resends_old_raw(self):
        script=(BASE/'h3film_studio_v3.py').read_text(encoding='utf-8')
        self.assertIn('ancien prompt NON réutilisé',script)
        self.assertIn('rejected_h3_prompt=h3_prompt',script)
        self.assertIn('force=True',script)

if __name__=='__main__':unittest.main()
