"""V10.71: rolling short H3 removal; no GPU required."""
from pathlib import Path
import sys, unittest
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_remove_relay as relay
import retouches_engine as engine
import retouches_masked_core as masked

class TestRelay(unittest.TestCase):
    def test_exact_five_second_coverage_and_no_blend(self):
        windows=relay.intervals(124)
        self.assertEqual(len(windows),7)
        self.assertEqual(windows[0],(0,22))
        self.assertEqual(windows[-1],(102,124))
        self.assertTrue(all(b-a==22 for a,b in windows))
        self.assertTrue(all(windows[i][0] == windows[i-1][1]-5 for i in range(1,7)))
        self.assertEqual(22+(len(windows)-1)*17,124)
        with self.assertRaises(ValueError):relay.intervals(120)

    def test_graph_replaces_sam_redetection_with_prechecked_masks(self):
        with patch.object(masked,'_make',side_effect=lambda obj,t,**inp:{'class_type':t,'inputs':inp}):
            graph=masked.build({},'remove_person','source.mp4','clean_plate.png','woman','',
                'minimax_h3_singularity.safetensors',frames=22,width=1152,height=640,
                conditioned_video_filename='green.mp4')
        relay.attach_exact_mask(graph,'prechecked_mask.mp4',
                                {'LoadVideo':{},'GetVideoComponents':{},'ImageToMask':{}}, continuation=True)
        self.assertNotIn('7',graph)
        self.assertNotIn('44',graph)
        self.assertEqual(graph['28']['inputs']['masks'],['72',0])
        self.assertEqual(graph['28']['inputs']['grow_temporal'],0)
        self.assertEqual(graph['14']['inputs']['video'],['13',0])
        self.assertEqual(graph['32']['inputs']['image'],'clean_plate.png')
        self.assertEqual(graph['36']['inputs']['steps'],12)
        self.assertEqual(graph['37']['inputs']['sampler_name'],'er_sde')
        self.assertEqual(graph['72']['inputs']['channel'],'red')
        for node in graph.values():
            for val in node.get('inputs',{}).values():
                if isinstance(val,list) and len(val)==2 and isinstance(val[0],str):
                    self.assertIn(val[0],graph,'Dangling graph link')

    def test_swap_graph_identical_and_short_remove_unchanged(self):
        with patch.object(masked,'_make',side_effect=lambda obj,t,**inp:{'class_type':t,'inputs':inp}):
            swap=masked.build({},'swap_person','source.mp4','person.png','woman','',
                'minimax_h3_singularity.safetensors',frames=124,width=1152,height=640)
            remove_short=masked.build({},'remove_person','source.mp4','plate.png','woman','',
                'minimax_h3_singularity.safetensors',frames=22,width=1152,height=640)
        self.assertEqual(swap['44']['inputs']['expand'],26)
        self.assertEqual(swap['28']['inputs']['grow_temporal'],1)
        self.assertEqual(remove_short['44']['inputs']['expand'],12)
        self.assertEqual(remove_short['28']['inputs']['grow_temporal'],1)

if __name__=='__main__':unittest.main()
