"""V10.66 verifies real active paths. These are CPU/graph tests, not GPU fidelity."""
import pathlib, sys, unittest
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_next as n
import retouches_llm_prompt_v66 as director

class V66Contracts(unittest.TestCase):
    def test_retakes_do_not_reach_external_diffsynth(self):
        text=(ROOT/'retouches_next.py').read_text(encoding='utf-8')
        self.assertNotIn('_run_true_diffsynth_job(',text)
        self.assertNotIn('DiffSynthJob',text)
        self.assertNotIn('DiffSynthGeneratedWindowV62',text)
        self.assertNotIn('H3DiffSynthClipRetakeV59',text)
        self.assertEqual(n.EXTRA_REQUIRED['precise'],set())
        self.assertFalse((ROOT/'retouches_diffsynth').exists())
    def test_launcher_never_executes_pip(self):
        text=(ROOT/'LANCER-RETOUCHES-V10_66.cmd').read_text(encoding='utf8')
        self.assertNotIn('DIFFSYNTH',text.upper().replace('AUCUN DIFFSYNTH',''))
        self.assertNotIn('pip install',text)
        self.assertNotIn('INSTALLER-DIFFSYNTH',text)
        self.assertNotIn('PY=python',text)
        ps=(ROOT/'NETTOYER-ANCIEN-DIFFSYNTH-V10_66.ps1').read_text(encoding='utf8')
        self.assertIn('H3RetouchDiffSynth',ps)
        self.assertIn('if (!$ConfirmerSuppression)',ps)
        self.assertNotIn('pip uninstall',ps)
    def test_prompt_authority_held_in_wrapper(self):
        text=director.assemble('Il se retourne', '[Shot 1] The actor rotates toward the window with progressive eye and torso focus. His head finishes the rotation naturally.',.121,1.217,5.15)
        self.assertIn('0.121s',text)
        self.assertIn('1.217s',text)
        self.assertIn('EXACT REQUEST: Il se retourne',text)
    def test_llm_unloads_even_when_exception(self):
        class FakeBackend:
            called=[]
            def _ollama_backend(self,n):return {'provider':'ollama','model':n,'display':n}
            def _llama_backend(self,key):return {'provider':'llamacpp','key':key,'display':key}
            def installed_model_names(self,tags):return ['gemma4:26b-a4b-it-q4_k_m']
            def director_text(self,*args,**kwargs):raise RuntimeError('offline')
            def unload_text_backend(self,*args,**kwargs):self.called.append('unload')
            def release_all_text_models_for_h3(self,*args,**kwargs):self.called.append('release')
        fake=FakeBackend()
        import h3film_studio_v3 as film
        fake.rt=film.rt
        with patch.object(director,'choose_backend',return_value={'provider':'ollama','model':'gemma4:26b','display':'26b'}),\
             patch.object(film,'director_text',side_effect=RuntimeError('offline')),\
             patch.object(film,'unload_text_backend',side_effect=lambda *args,**kw: fake.called.append('unload')),\
             patch.object(film,'release_all_text_models_for_h3',side_effect=lambda **kw:fake.called.append('release')):
            with self.assertRaisesRegex(RuntimeError,'offline'):
                director.write_prompt(mode='performance',performance_type='emotion',request='Elle fronce les sourcils',source_prompt='Studio',start=.1,end=1.2,duration=5.15,gpu_prepare=lambda:None)
        self.assertEqual(fake.called,['unload','release'])
    def test_source_prompt_preserved_readonly(self):
        text=director.build_request('precise','action','change la direction du regard','camera stationary',.2,1.4,5.1)
        self.assertIn('camera stationary',text)
        self.assertIn('0.200s to 1.400s',text)
    def test_static_mask_for_visual_retake(self):
        def api(*_):
            return {
                '127':{'class_type':'UNETLoader','inputs':{'unet_name':'Singularity'}},
                '174':{'class_type':'MiniMaxH3SigmaShift','inputs':{'model':['127',0]}},
                '176':{'class_type':'BasicScheduler','inputs':{'scheduler':'simple','steps':8,'denoise':1.}},
                '178':{'class_type':'KSamplerSelect','inputs':{'sampler_name':'euler'}},
                '207':{'class_type':'SamplerCustomAdvanced','inputs':{'latent_image':['159',1]}},
                '159':{'class_type':'H3StudioImageToVideo','inputs':{'prompt':'','width':1152,'height':640, 'v2v_video_file':'','ref_video_files':''}},
                '191':{'class_type':'SaveVideo','inputs':{'filename_prefix':'orig'}},
                '129':{'class_type':'RandomNoise','inputs':{'noise_seed':5}},
                '119':{'class_type':'VAELoader','inputs':{}},
                '188':{'class_type':'VAEDecode','inputs':{}},
                '189':{'class_type':'VAEDecodeAudio','inputs':{}},
                '190':{'class_type':'CreateVideo','inputs':{'images':['188',0],'audio':['189',0]}},
                '179':{'class_type':'BasicGuider','inputs':{'conditioning':['159',0]}},
            }
        params=dict(info={},project='Demo',clip='1',source=pathlib.Path('clip.mp4'),ident='f'*32,
                    seconds={'start':.375,'end':1.25,'duration':124/24,'frames':124},instruction='Une émotion plus forte',rect=(0,0,100,100),conditioning_video_name='h3new_demo_source.mp4')
        with patch.object(n,'_snapshot_gui',return_value={}),patch.object(n.rt,'gui_to_api',side_effect=api),patch.object(n.rt,'patch_models',return_value=None),patch.object(n.rt,'reset_h3_optional_inputs',return_value=None),patch.object(n,'_metadata',return_value={'width':1152,'height':640,'frames':124,'duration':124/24}):
            talk=n.build_graph(mode='performance',performance_type='dialogue',**params)
            visual=n.build_graph(mode='performance',performance_type='emotion',**params)
            ret=n.build_graph(mode='precise',**params)
        for graph in (visual,ret):
            self.assertEqual(graph['902']['class_type'],'H3RetouchMaskV58')
            self.assertEqual(graph['902']['inputs']['track'],'video only')
            self.assertEqual(graph['207']['inputs']['latent_image'],['902',0])
            self.assertEqual(graph['159']['inputs']['v2v_video_file'],'h3new_demo_source.mp4')
            self.assertNotIn('930',graph)
        self.assertEqual(talk['902']['inputs']['track'],'both')
    def test_vram_release_calls_native_free_only_if_queue_idle(self):
        with patch.object(n.legacy,'comfy_json',return_value={'queue_running':[],'queue_pending':[]}) as q, \
             patch.object(n.rt,'http_json',return_value={}) as h, \
             patch.object(n.rt,'query_gpu_vram',return_value={'used':300,'total':16384,'free':16084}), \
             patch.object(n,'_update') as u, patch.object(n.time,'sleep'):
            self.assertTrue(n._safe_comfy_free('Krea', 'a'*32))
        self.assertEqual(h.call_count,2)
        self.assertTrue(all('/free' in c.args[0] and c.args[1]=='POST' for c in h.call_args_list))
        with patch.object(n.legacy,'comfy_json',return_value={'queue_running':[['other-run']],'queue_pending':[]}), \
             patch.object(n.rt,'http_json') as h:
            with self.assertRaisesRegex(RuntimeError,'file ComfyUI non vide'):
                n._safe_comfy_free('Krea', 'a'*32)
        h.assert_not_called()

    def test_vram_release_never_interrupts_queue(self):
        s=(ROOT/'retouches_next.py').read_text(encoding='utf8')
        a=s.index('def _safe_comfy_free(')
        b=s.index('def _run(',a)
        scope=s[a:b]
        self.assertNotIn("'/interrupt'",scope)
        self.assertNotIn("'/queue',{'clear'",scope)
        self.assertIn("'/free'",scope)
        self.assertIn('queue_running',scope)

if __name__=='__main__':unittest.main()
