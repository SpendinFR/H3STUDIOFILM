"""V10.88: Gemma authors 63f only; H3 73f is a deterministic 10f timing adapter."""
from __future__ import annotations
import re
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from retouches_preroll_prompt_v88 import prepare_for_h3
import retouches_precise_half_v82 as half
import retouches_llm_prompt_half_v82 as gemma


def example_gemma_prompt(w):
    g=gemma._grid(w)
    desc={
        'TRANSITION AVANT':'Un léger mouvement de recul du visage, marquant une pause réflexive.',
        'ACTION':'Elle lève la main droite et se gratte l’arrière de la tête avec un air incrédule.',
        'TRANSITION APRÈS':'Son regard se fixe à nouveau intensément vers l’objectif, prête à parler.',
    }
    shots='\n'.join(f'[Shot {i}] {a:.3f}–{b:.3f}s {desc[role]}' for i,(role,a,b) in enumerate(g,1))
    return gemma._assemble('La streameuse sourit face à la caméra, dans sa chambre.',shots,w)


class TestV1088(unittest.TestCase):
    def setUp(self):
        self.half=half.select_window(37,124,3.6,4.5)
        self.render=half.render_window_with_preroll(self.half,37,124)
        self.local=example_gemma_prompt(self.half)

    def test_validated_gemma_is_still_the_working_63_frame_window(self):
        instruction=gemma._instruction(request='Elle se gratte la tête',source_prompt='',window=self.half)
        self.assertIn('LOCAL SOURCE WINDOW IN THE ORIGINAL CLIP: 2.542–5.167s',instruction)
        self.assertIn('1.042–1.958s',instruction)
        self.assertNotIn('2.125–5.167s',instruction)
        self.assertIn('exactly 2.625s',self.local)
        self.assertIn('[Shot 1] 0.000–1.042s',self.local)
        self.assertIn('[Shot 2] 1.042–1.958s',self.local)

    def test_extra_h3_frames_shift_only_shot_headers_not_action_prose(self):
        sent=prepare_for_h3(self.local,self.half,self.render)
        self.assertIn('exactly 3.042s',sent)
        self.assertIn('[Shot 1] 0.000–0.417s',sent)
        self.assertIn('[Shot 2] 0.417–1.458s',sent)
        self.assertIn('[Shot 3] 1.458–2.375s Elle lève la main droite',sent)
        self.assertIn('[Shot 4] 2.375–3.042s Son regard',sent)
        self.assertIn('Action assigned within the local take at 1.458–2.375s.',sent)
        for fragment in ('Un léger mouvement de recul','Elle lève la main droite',
                         'Son regard se fixe à nouveau'):
            self.assertEqual(self.local.count(fragment),sent.count(fragment))
        self.assertNotIn('— TRANSITION AVANT',sent)
        self.assertEqual(len(re.findall(r'\[Shot \d+\]',sent)),4)

    def test_unrelated_first_half_byte_identical(self):
        w=half.select_window(37,124,0,1.5)
        r=half.render_window_with_preroll(w,37,124)
        local=gemma._assemble('La streameuse sourit face à la caméra, dans sa chambre.',
               '[Shot 1] 0.000–1.500s Elle lève la main et regarde la caméra.\n'
               '[Shot 2] 1.500–2.625s Elle repose le bras doucement.',w)
        self.assertEqual(prepare_for_h3(local,w,r),local)

    def test_placeholder_gemma_rejected_and_retried(self):
        fake=('SCENE_CONTEXT: La streameuse est face à une caméra dans sa chambre.\nNEW_TAKE:\n'
              '[Shot 1] 0.000–1.042s TRANSITION AVANT\n'
              '[Shot 2] 1.042–1.958s Elle lève la main droite et se gratte la tête.\n'
              '[Shot 3] 1.958–2.625s TRANSITION APRÈS')
        # V10.90 restores the V83 Gemma writer byte-for-byte. Keep the V88
        # anti-placeholder check at dispatch, without modifying that writer.
        import retouches_precise_center_v90 as center
        local=gemma._assemble('La streameuse est face à la caméra.',
                              '[Shot 1] 0.000–1.042s TRANSITION AVANT\n'
                              '[Shot 2] 1.042–1.958s Elle lève la main droite et se gratte la tête.\n'
                              '[Shot 3] 1.958–2.625s TRANSITION APRÈS',self.half)
        with self.assertRaisesRegex(RuntimeError,'sans description de mouvement'):
            center.verify_gemma_descriptions(local)

    def test_wrong_time_grid_or_unadjusted_prompt_refused(self):
        with self.assertRaisesRegex(ValueError,'décalage RAW'):
            prepare_for_h3(self.local,self.half,{**self.render,'origin_frame':52})
        with self.assertRaisesRegex(ValueError,'temps Gemma'):
            prepare_for_h3(self.local.replace('0.000–1.042s','0.000–1.167s'),self.half,self.render)

    def test_routing_only_gemma_63_and_h3_73(self):
        code=(Path(__file__).resolve().parents[1]/'retouches_next.py').read_text('utf-8')
        self.assertIn('window=local_retake,',code)
        self.assertNotIn('window=render_retake,\n                        gpu_prepare=',code)
        self.assertIn('revised=prepare_for_h3(revised,local_retake,render_retake)',code)
        self.assertIn('precise_half.stage_reference(source,comfy,ident,render_retake)',code)
        self.assertIn('precise_half.trim_preroll(',code)
        self.assertIn('precise_half.stitch(source,trimmed,dest,local_retake',code)


if __name__=='__main__':unittest.main()
