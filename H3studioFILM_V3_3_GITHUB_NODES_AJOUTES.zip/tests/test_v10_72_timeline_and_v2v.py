"""V10.72 offline tests: timestamp integrity, retry, targeted V2V, no legacy mutation."""
import os,sys,unittest,hashlib
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_llm_prompt_v72 as writer
import retouches_next as engine

ORIGINAL='''[Shot 1] 0:00–2.5 Elle rit et regarde l'écran.\n[Shot 2] 2.5–5.167 Elle pointe vers l'écran et interpelle la caméra.'''
CONTEXT="SCENE_CONTEXT: Streameuse dans son bureau, ring-light et figurines, même actrice.\nNEW_TAKE:\n"
VALID=CONTEXT+'''[Shot 1] 0.000–1.293 Elle rit pendant qu'elle soulève et rabaisse la main droite tout en continuant à regarder son écran.
[Shot 2] 1.293–2.500 Elle termine son rire et tourne la tête vers la caméra, sans coupe.
[Shot 3] 2.500–5.167 Elle interpelle le spectateur et pointe l'écran avec un sourire naturel.'''
INVALID=CONTEXT+'''[Shot 1] 0.000–2.500 Elle rit et lève sa main droite sans repère précis.
[Shot 2] 2.500–5.167 Elle interpelle le public et pointe son doigt vers l'écran.'''

class TimelineV72(unittest.TestCase):
    def test_partial_window_aligned(self):
        parts=writer.validate_edit_timeline(writer._split_scene_and_new_take(VALID,ORIGINAL)[1],0,1.293,5.167)
        self.assertEqual(parts,[(0,1.293),(1.293,2.5),(2.5,5.167)])
        assembled=writer.assemble('Elle lève la main',VALID,0,1.293,5.167,ORIGINAL)
        self.assertIn('0.000–1.293',assembled)
        self.assertIn('NEW TAKE',assembled)
        self.assertEqual(assembled.count('[Shot 1]'),1)
        self.assertNotIn(ORIGINAL,assembled)
    def test_wrong_old_shot_boundaries_rejected(self):
        with self.assertRaisesRegex(RuntimeError,'fenêtre sélectionnée'):
            writer.assemble('Elle lève la main',INVALID,0,1.293,5.167,ORIGINAL)
    def test_window_start_interior_must_split(self):
        with self.assertRaisesRegex(RuntimeError,'fenêtre sélectionnée'):
            writer.assemble('cligne des yeux',VALID,0.4,1.293,5.167,ORIGINAL)
        s=CONTEXT+'''[Shot 1] 0–0.400 Elle rit et regarde vers le côté.
[Shot 2] 0.400–1.293 Elle fronce les sourcils en poursuivant son rire.
[Shot 3] 1.293–5.167 Elle continue le plan originel, pointe du doigt vers la caméra et parle.'''
        self.assertEqual(len(writer.validate_edit_timeline(writer._split_scene_and_new_take(s,ORIGINAL)[1],.4,1.293,5.167)),3)
    def test_full_clip_keeps_old_success(self):
        self.assertEqual(len(writer.validate_edit_timeline(writer._split_scene_and_new_take(INVALID,ORIGINAL)[1],0,5.167,5.167)),2)
    def test_timestamp_styles(self):
        q='[Shot 1] 0:00–1,293 Elle rit et regarde la caméra.\n[Shot 2] 1,293–5:00 Elle parle et réagit à la caméra.'
        with self.assertRaisesRegex(RuntimeError,'invalide'):
            writer.validate_edit_timeline(q,0,1.293,5.167)
        q='[Shot 1] 0:00–1,293 Elle rit et regarde la caméra.\n[Shot 2] 1,293–5,167 Elle parle et réagit à la caméra.'
        self.assertEqual(len(writer.validate_edit_timeline(q,0,1.293,5.167)),2)
    def test_gaps_duplicates_and_duration(self):
        for bad in [
            '[Shot 1] 0–1.293 Action et transition.\n[Shot 2] 1.5–5.167 Continuation.',
            '[Shot 1] 0–1.293 Action et transition.\n[Shot 2] 1.293–5.7 Continuation.',
            '[Shot 1] 0–1.293 Action et transition.\n[Shot 3] 1.293–5.167 Continuation.',
            '[Shot 1] Action et transition.\n[Shot 2] 1.293–5.167 Continuation.',
        ]:
            with self.subTest(bad=bad),self.assertRaises(RuntimeError):
                writer.validate_edit_timeline(bad,0,1.293,5.167)
    def test_request_explicit_edit_semantics(self):
        req=writer.build_request('performance','action','ajoute elle lève la main',ORIGINAL,0,1.293,5.167)
        self.assertIn('0.000s et 1.293s',req)
        self.assertIn('ADDITION / SUPERPOSITION',req)
        self.assertIn('SCINDE',req)
        self.assertIn('Chaque [Shot N]',req)
        self.assertIn(ORIGINAL,req)
        self.assertEqual(writer.requested_operation('remplace son geste'),'replace')
    def test_invalid_first_answer_retried_before_h3_once(self):
        import h3film_studio_v3 as film
        output_iter=iter([INVALID, VALID])
        with patch.object(writer,'choose_backend',return_value={'provider':'ollama','model':'gemma4:26b','display':'Gemma'}),\
             patch.object(film,'director_text',side_effect=lambda *a,**kw:next(output_iter)) as director,\
             patch.object(film,'unload_text_backend') as unload,\
             patch.object(film,'release_all_text_models_for_h3') as release:
            text,_=writer.write_prompt(mode='performance',performance_type='action',request='lève la main',source_prompt=ORIGINAL,start=0,end=1.293,duration=5.167,gpu_prepare=lambda:None)
        self.assertIn('[Shot 3]',text)
        self.assertEqual(director.call_count,2)
        self.assertEqual(unload.call_count,1)
        self.assertEqual(release.call_count,1)
    def test_double_invalid_aborts_and_unloads(self):
        import h3film_studio_v3 as film
        with patch.object(writer,'choose_backend',return_value={'provider':'ollama','model':'gemma4:26b'}),\
             patch.object(film,'director_text',return_value=INVALID) as director,\
             patch.object(film,'unload_text_backend') as unload,\
             patch.object(film,'release_all_text_models_for_h3') as release:
            with self.assertRaisesRegex(RuntimeError,'seconde tentative'):
                writer.write_prompt(mode='precise',performance_type='action',request='lève la main',source_prompt=ORIGINAL,start=0,end=1.293,duration=5.167,gpu_prepare=lambda:None)
        self.assertEqual(director.call_count,2)
        self.assertEqual(unload.call_count,1)
        self.assertEqual(release.call_count,1)

class H3DenoiseV72(unittest.TestCase):
    def v2v(self,mode,ptype,env=None):
        args={'v2v_video_file':'', 'ref_video_files':'', 'v2v_denoise':0}
        patch_env=patch.dict(os.environ,env or {},clear=True)
        with patch_env:
            engine._attach_source_video_conditioning(args,mode,ptype,'source.mp4',{'duration':5.167})
        self.assertEqual(args['ref_video_files'],'source.mp4')
        return args['v2v_denoise']
    def test_action_emotion_retake_intensities(self):
        self.assertEqual(self.v2v('performance','action'),.48)
        self.assertEqual(self.v2v('performance','emotion'),.38)
        self.assertEqual(self.v2v('precise','action'),.44)
        self.assertEqual(self.v2v('performance','dialogue'),.22)
        self.assertEqual(self.v2v('insert','action'),.24)
    def test_optional_backward_ab_test(self):
        self.assertEqual(self.v2v('performance','action',{'H3_RETOUCH_V2V_ACTION':'0.28'}),.28)
        self.assertEqual(self.v2v('performance','emotion',{'H3_RETOUCH_V2V_EMOTION':'0.24'}),.24)
        self.assertEqual(self.v2v('precise','action',{'H3_RETOUCH_V2V_PRECISE':'0.18'}),.18)
        with patch.dict(os.environ,{'H3_RETOUCH_V2V_ACTION':'4'},clear=True):
            with self.assertRaises(ValueError):
                engine._attach_source_video_conditioning({'v2v_denoise':0},'performance','action','source.mp4',{})
    def test_isolation_of_legacy_features_and_launcher(self):
        hashes={
            'h3film_studio_v3.py':'a5c260983391835479cba4592b972a46c01fac474b39674d9aaa37b0364fac07',
            'studio_web.py':'84954a1cd171786a1353b6d3b9a0d38eecdc494ac965ef8232b232a18f8afb96',
            'retouches_engine.py':'ba881a0c4107e84ba3a15552703404eb7e81d4242cee467d0318e4103c904be3',
            'retouches_masked_core.py':'95e4a13eaa2d0e19379675b105c9fb3230588b3e7148f0fa22071d5a3a0e2db9',
            'retouches_roycho_complete_v63.py':'8ea1fba0e0e9f24b90dcfff9a1da628340b103d5974b86bf3bca0fa145bda5f1',
            'studio_retouches.py':'09e712d19881a60392957c8e086b46e7d8c86ddcacc11823317d9f47be7ed13a',
            'workflows/H3Studio_1920_API_CLEAN.json':'0f16c5cfe34464d8504bb00000ef311149392174e5c374478ee8846818a9e103',
            'custom_nodes/H3StudioRetouchExtras/__init__.py':'f4db7e7c0bc6e023d48f0b03989cf0db60d0cb42f11636f15cc88530637ae153',
        }
        for name,expected in hashes.items():
            self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),expected,name)
        launcher=(ROOT/'LANCER-RETOUCHES-V10_72.cmd').read_text('utf-8')
        self.assertIn('studio_web.py',launcher)
        self.assertNotIn('pip install',launcher)
        self.assertNotIn('DIFFSYNTH',launcher)
        self.assertIn('llm72.write_prompt', (ROOT/'retouches_next.py').read_text('utf-8'))
        self.assertIn("graph['902']={'class_type':'H3RetouchMaskV58'",(ROOT/'retouches_next.py').read_text('utf-8'))

if __name__=='__main__':unittest.main()
