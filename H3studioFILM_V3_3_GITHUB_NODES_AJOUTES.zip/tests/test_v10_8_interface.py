"""V10.8 GUI regressions: asset routes, stable two-column shell, safe controls."""
import sys, re, unittest
from pathlib import Path
from http.server import ThreadingHTTPServer
from threading import Thread
from urllib.request import urlopen
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import studio_web as web
ROOT=Path(__file__).resolve().parents[1]
class InterfaceV108(unittest.TestCase):
    def test_css_and_js_actually_served_http(self):
        server=ThreadingHTTPServer(('127.0.0.1',0),web.Handler)
        thread=Thread(target=server.serve_forever,daemon=True);thread.start()
        try:
            for name in ('','studio.js','studio-v10-7.css','studio-v10-8.css'):
                with self.subTest(asset=name):
                    url=f'http://127.0.0.1:{server.server_address[1]}/'+name
                    with urlopen(url,timeout=5) as r:
                        self.assertEqual(r.status,200)
                        self.assertGreater(len(r.read()),100)
                        self.assertIn('text/css' if name.endswith('.css') else 'text/',r.headers['Content-Type'])
        finally:
            server.shutdown();server.server_close();thread.join(3)
    def test_shell_only_main_and_right_journal(self):
        html=(ROOT/'studio_ui/index.html').read_text(encoding='utf8')
        self.assertNotIn('class="sidebar left"',html)
        self.assertNotIn('id="expandSidebar"',html)
        self.assertIn('<aside class="directorJournal"',html)
        self.assertIn('id="projectsMenuBtn"',html)
        self.assertIn('id="pauseBtn"',html)
        self.assertIn('id="resumeBtn"',html)
        self.assertIn('id="suspendBtn"',html)
        self.assertIn('id="stopRenderBtn"',html)
        self.assertIn('/studio-v10-8.css',html)
    def test_no_accidental_js_comment_on_live_status(self):
        js=(ROOT/'studio_ui/studio.js').read_text(encoding='utf8')
        self.assertIn("$('conn').textContent=x.running?",js)
        for line in js.splitlines():
            if "$('conn').textContent=x.running?" in line:
                self.assertFalse(line.lstrip().startswith('//'),"Live controls swallowed by JS comment")
        self.assertNotIn("$('pauseHeaderBtn')",js)
        self.assertNotIn("$('stopHeaderBtn')",js)
    def test_direct_clip_editor_and_top_actions(self):
        js=(ROOT/'studio_ui/studio.js').read_text(encoding='utf8')
        self.assertIn('id="approveReviewTop"',js)
        self.assertIn('id="showReviewEditTop"',js)
        self.assertIn('id="clipEditText"',js)
        self.assertIn('clipEditSide',js)
        self.assertIn('reviewCorrectionEditor',js)
        self.assertIn('setProjectsMenu(false)',js)
if __name__=='__main__':unittest.main()
