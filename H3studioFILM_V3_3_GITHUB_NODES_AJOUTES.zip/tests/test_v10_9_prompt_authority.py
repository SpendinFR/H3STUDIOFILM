"""Regression: Director revisions may change the creative body, never protected H3 authority.
CPU only; no LLM/ComfyUI invocation.
"""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import h3film_studio_v3 as film
import pytest

REFS=[{'subject_name':'Matt','subject_key':'matt','kind':'character','role':'canonical_identity','picture_order':1},
      {'subject_name':'Nyx','subject_key':'nyx','kind':'character','role':'canonical_identity','picture_order':2},
      {'subject_name':'Terrasse','subject_key':'terrasse','kind':'decor','role':'film_environment','picture_order':3},
      {'subject_name':'Drone','subject_key':'drone','kind':'object','role':'continuing_object','picture_order':4}]
AUDIO=[{'subject_name':'Matt','subject_key':'matt','kind':'voice'}]
DIRECTOR='**Director :**\nFilmer avec une Arri Alexa, réalisme photographique.'
SPATIAL='**Spatial continuity — soft observed facts:**\nMatt tient son verre de la main droite.'
CREATIVE='''**description_multimodale_intégrée :**
Matt intercepte un drone sans lâcher son verre.

**[Shot 1] 0:00–5.0s**
Il attrape le drone de la main gauche. Il garde le verre de la main droite.

**soundscape_global :** Grésillement du drone.
**look_caméra_et_lumière :** Soleil direct.
**continuité_obligatoire :** Le verre reste à droite.'''


def sample():
    return '\n\n'.join((film.reference_prompt_prefix(REFS,AUDIO),DIRECTOR,SPATIAL,CREATIVE))


def test_existing_full_prompt_revisions_only_expose_creative():
    assert film.revision_creative_context(sample())==CREATIVE
    assert 'VOICE REFERENCE AUTHORITY' not in film.revision_creative_context(sample())
    assert 'Matt intercepte un drone' in film.revision_creative_context(sample())


def test_lmm_repeats_protected_header_sections_deep_in_revision():
    bad = '\n\n'.join((film.reference_prompt_prefix(REFS,AUDIO),DIRECTOR,SPATIAL,
                       'REFERENCE AUTHORITY — these Picture inputs are authoritative:',
                       DIRECTOR, SPATIAL, CREATIVE))
    assert film.creative_clip_body(bad)==CREATIVE
    result='\n\n'.join((film.reference_prompt_prefix(REFS,AUDIO),DIRECTOR,SPATIAL,
                        film.reconcile_clip_subject_claims(film.sanitize_clip_reference_claims(film.creative_clip_body(bad)),REFS)))
    assert result.count('\nREFERENCE AUTHORITY —')+int(result.startswith('REFERENCE AUTHORITY —'))==1
    assert result.count('VOICE REFERENCE AUTHORITY —')==1
    assert result.count('**Director :**')==1
    assert result.count('**Spatial continuity — soft observed facts:**')==1
    assert result.count('**[Shot 1]')==1
    assert result.count('<Audio 1> is the voice-timbre reference')==1
    assert 'main gauche' in result and 'main droite' in result


def test_minimal_prompt_without_system_headers_is_unchanged():
    text='**description_multimodale_intégrée :**\nPlan fixe, soleil.\n**[Shot 1] 0:00–5.00s**\nMatt sourit.'
    assert film.creative_clip_body(text)==text


def test_bad_director_reply_with_only_system_headers_is_rejected():
    with pytest.raises(ValueError,match='aucun contenu créatif'):
        film.creative_clip_body('REFERENCE AUTHORITY — these Picture inputs are authoritative:\n<Subject 1> is Matt.\n**Director :**\nArri Alexa')


def test_revision_paths_do_not_send_full_prompt_to_llm():
    core=(Path(__file__).resolve().parents[1]/'h3film_studio_v3.py').read_text('utf-8')
    assert 'revision_creative_context(rejected_h3_prompt)' in core
    assert 'revision_creative_context(h3_prompt)' in core
    assert core.count('sanitize_clip_reference_claims(creative_clip_body(clip_prompt))')==4
    assert 'Renvoie directement le prompt MiniMax/H3 final' in core # existing baseline


def test_no_runtime_or_audio_policy_changes_to_v10_8():
    import hashlib
    root=Path(__file__).resolve().parents[1]
    # Grounded digests from the shipped V10.8 ZIP; works offline on Windows too.
    expected={
     'h3_runtime_simple.py':'d363f16f6144400ebf0f3219b7cc872c47647fd4c7018194337a06871844c96d',
     'workflows/H3Studio_1920_API_CLEAN.json':'0f16c5cfe34464d8504bb00000ef311149392174e5c374478ee8846818a9e103',
     'custom_nodes/H3RawLatentPersist/__init__.py':'2192fcd927c1f300a193ed7d86fddd9876185f9410d13e484d707092ffde9128',
     'prompts/CLIP_DIRECTOR.txt':'96cf99e91be800f990855a8328a1f47eef795726d822432ef7e59ce3de1f12fe',
    }
    for name,digest in expected.items():
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
