"""V10.21: remove duplicate world panel; native prefix must never be mistaken for a manual edit.

The user's original project can have an older prefix; the UI submits a separate
creative body and the runtime rebuilds the authority from current selected refs.
"""
import json
from pathlib import Path

import h3film_studio_v3 as film
import studio_timeline_extension as timeline


def test_only_one_clip_prompt_panel_without_changing_h3_cue():
    root=Path(__file__).resolve().parents[1]
    html=(root/'studio_ui'/'index.html').read_text(encoding='utf-8')
    js=(root/'studio_ui'/'studio.js').read_text(encoding='utf-8')
    assert html.count('id="clipPrompt"')==1
    assert 'clipWorldCue' not in html and 'showClipWorld(' not in js
    assert 'creative_text:body' in js
    assert 'World ambience' in (root/'h3film_studio_v3.py').read_text(encoding='utf-8')


def test_changed_reference_prefix_uses_native_authority_and_preserves_world(tmp_path):
    comfy=tmp_path/'comfy'; inp=comfy/'input';inp.mkdir(parents=True)
    refs=[]
    for i,name in enumerate(['Matt','Brad'],1):
        image=inp/f'{name}.png';image.write_bytes(b'fake image')
        refs.append({'kind':'character','role':'canonical_identity','subject_name':name,
                     'subject_key':name.lower(),'picture_order':i,'annotated':f'{name}.png [input]',
                     'path':str(image),'strength':1.0})
    old_prefix=film.reference_prompt_prefix(refs)
    world='**World ambience — secondary context (not a Picture reference):** Old classroom. Specific local references have priority.'
    creative=world+'\n\n**[Shot 1] 0:00–5.00**\nBrad and Matt exchange a look.'
    original=old_prefix+'\n\n'+creative
    specs=[{'media':'image','index':1,'name':'Brad'},{'media':'image','index':0,'name':'Matt'}]
    switched=[dict(refs[1],picture_order=1),dict(refs[0],picture_order=2)]
    new_prefix=film.reference_prompt_prefix(switched)
    assert new_prefix!=old_prefix
    # Emulate V10.20's old UI text prefix (new) and a stale project review (old).
    accepted,images,_=film.apply_clip_studio_edits(
        {'edits':{'text':new_prefix+'\n\n'+creative,'creative_text':creative,'refs':specs}},
        original,refs,[],comfy,commit=False)
    assert accepted==film.reference_prompt_prefix(images)+'\n\n'+creative
    assert accepted.count('REFERENCE AUTHORITY —')==1
    assert accepted.count('World ambience')==1
    # Retain compatibility for legacy browser approvals that do not include creative_text.
    legacy,_,_=film.apply_clip_studio_edits(
        {'edits':{'text':new_prefix+'\n\n'+creative,'refs':specs}}, original,refs,[],comfy,commit=False)
    assert legacy==accepted
    # No mutation to canonical image files.
    assert all((inp/f'{name}.png').exists() for name in ('Matt','Brad'))


def test_pending_extension_after_last_scene_is_prepared_without_earlier_scenes(tmp_path):
    project=tmp_path/'movie';(project/'_studio').mkdir(parents=True)
    content={'parts':[{'part':1,'kind':'ACTE','name':'Acte 1','start_seconds':0,'end_seconds':10,
                       'duration_seconds':10,'start':'00:00','end':'00:10'}]}
    scenes=[{'scene':1,'start_seconds':0,'end_seconds':5},{'scene':2,'start_seconds':5,'end_seconds':10}]
    # Called at the boundary after the final clip of the final scene.
    new,part=timeline.extension_part(content,scenes,len(scenes),60,'Extend the film',film.tc)
    assert part['start_seconds']==10 and part['end_seconds']==70
    assert len(new['parts'])==2 and new['parts'][0]==content['parts'][0]
    timeline.atomic_json(timeline.pending_path(project),{'id':'extension','extra_seconds':60,'instructions':'Continue'})
    assert timeline.read_pending(project)['extra_seconds']==60
