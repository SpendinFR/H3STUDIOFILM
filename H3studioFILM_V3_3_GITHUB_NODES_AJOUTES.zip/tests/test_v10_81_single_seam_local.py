import unittest

import retouches_precise_local_v78 as loc
import retouches_llm_prompt_local_v81 as v81


class SingleSeamLocalTests(unittest.TestCase):
    def test_select_window_prefers_earliest_when_edit_in_first_half(self):
        w=loc.select_window(total_latent=37,total_frames=124,begin=0.7,end=1.1)
        self.assertEqual(w['origin_frame'],0)
        self.assertEqual(w['seam_mode'],'suffix_only')

    def test_select_window_prefers_latest_when_edit_in_second_half(self):
        w=loc.select_window(total_latent=37,total_frames=124,begin=4.1,end=4.6)
        self.assertGreater(w['origin_frame'],0)
        self.assertEqual(w['end_frame'],124)
        self.assertEqual(w['seam_mode'],'prefix_only')

    def test_local_writer_stays_in_local_times(self):
        w={'local_first':6,'local_last':30,'start':0.250,'end':1.250,'global_offset':3.542,'frames':39}
        prompt=v81._instruction(request='Elle lève brusquement la main.',source_prompt='[Shot 1] 0.000–2.500s Ancien. [Shot 2] 2.500–5.167s Suite.',window=w)
        self.assertIn('LOCAL SOURCE WINDOW: 3.542–5.167s',prompt)
        self.assertIn('[Shot 1] 0.000–0.250s',prompt)
        self.assertIn('[Shot 2] 0.250–1.250s',prompt)
        self.assertNotIn('2.500–5.167s — ACTION',prompt)


if __name__ == '__main__':
    unittest.main()
