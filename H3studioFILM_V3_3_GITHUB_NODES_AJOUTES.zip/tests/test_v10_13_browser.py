"""DOM: manual appearance + target, audio voice/object, and the emitted edit payload."""
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]


def test_browser_manual_appearance_and_object_audio_binding():
    pytest.importorskip('playwright.sync_api')
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1365,'height':930})
        errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        html=(ROOT/'studio_ui/index.html').read_text(encoding='utf-8').replace('<script src="/studio.js"></script>','')
        page.set_content(html)
        for sheet in ('studio.css','studio-v10-2.css','studio-v10-3.css','studio-v10-4.css','studio-v10-5.css','studio-v10-6.css','studio-v10-7.css','studio-v10-8.css','studio-v10-9.css','studio-v10-10.css'):
            page.add_style_tag(content=(ROOT/'studio_ui'/sheet).read_text(encoding='utf-8'))
        page.add_script_tag(content=(ROOT/'studio_ui/studio.js').read_text(encoding='utf-8'))
        page.evaluate('''() => {
          clipDraft={id:'r',text:'A scene',bankNames:['Matt','Nyx'],bankDeletes:[],originalPrefix:'',previewPrefix:'',previewNonce:0,refs:[
            {media:'image',index:0,name:'Matt',kind:'character',role:'canonical_identity',subjectKey:'matt',visualType:'person',bankScope:'clip'},
            {media:'image',index:1,name:'Nyx',kind:'character',role:'canonical_identity',subjectKey:'nyx',visualType:'person',bankScope:'clip'},
            {media:'image',index:2,name:'Drone',kind:'object',role:'continuing_object',subjectKey:'drone',visualType:'object',bankScope:'clip'},
            {media:'image',path:'/comfy/input/nyxnew.png',name:'Nouvelle photo',kind:'manual',visualType:'visual',bankScope:'clip'},
            {media:'audio',index:0,name:'Matt',audioUse:'voice',audioTarget:'Matt'},
            {media:'audio',path:'/comfy/input/motor.wav',name:'Moteur',audioUse:'voice',audioTarget:''}
          ]};
          document.getElementById('questionArea').innerHTML='<div id="clipRefCount"></div><div id="clipEditRefs"></div><div id="refAuthoritySync"></div><pre id="clipAuthorityText"></pre><textarea id="clipEditText">A scene</textarea>';
          window.fetch=async(_url,opts)=>({ok:true,json:async()=>({text:'AUTH / Appearance / Sound\\n\\nA scene',prefix:'AUTH / Appearance / Sound',original_prefix:'',subjects:[1,2,3,2],resolved_names:['Matt','Nyx','Drone','Nyx']})});
          renderClipRefEditor();
        }''')
        page.locator('.refPencil[data-ri="3"]').click()
        page.locator('.refTypeInput[data-ri="3"]').select_option('appearance')
        page.locator('.refBankTarget[data-ri="3"]').select_option('Nyx')
        page.locator('.refBankScope[data-ri="3"]').select_option('bank')
        page.locator('.refSave[data-ri="3"]').click()
        page.wait_for_function("document.querySelectorAll('.clipEditRef')[3]?.querySelector('.refRoleLabel')?.textContent.includes('Apparence')")
        page.locator('.refPencil[data-ri="5"]').click()
        page.locator('.refAudioUse[data-ri="5"]').select_option('object_sound')
        page.locator('.refAudioTarget[data-ri="5"]').select_option('Drone')
        page.locator('.refSave[data-ri="5"]').click()
        page.wait_for_function("document.querySelectorAll('.clipEditRef')[5]?.querySelector('.refRoleLabel')?.textContent.includes('Son d’objet')")
        info=page.evaluate('''() => ({payload:refPayload(),body:document.getElementById('clipEditText').value,
          numbers:Array.from(document.querySelectorAll('.clipEditRef .refEditFields > small')).map(x=>x.textContent)})''')
        assert info['payload'][3]['visual_type']=='appearance'
        assert info['payload'][3]['bank_target']=='Nyx'
        assert info['payload'][3]['bank_scope']=='bank'
        assert info['payload'][5]['audio_use']=='object_sound'
        assert info['payload'][5]['audio_target']=='Drone'
        assert info['numbers'][3]=='PICTURE 4 · SUBJECT 2'
        assert info['body'] == 'A scene'
        assert 'AUTH / Appearance / Sound' in page.locator('#clipAuthorityText').inner_text()
        assert not errors,errors
        browser.close()
