"""V10.73: selected user timeline only guides Gemma, H3 may regenerate full video.

No ComfyUI, Ollama, GPU, CUDA or installation required.
"""
import unittest, os, hashlib, copy
from pathlib import Path
from unittest.mock import patch
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_next as engine
import retouches_llm_prompt_v73 as writer

ORIGINAL='''[Shot 1] 0–2.500 Elle regarde son écran puis rit.
[Shot 2] 2.500–5.167 Elle parle et sourit.''' 
OUTPUT='''SCENE_CONTEXT: Streameuse avec un micro dans son bureau.
NEW_TAKE:
[Shot 1] 0.000–0.300 Elle regarde son écran.
[Shot 2] 0.300–1.446 Elle sourit et lève sa main droite tout en regardant son écran, puis la redescend.
[Shot 3] 1.446–2.500 Elle rit et tourne la tête.
[Shot 4] 2.500–5.167 Elle parle et sourit.'''
FAKE={
    '127':{'class_type':'UNETLoader','inputs':{}},
    '129':{'class_type':'RandomNoise','inputs':{}},
    '207':{'class_type':'SamplerCustomAdvanced','inputs':{'latent_image':['127',0]}},
    '191':{'class_type':'SaveVideo','inputs':{}},
    '184':{'class_type':'H3StudioImageToVideo','inputs':{'prompt':'','width':0,'height':0,'length':0,
        'ref_video_files':'','v2v_video_file':'','v2v_denoise':0.0}},
    '800':{'class_type':'BasicScheduler','inputs':{'steps':8,'denoise':1.0}}
}

class Test73(unittest.TestCase):
    def graph(self, mode,ptype,start=.3,end=1.446,test_clip=False):
        settings={'start':start,'end':end,'duration':5.167,'frames':124}
        with patch.object(engine,'_snapshot_gui',return_value={}),\
             patch.object(engine.rt,'gui_to_api',return_value=copy.deepcopy(FAKE)),\
             patch.object(engine.rt,'patch_models'),\
             patch.object(engine.rt,'reset_h3_optional_inputs'),\
             patch.object(engine,'_metadata',return_value={'width':832,'height':480}):
            return engine.build_graph({},mode,'testproject','1',Path('/unused'),
                        '0123456789abcdef0123456789abcdef',settings,'nouvelle action',
                        (0,0,100,100),performance_type=ptype,
                        conditioning_video_name='source.mp4',revised_prompt='prompt H3')
    def test_gemma_target_is_preserved_but_h3_window_is_full(self):
        result=writer.assemble('lève la main', OUTPUT,.3,1.446,5.167,ORIGINAL,full_h3_window=True)
        self.assertIn('0.300–1.446 Elle sourit et lève sa main',result)
        self.assertIn('requested edit interval 0.000–5.167s',result)
        self.assertIn('remains timed at 0.300–1.446s',result)
        self.assertNotIn(ORIGINAL,result)
        self.assertEqual(result.count('[Shot 1]'),1)
        self.assertIn('<Video 1>',result)
    def test_precise_retake_prompt_stays_narrow(self):
        result=writer.assemble('lève la main',OUTPUT,.3,1.446,5.167,ORIGINAL)
        self.assertIn('requested edit interval 0.300–1.446s',result)
        self.assertNotIn('requested edit interval 0.000–5.167s',result)
    def test_action_and_emotion_real_masks_cover_100_percent(self):
        for ptype in ('action','emotion'):
            with self.subTest(ptype=ptype):
                g=self.graph('performance',ptype)
                inputs=g['902']['inputs']
                self.assertEqual(inputs['start_pct'],0)
                self.assertEqual(inputs['end_pct'],100)
                self.assertEqual(inputs['track'],'video only')
                self.assertEqual(g['207']['inputs']['latent_image'],['902',0])
                self.assertEqual(g['184']['inputs']['ref_video_files'],'source.mp4')
    def test_dialogue_and_precise_retake_mask_still_exact(self):
        for mode,ptype,track in (('performance','dialogue','both'),('precise','action','video only')):
            with self.subTest(mode=mode,ptype=ptype):
                g=self.graph(mode,ptype)
                m=g['902']['inputs']
                self.assertAlmostEqual(m['start_pct'],100*.3/5.167)
                self.assertAlmostEqual(m['end_pct'],100*1.446/5.167)
                self.assertEqual(m['track'],track)
    def test_real_token_mask_from_upstream_math(self):
        import torch
        sys.path.insert(0,str(ROOT/'custom_nodes'/'H3StudioRetouchExtras'))
        from retouch_mask_math_v58 import make_masks
        vid=torch.empty(1,24,37,30,52)
        aud=torch.empty(1,2,2,100)
        v,a=make_masks([vid,aud], 'video only',0,100,0,0,100,100,2.5,7.0,1.)
        self.assertEqual(int((v[0,0,:,15,26]>.001).sum().item()),37)
        self.assertTrue(torch.all(a==0))
        self.assertEqual(v[0,0,20,15,26].item(),1)
    def test_actual_writer_used_for_performance_and_full_h3(self):
        import h3film_studio_v3 as film
        with patch.object(writer,'choose_backend',return_value={'provider':'ollama','display':'Gemma 26B'}),\
             patch.object(film,'director_text',return_value=OUTPUT),\
             patch.object(film,'unload_text_backend'),\
             patch.object(film,'release_all_text_models_for_h3'):
            text,_=writer.write_prompt(mode='performance',performance_type='action',request='lève la main',
                source_prompt=ORIGINAL,start=.3,end=1.446,duration=5.167,gpu_prepare=lambda:None)
            self.assertIn('requested edit interval 0.000–5.167s',text)
            other,_=writer.write_prompt(mode='precise',performance_type='action',request='lève la main',
                source_prompt=ORIGINAL,start=.3,end=1.446,duration=5.167,gpu_prepare=lambda:None)
            self.assertIn('requested edit interval 0.300–1.446s',other)
    def test_no_change_to_old_engines_or_models(self):
        baseline=Path('/mnt/data/work_v1072')
        for name in ('h3film_studio_v3.py','studio_web.py','retouches_engine.py',
            'retouches_masked_core.py','retouches_roycho_complete_v63.py',
            'studio_retouches.py','retouches_llm_prompt_v72.py',
            'workflows/H3Studio_1920_API_CLEAN.json',
            'custom_nodes/H3StudioRetouchExtras/__init__.py'):
            self.assertEqual((ROOT/name).read_bytes(),(baseline/name).read_bytes(),name)
        self.assertIn('llm73.write_prompt(', (ROOT/'retouches_next.py').read_text('utf-8'))
        cmd=(ROOT/'LANCER-RETOUCHES-V10_73.cmd').read_text('utf-8')
        self.assertNotIn('pip install',cmd)
        self.assertNotIn('INSTALLER-DIFFSYNTH',cmd.upper())
        self.assertIn('studio_web.py',cmd)

if __name__=='__main__': unittest.main()
