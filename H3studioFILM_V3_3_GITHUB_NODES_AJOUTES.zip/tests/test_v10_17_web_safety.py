"""V10.17: browser controls, safe queuing and no UI regressions."""
import json
import sys
import time
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import studio_web as web
import studio_timeline_extension as ext


def test_project_extension_queue_only_active_project(tmp_path,monkeypatch):
    session=tmp_path/'session';session.mkdir()
    project=tmp_path/'project';(project/'_studio').mkdir(parents=True)
    web.write_json(session/'active_project.json',{'name':'film123'})
    monkeypatch.setattr(web,'active_folder',lambda:session)
    monkeypatch.setattr(web,'load_project',lambda name:project if name=='film123' else None)
    with web.LOCK:
        old=web.STATE.copy()
        web.STATE['proc']=MagicMock(poll=lambda:None)
        web.STATE['session']=session
    try:
        data={'project':'film123','extra_seconds':60,'instructions':'Ralentir les scènes restantes'}
        class FakeHandler:
            path='/api/extend-timeline'
            def body(self):return data
            def send_data(self,value,status=200):self.result=value;self.status=status
        req=FakeHandler()
        web.Handler.do_POST(req)
        assert req.status==200 and req.result['ok']
        assert ext.read_pending(project)['extra_seconds']==60
        req2=FakeHandler()
        web.Handler.do_POST(req2)
        assert req2.status>=400
        assert 'déjà programmée' in req2.result['error']
    finally:
        with web.LOCK:web.STATE.clear();web.STATE.update(old)


def test_krea_job_refuses_non_clip_gate(tmp_path,monkeypatch):
    session=tmp_path/'session';session.mkdir()
    with web.LOCK:
        old=web.STATE.copy()
        web.STATE['proc']=MagicMock(poll=lambda:None)
    try:
        with pytest.raises(ValueError,match='Clip Director'):
            web.start_krea_clip_reference({'project':'test','review_id':'expired','prompt':'Nyx in a blue jacket'},session)
    finally:
        with web.LOCK:web.STATE.clear();web.STATE.update(old)


def test_krea_job_cannot_read_outside_comfy_input(tmp_path,monkeypatch):
    session=tmp_path/'session';session.mkdir()
    web.write_json(session/'review.json',{'id':'right','kind':'clips'})
    web.write_json(session/'active_project.json',{'name':'test'})
    source=tmp_path/'secret.jpg';source.write_bytes(b'secret')
    monkeypatch.setattr(web,'comfy_path',lambda:tmp_path/'comfy')
    with web.LOCK:
        old=web.STATE.copy()
        web.STATE['proc']=MagicMock(poll=lambda:None)
    try:
        with pytest.raises(ValueError,match='importée'):
            web.start_krea_clip_reference({'project':'test','review_id':'right','prompt':'A new jacket for Nyx',
               'source_path':str(source),'mode':'image'},session)
    finally:
        with web.LOCK:web.STATE.clear();web.STATE.update(old)


def test_browser_extension_and_krea_dialogs_and_request_data():
    try:from playwright.sync_api import sync_playwright
    except ImportError:pytest.skip('Playwright absent')
    html=(ROOT/'studio_ui/index.html').read_text(encoding='utf8')
    js=(ROOT/'studio_ui/studio.js').read_text(encoding='utf8')
    with sync_playwright() as p:
        try:
            browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        except Exception:
            pytest.skip('Navigateur non disponible')
        try:
            page=browser.new_page()
            errors=[]
            page.on('pageerror',lambda err:errors.append(str(err)))
            intercepted=[]
            def fake_extend(route):
                intercepted.append(route.request.post_data_json)
                route.fulfill(json={'ok':True,'message':'Prolongation enregistrée'})
            page.set_content(html)
            page.add_script_tag(content=js)
            page.expose_function('capture_extend',lambda x:intercepted.append(x))
            page.evaluate("request=async (url,data)=>{ if(url==='/api/extend-timeline'){await window.capture_extend(data);return {ok:true,message:'Enregistrée'}}; return {}}")
            page.evaluate("state={running:true,project:{name:'demo'}};projectName='demo';showModal('extendModal')")
            assert page.locator('#extendModal').is_visible()
            page.locator('#extendDuration').fill('1m')
            page.locator('#extendInstructions').fill('Garder la poursuite mais rallonger la confrontation')
            page.locator('#sendExtend').click()
            page.wait_for_timeout(400)
            assert intercepted[0]['extra_seconds']==60
            page.evaluate("clipDraft={id:'gate1',refs:[{media:'image',path:'C:/ComfyUI/input/Nyx.png',name:'Nyx',kind:'character'}]};openKreaClip()")
            assert page.locator('#kreaClipModal').is_visible()
            assert page.locator('#kreaClipMode').input_value()=='style'
            assert 'Nyx' in page.locator('#kreaClipSource').inner_text()
            assert not errors,errors
        finally:browser.close()
