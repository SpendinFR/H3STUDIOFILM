"""Add-on regression checks: inline controls + genuine short RAW-latent GPU graph."""
from __future__ import annotations
from pathlib import Path
import importlib.util
import json
import sys
import types
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_next as addon

class InlineUIContracts(unittest.TestCase):
    def test_four_new_buttons_share_existing_page(self):
        from bs4 import BeautifulSoup
        doc=BeautifulSoup((ROOT/'studio_ui/index.html').read_text(encoding='utf-8'),'html.parser')
        grid=doc.select_one('#retModes')
        self.assertIsNotNone(grid)
        self.assertEqual([x.get('data-new-engine') for x in grid.select('[data-new-engine]')],['extend','performance','precise','insert'])
        self.assertEqual(len(grid.select('[data-mode]')),5)
        self.assertIsNotNone(grid.find_next_sibling('div',id='newRetRoot'))
        self.assertIn('retouchCard',(doc.select_one('#newRetRoot').parent.get('class') or []))
        self.assertIsNotNone(doc.select_one('#retLegacySetup'))
        self.assertEqual(len(doc.select('#retVideo')),1)
        self.assertEqual(len(doc.select('#retMaskOverlay')),1)
        self.assertEqual(len(doc.select('#retShotStart')),1)
        self.assertEqual(len(doc.select('#retShotEnd')),1)
        self.assertEqual(len(doc.select('#newRetQuick')),1)
        self.assertFalse(doc.select('#newRetStart'))

    def test_new_ui_reads_exact_existing_controls(self):
        js=(ROOT/'studio_ui/studio-new-retouches.js').read_text(encoding='utf-8')
        for needle in ("$('retShotStart')", "$('retShotEnd')", "$('retVideo')", "$('retMaskBox')", "$('retDrawMask').click()", "$('retClearMask').click()",'test_clip'):
            self.assertIn(needle,js)
        self.assertNotIn('newRetTimelineBox',js)

    def test_raw_quick_graph_uses_22_frame_window(self):
        original=addon.rt.gui_to_api
        old_patch=addon.rt.patch_models
        old_reset=addon.rt.reset_h3_optional_inputs
        old_meta=addon._metadata
        try:
            def fake_api(gui,info):
                self.assertIn(191,[n['id'] for n in gui['nodes']])
                return {
                    '159':{'class_type':'H3StudioImageToVideo','inputs':{'prompt':'','width':1152,'height':640}},
                    '207':{'class_type':'SamplerCustomAdvanced','inputs':{'latent_image':['159',1]}},
                    '191':{'class_type':'SaveVideo','inputs':{'filename_prefix':'original'}},
                    '129':{'class_type':'RandomNoise','inputs':{'noise_seed':3}}
                }
            addon.rt.gui_to_api=fake_api
            addon.rt.patch_models=lambda g,info:None
            addon.rt.reset_h3_optional_inputs=lambda h,info:None
            addon._metadata=lambda src,c:{'frames':124,'duration':124/24,'width':1152,'height':640,'fps':24}
            info={}
            secs={'start':1.0,'end':2.0,'duration':124/24,'frames':124}
            for mode in ('performance','precise','insert'):
                graph=addon.build_graph(info,mode,'Demo','1',Path('raw.mp4'),'0123456789abcdef0123456789abcdef',secs,'Change la main',(5,15,50,65),test_clip=True)
                self.assertEqual(graph['159']['inputs']['length'],22)
                self.assertEqual(graph['902']['inputs']['latent'],['901',0])
                self.assertEqual(graph['207']['inputs']['latent_image'],['902',0])
                self.assertNotIn('903',graph)
            ext=addon.build_graph(info,'extend','Demo','1',Path('raw.mp4'),'0123456789abcdef0123456789abcdef',secs,'Prolonge de 5 secondes',(0,0,100,100),test_clip=True)
            self.assertEqual(ext['159']['inputs']['length'],56)
            self.assertNotIn('903',ext)
        finally:
            addon.rt.gui_to_api=original
            addon.rt.patch_models=old_patch
            addon.rt.reset_h3_optional_inputs=old_reset
            addon._metadata=old_meta

    def test_quick_window_temporal_shapes(self):
        try: import torch
        except ImportError: self.skipTest('No torch available')
        class Nested:
            def __init__(self,tracks):self.tracks=tracks
            def unbind(self):return self.tracks
        old_comfy=sys.modules.get('comfy'); old_nested=sys.modules.get('comfy.nested_tensor')
        c=types.ModuleType('comfy'); nt=types.ModuleType('comfy.nested_tensor'); nt.NestedTensor=Nested;c.nested_tensor=nt
        sys.modules['comfy']=c;sys.modules['comfy.nested_tensor']=nt
        try:
            path=ROOT/'custom_nodes/H3StudioRetouchExtras/__init__.py'
            spec=importlib.util.spec_from_file_location('h3_new_test_mask',path)
            m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
            input_lat={'samples':Nested((torch.zeros((1,8,37,8,12)),torch.zeros((1,32,2,205))))}
            out=m.H3RetouchQuickWindow().run(input_lat,10)[0]['samples'].unbind()
            self.assertEqual(out[0].shape,(1,8,7,8,12))
            self.assertGreater(out[1].shape[-1],0)
            self.assertLess(out[1].shape[-1],205)
            short={'samples':Nested(out)}
            masked=m.H3RetouchRawMask().run(short,'video only',10,80,10,5,70,90,1,2)[0]
            mask_video,mask_audio=masked['noise_mask'].unbind()
            self.assertGreater(float(mask_video.sum()),0)
            self.assertEqual(float(mask_audio.sum()),0)
        finally:
            if old_comfy is None:sys.modules.pop('comfy',None)
            else:sys.modules['comfy']=old_comfy
            if old_nested is None:sys.modules.pop('comfy.nested_tensor',None)
            else:sys.modules['comfy.nested_tensor']=old_nested

if __name__=='__main__':unittest.main()
