"""Exercise new RefBank edit buttons in the real Chromium DOM."""
from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]

def test_refbank_ui_scope_target_and_scene_retake_buttons():
    pytest.importorskip('playwright.sync_api')
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1380,'height':960})
        errors=[]
        page.on('pageerror', lambda error:errors.append(str(error)))
        html=(ROOT/'studio_ui/index.html').read_text(encoding='utf-8').replace('<script src="/studio.js"></script>','')
        page.set_content(html)
        for sheet in ('studio.css','studio-v10-2.css','studio-v10-3.css','studio-v10-4.css','studio-v10-5.css','studio-v10-6.css','studio-v10-7.css','studio-v10-8.css','studio-v10-9.css','studio-v10-10.css'):
            page.add_style_tag(content=(ROOT/'studio_ui'/sheet).read_text(encoding='utf-8'))
        page.add_script_tag(content=(ROOT/'studio_ui/studio.js').read_text(encoding='utf-8'))
        page.evaluate('''() => {
          clipDraft={id:'review-1',text:'Creative text',bankNames:['Matt','Nyx'],bankDeletes:[],previewPrefix:'',originalPrefix:'',previewNonce:0,refs:[
            {media:'image',index:0,name:'Matt',kind:'character',role:'canonical_identity',subjectKey:'canonical_matt',visualType:'person',bankScope:'clip',bankTarget:''},
            {media:'image',index:1,name:'Nyx',kind:'character',role:'film_appearance',subjectKey:'canonical_nyx',visualType:'person',bankScope:'clip',bankTarget:''}
          ]};
          document.getElementById('questionArea').innerHTML='<div id="clipRefCount"></div><div id="clipEditRefs"></div><div id="refAuthoritySync"></div><textarea id="clipEditText">Creative text</textarea>';
          renderClipRefEditor();
        }''')
        page.locator('.refPencil[data-ri="1"]').click()
        page.locator('.refBankTarget[data-ri="1"]').select_option('Matt')
        page.locator('.refBankScope[data-ri="1"]').select_option('bank')
        page.locator('.refSave[data-ri="1"]').click()
        values=page.evaluate('''() => ({
           name:clipDraft.refs[1].name,scope:clipDraft.refs[1].bankScope,target:clipDraft.refs[1].bankTarget,
           payload:refPayload()[1],pencilCount:document.querySelectorAll('.refPencil').length
        })''')
        assert values['name']=='Matt' and values['scope']=='bank' and values['target']=='Matt'
        assert values['payload']['bank_scope']=='bank' and values['payload']['bank_target']=='Matt'
        assert values['pencilCount']==2
        assert not errors,errors
        browser.close()
