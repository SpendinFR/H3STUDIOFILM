"""V10.16 regression: native precision of authorities, global Stop and no extra OK."""
import json
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import h3film_studio_v3 as film
import studio_emergency_stop as em
import studio_refbank_edits as bank
import studio_web as web


def _image(name,role,key,num,kind='character'):
    return {'kind':kind,'role':role,'subject_name':name,'subject_key':key,'picture_order':num}


def test_precise_v1013_authority_for_two_characters_and_environment():
    refs=[_image('MATT','canonical_identity','matt',1),_image('MATT','film_appearance','matt',2),
          _image('NYX','canonical_identity','nyx',3),_image('NYX','film_appearance','nyx',4),
          _image('Le Sanctuaire','canonical_environment','temple',5,kind='decor')]
    prefix=film.reference_prompt_prefix(refs)
    assert prefix.count('REFERENCE AUTHORITY —')==1
    for n, pic, name in ((1,2,'MATT'),(2,4,'NYX')):
        assert f'<Subject {n}> is {name}. <Picture {pic-1}> defines the canonical stable identity: preserve face, distinctive physical traits, hair identity and body proportions.' in prefix
        assert f'<Picture {pic}> is the latest rendered-film appearance state for the same <Subject {n}>.' in prefix
        assert f'<Subject {n}>: canonical_identity - preserve identity across the film.' in prefix
    assert prefix.count('wardrobe / temporary-state authority ONLY')==2
    assert prefix.count('it must never replace, duplicate or reinterpret the face/body identity')==2
    assert '<Subject 3> is Le Sanctuaire. <Picture 5> defines the canonical environment identity:' in prefix
    assert 'canonical_environment - preserve place identity' in prefix
    assert film.reference_subject_numbers(refs)==[1,1,2,2,3]


def test_existing_fully_preserved_identity_plus_appearance_keeps_detailed_authority():
    refs=[_image('Nyx','fully_preserved','a',1),_image('Nyx','film_appearance','a',2)]
    prefix=film.reference_prompt_prefix(refs)
    assert '<Picture 1> defines the canonical stable identity' in prefix
    assert '<Picture 2> is the latest rendered-film appearance state for the same <Subject 1>' in prefix
    assert 'temporary-state authority ONLY' in prefix
    assert '<Subject 1>: canonical_identity' in prefix


def test_manual_character_bank_persistence_remains_canonical(tmp_path):
    p=tmp_path/'film';(p/'refs').mkdir(parents=True)
    (p/'refs/static_refs.json').write_text('[]')
    (p/'refs/ref_bank.json').write_text('{}')
    ref={'kind':'character','role':'canonical_identity','subject_name':'Nyx',
         'subject_key':'studio_nyx','path':str(tmp_path/'nyx.png'),'annotated':'nyx.png [input]'}
    adjusted=bank.apply(p,[],[ref],[{'media':'image','name':'Nyx','bank_scope':'bank','visual_type':'person'}],commit=True)
    assert adjusted[0]['role']=='canonical_identity'
    persisted=json.loads((p/'refs/ref_bank.json').read_text())
    assert persisted['characters']['Nyx']['role']=='canonical_identity'


def test_emergency_stop_tries_all_operations_in_sequence_even_on_http_error(monkeypatch):
    monkeypatch.setattr(em.os,'name','nt')
    calls=[]
    def fake_run(cmd, **kwargs):
        calls.append(('process',cmd[-1]));return MagicMock(returncode=0)
    def fake_open(req,timeout=0):
        data=json.loads(req.data)
        calls.append((req.full_url.rsplit('/',1)[-1],data))
        if req.full_url.endswith('/interrupt'):raise OSError('GPU listener stopped')
        class Response:
            def __enter__(self):return self
            def __exit__(self,*args):pass
        return Response()
    with patch.object(em.subprocess,'run',side_effect=fake_run),patch.object(em.urllib.request,'urlopen',side_effect=fake_open):
        problems=em.emergency_stop()
    assert [k for k,_ in calls]==['process','interrupt','queue']
    assert "'llama-server','ollama'" in calls[0][1]
    assert calls[2][1]=={'clear':True}
    assert any('/interrupt' in p for p in problems)


def test_web_stop_marks_session_and_calls_global_cleanup(tmp_path):
    class Running:
        def poll(self):return None
    session=tmp_path/'session';session.mkdir()
    with web.LOCK:
        old=dict(web.STATE)
        web.STATE.update(session=session,proc=Running())
    import threading, urllib.request
    from http.server import ThreadingHTTPServer
    srv=ThreadingHTTPServer(('127.0.0.1',0),web.Handler)
    t=threading.Thread(target=srv.serve_forever,daemon=True);t.start()
    try:
        with patch.object(web,'emergency_stop_all',return_value=[]) as cleanup:
            req=urllib.request.Request(f'http://127.0.0.1:{srv.server_port}/api/stop',data=b'{}',method='POST')
            with urllib.request.urlopen(req,timeout=5) as resp:
                result=json.load(resp)
            assert result['ok']
            assert (session/'stop.request').exists()
            cleanup.assert_called_once_with()
    finally:
        srv.shutdown();srv.server_close();t.join(3)
        with web.LOCK:web.STATE.clear();web.STATE.update(old)


def test_director_edits_submit_without_native_browser_confirm():
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page=b.new_page()
        page.set_content((ROOT/'studio_ui/index.html').read_text().replace('<script src="/studio.js"></script>',''))
        page.add_script_tag(content=(ROOT/'studio_ui/studio.js').read_text())
        page.evaluate('''() => {window.confirm=()=>{throw Error('Unexpected native confirmation')};
          window.fetch=async(url,opts)=>{if(url==='/api/review'){window.sent=JSON.parse(opts.body);return {ok:true,json:async()=>({ok:true})}}return {ok:true,json:async()=>({ollama:[],special:[]})}};
          state={running:true,project:{name:'demo'},review:{id:'c',kind:'content',title:'Un film',allow_revise:true,payload:{text:'PITCH / SYNOPSIS\\nActe 1.',content:{parts:[{part:1,duration_seconds:20}]}}}};
          projectName='demo';project={name:'demo'};actionPanel(state)}''')
        page.locator('#directorDirectText').fill('PITCH / SYNOPSIS\nActes 1 et 2.')
        page.locator('#applyDirectorDraft').click()
        page.wait_for_function('window.sent !== undefined')
        assert page.evaluate('window.sent.action')=='revise'
        b.close()


def test_ctrl_c_on_web_marks_detached_worker_and_cleans_gpu(tmp_path, monkeypatch):
    class Running:
        def poll(self):return None
    class FakeWebServer:
        def __init__(self,*args):pass
        def serve_forever(self):raise KeyboardInterrupt()
        def server_close(self):self.closed=True
    session=tmp_path/'session';session.mkdir()
    with web.LOCK:
        old=dict(web.STATE)
        web.STATE.update(session=session,proc=Running())
    try:
        with patch.object(web,'restore_running_session'),\
             patch.object(web,'ThreadingHTTPServer',FakeWebServer),\
             patch.object(web,'emergency_stop_all',return_value=[]) as cleanup:
            monkeypatch.setattr(sys,'argv',['studio_web.py'])
            web.main()
            assert (session/'stop.request').exists()
            cleanup.assert_called_once()
    finally:
        with web.LOCK:web.STATE.clear();web.STATE.update(old)
