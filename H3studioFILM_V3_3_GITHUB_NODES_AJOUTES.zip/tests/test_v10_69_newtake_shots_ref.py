"""CPU-only V10.69 contracts, no GPU or model-fidelity claim."""
import pathlib,sys,unittest
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_llm_prompt_v69 as newtake
import retouches_next as nxt

class NewTakeV69(unittest.TestCase):
    PROMPT='''<Subject 1> is the streamer from <Picture 1>.
[Shot 1] The streamer looks sideways and smiles in a blue-lit room.
[Shot 2] The camera moves closer; she looks at the lens.'''
    def test_input_mentions_actual_video_and_original_prompt_and_shots(self):
        s=newtake.build_request('performance','action','Elle lève la main droite',self.PROMPT,.121,1.217,5.167)
        self.assertIn('<Video 1>',s)
        self.assertIn(self.PROMPT,s)
        self.assertIn('0.121',s)
        self.assertIn('1.217',s)
        self.assertIn('5.167',s)
        self.assertIn('Elle lève la main droite',s)
        self.assertIn('[Shot 1], [Shot 2]',s)
    def test_output_is_new_take_h3_prompt_not_editor_checklist(self):
        result='''[Shot 1] The same streamer in blue room raises her right hand, slowly then decisively and returns to her initial pose.\n[Shot 2] Camera moves closer after a seamless natural movement and she looks at the lens.'''
        x=newtake.assemble('Elle lève la main droite',result,.121,1.217,5.167,self.PROMPT)
        self.assertIn('NEW TAKE of <Video 1>',x)
        self.assertIn(result,x)
        self.assertIn('VISIBLE NEW ACTION',x)
    def test_rejects_shot_count_mismatch_without_gpu(self):
        with self.assertRaisesRegex(RuntimeError,'découpage'):
            newtake.assemble('geste','[Shot 1] '+('The actor changes his gesture at the right moment. '*4),0,1,5,self.PROMPT)
    def test_missing_original_defaults_to_one_shot(self):
        self.assertEqual(newtake.original_shots(''),[1])
        x=newtake.build_request('precise','action','remplace un geste','',0,2,5)
        self.assertIn('Original text missing',x)
    def test_performance_and_precise_use_new_writer_but_dialogue_doesnt(self):
        t=(ROOT/'retouches_next.py').read_text(encoding='utf8')
        # Legacy V10.69 writer remains importable for archival tests, but V10.70 routes to the revised writer.
        self.assertIn('import retouches_llm_prompt_v70 as llm70',t)
        self.assertIn("row.get('performance_type','action') in ('action','emotion')",t)
        self.assertIn("if performance_type=='dialogue'",t)
        self.assertIn('llm_seconds=',t)
        self.assertIn('h3_seconds=',t)
    def test_reference_must_be_connected_before_render(self):
        # Calling through actual graph preflight requires all workflow nodes,
        # so this test checks the fail-closed guard in the compiler.
        t=(ROOT/'retouches_next.py').read_text(encoding='utf8')
        self.assertIn('le canal vidéo <Video 1>',t)
        self.assertIn("h3in.get('ref_video_files')!=conditioning_video_name",t)
    def test_no_legacy_workflow_changed(self):
        old=pathlib.Path('/mnt/data/v1068_fullshot_ollama')
        for path in ['h3film_studio_v3.py','studio_web.py','retouches_engine.py',
                     'retouches_masked_core.py','retouches_roycho_complete_v63.py',
                     'studio_retouches.py','workflows/H3Studio_1920_API_CLEAN.json']:
            if old.exists():
                self.assertEqual((ROOT/path).read_bytes(),(old/path).read_bytes(),path)
    def test_backend_remains_ollama_only_and_unloads(self):
        t=(ROOT/'retouches_llm_prompt_v69.py').read_text(encoding='utf8')
        self.assertIn('ensure_ollama_running(film)',t)
        self.assertIn('film.unload_text_backend(backend',t)
        self.assertIn('film.release_all_text_models_for_h3(',t)
        self.assertNotIn("subprocess.Popen([exe,'pull'",t)
        self.assertNotIn("film._llama_backend(",t)
    def test_auto_action_roi_covers_hands_not_just_face(self):
        t=(ROOT/'retouches_next.py').read_text(encoding='utf8')
        self.assertIn("if row.get('performance_type')=='action':",t)
        self.assertIn('rect=(0.,0.,100.,100.)',t)
    def test_full_clip_default_without_user_selection(self):
        t=(ROOT/'retouches_next.py').read_text(encoding='utf8')
        self.assertIn('default_a=0.0 if segment_retake',t)
        self.assertIn('default_b=min(duration,39/24) if',t)
        self.assertIn("start=row['start'] if row['selected']",t)
    def test_launcher_no_installs(self):
        t=(ROOT/'LANCER-RETOUCHES-V10_69.cmd').read_text(encoding='utf8')
        self.assertNotIn('pip install',t)
        self.assertNotIn('INSTALLER-DIFFSYNTH',t)
        self.assertIn('studio_web.py',t)
if __name__=='__main__':unittest.main()
