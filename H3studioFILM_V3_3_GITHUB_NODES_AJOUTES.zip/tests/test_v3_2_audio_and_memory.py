"""V3.2 offline tests: FFmpeg audio restoration and no-queue-interrupt GPU release.

These tests generate miniature synthetic files; they do not touch ComfyUI or GPU.
"""
import hashlib
import shutil
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import h3film_studio_v3 as film
import retouches_next as retouch


def mp4(path: Path, hz: int, seconds: float):
    path.parent.mkdir(parents=True,exist_ok=True)
    subprocess.run([
        'ffmpeg','-y','-loglevel','error',
        '-f','lavfi','-i','color=c=blue:s=128x96:r=24',
        '-f','lavfi','-i',f'sine=frequency={hz}:sample_rate=48000',
        '-t', str(seconds),'-c:v','mpeg4','-q:v','4','-c:a','aac','-b:a','128k',
        str(path)
    ],check=True)
    assert path.stat().st_size>1000
    return path


def audio_codec_digest(path: Path):
    out=subprocess.run(['ffmpeg','-loglevel','error','-i',str(path),
                        '-map','0:a:0','-c:a','copy','-f','md5','-'],
                       capture_output=True,text=True,check=True)
    return out.stdout.strip()


def video_codec_digest(path: Path):
    out=subprocess.run(['ffmpeg','-loglevel','error','-i',str(path),
                        '-map','0:v:0','-c:v','copy','-f','md5','-'],
                       capture_output=True,text=True,check=True)
    return out.stdout.strip()


def frequency_at(path: Path, start: float, seconds=0.25):
    import numpy as np
    out=subprocess.run(['ffmpeg','-loglevel','error','-ss',str(start),'-i',str(path),
                       '-map','0:a:0','-t',str(seconds),'-ac','1','-ar','16000',
                       '-f','f32le','-'],capture_output=True,check=True)
    vals=np.frombuffer(out.stdout,dtype='<f4')
    assert vals.size>100
    spec=abs(np.fft.rfft(vals*np.hanning(len(vals))))
    freqs=np.fft.rfftfreq(len(vals),d=1/16000)
    return float(freqs[spec.argmax()])


@pytest.mark.skipif(not shutil.which('ffmpeg'),reason='test needs local FFmpeg')
def test_approved_audio_bit_exact_while_hd_video_unchanged(tmp_path):
    comfy=tmp_path/'comfy';comfy.mkdir()
    approved=mp4(tmp_path/'approved.mp4',680,1.5)
    original=mp4(tmp_path/'project'/'clips'/'visible.mp4',180,1.5)
    before_video=video_codec_digest(original)
    approved_sound=audio_codec_digest(approved)
    with patch.object(film.rt,'find_ffmpeg_exe',return_value=shutil.which('ffmpeg')):
        film._restore_validated_audio(comfy,original,approved=approved)
    assert video_codec_digest(original)==before_video
    assert audio_codec_digest(original)==approved_sound
    assert abs(frequency_at(original,.3)-680)<15
    backup=list((tmp_path/'project'/'_studio'/'audio_before_restore').glob('*.mp4'))
    assert len(backup)==1 and abs(frequency_at(backup[0],.3)-180)<15
    assert audio_codec_digest(approved)==approved_sound


@pytest.mark.skipif(not shutil.which('ffmpeg'),reason='test needs local FFmpeg')
def test_final_concatenates_authoritative_sound_after_mc22_trim(tmp_path):
    comfy=tmp_path/'comfy';comfy.mkdir()
    previous=mp4(tmp_path/'previous.mp4',430,1.5)
    visible=mp4(tmp_path/'current.mp4',900,2.0)
    final=mp4(tmp_path/'project'/'final'/'final.mp4',170,2.58)
    expected_video=video_codec_digest(final)
    with patch.object(film.rt,'find_ffmpeg_exe',return_value=shutil.which('ffmpeg')):
        film._restore_validated_audio(comfy,final,preceding_final=previous,
                                      current_visible=visible,trim_motion_context=True)
    assert video_codec_digest(final)==expected_video
    assert abs(frequency_at(final,.35)-430)<15
    assert abs(frequency_at(final,1.85)-900)<15
    assert abs(frequency_at(final,1.85)-170)>100


def test_safe_release_never_interrupts_or_clears_queue(tmp_path):
    calls=[]
    with patch.object(retouch.legacy,'comfy_json',return_value={'queue_running':[],'queue_pending':[]}),\
         patch.object(retouch.rt,'http_json',side_effect=lambda url,method,payload,**kw: calls.append((url,payload))),\
         patch.object(retouch.rt,'query_gpu_vram',return_value={'used':500,'total':16000,'free':15500}),\
         patch.object(retouch,'_update'),patch.object(retouch.time,'sleep'):
        assert retouch._safe_comfy_free('H3 unit test','a'*32)
    assert len(calls)==2
    assert all(url.endswith('/free') and p['unload_models'] and p['free_memory'] for url,p in calls)


def test_safe_release_refuses_while_another_job_is_active():
    with patch.object(retouch.legacy,'comfy_json',return_value={'queue_running':[[0,'other-prompt']],'queue_pending':[]}),\
         patch.object(retouch.rt,'http_json') as h:
        with pytest.raises(RuntimeError,match='file ComfyUI non vide'):
            retouch._safe_comfy_free('before H3','a'*32)
        h.assert_not_called()

@pytest.mark.skipif(not shutil.which('ffmpeg'),reason='test needs local FFmpeg')
def test_audio_failure_never_overwrites_hd_video_or_approved_raw(tmp_path):
    comfy=tmp_path/'comfy';comfy.mkdir()
    approved=tmp_path/'no_audio.mp4'
    subprocess.run(['ffmpeg','-y','-loglevel','error','-f','lavfi','-i',
                    'color=c=blue:s=128x96:r=24','-t','1.0',
                    '-c:v','mpeg4',str(approved)],check=True)
    rendered=mp4(tmp_path/'project'/'clips'/'visible.mp4',180,1.0)
    saved_video=hashlib.sha256(rendered.read_bytes()).hexdigest()
    saved_source=hashlib.sha256(approved.read_bytes()).hexdigest()
    with patch.object(film.rt,'find_ffmpeg_exe',return_value=shutil.which('ffmpeg')):
        with pytest.raises(RuntimeError,match='fusion FFmpeg échouée'):
            film._restore_validated_audio(comfy,rendered,approved=approved)
    assert hashlib.sha256(rendered.read_bytes()).hexdigest()==saved_video
    assert hashlib.sha256(approved.read_bytes()).hexdigest()==saved_source
    assert not list(rendered.parent.glob('*.audio_*.mp4'))
    assert not (tmp_path/'project'/'_studio'/'audio_before_restore').exists()


def test_second_release_aborts_if_external_prompt_starts():
    checks=iter([{'queue_running':[],'queue_pending':[]},
                 {'queue_running':[[0,'another']], 'queue_pending':[]}])
    calls=[]
    with patch.object(retouch.legacy,'comfy_json',side_effect=lambda *a,**k: next(checks)),\
         patch.object(retouch.rt,'http_json',side_effect=lambda url,*a,**k: calls.append(url)),\
         patch.object(retouch.rt,'query_gpu_vram',return_value={'used':500,'total':16000,'free':15500}),\
         patch.object(retouch.time,'sleep'):
        with pytest.raises(RuntimeError,match='autre travail ComfyUI'):
            retouch._safe_comfy_free('Test','a'*32)
    assert len(calls)==1 and calls[0].endswith('/free')
