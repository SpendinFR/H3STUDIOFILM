"""Regressions for V10.80 local prompt only; no Ollama/Comfy access."""
import ast,hashlib,re,unittest
from pathlib import Path
from unittest.mock import patch
import retouches_precise_local_v78 as v78
import retouches_llm_prompt_local_v80 as v80
import retouches_llm_prompt_v74 as v74

ROOT=Path(__file__).resolve().parents[1]
SOURCE="[Shot 1] 0.000–2.500s Une streameuse fixe son écran et rit.\n[Shot 2] 2.500–5.167s Elle interpelle la caméra."

def fake_gemma(window):
    grid=v80._grid(window)
    roles={'ACTION':'elle lève la main droite et la redescend vivement en fixant la caméra.',
           'TRANSITION AVANT':'elle tourne progressivement le regard et prépare son bras.',
           'TRANSITION APRÈS':'elle relâche le bras et reprend doucement sa pose naturelle.'}
    shots='\n'.join(f'[Shot {i}] {a:.3f}–{b:.3f}s {roles[role]}' for i,(role,a,b) in enumerate(grid,1))
    return ('SCENE_CONTEXT: Une streameuse dans son studio éclairé par des néons.\n'
            'NEW_TAKE:\n'+shots)

class V80LocalGemmaTest(unittest.TestCase):
    def test_first_success_action_then_separate_short_transition(self):
        w=v78.select_window(37,124,0,1.083)
        self.assertEqual([r for r,_,_ in v80._grid(w)],['ACTION','TRANSITION APRÈS'])
        prompt=v80._instruction(request='elle lève la main',source_prompt=SOURCE,window=w)
        self.assertIn('Prochain repère original après ce segment : 2.500s',prompt)
        self.assertIn('[Shot 2] 1.083–1.625s — TRANSITION APRÈS',prompt)
        ctx,shots=v80._extract(fake_gemma(w),w)
        final=v80._assemble(ctx,shots,w)
        self.assertIn('[Shot 1] 0.000–1.083s',final)
        self.assertIn('[Shot 2] 1.083–1.625s',final)
        self.assertNotIn('[Shot 3]',final)
        self.assertNotIn('[Shot 2] 2.500–5.167s',final)
        self.assertEqual(len(re.findall(r'\[Shot\s+\d+\]',final)),2)

    def test_end_clip_transition_before_action(self):
        w=v78.select_window(37,124,4.145,5.167)
        self.assertEqual([r for r,_,_ in v80._grid(w)],['TRANSITION AVANT','ACTION'])
        _,shots=v80._extract(fake_gemma(w),w)
        self.assertIn('[Shot 1] 0.000–0.583s',shots)
        self.assertIn('[Shot 2] 0.583–1.625s',shots)
        self.assertNotIn('4.145',shots)

    def test_middle_window_both_transitions(self):
        w=v78.select_window(37,124,0.7,1.2)
        self.assertEqual([r for r,_,_ in v80._grid(w)],['TRANSITION AVANT','ACTION','TRANSITION APRÈS'])
        _,shots=v80._extract(fake_gemma(w),w)
        self.assertEqual(shots.count('[Shot'),3)
        self.assertTrue(shots.endswith('elle relâche le bras et reprend doucement sa pose naturelle.'))

    def test_wrong_window_is_rejected_not_sent_to_h3(self):
        w=v78.select_window(37,124,0,1.083)
        bad=fake_gemma(w).replace('1.083–1.625s','1.083–2.500s')
        with self.assertRaisesRegex(RuntimeError,'hors grille'):
            v80._extract(bad,w)

    def test_doubled_cue_is_deduplicated(self):
        w=v78.select_window(37,124,0,1.083)
        gemma=fake_gemma(w).replace('elle lève la main droite',
                    'Pendant 0.000–1.083s : Pendant 0.000–1.083s : elle lève la main droite')
        _,shot=v80._extract(gemma,w)
        self.assertEqual(shot.count('Pendant 0.000–1.083s :'),1)

    def test_too_long_selection_fails_instead_of_silent_global_fallback(self):
        import retouches_next as engine
        import tempfile
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as temp:
            ident='d'*32
            row={'id':ident,'mode':'precise','performance_type':'action',
                 'project':'test','clip':'1','start':3.501,'end':5.167,
                 'selected':True,'test_clip':False,'instruction':'Elle serre le poing',
                 'region':None}
            root=Path(temp)
            with patch.object(engine,'ROOT',root/'engine'),\
                 patch.object(engine,'JOBS',root/'engine'/'jobs'),\
                 patch.object(engine,'_project',return_value=(root/'source.mp4',root/'latent.pt')),\
                 patch.object(engine,'_metadata',return_value={'fps':24,'duration':124/24,'frames':124}),\
                 patch.object(engine.legacy,'comfy_json',side_effect=AssertionError('ComfyUI must not be called')):
                engine._save(row)
                engine._run(ident,lambda p:root,lambda:root)
                failed=engine.job(ident)
                self.assertEqual(failed['status'],'error')
                self.assertIn('sélection trop longue',failed['error'])

    def test_writer_ollama_lifecycle_and_local_output(self):
        w=v78.select_window(37,124,0,1.083)
        calls=[]
        import h3film_studio_v3 as film
        with patch.object(v74,'choose_backend',return_value={'display':'mock 26B'}),\
             patch.object(film,'director_text',side_effect=lambda *_args,**_kw:fake_gemma(w)),\
             patch.object(film,'unload_text_backend',side_effect=lambda *_args,**_kw:calls.append('unload')),\
             patch.object(film,'release_all_text_models_for_h3',side_effect=lambda *_args,**_kw:calls.append('release')):
            p,name=v80.write_prompt(mode='precise',performance_type='action',
                request='Elle lève la main et la redescend',source_prompt=SOURCE,
                window=w,gpu_prepare=lambda:calls.append('free'))
        self.assertEqual(calls,['free','unload','release'])
        self.assertIn('1.083–1.625s',p)
        self.assertIn('V10.80',name)

    def test_protected_raw_trial_functions_are_byte_identical_to_v77(self):
        golden={
            '_prepare_quick_payload':'dae2468ac66542be74ec0b6b75044a6d2e4b1f0e944a2b71afae3bc89e88d340',
            '_stage_short_source_video':'245a81358ee54782edbbeaaa9bff10e62b033e03f642ba06eb3bc1a461547b8d',
        }
        s=(ROOT/'retouches_next.py').read_text('utf-8')
        for name,digest in golden.items():
            node=next(n for n in ast.parse(s).body if isinstance(n,ast.FunctionDef) and n.name==name)
            original='\n'.join(s.splitlines()[node.lineno-1:node.end_lineno])
            self.assertEqual(hashlib.sha256(original.encode()).hexdigest(),digest)

if __name__=='__main__':unittest.main()
