"""V10.23 regressions: no GPU, tests exact delivery behavior."""
from pathlib import Path
import importlib.util
import subprocess
import sys
import time
import urllib.request
import pytest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('dialogue_budget_v23',ROOT/'studio_dialogue_budget.py')
dialogue=importlib.util.module_from_spec(spec)
spec.loader.exec_module(dialogue)

ORIGINAL='''REFERENCE AUTHORITY — never change this.
**[Shot 1] 0:00–2.5s**
Macro of Brad's face. Brad speaks:
<d>[French] Bonjour mon cher, je voudrais te demander si tu viens dîner avec moi ce soir.</d>
**CUT.**
**[Shot 2] 2.5–5.0s**
Two-shot. Matt responds:
<d>[French] Oui je viens avec toi !</d>
'''


def test_dialogue_transplant_only_changes_spoken_words_not_camera_character_or_authority():
    suggested='''**[Shot 1] 0:00–2.5s**
NOW THE CAMERA POINTS TO MATT (not permitted)
<d>[French] On dîne ensemble ce soir ?</d>
**[Shot 2] 2.5–5.0s**
Matt responds:
<d>[French] Oui, avec plaisir.</d>'''
    result=dialogue.transplant_spoken(ORIGINAL,suggested)
    assert 'Macro of Brad\'s face. Brad speaks:' in result
    assert 'NOW THE CAMERA POINTS' not in result
    assert 'Two-shot. Matt responds:' in result
    assert result.startswith('REFERENCE AUTHORITY — never change this.')
    assert not dialogue.check(result)


def test_dialogue_autorepair_bounded_rechecks_and_preserves_approval():
    calls=[]
    def director(prompt,issues,attempt):
        calls.append((attempt,len(issues),prompt))
        if attempt==1:
            return '''[Shot 1] 0:00–2.5s
<d>[French] Bonjour je voudrais absolument te voir demain soir après le dîner.</d>
[Shot 2] 2.5–5.0s
<d>[French] Bien entendu demain !</d>'''
        return '''[Shot 1] 0:00–2.5s
<d>[French] Tu viens dîner ?</d>
[Shot 2] 2.5–5.0s
<d>[French] Oui, avec plaisir.</d>'''
    fixed,issues=dialogue.repair(ORIGINAL,director)
    assert issues==[]
    assert [x[0] for x in calls]==[1,2]
    assert dialogue.check(fixed)==[]
    assert fixed.startswith('REFERENCE AUTHORITY — never change this.')


def test_repair_refuses_missing_shots_and_bad_speaker_count():
    bad='[Shot 1] 0:00–2.5s\n<d>trop</d>'
    with pytest.raises(ValueError,match='shots'):
        dialogue.transplant_spoken(ORIGINAL,bad)
    fixed,issues=dialogue.repair(ORIGINAL,lambda *_:bad)
    assert fixed==ORIGINAL and issues


def test_new_director_guidance_and_every_render_path_checked():
    source=(ROOT/'h3film_studio_v3.py').read_text(encoding='utf8')
    assert 'Conserve le SENS de chaque réplique.' in source
    assert 'autres shots du MÊME clip' in source
    assert 'PROCHAIN clip' in source
    assert "_auto_dialogue_gate(h3_prompt,'validation')" in source
    assert "_auto_dialogue_gate(h3_prompt,'avant RAW/H3')" in source
    assert source.index("_auto_dialogue_gate(h3_prompt,'avant RAW/H3')") < source.index('video_ann, raw_ann, cumulative_final_ann, used_mc = render_clip(')


def test_krea_and_lora_css_served_by_actual_http_server():
    cmd=[sys.executable,'-I',str(ROOT/'studio_web.py'),'--port','7860']
    proc=subprocess.Popen(cmd,cwd=ROOT,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        for i in range(40):
            try:
                with urllib.request.urlopen('http://127.0.0.1:7860/studio-v10-23.css',timeout=.6) as r:
                    assert r.status==200 and 'text/css' in r.headers['Content-Type']
                    assert b'kreaWorking' in r.read()
                    break
            except Exception:time.sleep(.1)
        else:pytest.fail('server did not expose updated CSS')
        for name in ('studio-v10-20.css','studio-v10-22.css'):
            with urllib.request.urlopen('http://127.0.0.1:7860/'+name,timeout=2) as r:
                assert r.status==200
    finally:
        proc.terminate()
        try:proc.wait(timeout=3)
        except subprocess.TimeoutExpired:proc.kill()


def test_browser_loading_real_css_constrains_preview_and_hides_form():
    try:from playwright.sync_api import sync_playwright
    except ImportError:pytest.skip('Playwright not installed')
    with sync_playwright() as p:
        try:browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        except Exception:pytest.skip('Chromium not available')
        page=browser.new_page(viewport={'width':1180,'height':800})
        page.set_content((ROOT/'studio_ui/index.html').read_text(encoding='utf8'))
        for css in ROOT.joinpath('studio_ui').glob('*.css'):
            page.add_style_tag(content=css.read_text(encoding='utf8'))
        page.evaluate('''() => {
          document.getElementById('kreaClipModal').classList.remove('hidden');
          document.querySelector('#kreaClipModal .dialog').classList.add('kreaWorking');
          document.getElementById('kreaStage').classList.remove('hidden');
          document.getElementById('kreaBusyVisual').classList.add('hidden');
          const img=document.getElementById('kreaResultImage');
          img.src='data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="1024" height="2048"%3E%3Crect width="1024" height="2048" fill="red"/%3E%3C/svg%3E';
          img.classList.remove('hidden');
        }''')
        page.locator('#kreaResultImage').wait_for(state='visible')
        dims=page.evaluate('''() => {
          const d=document.querySelector('#kreaClipModal .dialog');
          const stage=document.getElementById('kreaStage');
          const img=document.getElementById('kreaResultImage');
          const a=stage.getBoundingClientRect(), b=img.getBoundingClientRect();
          return {sh:a.height, ih:b.height, sw:a.width, iw:b.width,
                  promptVisible:getComputedStyle(document.querySelector('#kreaClipModal label')).display !=='none',
                  overflow:d.scrollWidth>d.clientWidth};
        }''')
        assert dims['ih']<=dims['sh'] and dims['iw']<=dims['sw']
        assert not dims['promptVisible'] and not dims['overflow']
        browser.close()
