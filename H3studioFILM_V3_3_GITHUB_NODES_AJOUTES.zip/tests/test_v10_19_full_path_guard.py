"""V10.19 regression gates: raw retake, Krea UI sources, graceful stop,
object continuity immutability, and Python isolated entrypoints.
"""
import ast
import hashlib
import json
import os
import signal
from pathlib import Path
from unittest.mock import MagicMock
import pytest

ROOT = Path(__file__).resolve().parents[1]
import h3film_studio_v3 as film
import studio_emergency_stop as stops


def test_world_context_is_always_present_and_idempotent():
    world = {'world_environment':'En 2056, Nice est une mégapole verticale sous les pluies acides.'}
    decors = [{'kind':'decor','role':'canonical_environment','subject_name':'École'}]
    pitch = film.world_ambient_mini_pitch(world, decors)
    assert 'En 2056' in pitch
    assert 'canonical local environment Picture have priority' in pitch
    raw = 'REFERENCE AUTHORITY — these Picture inputs are authoritative:\n<Subject 1> is École.\n\n**description_multimodale_intégrée :**\nMatt entre dans la classe.'
    full = film.ensure_world_ambient_in_h3_prompt(raw,pitch)
    assert full.count('**World ambience')==1
    assert film.ensure_world_ambient_in_h3_prompt(full,pitch)==full
    assert film.creative_clip_body(full).startswith('**description_multimodale_intégrée')
    assert film.creative_clip_body(full).endswith('Matt entre dans la classe.')
    assert film.world_ambient_mini_pitch({'concept':'Une invasion alien'},decors).count('invasion alien')==1
    assert '**World ambience' in film.world_ambient_mini_pitch({},decors)


def test_world_cue_in_all_saved_and_rendered_prompt_paths():
    src=(ROOT/'h3film_studio_v3.py').read_text(encoding='utf8')
    assert src.count('h3_prompt=ensure_world_ambient_in_h3_prompt(h3_prompt,world_block)')>=1
    assert src.count('h3_prompt = ensure_world_ambient_in_h3_prompt(h3_prompt,world_block)')>=1
    # Refused-RAW generation has two revision branches: both must include world.
    assert src.count('prefix,world_block,director_block,spatial_block,cue')>=2  # plus optional dialogue-budget revision
    assert src.index('h3_prompt=ensure_world_ambient_in_h3_prompt(h3_prompt,world_block)') < src.index('video_ann, raw_ann, cumulative_final_ann, used_mc = render_clip')


def test_no_function_local_import_shadows_global_shutil():
    tree=ast.parse((ROOT/'h3film_studio_v3.py').read_text(encoding='utf8'))
    f=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='main')
    assert not [x for x in ast.walk(f) if isinstance(x,ast.Import) and any(a.name=='shutil' for a in x.names)]
    assert any(x for x in ast.walk(f) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and isinstance(x.func.value,ast.Name) and x.func.value.id=='shutil' and x.func.attr=='copy2')


def test_stop_cleans_up_even_when_first_action_fails_and_ctrl_c_repeats(monkeypatch):
    calls=[]
    monkeypatch.setattr(stops.os, 'name', 'nt',raising=False)
    def fail_powershell(*a,**kw):
        calls.append('powershell')
        raise OSError('Simulated process launch failure')
    monkeypatch.setattr(stops.subprocess,'run',fail_powershell)
    class DummyResponse:
        def __enter__(self): return self
        def __exit__(self,*a): return False
    def fake_open(req,timeout):
        calls.append(req.full_url.rsplit('/',1)[-1])
        return DummyResponse()
    monkeypatch.setattr(stops.urllib.request,'urlopen',fake_open)
    old=signal.getsignal(signal.SIGINT)
    problems=stops.emergency_stop()
    assert calls==['powershell','interrupt','queue']
    assert len(problems)==1 and 'Simulated' in problems[0]
    assert signal.getsignal(signal.SIGINT)==old


def test_critical_object_functions_byte_equivalent_to_v1016():
    older=ROOT.parent/'h3v1016_work'/'h3film_studio_v3.py'
    if not older.exists(): pytest.skip('V10.16 baseline archive not available')
    expected=ast.parse(older.read_text(encoding='utf8'))
    actual=ast.parse((ROOT/'h3film_studio_v3.py').read_text(encoding='utf8'))
    names=['plan_continuity_object_candidates','verify_continuity_object_reference',
           'stage_dynamic_ref','reference_prompt_prefix','render_clip']
    for name in names:
        def func(tree):return next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
        assert ast.dump(func(expected))==ast.dump(func(actual)),name


def test_krea_source_picker_and_import_browser(tmp_path):
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1100,'height':900})
        errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        html=(ROOT/'studio_ui/index.html').read_text(encoding='utf8')
        page.set_content(html)
        for filename in ('studio.css','studio-v10-15.css','studio-v10-17.css'):
            page.add_style_tag(content=(ROOT/'studio_ui'/filename).read_text(encoding='utf8'))
        page.add_script_tag(content=(ROOT/'studio_ui/studio.js').read_text(encoding='utf8'))
        page.evaluate('''() => {
          projectName='demo';
          clipDraft={id:'clip_0001',refs:[{media:'image',path:'C:/Comfy/input/H3FilmSimple/demo/matt.png',
               name:'Matt',kind:'character',url:'/media/input/H3FilmSimple/demo/matt.png'}]};
          const calls=[];window.kreaCalls=calls;
          window.fetch=async (url,options={})=>{
           calls.push({url,method:options.method||'GET'});
           if(String(url).startsWith('/api/ref-images'))return {ok:true,json:async()=>[
             {name:'Classe',path:'C:/Comfy/input/H3FilmSimple/demo/classe.png',url:'/media/input/H3FilmSimple/demo/classe.png',group:'decor'}]};
           if(url==='/api/upload')return {ok:true,json:async()=>({path:'C:/Comfy/input/H3FilmSimple/studio_uploads/upload.png',url:'/media/input/H3FilmSimple/studio_uploads/upload.png'})};
           return {ok:false,json:async()=>({error:'unexpected '+url})};
          };
          openKreaClip();
        }''')
        page.wait_for_function("document.querySelector('#kreaClipSource')?.options.length===2")
        options=page.locator('#kreaClipSource option').all_text_contents()
        assert any('Matt' in x for x in options)
        assert any('Classe' in x for x in options)
        page.locator('#kreaClipSource').select_option('C:/Comfy/input/H3FilmSimple/demo/classe.png')
        assert 'classe.png' in page.locator('#kreaSourcePreview').get_attribute('src')
        file=tmp_path/'image.png';file.write_bytes(b'\x89PNG\r\n\x1a\n' + b'pixel')
        page.locator('#kreaImportSource').set_input_files(str(file))
        page.wait_for_function("document.querySelector('#kreaClipSource')?.value?.includes('upload.png')")
        assert 'upload.png' in page.locator('#kreaSourcePreview').get_attribute('src')
        assert 'Importer une image source' in page.locator('#kreaClipModal').inner_text()
        page.locator('#kreaClipMode').select_option('text')
        assert page.locator('#kreaSourceRow').is_hidden()
        assert not errors,errors
        browser.close()


def test_krea_api_accepts_imported_source_and_only_stages_output(tmp_path,monkeypatch):
    import studio_web as web
    session=tmp_path/'session';session.mkdir()
    web.write_json(session/'review.json',{'id':'clip-1','kind':'clips'})
    web.write_json(session/'active_project.json',{'name':'demo'})
    comfy=tmp_path/'comfy';(comfy/'input'/'H3FilmSimple').mkdir(parents=True)
    (comfy/'output').mkdir()
    src=comfy/'input'/'H3FilmSimple'/'image.png';src.write_bytes(b'PNG from refbank')
    result=comfy/'output'/'krea.png';result.write_bytes(b'Krea result')
    monkeypatch.setitem(web.STATE,'proc',MagicMock(poll=lambda:None))
    monkeypatch.setattr(web,'comfy_path',lambda:comfy)
    monkeypatch.setattr(web,'media_uri',lambda path:'/media/input/KreaImage.png')
    seen=[]
    class FakeEngine:
        def installed_model_names(self, tags):return ['gemma4:12b']
        def _ollama_backend(self, model):return {'model':model}
        def studio_clip_krea_prompt(self, backend, **kwargs):
            assert kwargs['mode']=='transform' and kwargs['user_description']
            return 'A photorealistic classroom in the same composition, with new lighting.'
        def release_all_text_models_for_h3(self,**kwargs):seen.append('unload')
        def render_krea_reference(self,*args,**kwargs):
            seen.append((args,kwargs));return result
        rt=MagicMock()
    engine=FakeEngine()
    engine.rt.COMFY_URL='http://127.0.0.1:8188'
    engine.rt.OLLAMA_URL='http://127.0.0.1:11434'
    engine.rt.http_json.return_value={}
    monkeypatch.setattr(web,'reference_preview_engine',lambda:engine)
    class InlineThread:
        def __init__(self, target, **kwargs):self.target=target
        def start(self):self.target()
    monkeypatch.setattr(web.threading,'Thread',InlineThread)
    before=src.read_bytes()
    job=web.start_krea_clip_reference({'project':'demo','review_id':'clip-1',
           'prompt':'Keep the same classroom with new light',
           'name':'Classroom','category':'decor','mode':'image','source_path':str(src)},session)
    state=web.krea_job_status(job['job_id'])
    assert state['status']=='complete' and Path(state['path']).is_file()
    assert Path(state['path']).read_bytes()==b'Krea result'
    assert src.read_bytes()==before
    assert seen[1][1]['source_image']==src
    assert not any((comfy/'input'/'H3FilmSimple'/'demo').glob('**/canonical*'))
    with web._KREA_LOCK:
        web._KREA_JOBS.pop(job['job_id'],None)


def test_second_ctrl_c_during_cleanup_is_ignored_then_handler_restored(monkeypatch):
    if os.name == 'nt': pytest.skip('SIGINT simulation here uses POSIX semantics')
    observed=[]
    original=signal.getsignal(signal.SIGINT)
    def fake_impl():
        assert signal.getsignal(signal.SIGINT) == signal.SIG_IGN
        signal.raise_signal(signal.SIGINT)  # second Ctrl+C while handling the first
        observed.append('cleanup continued')
        return []
    monkeypatch.setattr(stops,'_emergency_stop_impl',fake_impl)
    assert stops.emergency_stop()==[]
    assert observed==['cleanup continued']
    assert signal.getsignal(signal.SIGINT) == original
