"""Regression: the first choice after Content must render, not crash the UI.

The V10.25/26 question branch declared `const title` after assigning `title`.
Javascript's temporal dead zone threw a ReferenceError and the refresh catch
misleadingly said HORS LIGNE while the worker awaited a response.
"""
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]


def _run_question_branch(js_path: Path, title: str) -> dict:
    script = r'''
const fs=require('fs'), vm=require('vm');
const file=process.argv[1], label=process.argv[2];
const source=fs.readFileSync(file,'utf8');
const start=source.indexOf('function actionPanel(data){');
const end=source.indexOf('\nasync function decideRaw(',start);
if(start<0||end<0)throw Error('actionPanel not located');
const el={};
function make(id){return {textContent:'',innerHTML:'',dataset:{},classList:{toggle(){},add(){},remove(){}},querySelectorAll(){return []}}}
function $(id){return el[id]||(el[id]=make(id))}
const context={projectName:'film_test',project:{},$: $,escapeHTML:x=>String(x??'').replace(/&/g,'&amp;').replace(/</g,'&lt;'),
  optionButton: opt=>`<button class="decisionOption" data-value="${opt.value}">${opt.label}</button>`,
  focusDirector(){},answer(){},console};
vm.createContext(context);
vm.runInContext(source.slice(start,end),context);
context.actionPanel({running:true,project:{name:'film_test'},question:{id:'first-reference',context:{
  title:label,description:'Choisir les références',options:[{value:'',label:'Parcourir'},{value:'s',label:'Ignorer'}],input_type:'choice'}},raw_gates:[]});
const html=el.questionArea.innerHTML;
if(!html.includes('Parcourir')||!html.includes('Ignorer'))throw Error('Question buttons not rendered');
if(el.deskTitle.textContent!==label)throw Error('Wrong question title');
if(el.decisionStatus.textContent!=='ACTION REQUISE')throw Error('Wrong review state');
process.stdout.write(JSON.stringify({status:el.decisionStatus.textContent,title:el.deskTitle.textContent,buttons:2}));
'''
    r=subprocess.run(['node','-e',script,str(js_path),title],capture_output=True,text=True,timeout=12)
    if r.returncode:
        raise AssertionError(r.stderr)
    import json
    return json.loads(r.stdout)


def test_first_reference_question_is_rendered_after_content():
    out=_run_question_branch(ROOT/'studio_ui'/'studio.js','Références canoniques proposées')
    assert out['buttons']==2


def test_krea_source_question_is_rendered():
    out=_run_question_branch(ROOT/'studio_ui'/'studio.js','Image source pour Le Streamer')
    assert out['status']=='ACTION REQUISE'


def test_no_title_shadow_inside_question_branch():
    text=(ROOT/'studio_ui'/'studio.js').read_text(encoding='utf-8')
    q=text[text.index('} else if(question){'):text.index('} else {',text.index('} else if(question){'))]
    assert "const title=ctx.title||''" not in q
    assert 'const kreaBackButtons' in q
