"""V10.84: prove the old 4-frame transition is restored at exactly ONE seam.

These tests use generated color clips and FFmpeg only. No GPU / H3 inference.
"""
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

import retouches_precise_half_v82 as half


@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'), 'ffmpeg unavailable')
class SingleJoinTests(unittest.TestCase):
    def make_clip(self,path,frames,color):
        p=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi','-i',
                          f'color=c={color}:size=64x64:rate=24','-frames:v',str(frames),
                          '-c:v','libx264','-crf','0','-pix_fmt','yuv420p',str(path)],
                         capture_output=True,text=True,timeout=60)
        self.assertEqual(p.returncode,0,p.stderr)

    def mean_luma(self,video,index):
        p=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-i',str(video),
                          '-vf',f'select=eq(n\\,{index})','-vsync','0','-frames:v','1',
                          '-f','rawvideo','-pix_fmt','gray','-'],capture_output=True,timeout=60)
        self.assertEqual(p.returncode,0,p.stderr[-300:])
        return sum(p.stdout)/len(p.stdout)

    def check_join(self,mode):
        with tempfile.TemporaryDirectory() as d:
            d=Path(d); source=d/'original.mp4'; gen=d/'new.mp4'; out=d/'result.mp4'
            self.make_clip(source,124,'gray')
            self.make_clip(gen,63,'white')
            if mode=='prefix_only':
                win={'seam_mode':mode,'origin_frame':61,'end_frame':124,'frames':63,'first_frame':61,'last_frame':110}
                cut=61
            else:
                win={'seam_mode':mode,'origin_frame':0,'end_frame':63,'frames':63,'first_frame':0,'last_frame':36}
                cut=63
            half.stitch(source,gen,out,win,124,d/'comfy')
            self.assertEqual(half._frame_count(out,d/'comfy'),124)
            values=[self.mean_luma(out,i) for i in range(cut-2,cut+5)]
            if mode=='prefix_only':
                # frame 61 should still resemble original more than generated;
                # by frame 64 the full generated footage should take over.
                self.assertLess(values[2]-values[1],75,values)
                self.assertGreater(values[5],200,values)
                self.assertGreater(values[3],values[2],values)
                self.assertGreater(values[4],values[3],values)
            else:
                # final generated frames fade back to original, avoiding a hard cut.
                self.assertLess(abs(values[2]-values[1]),75,values)
                self.assertLess(values[2],170,values)
                self.assertLess(abs(values[2]-values[3]),8,values)

    def test_original_to_generated_single_boundary(self):
        self.check_join('prefix_only')

    def test_generated_to_original_single_boundary(self):
        self.check_join('suffix_only')


if __name__=='__main__':
    unittest.main()
