"""V10.5 lightweight tests: no risk to ComfyUI, and no stale legacy PID termination."""
import sys, unittest, tempfile, json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import studio_web as web

class V105(unittest.TestCase):
    def test_assets_and_stability_guards(self):
        root=Path(__file__).resolve().parents[1]
        js=(root/'studio_ui'/'studio.js').read_text('utf-8')
        html=(root/'studio_ui'/'index.html').read_text('utf-8')
        py=(root/'studio_web.py').read_text('utf-8')
        for fragment in ("timelineSignature", "liveRefsSignature", "refreshBusy", "storySignature", "projectListSignature", "stopLegacySession"):
            self.assertIn(fragment,js)
        self.assertNotIn("const viewingProject=project.clips||{};document.body.classList.toggle",js)
        self.assertIn('id="pauseBtn"',html)
        self.assertIn('id="stopRenderBtn"',html)
        self.assertIn('studio-v10-5.css',html)
        self.assertIn("'/api/stop-older'",py)
        self.assertIn("'/studio-v10-5.css'",py)

    def test_legacy_stop_fails_closed_if_process_identity_unverified(self):
        with tempfile.TemporaryDirectory() as td:
            old=Path(td)
            with patch.object(web,'older_running_productions',return_value=[{'pid':14048,'session':str(old),'project':'test'}]), \
                 patch.object(web,'verified_film_worker',return_value=False), \
                 patch.object(web.subprocess,'run') as kill:
                with self.assertRaisesRegex(ValueError,'Identité du processus'):
                    web.stop_older_session(14048)
                kill.assert_not_called()

    def test_legacy_stop_targets_only_verified_film_worker(self):
        with tempfile.TemporaryDirectory() as td:
            old=Path(td)
            (old/'run.json').write_text(json.dumps({'pid':14048,'running':True}),encoding='utf-8')
            p=SimpleNamespace(returncode=0,stdout='SUCCESS',stderr='')
            with patch.object(web,'older_running_productions',return_value=[{'pid':14048,'session':str(old),'project':'test'}]), \
                 patch.object(web,'verified_film_worker',return_value=True), \
                 patch.object(web,'process_alive',return_value=False), \
                 patch.object(web,'interrupt_owned_prompt',return_value='Cible Comfy vérifiée.'), \
                 patch.object(web,'load_project',return_value=None), \
                 patch.object(web.subprocess,'run',return_value=p) as kill:
                res=web.stop_older_session(14048)
                self.assertTrue(res['ok'])
                self.assertTrue((old/'stop.request').exists())
                self.assertFalse(json.loads((old/'run.json').read_text('utf-8'))['running'])
                argv=kill.call_args.args[0]
                self.assertEqual(argv,['taskkill.exe','/PID','14048','/F'])
                self.assertNotIn('/T',argv)

if __name__=='__main__':unittest.main()
