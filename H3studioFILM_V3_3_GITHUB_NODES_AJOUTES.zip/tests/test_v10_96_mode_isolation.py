from pathlib import Path
import sys,copy,types
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import retouches_next as n
import retouches_performance_native_v96 as performance
import retouches_roycho_complete_v63 as insert


def test_node_gates_do_not_require_retake_mask_in_performance_insert():
    assert 'H3RetouchMaskV58' in n._mode_required_nodes('precise')
    assert 'H3RetouchMaskV58' not in n._mode_required_nodes('insert')
    assert 'H3RetouchMaskV58' not in n._mode_required_nodes('performance')
    assert 'H3LoadRawLatentExact' not in n._mode_required_nodes('performance')
    assert 'H3RoychoAnimatedMaskV62' in n._mode_required_nodes('insert')


def test_native_performance_has_no_retake_mask_latent_or_video(monkeypatch,tmp_path):
    graph={
       '159':{'class_type':'H3StudioImageToVideo','inputs':{'prompt':'old','ref_video_files':'my.mp4','motion_context_file':'old.mp4','first_frame_file':''}},
       '207':{'class_type':'SamplerCustomAdvanced','inputs':{'latent_image':['159',1]}},
       '201':{'class_type':'H3RawCacheHold','inputs':{'samples':['207',0]}},
       '190':{'class_type':'CreateVideo','inputs':{'images':['207',0]}},
       '191':{'class_type':'SaveVideo','inputs':{'video':['190',0],'filename_prefix':'old'}},
       '129':{'class_type':'RandomNoise','inputs':{'noise_seed':1}},
    }
    rt=types.SimpleNamespace(gui_to_api=lambda *_:copy.deepcopy(graph),patch_models=lambda *_:None,reset_h3_optional_inputs=lambda *_:None)
    result=performance.build({},tmp_path/'old.mp4','1'*32,{'frames':124},'THE REWRITTEN PROMPT',42,first_frame_name='h3new_source_frame0.png',
        snapshot=lambda:{},metadata=lambda *a:{'width':640,'height':384},comfy=tmp_path,rt=rt,preflight=lambda *a:None)
    assert result['207']['inputs']['latent_image']==['159',1]
    assert result['159']['inputs']['prompt']=='THE REWRITTEN PROMPT'
    assert result['159']['inputs']['first_frame_file']=='h3new_source_frame0.png'
    assert result['159']['inputs']['ref_video_files']==''
    assert result['159']['inputs']['motion_context_file']==''
    assert result['129']['inputs']['noise_seed']==42
    assert result['159']['inputs']['length']==124
    assert '201' not in result
    assert '901' not in result and '902' not in result


def test_image_reference_reaches_minimax_conditioner_not_as_overlay():
    required={
      'H3LoadRawLatentExact','H3RoychoAnimatedMaskV62','LoadVideo','GetVideoComponents',
      'MVEx_MaskCleanup','MVEx_SubjectCrop','MVEx_MaskToLatentSpace','MVEx_SubjectUncrop',
      'VAELoader','CLIPLoader','UNETLoader','MiniMaxH3SigmaShift','VAEEncode','GetImageSizeAndCount',
      'SetLatentNoiseMask','VAEEncodeAudio','LTXVConcatAVLatent','MiniMaxH3ReferenceToVideo',
      'BasicGuider','RandomNoise','BasicScheduler','KSamplerSelect','SamplerCustomAdvanced',
      'LTXVSeparateAVLatent','VAEDecode','CreateVideo','SaveVideo','LoadImage',
      'H3RoychoCropGuideV64','MiniMaxH3AddGuide'
    }
    info={x:{} for x in required}
    sec={'start':0.,'end':124/24.,'duration':124/24.,'frames':124}
    kwargs=dict(ident='f'*32,source=Path('/tmp/a.mp4'),source_filename='source.mp4',project='myproject',clip='1',
                seconds=sec,instruction='Ajoute un téléphone rouge.',rect=(10,10,40,50),
                latent_name='clip_0001_RAW_LATENT',guide_image_name='guide.png')
    no_ref=insert.build(info,**kwargs)
    with_ref=insert.build(info,**kwargs,insert_reference_name='phone.png')
    assert no_ref['33']['inputs'].get('ref_images.ref_image_0') is None
    assert with_ref['33']['inputs']['ref_images.ref_image_0']==['46',0]
    assert with_ref['46']['inputs']['image']=='phone.png'
    assert 'Picture 1' in with_ref['33']['inputs']['prompt']
    assert with_ref['45']['inputs']['frame_idx']==0
    assert with_ref['44']['inputs']['frame_index']==0
    assert with_ref['41']['inputs']['original_images']==['2',0]


def test_seed_reuses_original_when_known_and_stable_when_unknown(tmp_path):
    import json
    p=tmp_path/'_studio';p.mkdir()
    manifest=p/'clips.json'
    manifest.write_text(json.dumps({'clips':{'1':{'noise_seed':123}}}))
    assert performance.seed_for_source('myproject',1,lambda *_:tmp_path)==123
    manifest.write_text(json.dumps({'clips':{'1':{}}}))
    a=performance.seed_for_source('myproject',1,lambda *_:tmp_path)
    assert a==performance.seed_for_source('myproject',1,lambda *_:tmp_path)
