"""End-to-end server authority and native encoded continuation wiring (no GPU)."""
import tempfile
import uuid
from pathlib import Path
from unittest.mock import patch

import pytest
import studio_retouch_review as review
import studio_web as web
import retouches_next as native


def test_continue_creates_immutable_intermediate_not_film_approval():
    with tempfile.TemporaryDirectory() as root:
        root=Path(root)
        rid=uuid.uuid4().hex
        source=root/'raw.mp4';source.write_bytes(b'raw'*100)
        row={'id':rid,'source':{'type':'project','project':'film_A','clip':'1','variant':'raw'},'status':'complete','mode':'local_edit'}
        with patch.object(review,'ROOT',root/'review'),patch.object(review.legacy,'job',return_value=row),patch.object(review.legacy,'job_result',return_value=source):
            outcome=review.decide('legacy',rid,'continue')
            assert outcome['state']=='continued'
            assert review.approved_file('legacy',rid).read_bytes()==source.read_bytes()
            assert review.result_path('legacy',rid)==source
            assert review.source_project_clip('legacy',rid)==('film_A','1')
            assert review.decision('legacy',rid)['state']=='continued'
            assert not (root/'film_A/_studio/gates/clip_0001.retouch.approved.json').exists()
            assert review.decide('legacy',rid,'approve')['state']=='approved'
            assert source.read_bytes()==b'raw'*100


def test_mixed_chain_native_to_legacy_to_native_keeps_project_identity():
    with tempfile.TemporaryDirectory() as root:
        root=Path(root)
        a,b,c=[uuid.uuid4().hex for _ in range(3)]
        jobs={
            ('new',a):{'id':a,'status':'complete','project':'film_Z','clip':'2','source':{'type':'project','project':'film_Z','clip':'2','variant':'raw'}},
            ('legacy',b):{'id':b,'status':'complete','source':{'type':'review','kind':'new','id':a}},
            ('new',c):{'id':c,'status':'complete','project':'film_Z','clip':'2','source':{'type':'review','kind':'legacy','id':b}},
        }
        mp4=root/'ready.mp4';mp4.write_bytes(b'video')
        with patch.object(review,'ROOT',root/'review'),patch.object(review.legacy,'job',side_effect=lambda ident:jobs['legacy',ident]),\
             patch.object(review.native,'job',side_effect=lambda ident:jobs['new',ident]),\
             patch.object(review.legacy,'job_result',return_value=mp4),patch.object(review.native,'output',return_value=mp4):
            for kind,ident in [('new',a),('legacy',b),('new',c)]:
                assert review.decide(kind,ident,'continue')['state']=='continued'
                assert review.source_project_clip(kind,ident)==('film_Z','2')
            assert review.result_path('new',c)==mp4
            assert review.decide('new',c,'approve')['state']=='approved'


def test_film_pending_accepts_continued_review_only_for_same_clip():
    with tempfile.TemporaryDirectory() as root:
        root=Path(root)
        class Worker:
            def poll(self):return None
        session=root/'s';session.mkdir()
        (session/'active_project.json').write_text('{"name":"myfilm"}')
        (session/'stage.json').write_text('{"stage":"raw_retouch"}')
        p=root/'myfilm';g=p/'_studio/gates';g.mkdir(parents=True)
        (g/'clip_0001.retouch.requested.json').write_text('{"project":"myfilm","clip":1,"session":"s"}')
        source={'type':'review','kind':'legacy','id':'a'*32}
        with patch.object(web,'load_project',return_value=p),patch.object(web,'active_folder',return_value=session),\
             patch.dict(web.STATE,{'proc':Worker(),'session':session}),\
             patch.object(web.studio_retouch_review,'decision',return_value={'state':'continued'}),\
             patch.object(web.studio_retouch_review,'source_project_clip',return_value=('myfilm','1')):
            assert web.pending_film_retouch('myfilm','1')
            web.ensure_retouch_can_start(source)
        with patch.dict(web.STATE,{'proc':Worker(),'session':session}),\
             patch.object(web.studio_retouch_review,'decision',return_value={'state':'continued'}),\
             patch.object(web.studio_retouch_review,'source_project_clip',return_value=('anotherfilm','1')):
            with pytest.raises(ValueError,match='ne provient pas'):
                web.ensure_retouch_can_start(source)


def test_native_video_encoder_branch_has_no_raw_sampler():
    with tempfile.TemporaryDirectory() as root:
        root=Path(root);comfy=root/'ComfyUI';(comfy/'input').mkdir(parents=True)
        (comfy/'output').mkdir(parents=True)
        source=root/'source.mp4';source.write_bytes(b'video')
        info={'H3StoreRawLatentExact':{},'H3StudioImageToVideo':{},'LTXVSeparateAVLatent':{}}
        graph={'159':{'class_type':'H3StudioImageToVideo','inputs':{'prompt':'', 'length':124,'ref_audio_files':'', 'motion_context_file':''}},
               '183':{'class_type':'LTXVSeparateAVLatent','inputs':{'av_latent':['207',0]}},
               '188':{'class_type':'VAEDecode','inputs':{'samples':['183',0],'vae':['119',0]}},
               '189':{'class_type':'VAEDecodeAudio','inputs':{'samples':['183',1],'vae':['120',0]}},
               '119':{'class_type':'VAELoader','inputs':{'vae_name':'video'}},
               '120':{'class_type':'VAELoader','inputs':{'vae_name':'audio'}},
               '190':{'class_type':'CreateVideo','inputs':{'images':['188',0],'audio':['189',0]}},
               '191':{'class_type':'SaveVideo','inputs':{'video':['190',0]}},
               '207':{'class_type':'SamplerCustomAdvanced','inputs':{'latent_image':['159',1]}}}
        def test_graph(g, cid):
            assert not any(v['class_type']=='SamplerCustomAdvanced' for v in g.values())
            assert any(v['class_type']=='H3StoreRawLatentExact' for v in g.values())
            assert g['183']['inputs']['av_latent']==['999991',0]
            assert g['188']['inputs']['samples']==['183',0]
            assert g['189']['inputs']['samples']==['183',1]
            assert g['159']['inputs']['v2v_denoise']==0
            assert g['159']['inputs']['length']==124
            return 'mockpid'
        def status(path,timeout=7):
            if path=='/queue':return {'queue_running':[],'queue_pending':[]}
            return {'mockpid':{'status':{'status_str':'success'}}}
        import torch
        encoded=comfy/'output/H3FilmSimple/film/_state'
        def result_graph(g,cid):
            encoded.mkdir(parents=True,exist_ok=True)
            (encoded/('clip_0001_CHAIN_ENCODE_'+('a'*32)+'.pt')).write_bytes(b'opaque-test')
            return test_graph(g,cid)
        with patch.object(native,'_snapshot_gui',return_value={'nodes':[]}),patch.object(native.rt,'gui_to_api',return_value=graph),\
             patch.object(native.rt,'patch_models'),patch.object(native.rt,'reset_h3_optional_inputs'),\
             patch.object(native.rt,'input_schema',return_value=({'v2v_video_file':[]},{})),\
             patch.object(native,'_preflight_graph_links'),patch.object(native,'_preflight_required_inputs'),\
             patch.object(native,'_preflight_h3_numeric_inputs'),\
             patch.object(native,'_update'),patch.object(native.rt,'queue_graph',side_effect=result_graph),\
             patch.object(native.legacy,'comfy_json',side_effect=status),\
             patch.object(native,'_load_payload',return_value={'samples':{'members':[]}}),\
             patch.object(native.windows,'_video_members',return_value=([],torch.zeros(1,24,37,40,72),torch.zeros(1,32,2,207))):
            result=native._encode_continuation_mp4_as_h3_latent(source,comfy,'film','1','a'*32,info,
                {'width':1152,'height':640,'fps':24,'frames':124})
            assert result.exists()
            assert not (comfy/'input'/('h3new_'+'a'*32+'_continuation_source.mp4')).exists()


def test_first_film_retouch_preview_and_input_prefer_current_raw():
    with tempfile.TemporaryDirectory() as root:
        root=Path(root);comfy=root/'ComfyUI';project=comfy/'output/H3FilmSimple/filmX'
        rawdir=project/'raw';rawdir.mkdir(parents=True)
        old=rawdir/'clip_0001_RAW_MC_00001_.mp4';old.write_bytes(b'older')
        current=rawdir/'clip_0001_RAW_MC_00002_.mp4';current.write_bytes(b'latest')
        (project/'_state').mkdir()
        (project/'_state/clip_0001_RAW_LATENT.pt').write_bytes(b'pt')
        (project/'_studio').mkdir()
        (project/'_studio/clips.json').write_text('{"clips":{"1":{"raw":"'+str(old)+'","clip":1}}}')
        fake={'project':'filmX','clip':'1','project_path':project}
        with patch.object(web,'load_project',return_value=project),patch.object(web,'comfy_path',return_value=comfy),\
             patch.object(web,'pending_film_retouch',return_value=fake):
            data=web.project_data('filmX')
            assert data['clips']['1']['raw']==str(current)
            assert web.retouch_video_source({'type':'project','project':'filmX','clip':'1','variant':'raw'})==current
        # The registry is never overwritten by this transient film-stage mapping.
        assert '00001' in (project/'_studio/clips.json').read_text()


def test_real_raw_save_dependency_closure_omits_split_but_has_required_av_decoders():
    gui=native._snapshot_gui()
    node_by_id={int(n['id']):n['type'] for n in gui['nodes']}
    assert 183 not in node_by_id  # This was the V3 GPU-blocking regression.
    assert node_by_id[159]=='H3StudioImageToVideo'
    assert node_by_id[188]=='VAEDecode'
    assert node_by_id[189]=='VAEDecodeAudio'
    assert node_by_id[190]=='CreateVideo'
    assert node_by_id[191]=='SaveVideo'


def test_continuation_adapter_inserts_absent_split_without_touching_raw_sampler():
    # Exercise the same encoder contract as the GPU error, but with the split
    # deliberately missing (as in the REAL RAW dependency closure).
    import torch
    with tempfile.TemporaryDirectory() as root:
        root=Path(root);comfy=root/'ComfyUI'
        (comfy/'input').mkdir(parents=True)
        (comfy/'output').mkdir(parents=True)
        source=root/'retake_complete.mp4';source.write_bytes(b'video')
        graph={
          '159':{'class_type':'H3StudioImageToVideo','inputs':{'length':124,'motion_context_file':''}},
          '119':{'class_type':'VAELoader','inputs':{'vae_name':'video'}},
          '120':{'class_type':'VAELoader','inputs':{'vae_name':'audio'}},
          '188':{'class_type':'VAEDecode','inputs':{'samples':['201',0],'vae':['119',0]}},
          '189':{'class_type':'VAEDecodeAudio','inputs':{'samples':['201',0],'vae':['120',0]}},
          '190':{'class_type':'CreateVideo','inputs':{'images':['188',0],'audio':['189',0]}},
          '191':{'class_type':'SaveVideo','inputs':{'video':['190',0]}},
          '201':{'class_type':'H3RawCacheHold','inputs':{'latent':['207',0]}},
          '207':{'class_type':'SamplerCustomAdvanced','inputs':{'latent_image':['159',1]}},
        }
        info={'H3StoreRawLatentExact':{},'H3StudioImageToVideo':{},'LTXVSeparateAVLatent':{}}
        ident='b'*32
        def simulate_gpu(g,_client_id):
            classes=[n['class_type'] for n in g.values()]
            assert classes.count('H3StoreRawLatentExact')==1
            assert classes.count('LTXVSeparateAVLatent')==1
            assert 'SamplerCustomAdvanced' not in classes
            assert 'H3RawCacheHold' not in classes
            assert g['183']['inputs']['av_latent']==['999991',0]
            assert g['188']['inputs']['samples']==['183',0]
            assert g['189']['inputs']['samples']==['183',1]
            assert g['159']['inputs']['v2v_video_file'].endswith('continuation_source.mp4')
            outfile=comfy/'output/H3FilmSimple/film/_state'/f'clip_0001_CHAIN_ENCODE_{ident}.pt'
            outfile.parent.mkdir(parents=True,exist_ok=True);outfile.write_bytes(b'test')
            return 'pid'
        def simulated_comfy(path,timeout=7):
            if path=='/queue':return {'queue_running':[],'queue_pending':[]}
            return {'pid':{'status':{'status_str':'success'}}}
        with patch.object(native,'_snapshot_gui',return_value={'nodes':[]}),\
             patch.object(native.rt,'gui_to_api',return_value=graph),\
             patch.object(native.rt,'patch_models'),\
             patch.object(native.rt,'reset_h3_optional_inputs'),\
             patch.object(native.rt,'input_schema',return_value=({'v2v_video_file':[]},{})),\
             patch.object(native,'_preflight_graph_links'),\
             patch.object(native,'_preflight_required_inputs'),\
             patch.object(native,'_preflight_h3_numeric_inputs'),\
             patch.object(native,'_update'),\
             patch.object(native.rt,'queue_graph',side_effect=simulate_gpu),\
             patch.object(native.legacy,'comfy_json',side_effect=simulated_comfy),\
             patch.object(native,'_load_payload',return_value={'samples':{'members':[]}}),\
             patch.object(native.windows,'_video_members',return_value=([],torch.zeros(1,24,37,40,72),torch.zeros(1,32,2,207))),\
             patch.object(native.time,'sleep'):
            result=native._encode_continuation_mp4_as_h3_latent(source,comfy,'film','1',ident,info,
                {'width':1152,'height':640,'fps':24,'frames':124})
        assert result.exists()
        assert not (comfy/'input'/f'h3new_{ident}_continuation_source.mp4').exists()
