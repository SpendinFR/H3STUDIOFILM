"""No network, no GPU; V10.70 prompt authority and unchanged core contract."""
import sys,unittest,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_llm_prompt_v70 as retake

class V70Prompt(unittest.TestCase):
    old='''<Subject 1> = streameuse.
[Shot 1] 0.000–2.500 Elle regarde son écran, rit puis tourne la tête vers le spectateur.
[Shot 2] 2.500–5.167 Push-in, elle pointe l'écran et lève déjà la main droite en disant <d>[French] Attendez !</d>.
Ambiance live, néons bleus, ring light.'''
    new='''[Shot 1] 0.000–1.500 Elle rit en regardant l'écran, tourne la tête et lève clairement sa main droite EN MEME TEMPS, sans interrompre le rire.
[Shot 2] 1.500–2.900 Elle garde le bras levé un instant puis l'abaisse tout en fixant le spectateur et en continuant à pointer l'écran.
[Shot 3] 2.900–5.167 Push-in, elle interpelle la caméra avec sa réplique originale <d>[French] Attendez !</d> et finit le plan avec un geste naturel.'''
    def test_add_overlay_not_replace(self):
        prompt=retake.build_request('performance','action','Elle lève la main droite',self.old,0,5.167,5.167)
        self.assertIn('ADDITION / SUPERPOSITION',prompt)
        self.assertIn('EN MEME TEMPS',prompt)
        self.assertIn('déjà',prompt)
        self.assertIn('visuellement distincte',prompt)
        self.assertIn(self.old,prompt)
        self.assertNotIn('COPY THESE HEADERS',prompt)
        self.assertNotIn('SAME shots',prompt)
    def test_replace_only_explicit(self):
        self.assertEqual(retake.requested_operation('elle lève la main'), 'add')
        self.assertEqual(retake.requested_operation('Ajoute une levée de main'), 'add')
        self.assertEqual(retake.requested_operation('remplace le sourire par la colère'), 'replace')
        self.assertEqual(retake.requested_operation('elle sourit au lieu de pleurer'), 'replace')
        r=retake.assemble('remplace le sourire',self.new,0,5.167,5.167,self.old)
        self.assertIn('REMPLACER uniquement',r)
    def test_full_h3_prompt_contains_exact_original_user_change_and_new_shots(self):
        q=retake.assemble('Elle lève la main droite',self.new,0,5.167,5.167,self.old)
        self.assertIn('<Video 1>',q)
        self.assertIn(self.old,q)
        self.assertIn(self.new,q)
        self.assertIn('AJOUTER cette action',q)
        self.assertLess(q.index(self.old),q.index('NEW RETAKE / PERFORMANCE'))
        self.assertLess(q.index('NEW RETAKE / PERFORMANCE'),q.index(self.new))
        self.assertIn('NEW TAKE',q)
        self.assertIn('la timeline ci-dessous prévaut',q)
    def test_new_shot_count_and_timeline_may_change(self):
        self.assertEqual(retake.original_shots(self.old),[1,2])
        q=retake.assemble('Ajoute une nouvelle action',self.new,0,5.167,5.167,self.old)
        self.assertIn('[Shot 3]',q)
        self.assertIn('change shot COUNT, boundaries and numbering',retake.SYSTEM)
    def test_rejects_unchanged_and_duplicate_shots(self):
        with self.assertRaisesRegex(RuntimeError,'inchangé'):
            retake.assemble('Nouvelle action',self.old,0,5.167,5.167,self.old)
        duplicate='[Shot 1] '+'a long original text '*6+'\n[Shot 1] '+'another segment '*8
        with self.assertRaisesRegex(RuntimeError,'numérotés'):
            retake.assemble('Nouvelle action',duplicate,0,5.167,5.167,self.old)
    def test_runtime_uses_new_writer(self):
        code=(ROOT/'retouches_next.py').read_text('utf-8')
        self.assertIn('import retouches_llm_prompt_v70 as llm70',code)
        self.assertIn('llm70.write_prompt(',code)
        self.assertIn('h3_vram_before=',code)
        self.assertIn('h3_vram_after=',code)
        self.assertIn("h3in.get('ref_video_files')!=conditioning_video_name",code)
        self.assertIn("'latent_name':latent_name or _state_latent_name(clip)",code)
    def test_dialogue_remains_short_direct_path(self):
        code=(ROOT/'retouches_next.py').read_text('utf-8')
        self.assertIn("if performance_type=='dialogue':",code)
        self.assertIn("if row['mode']=='precise' or (row['mode']=='performance' and row.get('performance_type') in ('action','emotion')):",code)
        self.assertIn("'both' if mode=='performance' and performance_type=='dialogue'",code)
    def test_original_engines_filmmaker_insert_unmodified(self):
        old=Path('/mnt/data/v1069_new_take')
        for name in ('h3film_studio_v3.py','studio_web.py','retouches_engine.py','retouches_masked_core.py',
                'retouches_roycho_complete_v63.py','studio_retouches.py',
                'workflows/H3Studio_1920_API_CLEAN.json'):
            self.assertEqual((ROOT/name).read_bytes(),(old/name).read_bytes(),name)
    def test_no_diffsynth_install_or_qwen_fallback(self):
        launcher=(ROOT/'LANCER-RETOUCHES-V10_70.cmd').read_text('utf-8')
        self.assertNotIn('pip install',launcher)
        self.assertNotIn('DIFFSYNTH',launcher)
        text=(ROOT/'retouches_llm_prompt_v70.py').read_text('utf-8')
        self.assertIn('choose_backend(film)',text)
        self.assertIn('film.release_all_text_models_for_h3',text)
        self.assertNotIn('_llama_backend(',text)

if __name__=='__main__':unittest.main()
