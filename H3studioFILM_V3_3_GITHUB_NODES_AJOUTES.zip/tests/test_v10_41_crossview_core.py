import pathlib,sys,unittest
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_crossview_core as c

class CrossViewBuilder(unittest.TestCase):
    def obj(self):return {'LoadMoGeModel':{'input':{'required':{'model_name':[['moge_2_vitl_normal_fp16.safetensors']]}}}}
    def build(self,preview):
        with patch.object(c,'_make',side_effect=lambda obj,t,**arg:{'class_type':t,'inputs':arg}):
            return c.build(self.obj(),'source.mp4','Minimax-h3_Singularity_ref2va_Pruned_v1.3_int8.safetensors',-30,15,22,736,1280,preview_only=preview)
    def test_preview_has_no_h3_nodes(self):
        g=self.build(True)
        self.assertEqual(g['4']['class_type'],'MoGeInference')
        self.assertEqual(g['5']['class_type'],'CrossViewWarp')
        self.assertEqual(g['5']['inputs']['moge_geometry'],['4',0])
        self.assertEqual(g['51']['class_type'],'SaveVideo')
        self.assertNotIn('16',g)
    def test_full_has_two_videos_and_lora(self):
        g=self.build(False)
        self.assertEqual(g['16']['inputs']['ref_videos.ref_video_0'],['2',0])
        self.assertEqual(g['16']['inputs']['ref_videos.ref_video_1'],['5',0])
        self.assertEqual(g['14']['class_type'],'LoraLoaderModelOnly')
        self.assertEqual(g['25']['class_type'],'SaveVideo')
        self.assertNotIn('51',g)
        for n in g.values():
            for v in n['inputs'].values():
                if isinstance(v,list) and len(v)==2 and isinstance(v[0],str):
                    self.assertIn(v[0],g)
    def test_without_moge_refused_before_h3(self):
        with self.assertRaisesRegex(RuntimeError,'MoGe2'):
            c.build({'LoadMoGeModel':{'input':{'required':{'model_name':[[]]}}}},'a.mp4','h3',-30,15,22,736,1280)

if __name__=='__main__':unittest.main()
