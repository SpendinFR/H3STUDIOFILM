"""V10.1: no ComfyUI model required; verify persistence and browser contracts."""
import json, os, tempfile, threading, time, unittest
from pathlib import Path
from unittest.mock import patch
from urllib.request import urlopen

import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import studio_bridge as bridge
import studio_web as web

class PersistenceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.old=bridge.DIR
        bridge.DIR=Path(self.tmp.name)/'session'
        bridge.DIR.mkdir();(bridge.DIR/'answers').mkdir()
        self.addCleanup(lambda:setattr(bridge,'DIR',self.old))

    def test_checkpoint_save_load_complete(self):
        project=Path(self.tmp.name)/'demo'
        bridge.save_resume_state(project,{'completed_clip':2,'rendered':['a','b'],'mc_flags':[False,True]})
        checkpoint=bridge.load_resume_state(project)
        self.assertEqual(checkpoint['completed_clip'],2)
        self.assertFalse(checkpoint['completed'])
        bridge.mark_completed(project)
        self.assertTrue(bridge.load_resume_state(project)['completed'])

    def test_suspension_only_at_safe_boundary(self):
        (bridge.DIR/'pause.request').write_text('1')
        (bridge.DIR/'suspend.request').write_text('1')
        with self.assertRaises(bridge.StudioSuspend):bridge.pause_boundary()
        self.assertTrue((bridge.DIR/'suspended.json').exists())

    def test_suspend_waiting_review(self):
        web.write_json(bridge.DIR/'config.json',{'reviews':{'brief':True}})
        (bridge.DIR/'suspend.request').write_text('1')
        with self.assertRaises(bridge.StudioSuspend):
            bridge.checkpoint('brief','Brief avant Content',{'text':'Mon film'},True)

class WebContracts(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.tmp_root=Path(self.tmp.name)
        self.old_sessions=web.SESSIONS
        web.SESSIONS=self.tmp_root/'sessions';web.SESSIONS.mkdir()
        self.addCleanup(lambda:setattr(web,'SESSIONS',self.old_sessions))
        self.old=os.environ.get('COMFYUI_DIR')
        os.environ['COMFYUI_DIR']=str(self.tmp_root/'ComfyUI')
        self.addCleanup(self.restore_env)
        web.STATE.update(session=None,proc=None,log=[],last_error='',started=None)

    def restore_env(self):
        if self.old is None:os.environ.pop('COMFYUI_DIR',None)
        else:os.environ['COMFYUI_DIR']=self.old

    def test_role_models_and_brief_checkpoint_config(self):
        settings={'prompt':'Un film original','duration':'1m','mode':'studio',
                  'models':{'content':'gemma4:12b','scene':'qwen3.5:9b','plan':'27','clip':'jp'},
                  'reviews':{'brief':True,'plans':True,'raw':True}}
        with patch.object(web,'_launch_session',side_effect=lambda folder,prompt,**kwargs:{'folder':str(folder),'prompt':prompt}):
            result=web.start_film(settings)
        config=web.json_get(Path(result['folder'])/'config.json',{})
        self.assertTrue(config['reviews']['brief'])
        self.assertEqual(config['models']['plan'],'27')
        self.assertEqual(config['models']['clip'],'jp')
        self.assertEqual(config['initial_answers'][1],'1m')

    def test_reopen_same_project_with_saved_directors(self):
        project=web.output_dir()/'example'
        (project/'_studio').mkdir(parents=True)
        web.write_json(project/'_studio'/'resume_state.json',{'completed_clip':1,'completed':False})
        folder=web.SESSIONS/'original';folder.mkdir()
        web.write_json(folder/'active_project.json',{'name':'example','path':str(project)})
        config={'brief':'Mon premier film','models':{'content':'gemma4:12b','clip':'27'},
                'initial_answers':['détails','1m','style','direction'],'reviews':{'raw':True}}
        web.write_json(folder/'config.json',config)
        with patch.object(web,'_launch_session',side_effect=lambda dest,prompt,**kw:{'folder':str(dest),'prompt':prompt,'resume':kw.get('resume_project')}):
            result=web.restart_project('example')
        self.assertEqual(result['resume'],'example')
        copied=web.json_get(Path(result['folder'])/'config.json',{})
        self.assertEqual(copied['models']['clip'],'27')
        self.assertEqual(copied['brief'],'Mon premier film')

    def test_browser_exposes_four_role_controls_and_live_panel(self):
        ui=(Path(__file__).resolve().parents[1]/'studio_ui'/'index.html').read_text('utf-8')
        for tag in ('modelContent','modelScene','modelPlan','modelClip','reviewBrief',
                    'currentPrompt','currentRefs','currentClipLabel','suspendBtn','resumeProjectBtn'):
            self.assertIn(f'id="{tag}"',ui)
        self.assertIn('id="currentPrompt"',ui)

if __name__=='__main__':unittest.main()
