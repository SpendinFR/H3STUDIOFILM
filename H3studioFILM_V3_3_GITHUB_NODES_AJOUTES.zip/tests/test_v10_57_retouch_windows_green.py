"""Regression checks for segmented swap and green removal. No GPU required."""
import pathlib
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_engine as engine
import retouches_masked_core as masked

class TestRetouchV1057(unittest.TestCase):
    def _ffmpeg(self,*argv):
        cp=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',*map(str,argv)],capture_output=True,text=True,timeout=90)
        self.assertEqual(cp.returncode,0,cp.stderr)

    def test_h3_window_alignment_and_complete_coverage(self):
        for total in (5,22,39,56,73,90,107,124,141,158,175,192,209,226,243,260,277,294,311,328,345,362,379):
            intervals=engine._swap_windows(total)
            self.assertEqual(intervals[0][0],0)
            self.assertEqual(intervals[-1][1],total)
            for i,(a,b) in enumerate(intervals):
                self.assertEqual((b-a-5)%17,0)
                self.assertLessEqual(b-a,73)
                if i:self.assertEqual(intervals[i-1][1]-a,22)
        self.assertEqual(engine._swap_windows(124),[(0,73),(51,124)])
        self.assertEqual(engine._swap_windows(90),[(0,73),(51,90)])
        self.assertEqual(engine._swap_windows(22),[(0,22)])
        with self.assertRaises(ValueError):engine._swap_windows(120)

    def test_reseed_sam_on_the_same_actor(self):
        from PIL import Image
        import numpy as np
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d)
            mask=root/'mask.png';Image.fromarray(np.pad(np.full((48,48),255,dtype=np.uint8),32)).save(mask)
            with patch.object(masked,'_make',side_effect=lambda obj,t,**inp:{'class_type':t,'inputs':inp}):
                g=masked.build({},'swap_person','shot.mp4','ref.png','person','',
                   'minimax_h3_singularity_ref2va_pruned_v1.3_int8.safetensors',frames=73,width=128,height=128)
            engine._seed_segment_mask(g,mask,root,'q',1,{'ImageToMask':{}})
            self.assertNotIn('6',g)
            self.assertEqual(g['7']['inputs']['initial_mask'],['49',0])
            self.assertEqual(g['49']['inputs']['channel'],'red')
            self.assertEqual(g['9']['inputs']['mask'],['44',0])

    def test_full_5_seconds_segment_extract_and_stitch(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d)
            orig=root/'source.mp4'
            self._ffmpeg('-f','lavfi','-i','testsrc2=size=128x128:rate=24:duration=5.166666667',
              '-f','lavfi','-i','sine=frequency=440:sample_rate=32000:duration=5.16666667',
              '-map','0:v:0','-map','1:a:0','-c:v','libx264','-crf','16','-pix_fmt','yuv420p','-c:a','aac',orig)
            self.assertEqual(engine._video_metadata(orig)['frames'],124)
            parts=[]; intervals=engine._swap_windows(124)
            for i,(a,b) in enumerate(intervals):
                p=root/f'part{i}.mp4'
                engine._slice_h3_window(orig,p,a,b)
                parts.append(p)
                self.assertEqual(engine._video_metadata(p)['frames'],73)
            stitched=root/'stitched.mp4'
            engine._stitch_h3_windows(parts,intervals,stitched)
            self.assertEqual(engine._video_metadata(stitched)['frames'],124)
            original_five=root/'orig5.mp4'
            self._ffmpeg('-i',orig,'-frames:v','120','-an','-c:v','libx264',original_five)
            engine._restore_source_length(stitched,original_five,{'mode':'swap_person'})
            self.assertEqual(engine._video_metadata(stitched)['frames'],120)

    def test_multisegment_longer_shot_stitch(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);source=root/'long.mp4'
            self._ffmpeg('-f','lavfi','-i','testsrc2=size=128x128:rate=24:duration=5.875',
                         '-f','lavfi','-i','sine=frequency=600:sample_rate=32000:duration=5.875',
                         '-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac',source)
            self.assertEqual(engine._video_metadata(source)['frames'],141)
            segments=engine._swap_windows(141)
            self.assertEqual(segments,[(0,73),(51,124),(102,141)])
            parts=[]
            for i,(start,end) in enumerate(segments):
                segment=root/f's{i}.mp4'
                engine._slice_h3_window(source,segment,start,end)
                parts.append(segment)
            out=root/'merged.mp4'
            engine._stitch_h3_windows(parts,segments,out)
            meta=engine._video_metadata(out)
            self.assertEqual(meta['frames'],141)
            self.assertAlmostEqual(meta['fps'],24.0,places=2)

    def test_green_conditioning_yuv444_and_targeted_cleanup(self):
        import cv2
        import numpy as np
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d);src=root/'src.mp4'
            self._ffmpeg('-f','lavfi','-i','color=c=black:s=128x128:r=24:d=0.91666667',
                        '-frames:v','22','-c:v','libx264','-pix_fmt','yuv420p',src)
            mask=np.zeros((128,128),dtype=np.uint8);mask[40:88,40:88]=255
            paths=[]
            for i in range(22):
                f=root/f'{i:03d}.png';cv2.imwrite(str(f),mask);paths.append(f)
            green=root/'green.mp4'
            engine._build_green_mask_video(src,paths,green)
            self.assertEqual(engine._video_metadata(green)['frames'],22)
            p=subprocess.run(['ffprobe','-v','error','-show_entries','stream=pix_fmt','-of','default=nk=1:nw=1',str(green)],capture_output=True,text=True)
            self.assertIn('yuv444p',p.stdout)
            # Residue newly green on the mask border is removed; normal green
            # content outside the matte ring is not touched.
            render=root/'render.mp4'
            frames=[]
            for i in range(22):
                frame=np.zeros((128,128,3),dtype=np.uint8)
                frame[41:45,41:45]=(0,220,0) # green contamination near subject outline
                frame[0:12,0:12]=(0,180,0) # a green object elsewhere must be preserved
                frames.append(frame)
            w=cv2.VideoWriter(str(render),cv2.VideoWriter_fourcc(*'mp4v'),24,(128,128))
            self.assertTrue(w.isOpened())
            for fr in frames:w.write(fr)
            w.release()
            self.assertTrue(engine._remove_green_spill(src,render,paths))
            out=cv2.VideoCapture(str(render));ok,first=out.read();out.release()
            self.assertTrue(ok)
            self.assertLess(int(first[42,42,1]),120)
            self.assertGreater(int(first[5,5,1]),100)
            self.assertFalse(engine._remove_green_spill(src,render,paths))

if __name__=='__main__':unittest.main()
