import pathlib,sys,unittest
from unittest.mock import patch,Mock
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_llm_prompt_v66 as prompt

class FullShotRetakeTests(unittest.TestCase):
    def test_full_original_timings_and_explicit_rejoin(self):
        s=prompt.build_request('performance','action','Elle lève sa main droite', 'A close-up', 0, .962, 5.167)
        for t in ('0.000s–0.962s','0.962s–5.167s','transition back','REJOIN','REQUESTED ACTION'):
            self.assertIn(t,s)
        self.assertIn('0.154s',s)
    def test_preserves_user_window_when_assembled(self):
        txt=prompt.assemble('Elle lève la main droite','[Shot 1] At first the actor remains as filmed. She gently raises her right hand and returns to the original pose before the end of the window. The original shot then continues.',.121,1.217,5.167)
        self.assertIn('0.121s–1.217s',txt)
        self.assertIn('BEFORE 1.217s',txt)
        self.assertIn('1.217s–5.167s',txt)
    def test_ollama_running_no_process_launched(self):
        f=Mock();f.rt.OLLAMA_URL='http://127.0.0.1:11434';f.rt.http_json.return_value={'models':[]}
        with patch.object(prompt.subprocess,'Popen') as pop:
            self.assertEqual(prompt.ensure_ollama_running(f),{'models':[]})
            pop.assert_not_called()
    def test_ollama_offline_starts_like_filmmaker(self):
        f=Mock();f.rt.OLLAMA_URL='http://127.0.0.1:11434';f.rt.http_json.side_effect=[ConnectionError('refused'),{'models':[]}]
        child=Mock();child.poll.return_value=None
        with patch.object(prompt.shutil,'which',return_value='/fake/ollama.exe'),patch.object(prompt.subprocess,'Popen',return_value=child) as pop:
            out=prompt.ensure_ollama_running(f,timeout=2)
        self.assertEqual(out,{'models':[]})
        self.assertEqual(pop.call_args.args[0],['/fake/ollama.exe','serve'])
    def test_ollama_not_found_fails_without_download(self):
        f=Mock();f.rt.OLLAMA_URL='http://127.0.0.1:11434';f.rt.http_json.side_effect=ConnectionError('refused')
        with patch.object(prompt.shutil,'which',return_value=None),patch.object(prompt.os,'name','posix'),patch.object(prompt.subprocess,'Popen') as pop:
            with self.assertRaisesRegex(RuntimeError,'introuvable'):
                prompt.ensure_ollama_running(f)
            pop.assert_not_called()
    def test_studio_modules_bitwise_unchanged(self):
        previous=pathlib.Path('/mnt/data/v1067_gemma26_only')
        for name in ['h3film_studio_v3.py','studio_web.py','retouches_engine.py','retouches_masked_core.py','retouches_roycho_complete_v63.py','custom_nodes/H3StudioRetouchExtras/__init__.py']:
            if previous.is_file():
                self.assertEqual((ROOT/name).read_bytes(),(previous/name).read_bytes())

if __name__=='__main__':unittest.main()
