"""Regression checks for V10.7 last-mile safeguards (CPU only)."""
import sys, unittest, tempfile
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import h3film_studio_v3 as film

class V107Final(unittest.TestCase):
    def test_owned_llama_process_successful_stop(self):
        class Proc:
            def __init__(self):self.stopped=False
            def poll(self):return 0 if self.stopped else None
            def terminate(self):self.stopped=True
            def wait(self,timeout):return 0
        old,oldkey=film._LLAMA_PROC,film._LLAMA_ACTIVE_KEY
        proc=Proc();film._LLAMA_PROC=proc;film._LLAMA_ACTIVE_KEY='qwen38'
        try:
            film.stop_llama_server('test')
            self.assertTrue(proc.stopped)
            self.assertIsNone(film._LLAMA_PROC)
            self.assertEqual(film._LLAMA_ACTIVE_KEY,'')
        finally:film._LLAMA_PROC=old;film._LLAMA_ACTIVE_KEY=oldkey
    def test_owned_llama_process_cannot_stop_blocks_h3(self):
        class Proc:
            def poll(self):return None
            def terminate(self):raise RuntimeError('refuses exit')
            def kill(self):raise RuntimeError('cannot kill')
        old,oldkey=film._LLAMA_PROC,film._LLAMA_ACTIVE_KEY
        film._LLAMA_PROC=Proc();film._LLAMA_ACTIVE_KEY='qwen38'
        try:
            with self.assertRaisesRegex(RuntimeError,'RAW H3 non lancé'):
                film.stop_llama_server('before H3')
            self.assertIsNotNone(film._LLAMA_PROC)
        finally:film._LLAMA_PROC=old;film._LLAMA_ACTIVE_KEY=oldkey
    def test_all_eight_images_and_eight_audio_valid(self):
        with tempfile.TemporaryDirectory() as td:
            comfy=Path(td);inp=comfy/'input';inp.mkdir()
            specs=[]
            for i in range(8):
                for media,ext in (('image','png'),('audio','wav')):
                    path=inp/f'{media}{i}.{ext}';path.write_bytes(b'test')
                    specs.append({'media':media,'path':str(path),'name':f'{media}{i}'})
            text,imgs,aud=film.apply_clip_studio_edits({'edits':{'text':'My new prompt','refs':specs}},'original',[],[],comfy)
            self.assertEqual((len(imgs),len(aud)),(8,8))
            self.assertIn('<Picture 8>',text)
            self.assertIn('<Audio 8>',text)
    def test_latest_prompt_h3_input_used_for_director_roundtrip(self):
        s=(Path(__file__).resolve().parents[1]/'h3film_studio_v3.py').read_text(encoding='utf-8')
        # The latest approved text still wins, but only its creative portion is sent
        # back to the Director. Protected blocks are owned by FilmMaker and reattached.
        self.assertIn('DERNIÈRE PARTIE CRÉATIVE H3 ACTUELLE',s)
        self.assertIn('revision_creative_context(h3_prompt)',s)
        self.assertIn('revision_creative_context(rejected_h3_prompt)',s)
        self.assertIn('rejected_h3_prompt=h3_prompt',s)
if __name__ == '__main__':unittest.main()
