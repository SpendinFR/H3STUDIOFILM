"""No model GPU required. V10.74 tests genuine semantics, timeline, graph invariants."""
import unittest,sys,copy,hashlib
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_llm_prompt_v74 as llm
import retouches_next as eng

SOURCE='''[Shot 1] 0.000–2.500 Elle rit et regarde l'écran.
[Shot 2] 2.500–5.167 Elle pointe le doigt vers l'écran (hors champ) et parle, sourire complice.'''
MOD='''EDIT_DECISION: MODIFY_EXISTING
SCENE_CONTEXT: La streameuse est dans son studio de streaming, avec ring-light.
NEW_TAKE:
[Shot 1] 0.000–2.500 Elle rit et regarde l'écran.
[Shot 2] 2.500–5.167 Elle parle puis pointe vers l'écran hors champ. Pendant 3.651–5.167s : elle pointe de l'index de la main gauche vers le même écran hors champ et maintient son regard sur l'écran, avec le mouvement d'origine. Elle garde son dialogue intact.'''
BAD_MOD='''EDIT_DECISION: MODIFY_EXISTING
SCENE_CONTEXT: La streameuse est dans son studio de streaming, avec ring-light.
NEW_TAKE:
[Shot 1] 0.000–2.500 Elle rit et regarde l'écran.
[Shot 2] 2.500–5.167 Elle pointe de la main gauche sans préciser le moment et parle.'''
EMOTION='''EDIT_DECISION: EMOTION
SCENE_CONTEXT: Streameuse sur un plateau de streaming.
NEW_TAKE:
[Shot 1] 0.000–2.500 Elle regarde l'écran. Pendant 0.000–1.574s : son sourire s'efface, sourcils rapprochés, respiration tremblante, regard triste visible avant de tourner la tête. Puis reprend la scène.
[Shot 2] 2.500–5.167 Elle prononce sa réplique originale et désigne l'écran.'''
ADD='''EDIT_DECISION: ADD_NEW
SCENE_CONTEXT: Streameuse sous ring-light.
NEW_TAKE:
[Shot 1] 0.000–1.446 Elle rit et lève vivement la main avant de la redescendre.
[Shot 2] 1.446–2.500 Elle regarde la caméra.
[Shot 3] 2.500–5.167 Elle désigne l'écran en parlant.'''

class TestV74(unittest.TestCase):
    def test_inferred_modification_is_not_forced_addition(self):
        self.assertEqual(llm.requested_operation('le doigt de la main gauche'),'infer')
        self.assertEqual(llm.requested_operation('elle pointe avec la main gauche'),'infer')
        self.assertEqual(llm.requested_operation('ajoute une main levée'),'add')
        self.assertEqual(llm.requested_operation('remplace son geste'),'replace')
        instruction=llm.build_request('performance','action','le doigt de la main gauche',SOURCE,3.651,5.167,5.167)
        self.assertIn('MODIFY_EXISTING',instruction)
        self.assertIn('cible spatiale',instruction)
        self.assertIn(SOURCE,instruction)
    def test_same_existing_shot_allowed_with_exact_inline_cue(self):
        out=llm.assemble('le doigt de la main gauche',MOD,3.651,5.167,5.167,SOURCE,full_h3_window=True)
        self.assertEqual(out.count('[Shot '),2)
        self.assertIn('Pendant 3.651–5.167s',out)
        self.assertIn('requested edit interval 0.000–5.167s',out)
        self.assertNotIn('EDIT_DECISION',out)
        self.assertNotIn('BEGIN ORIGINAL',out)
        self.assertIn('vers le même écran',out)
        self.assertNotIn(SOURCE,out)
    def test_same_shot_requires_explicit_time_cue(self):
        with self.assertRaisesRegex(RuntimeError,'Pendant'):
            llm.assemble('main gauche',BAD_MOD,3.651,5.167,5.167,SOURCE,full_h3_window=True)
    def test_new_action_still_requires_new_beat_boundary(self):
        good=llm.assemble('ajoute une main levée',ADD,0,1.446,5.167,SOURCE,full_h3_window=True)
        self.assertIn('[Shot 3]',good)
        bad=MOD.replace('MODIFY_EXISTING','ADD_NEW')
        with self.assertRaisesRegex(RuntimeError,'ADD_NEW'):
            llm.assemble('ajoute une main levée',bad,3.651,5.167,5.167,SOURCE,full_h3_window=True)
    def test_emotion_may_reinterpret_joy_with_inline_time(self):
        out=llm.assemble('elle est triste',EMOTION,0,1.574,5.167,SOURCE,full_h3_window=True)
        self.assertIn('son sourire s\'efface',out)
        self.assertEqual(out.count('[Shot '),2)
        system=llm.SYSTEM
        self.assertIn('Old expressions that contradict',system)
    def test_old_h3_graph_still_full_for_performance(self):
        self.assertTrue(eng._full_clip_h3_for_performance('performance','action'))
        self.assertTrue(eng._full_clip_h3_for_performance('performance','emotion'))
        self.assertFalse(eng._full_clip_h3_for_performance('performance','dialogue'))
        self.assertFalse(eng._full_clip_h3_for_performance('precise','action'))
    def test_protect_historical_engines(self):
        original=Path('/mnt/data/work_v1073')
        for name in ('h3film_studio_v3.py','studio_web.py','retouches_engine.py','retouches_masked_core.py','retouches_roycho_complete_v63.py', 'studio_retouches.py','workflows/H3Studio_1920_API_CLEAN.json', 'retouches_llm_prompt_v73.py'):
            self.assertEqual((ROOT/name).read_bytes(),(original/name).read_bytes(),name)
        self.assertIn('llm74.write_prompt(', (ROOT/'retouches_next.py').read_text('utf-8'))
        cmd=(ROOT/'LANCER-RETOUCHES-V10_74.cmd').read_text('utf-8')
        self.assertIn('studio_web.py',cmd)
        self.assertNotIn('pip install',cmd)

if __name__=='__main__':unittest.main()
