"""V10.10: reference-authority preview through the real FilmMaker builder, no H3 or GPU."""
import json, threading, tempfile, urllib.request, hashlib
from pathlib import Path
from http.server import ThreadingHTTPServer
from unittest.mock import patch
import studio_web as web
import h3film_studio_v3 as film


def fixture(comfy):
    (comfy/'input').mkdir(parents=True,exist_ok=True)
    photo=comfy/'input'/'nikita.png'
    photo.write_bytes(b'png test')
    refs=[
        {'kind':'character','role':'canonical_identity','subject_name':'Matt','subject_key':'matt','picture_order':1,'annotated':'Matt.png [input]','strength':1.0},
        {'kind':'character','role':'film_appearance','subject_name':'Matt','subject_key':'matt','picture_order':2,'annotated':'MattFilm.png [input]','strength':1.0},
        {'kind':'decor','role':'film_environment','subject_name':'Terrasse','subject_key':'terrasse','picture_order':3,'annotated':'Terrasse.png [input]','strength':1.0},
    ]
    voice=[{'kind':'voice','subject_name':'Matt','subject_key':'matt','annotated':'Matt.wav [input]','strength':1.0}]
    original=film.reference_prompt_prefix(refs,voice)+'\n\n**Director :**\nLook Arri Alexa\n\n**Spatial continuity — soft observed facts:**\nMatt stands at railing.\n\n**description_multimodale_intégrée :**\nNikita steps onto the terrace.'
    specs=[{'media':'image','index':i,'name':r['subject_name'],'visual_type':'visual'} for i,r in enumerate(refs)]
    specs.append({'media':'audio','index':0,'name':'Matt'})
    return refs,voice,original,specs,photo


def test_native_builder_add_remove_and_role_consistency(tmp_path):
    refs,voices,original,specs,photo=fixture(tmp_path)
    original_prefix=film.reference_prompt_prefix(refs,voices)
    body=original[len(original_prefix):].strip()
    new=specs+[{'media':'image','path':str(photo),'name':'Nikita','visual_type':'person'}]
    prompt,images,voices_out=film.apply_clip_studio_edits({'edits':{'text':original,'refs':new}},original,refs,voices,tmp_path)
    assert '<Subject 3> is Nikita. <Picture 4> defines the canonical stable identity' in prompt
    assert 'preserve face, distinctive physical traits, hair identity and body proportions.' in prompt
    assert prompt.count('REFERENCE AUTHORITY — these Picture inputs')==1
    assert prompt.count('VOICE REFERENCE AUTHORITY —')==1
    assert prompt.count('**Director :**')==1
    assert prompt.count('**Spatial continuity')==1
    assert prompt.endswith('Nikita steps onto the terrace.')
    assert images[-1]['kind']=='character' and images[-1]['role']=='canonical_identity'
    assert images[0]['role']=='canonical_identity' and images[1]['role']=='film_appearance'
    # Removing Matt's film appearance also removes its unique Picture reference line.
    stripped=[new[0],new[2],new[3],new[4]]
    p2,im2,_=film.apply_clip_studio_edits({'edits':{'text':original,'refs':stripped}},original,refs,voices,tmp_path)
    assert '<Picture 2> is the latest rendered-film' not in p2
    assert '<Picture 3>' in p2 and 'Nikita' in p2
    assert len(im2)==3
    # Different role must use the native *object* or *decor* rule, not a guessed JS line.
    for role,expected in [('object','continuing_object'),('decor','established environment'),('visual','recurring visual subject')]:
        new[-1]['visual_type']=role
        text,_,_=film.apply_clip_studio_edits({'edits':{'text':original,'refs':new}},original,refs,voices,tmp_path)
        assert expected in text
    # Canonical refs cannot be silently turned into continuing objects.
    new[0]['visual_type']='object'
    p3,im3,_=film.apply_clip_studio_edits({'edits':{'text':original,'refs':new}},original,refs,voices,tmp_path)
    assert im3[0]['kind']=='character' and 'canonical_identity' in p3


def test_http_reference_preview_equals_submitted_prompt(tmp_path):
    comfy=tmp_path/'comfy'
    refs,voices,original,spec,photo=fixture(comfy)
    session=tmp_path/'sessions'/'project';session.mkdir(parents=True)
    web.write_json(session/'review.json',{'id':'r-1','kind':'clips','payload':{'text':original,'refs':refs,'audio_refs':voices}})
    new=spec+[{'media':'image','path':str(photo),'name':'Nikita','visual_type':'person'}]
    with patch.object(web,'active_folder',return_value=session),patch.object(web,'comfy_path',return_value=comfy):
        server=ThreadingHTTPServer(('127.0.0.1',0),web.Handler)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        base=f'http://127.0.0.1:{server.server_port}'
        try:
            # First preview gets the FULL initial prompt, subsequent ones get creative body.
            def post(body):
                req=urllib.request.Request(base+'/api/reference-preview',method='POST',data=json.dumps(body).encode('utf-8'),headers={'Content-Type':'application/json'})
                with urllib.request.urlopen(req,timeout=8) as response:return json.load(response)
            first=post({'id':'r-1','body':original,'refs':spec})
            assert first['text']==original
            assert first['prefix']==film.reference_prompt_prefix(refs,voices)
            creative=original[len(first['prefix']):].lstrip()+'\n\nTest creative user edit.'
            preview=post({'id':'r-1','body':creative,'refs':new})
            assert 'Nikita' in preview['text']
            assert 'Test creative user edit' in preview['text']
            assert preview['text'].count('REFERENCE AUTHORITY — these Picture inputs')==1
            # What the browser submits is its BASE prefix + the creative content;
            # the existing renderer replaces the base prefix with the new native authority.
            submitted={'text':first['original_prefix']+'\n\n'+creative,'refs':new}
            committed,imgs,auds=film.apply_clip_studio_edits({'edits':submitted},original,refs,voices,comfy)
            assert preview['text']==committed
            assert imgs[-1]['subject_name']=='Nikita'
            assert preview['images']==len(imgs)
            # no artifact from new renderer module imported; pipeline files stay stable
            with urllib.request.urlopen(base+'/studio-v10-10.css',timeout=5) as res:
                assert res.status==200 and b'.editableClip' in res.read()
        finally:
            server.shutdown();server.server_close();thread.join(timeout=4)


def test_no_changes_to_h3_comfy_and_voice_files():
    root=Path(__file__).resolve().parents[1]
    original_zip=Path('/mnt/data/H3Film_STUDIO_V10_9_PROMPT_AUTHORITY_TABS_JOURNAL_FIX.zip')
    if not original_zip.is_file():return # Users run tests on Windows with no archive.
    import zipfile
    with zipfile.ZipFile(original_zip) as z:
        for file in ['h3_runtime_simple.py','custom_nodes/H3RawLatentPersist/__init__.py','workflows/H3Studio_1920_API_CLEAN.json','prompts/CLIP_DIRECTOR.txt']:
            assert hashlib.sha256(z.read(file)).digest()==hashlib.sha256((root/file).read_bytes()).digest(),file
