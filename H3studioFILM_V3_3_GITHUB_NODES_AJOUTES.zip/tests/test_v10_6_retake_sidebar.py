"""V10.6: only CPU and HTTP, never launch ComfyUI/LLM."""
import json, sys, tempfile, threading, unittest, urllib.request, time
from pathlib import Path
from unittest.mock import patch
from http.server import ThreadingHTTPServer
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import studio_web as web

class RetakePersistence(unittest.TestCase):
    def test_api_refusal_persists_original_prompt_then_decision(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);project=root/'output'/'H3FilmSimple'/'movie';project.mkdir(parents=True)
            gate=project/'_studio'/'gates'/'clip_0002'
            gate.with_suffix('.waiting.json').parent.mkdir(parents=True)
            gate.with_suffix('.waiting.json').write_text('{}',encoding='utf-8')
            prev=project/'prompts'/'clip_0002.txt';prev.parent.mkdir();prev.write_text('OLD EXACT H3',encoding='utf-8')
            sess=root/'session';sess.mkdir();web.write_json(sess/'active_project.json',{'name':'movie','path':str(project)})
            class Active:
                def poll(self):return None
            with web.LOCK:
                previous=dict(web.STATE);web.STATE.update(session=sess,proc=Active())
            server=ThreadingHTTPServer(('127.0.0.1',0),web.Handler)
            worker=threading.Thread(target=server.serve_forever,daemon=True)
            with patch.object(web,'load_project',return_value=project):
                try:
                    worker.start()
                    request=urllib.request.Request(f'http://127.0.0.1:{server.server_port}/api/raw-decision',
                        method='POST',data=json.dumps({'clip':2,'action':'redo','feedback':'camera right'}).encode(),
                        headers={'Content-Type':'application/json'})
                    with urllib.request.urlopen(request,timeout=5) as response:
                        self.assertTrue(json.load(response)['ok'])
                    data=web.json_get(gate.with_suffix('.retake.json'),{})
                    self.assertEqual(data['status'],'requested')
                    self.assertEqual(data['feedback'],'camera right')
                    self.assertEqual(data['previous_prompt'],'OLD EXACT H3')
                    self.assertEqual(web.json_get(gate.with_suffix('.decision.json'),{})['action'],'redo')
                finally:
                    server.shutdown();server.server_close();worker.join(2)
                    with web.LOCK:web.STATE.clear();web.STATE.update(previous)
    def test_api_status_hides_rejected_raw_gate_and_announces_clip_director(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);project=root/'output'/'H3FilmSimple'/'movie';project.mkdir(parents=True)
            gate=project/'_studio'/'gates'/'clip_0002'
            gate.parent.mkdir(parents=True)
            web.write_json(gate.with_suffix('.waiting.json'),{'clip':2})
            web.write_json(gate.with_suffix('.retake.json'),{'clip':2,'status':'requested',
                'feedback':'new direction','previous_prompt':'old','requested_at':time.time()})
            session=root/'session';session.mkdir()
            web.write_json(session/'active_project.json',{'name':'movie','path':str(project)})
            class Running:
                def poll(self):return None
            with web.LOCK:
                previous=dict(web.STATE);web.STATE.update(session=session,proc=Running(),started=time.time())
            server=ThreadingHTTPServer(('127.0.0.1',0),web.Handler)
            worker=threading.Thread(target=server.serve_forever,daemon=True)
            with patch.object(web,'load_project',return_value=project), \
                 patch.object(web,'older_running_productions',return_value=[]), \
                 patch.object(web,'recent_projects',return_value=[]):
                try:
                    worker.start()
                    with urllib.request.urlopen(f'http://127.0.0.1:{server.server_port}/api/status',timeout=5) as response:
                        data=json.load(response)
                    self.assertEqual(data['raw_gates'],[])
                    self.assertEqual(data['stage']['stage'],'retake_queued')
                    self.assertIn('Clip Director',data['stage']['title'])
                finally:
                    server.shutdown();server.server_close();worker.join(2)
                    with web.LOCK:web.STATE.clear();web.STATE.update(previous)

    def test_resume_migrates_legacy_redo_and_clears_stale_gate(self):
        with tempfile.TemporaryDirectory() as td:
            project=Path(td);stem=project/'_studio'/'gates'/'clip_0002'
            stem.parent.mkdir(parents=True)
            stem.with_suffix('.waiting.json').write_text('{}')
            stem.with_suffix('.redo.json').write_text('{"feedback":"hold on subject"}',encoding='utf-8')
            prev=project/'prompts'/'clip_0002.txt';prev.parent.mkdir();prev.write_text('old prompt')
            recovered=web.recover_abandoned_raw_decision(project,2)
            self.assertEqual(recovered['status'],'requested')
            self.assertEqual(recovered['previous_prompt'],'old prompt')
            self.assertFalse(stem.with_suffix('.waiting.json').exists())
            self.assertFalse(stem.with_suffix('.redo.json').exists())
            self.assertEqual(web.recover_abandoned_raw_decision(project,2)['feedback'],'hold on subject')
    def test_retake_approved_survives_resume_recovery(self):
        with tempfile.TemporaryDirectory() as td:
            project=Path(td);stem=project/'_studio'/'gates'/'clip_0002';stem.parent.mkdir(parents=True)
            web.write_json(stem.with_suffix('.retake.json'),{'status':'approved','h3_prompt':'new correct prompt'})
            self.assertEqual(web.recover_abandoned_raw_decision(project,2)['h3_prompt'],'new correct prompt')
    def test_static_pipeline_preserves_rejected_source_and_no_silent_replay(self):
        source=(Path(__file__).resolve().parents[1]/'h3film_studio_v3.py').read_text('utf-8')
        self.assertIn("incoming_state.get('status') in ('requested','approved')",source)
        self.assertIn('rejected_h3_prompt=h3_prompt',source)
        self.assertIn("if retake.get('status')=='requested':",source)
        self.assertIn("force=True",source)
        self.assertIn("ancien prompt NON réutilisé",source)
        self.assertIn('retake_file.unlink(missing_ok=True)',source)

if __name__=='__main__': unittest.main()
