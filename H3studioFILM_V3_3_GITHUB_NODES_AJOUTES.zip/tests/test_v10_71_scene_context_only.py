"""V10.71: prompt-only A/B. No GPU, internet or installed ComfyUI required."""
from pathlib import Path
import sys, unittest, json
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_llm_prompt_v71 as writer

ORIGINAL='''REFERENCE AUTHORITY — <Subject 1> is La streameuse. <Picture 1> defines face.
**World ambience — secondary context (not a Picture reference):** Un setup de streaming personnel dans une chambre aux néons bleus et des figurines.
**description_multimodale_intégrée :** Streamer amusée.
**[Shot 1] 0:00–2.5** Elle regarde l'écran, rit et tourne la tête.
**CUT.**
**[Shot 2] 2.5–5.0** Elle pointe le doigt et dit: <d>[French] Vous avez vu ?!</d>.
**soundscape_global :** Micro, clic de souris et silence intérieur.
**look_caméra_et_lumière :** Gros plan avec néons bleus.
'''
NEW='''[Shot 1] 0:00–1.249 La streameuse regarde l'écran et rit EN MÊME TEMPS qu'elle lève puis abaisse sa main droite avant de tourner la tête.
[Shot 2] 1.249–2.500 Le rire continue, elle regarde le spectateur sans couper la prise.
[Shot 3] 2.500–5.167 Elle pointe le doigt et dit: <d>[French] Vous avez vu ?!</d>.'''
OUTPUT='''SCENE_CONTEXT: Streameuse en gros plan dans son setup, néons bleus, micro et figurines, éclairage de ring-light.
NEW_TAKE:
'''+NEW

class Tests(unittest.TestCase):
    def test_sends_only_scene_context_and_new_shots(self):
        prompt=writer.assemble('ajoute une levée de main',OUTPUT,0.,1.249,5.167,ORIGINAL)
        self.assertIn('<Video 1>',prompt)
        self.assertIn('SCENE CONTEXT',prompt)
        self.assertIn('NEW TAKE',prompt)
        self.assertIn('ring-light',prompt)
        self.assertIn(NEW,prompt)
        self.assertNotIn('REFERENCE AUTHORITY',prompt)
        self.assertNotIn('Elle pointe le doigt et dit: <d>[French] Vous avez vu ?!</d>.\n**soundscape_global',prompt)
        self.assertEqual(prompt.count('[Shot 1]'),1)
        self.assertEqual(prompt.count('[Shot 2]'),1)
        self.assertEqual(prompt.count('[Shot 3]'),1)
        self.assertNotIn('----- BEGIN ORIGINAL VIDEO PROMPT -----',prompt)
    def test_legacy_plain_shot_output_falls_back_to_environment_only(self):
        p=writer.assemble('ajoute la main',NEW,0.,5.167,5.167,ORIGINAL)
        self.assertIn('Un setup de streaming personnel',p)
        self.assertIn('Gros plan avec néons bleus',p)
        self.assertNotIn('Elle regarde l\'écran, rit et tourne la tête.\n',p)
        self.assertEqual(p.count('[Shot 1]'),1)
    def test_validation_and_add_semantics_preserved(self):
        self.assertEqual(writer.requested_operation('Ajouter une action'), 'add')
        self.assertEqual(writer.requested_operation('Remplace le sourire'), 'replace')
        bad='SCENE_CONTEXT: Salle lumineuse.\nNEW_TAKE:\n[Shot 1] '+('quelque chose '*20)+'\n[Shot 1] '+('autre chose '*20)
        with self.assertRaisesRegex(RuntimeError,'shots non consécutifs'):
            writer.assemble('ajoute',bad,0,5.167,5.167,ORIGINAL)
    def test_h3_graph_and_params_not_changed_except_readonly_diagnostic(self):
        old=Path('/mnt/data/v1070_work')
        now=(ROOT/'retouches_next.py').read_text('utf-8')
        previous=(old/'retouches_next.py').read_text('utf-8')
        self.assertIn('retouches_llm_prompt_v71',now)
        self.assertIn('mask_diagnostic_part',now)
        self.assertIn("'krea_mask_used':False",now)
        self.assertIn("graph['902']={'class_type':'H3RetouchMaskV58'",now)
        self.assertIn("if row['mode']=='insert':",now)
        self.assertIn('denoise=0.28',now)
        self.assertIn("'latent_image']=['906',0] if mode=='insert' else ['902',0]",now)
        # Apart from the new read-only logging, metadata and writer routing the graph is unmodified.
        self.assertEqual((ROOT/'retouches_roycho_complete_v63.py').read_bytes(), (old/'retouches_roycho_complete_v63.py').read_bytes())
        self.assertEqual((ROOT/'workflows/H3Studio_1920_API_CLEAN.json').read_bytes(),(old/'workflows/H3Studio_1920_API_CLEAN.json').read_bytes())
        self.assertEqual((ROOT/'retouches_engine.py').read_bytes(),(old/'retouches_engine.py').read_bytes())
        self.assertEqual((ROOT/'h3film_studio_v3.py').read_bytes(),(old/'h3film_studio_v3.py').read_bytes())
    def test_no_install(self):
        cmd=(ROOT/'LANCER-RETOUCHES-V10_71.cmd').read_text('utf-8')
        self.assertNotIn('pip install',cmd)
        self.assertNotIn('INSTALLER-DIFFSYNTH',cmd.upper())
        self.assertIn('studio_web.py',cmd)

if __name__=='__main__':unittest.main()
