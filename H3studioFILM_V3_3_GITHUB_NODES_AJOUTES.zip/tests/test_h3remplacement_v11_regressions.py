"""Regression tests for specific user-reported failures; zero claim about GPU quality."""
import pathlib, sys, tempfile, unittest
from unittest.mock import patch
import numpy as np
import cv2
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_engine as eng
import retouches_pixel_tracker as pix
import retouches_clean_plate as plate
import retouches_masked_core as masked

class V11ReportedBugs(unittest.TestCase):
    def test_real_opencv_connected_components_returns_labels_not_number(self):
        # Exercises GrabCut's component-label branch (the real user crash).
        img=np.full((130,190,3),75,dtype=np.uint8)
        img[32:85,60:126]=[25,110,220]
        roi=(55,27,131,90)
        original=cv2.connectedComponentsWithStats
        calls=[]
        def record(*args,**kwargs):
            result=original(*args,**kwargs)
            calls.append((isinstance(result[0],int),result[1].shape))
            return result
        with patch.object(cv2,'connectedComponentsWithStats',side_effect=record):
            mask=pix._initial_mask(img,roi)
        self.assertTrue(calls,'GrabCut did not reach the reported code path')
        self.assertEqual(calls[0][0],True)
        self.assertEqual(mask.shape,img.shape[:2]);self.assertGreater(mask[58,90],0)

    def test_krea_link_allows_removal_object_and_generated_text_only_replacement(self):
        with tempfile.TemporaryDirectory() as folder:
            root=pathlib.Path(folder)
            input_path=root/'input';input_path.mkdir()
            for mode in ('remove_person','remove_element','replace_element'):
                job_id='a'*32
                file=input_path/f'retouches_{job_id}_krea_clean_plate.png'
                file.write_bytes(b'PNG')
                with patch.object(eng,'job',return_value={'mode':mode,'clean_plate_ready':True}):
                    self.assertEqual(eng.clean_plate_result(job_id,root),file)
            with patch.object(eng,'job',return_value={'mode':'swap_person','clean_plate_ready':True}):
                self.assertIsNone(eng.clean_plate_result('a'*32,root))

    def test_text_and_photo_prompt_routes_are_distinct(self):
        a=eng.element_prompt('replace_element','chair','a ceramic lamp',photo_reference=False)
        b=eng.element_prompt('replace_element','chair','a ceramic lamp',photo_reference=True)
        self.assertIn('a ceramic lamp',a)
        self.assertIn('automatically generated first-frame',a)
        self.assertNotIn('automatically generated first-frame',b)
        self.assertIn('<Picture 1>',b)

    def test_krea_masked_reference_generates_requested_object_not_remove(self):
        pseudo_info={name:{} for name in plate.REQUIRED_NODES}
        def fake_make(info,k,**args):return {'class_type':k,'inputs':args}
        with patch.object(masked,'_make',side_effect=fake_make):
            g=plate.graph(pseudo_info,'original.png','mask.png','chair','a'*32,replacement_prompt='a new chrome lamp')
            old=plate.graph(pseudo_info,'original.png','mask.png','woman','a'*32)
        self.assertIn('a new chrome lamp',g['6']['inputs']['text'])
        self.assertIn('REPLACE the selected chair',g['6']['inputs']['text'])
        self.assertIn('completely absent',old['6']['inputs']['text'])

    def test_missing_photo_permitted_for_precheck_but_still_required_for_old_swap(self):
        with patch.object(masked,'_make',side_effect=lambda _info,t,**kwargs:{'class_type':t,'inputs':kwargs}):
            graph=masked.build({},'swap_person','source.mp4',None,'unknown object','lamp',
                    'h3_ref2va.safetensors',frames=22,width=128,height=96,
                    allow_missing_reference=True)
            self.assertNotIn('32',graph)
            self.assertNotIn('ref_images.ref_image_0',graph['33']['inputs'])
            with self.assertRaisesRegex(ValueError,'Image de nouvelle apparence'):
                masked.build({},'swap_person','source.mp4',None,'person','',
                    'h3_ref2va.safetensors',frames=22,width=128,height=96)

    def test_real_job_accepts_text_without_photo_and_keeps_actor_swap_unchanged(self):
        import threading
        p={'mode':'replace_element','source':{'type':'upload','id':'a'*32},
           'target':'microphone','instructions':'replace with a floating bronze orb',
           'region':[.1,.1,.2,.2]}
        with patch.object(eng,'_write_job'), patch.object(threading.Thread,'start'):
            before=set(eng.RUNNING)
            try:
                queued=eng.start(p,p['source'],lambda x:None,lambda:None,None)
                self.assertEqual(queued['status'],'queued')
                with self.assertRaisesRegex(ValueError,'image de référence'):
                    eng.start({**p,'mode':'swap_person'},p['source'],lambda x:None,lambda:None,None)
            finally:
                eng.RUNNING.difference_update(eng.RUNNING-before)

    def test_original_launch_port_and_new_mode_labels(self):
        launcher=(ROOT/'LANCER-RETOUCHES-V108_V2_INTEGRE.cmd').read_text(encoding='utf-8')
        ui=(ROOT/'studio_ui'/'studio-retouches.js').read_text(encoding='utf-8')
        self.assertIn('--port 7861',launcher)
        self.assertNotIn('7863',launcher)
        self.assertIn('Photo facultative',ui)
        self.assertNotIn("if(mode==='replace_element'&&!reference)",ui)

if __name__=='__main__':unittest.main()
