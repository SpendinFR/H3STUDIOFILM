import sys, pathlib, unittest, tempfile, subprocess, json
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_masked_core as m
import retouches_engine as e

class NewMaskedEngine(unittest.TestCase):
    def _build(self,mode,model='Minimax-h3_Singularity_ref2va_Pruned_v1.3_int8.safetensors'):
        with patch.object(m,'_make',side_effect=lambda o,t,**a:{'class_type':t,'inputs':a}):
            return m.build({},mode,'original.mp4','blonde.png' if mode in ('swap_person','remove_person') else None,
               'woman with brown hair' if mode!='local_edit' else 'microphone','replace with a banana',
               model, 'h3_character_swap_pro4500_1000.safetensors' if mode=='swap_person' else None,
               frames=22,width=736,height=1280)
    def test_all_four_modes_are_masked_and_linked(self):
        for mode in m.MASK_MODES:
            with self.subTest(mode=mode):
                g=self._build(mode)
                for node in g.values():
                    for val in node['inputs'].values():
                        if isinstance(val,list) and len(val)==2 and isinstance(val[0],str):
                            self.assertIn(val[0],g)
                self.assertEqual(g['10']['class_type'],'SaveImage')
                self.assertEqual(g['43']['class_type'],'SaveVideo')
                self.assertEqual(g['28']['class_type'],'MVEx_MaskToLatentSpace')
                self.assertEqual(g['29']['class_type'],'SetLatentNoiseMask')
                self.assertEqual(g['38']['class_type'],'SamplerCustomAdvanced')
                self.assertEqual(g['42']['inputs']['audio'],['2',1])
                self.assertEqual(g['33']['inputs']['width'],['26',1])
                self.assertEqual(g['33']['inputs']['height'],['26',2])
                self.assertEqual(g['33']['inputs']['length'],['26',3])
    def test_background_does_not_crop_subject_and_inverts_mask(self):
        g=self._build('replace_background')
        self.assertEqual(g['12']['class_type'],'InvertMask')
        self.assertNotIn('25',g)
        self.assertEqual(g['28']['inputs']['masks'],['12',0])
    def test_remove_uses_akatz_contract(self):
        g=self._build('remove_person')
        self.assertEqual(g['24']['class_type'],'LoraLoaderModelOnly')
        self.assertEqual(g['33']['inputs']['ref_images.ref_image_0'],['32',0])
        self.assertEqual(g['37']['inputs']['sampler_name'],'er_sde')
        self.assertEqual(g['36']['inputs']['steps'],12)

    def test_swap_requires_image_and_uses_lora(self):
        g=self._build('swap_person')
        self.assertEqual(g['24']['class_type'],'LoraLoaderModelOnly')
        self.assertEqual(g['33']['inputs']['ref_images.ref_image_0'],['32',0])
    def test_fl2va_uses_its_own_conditioning_node(self):
        g=self._build('replace_background','minimax_h3_fl2va_pruned_int8_convrot.safetensors')
        self.assertEqual(g['33']['class_type'],'MiniMaxH3ImageToVideo')
    def test_mask_threshold_is_checked_before_render(self):
        import inspect
        body=inspect.getsource(e._run)
        self.assertLess(body.index('_mask_precheck('),body.index("comfy_json('/prompt',{'prompt':graph"))
    def test_portrait_video_cut_22_frames_and_preview(self):
        with tempfile.TemporaryDirectory() as td:
            root=pathlib.Path(td);src=root/'portrait.mp4'
            r=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',
                '-f','lavfi','-i','testsrc=size=320x576:rate=24',
                '-f','lavfi','-i','anullsrc=r=32000:cl=stereo',
                '-frames:v','56','-c:v','libx264','-pix_fmt','yuv420p',
                '-c:a','aac','-shortest',str(src)],capture_output=True,text=True,timeout=60)
            self.assertEqual(r.returncode,0,r.stderr)
            with patch.object(e,'JOBS_ROOT',root/'jobs'):
                out=e._prepare_shot(src,{'shot_start':0,'shot_end':0,'quality':'test','mode':'swap_person','test_clip':True},root,'a'*32)
                self.assertEqual(e._video_metadata(out)['frames'],22)
                self.assertLess(e._video_metadata(out)['width'],e._video_metadata(out)['height'])

if __name__=='__main__':unittest.main()
