"""V10.87 late-H3 warmup regression: temporal window and 63-frame single seam.

No H3 model installed here. Only proof of arguments/latents/video alignment.
"""
import hashlib
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

import torch
import retouches_precise_half_v82 as half
import retouches_llm_prompt_half_v82 as writer


class TestPreroll(unittest.TestCase):
    def setUp(self):
        self.window=half.select_window(37,124,3.6,4.5)
        self.render=half.render_window_with_preroll(self.window,37,124)

    def test_63_output_73_render_10_warmup(self):
        self.assertEqual((self.window['origin_frame'],self.window['frames'],self.window['end_frame']), (61,63,124))
        self.assertEqual((self.render['origin_frame'],self.render['frames'],self.render['end_frame']), (51,73,124))
        self.assertEqual((self.render['start_latent'],self.render['latent_t'],self.render['preroll_frames']), (15,22,10))
        self.assertEqual((self.render['local_first'],self.render['local_last']),(86-51,108-51))
        self.assertAlmostEqual(self.render['global_offset']+self.render['start'],86/24,places=6)
        self.assertAlmostEqual(self.render['global_offset']+self.render['end'],108/24,places=6)

    def test_first_half_still_exact_63(self):
        w=half.select_window(37,124,0,1.5)
        r=half.render_window_with_preroll(w,37,124)
        self.assertEqual((r['frames'],r['preroll_frames'],r['start_latent']),(63,0,0))
        self.assertEqual((r['origin_frame'],r['end_frame']),(0,63))

    def test_audio_video_latent_cut_still_exact_tensors(self):
        video=torch.arange(37,dtype=torch.float32).view(1,1,37,1,1)
        audio=torch.arange(400,dtype=torch.float32).view(1,1,1,400)
        saved={'samples':{'members':[{'tensor':video,'shape':tuple(video.shape),'device':'cpu'},
                                      {'tensor':audio,'shape':tuple(audio.shape),'device':'cpu'}]}, 'noise_mask':None}
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'original.pt';torch.save(saved,f)
            checksum=hashlib.sha256(f.read_bytes()).hexdigest()
            dst=half.write_window(saved,f,'half_preroll',self.render)
            v=torch.load(dst,weights_only=True)
            self.assertEqual(v['samples']['members'][0]['tensor'].shape[2],22)
            self.assertEqual(v['samples']['members'][0]['tensor'][0,0,0,0,0].item(),15)
            self.assertEqual(v['samples']['members'][0]['tensor'][0,0,-1,0,0].item(),36)
            self.assertEqual(hashlib.sha256(f.read_bytes()).hexdigest(),checksum)

    def test_gemma_new_beat_grid_aligned(self):
        grid=writer._grid(self.window)
        self.assertEqual(grid[0][1],0)
        self.assertEqual(grid[-1][2],63/24)
        self.assertAlmostEqual(grid[1][1],25/24)
        self.assertAlmostEqual(grid[1][2],47/24)
        inst=writer._instruction(request='Elle se gratte la tête',source_prompt='',window=self.window)
        self.assertIn('2.542–5.167s',inst)
        self.assertIn('1.042–1.958s',inst)

    def test_preroll_invalid_geometry_rejected(self):
        window=dict(self.window);window['start_latent']=17
        with self.assertRaisesRegex(ValueError,'désalignée|extension RAW'):
            half.render_window_with_preroll(window,37,124)

    def test_code_routes_all_h3_inputs_to_render_window(self):
        import retouches_next as engine
        import inspect
        src=inspect.getsource(engine._run)
        self.assertIn('window=local_retake',src)
        self.assertIn('prepare_for_h3(revised,local_retake,render_retake)',src)
        self.assertIn('precise_half.stage_reference(source,comfy,ident,render_retake)',src)
        self.assertIn('precise_half.write_window(saved_payload,latent,local_name,render_retake)',src)
        self.assertIn('precise_half.trim_preroll(',src)
        self.assertIn('precise_half.stitch(source,trimmed,dest,local_retake',src)


@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'), 'FFmpeg absent')
class TestRunIntegration(unittest.TestCase):
    def _late_window_for_stub(self):
        return half.select_window(37,124,3.6,4.5)

    def test_full_retake_sends_73_to_h3_and_stitches_63(self):
        from unittest.mock import patch
        import retouches_next as engine
        with tempfile.TemporaryDirectory() as td:
            d=Path(td); comfy=d/'comfy'; (comfy/'input').mkdir(parents=True)
            original=d/'original.mp4'; generated=d/'generated73.mp4'; latent=d/'clip_0001_RAW_LATENT.pt'
            for p,filter_expr,count in ((original,'testsrc2=size=96x64:rate=24',124),
                                        (generated,'color=c=red:size=96x64:rate=24',73)):
                q=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-f','lavfi','-i',filter_expr,
                        '-frames:v',str(count),'-c:v','libx264','-pix_fmt','yuv420p',str(p)],
                        capture_output=True,text=True,timeout=60)
                self.assertEqual(q.returncode,0,q.stderr)
            original_payload={'samples':{'members':[
                 {'tensor':torch.zeros(1,1,37,1,1),'shape':(1,1,37,1,1),'device':'cpu'},
                 {'tensor':torch.zeros(1,1,1,400),'shape':(1,1,1,400),'device':'cpu'}]},'noise_mask':None}
            torch.save(original_payload,latent)
            ident='c'*32
            graph_calls=[]
            def fake_graph(info,mode,project,clip,src,id,seconds,instruction,rect,**kw):
                graph_calls.append((seconds,kw))
                return {'902':{'class_type':'H3RetouchMaskV58','inputs':{}},
                        '159':{'class_type':'H3StudioImageToVideo','inputs':{'ref_video_files':kw['conditioning_video_name']}}}
            def comfy_api(endpoint,payload=None,timeout=None):
                if endpoint=='/object_info':return {name:{} for name in engine.REQUIRED}
                if endpoint=='/prompt':return {'prompt_id':'preroll_test'}
                if endpoint=='/history/preroll_test':return {'preroll_test':{'status':{'status_str':'success'},'outputs':{'191':{}}}}
                raise AssertionError(endpoint)
            with patch.object(engine,'ROOT',d/'jobs_root'),patch.object(engine,'JOBS',d/'jobs_root'/'jobs'), \
                 patch.object(engine,'RESULTS',d/'jobs_root'/'results'), \
                 patch.object(engine,'_project',return_value=(original,latent)), \
                 patch.object(engine,'_metadata',return_value={'fps':24,'duration':124/24,'frames':124,'width':96,'height':64}), \
                 patch.object(engine,'_authoring_context',return_value=('[Shot 1] 0–5.167s Original',[],[])), \
                 patch.object(engine,'build_graph',side_effect=fake_graph), \
                 patch.object(engine.legacy,'comfy_json',side_effect=comfy_api), \
                 patch.object(engine,'_history_output',return_value=generated), \
                 patch.object(engine,'_measured_visual_change',return_value=20.0), \
                 patch.object(engine.rt,'query_gpu_vram',return_value=None), \
                 patch('retouches_llm_prompt_half_v82.write_prompt',return_value=(
                     writer._assemble('La streameuse sourit face à la caméra, dans sa chambre.',
                       '[Shot 1] 0.000–1.042s Elle attend en regardant son écran.\n'
                       '[Shot 2] 1.042–1.958s Elle se gratte l’arrière de la tête.\n'
                       '[Shot 3] 1.958–2.625s Elle regarde de nouveau la caméra.',
                       self._late_window_for_stub()),'Gemma test')), \
                 patch.object(engine.time,'sleep'):
                engine._save({'id':ident,'project':'test','clip':'1','mode':'precise',
                    'instruction':'Elle se gratte la tête', 'performance_type':'action',
                    'selected':True,'start':3.6,'end':4.5,'test_clip':False,'region':None})
                engine._run(ident,lambda project:d,lambda:comfy)
                job=engine.job(ident)
                self.assertEqual(job['status'],'complete',job.get('error'))
                self.assertEqual(len(graph_calls),1)
                passed,kw=graph_calls[0]
                self.assertEqual(passed['frames'],73)
                self.assertEqual(kw['latent_name'],'clip_0001_RAW_LATENT__half_cccccccc')
                # The saved Gemma screenplay MUST remain the successful 63f timeline.
                gemma_text=(d/'jobs_root'/ident/'gemma_halfclip_part1.txt').read_text('utf-8')
                self.assertIn('exactly 2.625s',gemma_text)
                self.assertIn('[Shot 2] 1.042–1.958s',gemma_text)
                self.assertNotIn('0.000–0.417s',gemma_text)
                # H3 sees the 73f technical window, shifted only after Gemma.
                h3_prompt=kw['revised_prompt']
                self.assertIn('exactly 3.042s',h3_prompt)
                self.assertIn('[Shot 1] 0.000–0.417s',h3_prompt)
                self.assertIn('[Shot 3] 1.458–2.375s',h3_prompt)
                self.assertIn('Elle se gratte l’arrière de la tête.',h3_prompt)
                self.assertEqual(half._frame_count(d/'jobs_root'/'results'/(ident+'.mp4'),comfy),124)
                self.assertFalse((latent.parent/(kw['latent_name']+'.pt')).exists())


@unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'), 'FFmpeg absent')
class TestPrerollVideo(unittest.TestCase):
    def make(self,p,frames,kind):
        if kind=='source':
            inp=['-f','lavfi','-i','testsrc2=size=96x64:rate=24']
        else:
            inp=['-f','lavfi','-i',f'color=c={kind}:size=96x64:rate=24']
        q=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',*inp,'-frames:v',str(frames),'-c:v','libx264','-pix_fmt','yuv420p',str(p)],capture_output=True,text=True,timeout=60)
        self.assertEqual(q.returncode,0,q.stderr)

    def test_reference_73_and_trimmed_63_and_one_seam(self):
        w=half.select_window(37,124,3.6,4.5)
        r=half.render_window_with_preroll(w,37,124)
        with tempfile.TemporaryDirectory() as td:
            d=Path(td); comfy=d/'comfy'; (comfy/'input').mkdir(parents=True)
            source=d/'source.mp4'; rendered=d/'raw73.mp4'; trimmed=d/'raw63.mp4'; output=d/'full.mp4'
            self.make(source,124,'source'); self.make(rendered,73,'white')
            before=hashlib.sha256(source.read_bytes()).hexdigest()
            ref=half.stage_reference(source,comfy,'b'*32,r)
            self.assertEqual(half._frame_count(comfy/'input'/ref,comfy),73)
            half.trim_preroll(rendered,w,r,comfy,trimmed)
            self.assertEqual(half._frame_count(trimmed,comfy),63)
            half.stitch(source,trimmed,output,w,124,comfy)
            self.assertEqual(half._frame_count(output,comfy),124)
            self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(),before)

    def test_early_case_keeps_63(self):
        w=half.select_window(37,124,0,1.5)
        r=half.render_window_with_preroll(w,37,124)
        with tempfile.TemporaryDirectory() as td:
            d=Path(td);comfy=d/'comfy';comfy.mkdir()
            generated=d/'raw63.mp4';target=d/'prepared.mp4'
            self.make(generated,63,'blue')
            result=half.trim_preroll(generated,w,r,comfy,target)
            self.assertEqual(result,generated)
            self.assertEqual(half._frame_count(result,comfy),63)


if __name__=='__main__':unittest.main()
