"""V10.29: initial native authority; no UI async roundtrip for unchanged refs;
            RAW redo dialogue gates and safe dialogue slot redistribution.
"""
from pathlib import Path
import re
import subprocess
from unittest.mock import patch
import h3film_studio_v3 as film
import studio_dialogue_budget as budget

ROOT=Path(__file__).resolve().parents[1]
JS=(ROOT/'studio_ui'/'studio.js').read_text(encoding='utf-8')
SRC=(ROOT/'h3film_studio_v3.py').read_text(encoding='utf-8')


def test_native_authority_is_built_at_every_review():
    assert SRC.count("'authority_prefix':reference_prompt_prefix(active_refs,active_voice_refs)") >= 4
    assert 'if(clipDraft.authorityReady)' in JS
    assert 'previewClipAuthority().catch' in JS  # still present for older saves
    assert 'initLoraPicker' in JS


def test_dialogue_retake_gate_before_approved_checkpoint_and_each_h3_render():
    retake=SRC.index("before_retake_dialogue=h3_prompt")
    save=SRC.index("retake_state={'clip':global_clip,'status':'approved'", retake)
    loop=SRC.index('for studio_raw_attempt in range(12):')
    gpu=SRC.index('video_ann, raw_ann, cumulative_final_ann, used_mc = render_clip(',loop)
    final_check=SRC.index("h3_prompt, last_dialogue_issues = _auto_dialogue_gate(h3_prompt,'avant RAW/H3')",loop)
    assert retake < save
    assert final_check < gpu
    assert '_show_corrected_dialogue(before_retake_dialogue,h3_prompt' in SRC


def test_speaker_slot_repair_can_share_important_line_with_next_shot():
    original='''**[Shot 1] 0:00–2.5s**\nMatt :\n<d>[French] Salut tout le monde, bienvenue à ce live, vous m’avez manqué !</d>\n\n**[Shot 2] 2.5–5.0s**\nMatt :\n<d>[French] Il va se passer quelque chose.</d>'''
    rewritten='''**[Shot 1] 0:00–2.5s**\nMatt :\n<d>[French] Salut, vous m’avez manqué !</d>\n\n**[Shot 2] 2.5–5.0s**\nMatt :\n<d>[French] Bienvenue, ça va bouger !</d>'''
    result=budget.transplant_spoken(original,rewritten)
    assert result==rewritten
    assert not budget.check(result)
    assert len(re.findall(r'<d>',result))==2


def test_repair_does_not_move_to_different_speaker_or_modify_actions():
    original='''**[Shot 1] 0:00–2.5s**\nMatt :\n<d>[French] Bonjour tout le monde !</d>\n\n**[Shot 2] 2.5–5.0s**\nBrad :\n<d>[French] Il est en retard !</d>'''
    rewritten=original.replace('Brad :','Matt :').replace('Il est en retard !','On arrive !')
    updated=budget.transplant_spoken(original,rewritten)
    assert 'Brad :' in updated
    assert 'Matt :\n<d>[French] On arrive !' not in updated


def test_no_shot_header_will_not_allow_25_spoken_words():
    p='<d>[French] '+ ' '.join(f'mot{i}' for i in range(25)) + '</d>'
    warnings=budget.check(p)
    assert warnings and warnings[0]['words']==25 and warnings[0]['max_words']==15


def test_no_technical_changes_relative_to_v1028():
    assert (ROOT/'workflows'/'H3Studio_1920_API_CLEAN.json').is_file()
    assert (ROOT/'workflows'/'Krea_reference.json').is_file()
