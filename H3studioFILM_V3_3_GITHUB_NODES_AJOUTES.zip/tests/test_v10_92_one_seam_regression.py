"""Prove full V88 one-seam routing remains identical after central V10.92 addition."""
from pathlib import Path
from unittest.mock import patch
import tempfile, unittest
import torch
import retouches_precise_half_v82 as half
import retouches_llm_prompt_half_v82 as gemma
from retouches_preroll_prompt_v88 import prepare_for_h3
import retouches_next as engine

class SingleSeamIntegration(unittest.TestCase):
    def test_early_and_late_single_seam_pipeline(self):
        from test_v10_92_center_63f_with_context import RealVideo, authored
        make=RealVideo().make
        for start,end in ((0.0,1.5),(3.5,4.5)):
            with self.subTest(selection=(start,end)), tempfile.TemporaryDirectory() as td:
                p=Path(td);comfy=p/'ComfyUI';(comfy/'input').mkdir(parents=True)
                source=p/'src.mp4';latent=p/'clip_0001_RAW_LATENT.pt'
                make(source,124,audio=True)
                stored={'samples':{'members':[{'tensor':torch.zeros(1,1,37,1,1),'device':'cpu'},
                                              {'tensor':torch.zeros(1,1,1,400),'device':'cpu'}]},'noise_mask':None}
                torch.save(stored,latent)
                a=half.select_window(37,124,start,end)
                r=half.render_window_with_preroll(a,37,124)
                generation=p/'render.mp4';make(generation,r['frames'],'color=c=white:size=96x64:rate=24')
                records=[]
                def build(_info,mode,project,clip,source,ident,settings,instruction,rect,**kwargs):
                    records.append((settings,kwargs,half._frame_count(comfy/'input'/kwargs['conditioning_video_name'],comfy)))
                    return {'902':{'class_type':'H3RetouchMaskV58','inputs':{}},
                            '159':{'class_type':'H3StudioImageToVideo','inputs':{'ref_video_files':kwargs['conditioning_video_name']}}}
                def api(url,payload=None,timeout=None):
                    if url=='/object_info':return {key:{} for key in engine.REQUIRED}
                    if url=='/prompt':return {'prompt_id':'v92one'}
                    if url=='/history/v92one':return {'v92one':{'status':{'status_str':'success'},'outputs':{'191':{}}}}
                    raise AssertionError(url)
                ident='b'*32
                with patch.object(engine,'ROOT',p/'jobs'), patch.object(engine,'JOBS',p/'jobs'/'jobs'), \
                     patch.object(engine,'RESULTS',p/'jobs'/'results'), \
                     patch.object(engine,'_project',return_value=(source,latent)), \
                     patch.object(engine,'_metadata',return_value={'fps':24,'duration':124/24,'frames':124,'width':96,'height':64}), \
                     patch.object(engine,'_authoring_context',return_value=('[Shot 1] 0–5.167s original',[],[])), \
                     patch.object(engine,'build_graph',side_effect=build), \
                     patch.object(engine.legacy,'comfy_json',side_effect=api), \
                     patch.object(engine,'_history_output',return_value=generation), \
                     patch.object(engine,'_measured_visual_change',return_value=7.), \
                     patch.object(engine.rt,'query_gpu_vram',return_value=None), \
                     patch('retouches_llm_prompt_half_v82.write_prompt',side_effect=lambda **kwargs:(authored(kwargs['window']),'V83')) as mocked_gemma, \
                     patch.object(engine.time,'sleep'):
                    engine._save({'id':ident,'project':'demo','clip':'1','mode':'precise',
                                 'instruction':'Elle lève la main droite','performance_type':'action',
                                 'selected':True,'start':start,'end':end,'test_clip':False,'region':None})
                    engine._run(ident,lambda project:p,lambda:comfy)
                    self.assertEqual(engine.job(ident)['status'],'complete',engine.job(ident).get('error'))
                self.assertEqual(mocked_gemma.call_args.kwargs['window'],a)
                self.assertEqual(len(records),1)
                settings,kw,ref_count=records[0]
                self.assertEqual(ref_count,r['frames'])
                self.assertEqual(settings['frames'],r['frames'])
                self.assertEqual(settings['start'],r['start'])
                self.assertEqual(settings['end'],r['end'])
                expected=(prepare_for_h3(authored(a),a,r) if r['preroll_frames'] else authored(a))
                self.assertEqual(kw['revised_prompt'],expected)
                self.assertEqual(half._frame_count(p/'jobs'/'results'/(ident+'.mp4'),comfy),124)
if __name__=='__main__':unittest.main()
