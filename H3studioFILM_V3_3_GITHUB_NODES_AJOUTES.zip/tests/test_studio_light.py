import json, os, tempfile, threading, time, unittest
from pathlib import Path
from urllib.request import urlopen, Request
from urllib.error import HTTPError

import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import studio_bridge as bridge
import studio_web as web

class ControlTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        bridge.DIR=Path(self.tmp.name)
        (bridge.DIR/'answers').mkdir()
        web.write_json(bridge.DIR/'config.json',{'initial_answers':['details','1m','style','h3'], 'reviews':{'plans':True}})
    def test_prefilled_inputs_then_question(self):
        self.assertEqual([bridge.ask_input() for x in range(4)],['details','1m','style','h3'])
        result=[]
        t=threading.Thread(target=lambda:result.append(bridge.ask_input()))
        t.start()
        for _ in range(50):
            q=web.json_get(bridge.DIR/'question.json',{})
            if q.get('id'):break
            time.sleep(.01)
        self.assertTrue(q.get('id'))
        web.write_json(bridge.DIR/'answers'/f"{q['id']}.json",{'value':'f'})
        t.join(2)
        self.assertFalse(t.is_alive());self.assertEqual(result,['f'])
    def test_review_revision_and_pause_boundary(self):
        out=[]
        t=threading.Thread(target=lambda:out.append(bridge.checkpoint('plans','Plan A',{'text':'plan prompt'},True)))
        t.start()
        for _ in range(50):
            r=web.json_get(bridge.DIR/'review.json',{})
            if r.get('id'):break
            time.sleep(.01)
        self.assertEqual(r['kind'],'plans')
        web.write_json(bridge.DIR/'answers'/f"{r['id']}.json",{'action':'revise','feedback':'Changer axe camera'})
        t.join(2)
        self.assertEqual(out[0]['action'],'revise')
        self.assertEqual(out[0]['feedback'],'Changer axe camera')
        (bridge.DIR/'pause.request').write_text('1')
        finished=[]
        t=threading.Thread(target=lambda:(bridge.pause_boundary(),finished.append(True)))
        t.start();time.sleep(.05);self.assertFalse(finished)
        (bridge.DIR/'pause.request').unlink()
        t.join(1);self.assertTrue(finished)
    def test_clip_snapshot(self):
        p=bridge.DIR/'project';p.mkdir()
        bridge.snapshot_clip(p,2,{'raw_pt':'clip_2.pt'})
        self.assertEqual(web.json_get(p/'_studio'/'clips.json')['clips']['0002']['raw_pt'],'clip_2.pt')

class HttpTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.old=os.environ.get('COMFYUI_DIR');os.environ['COMFYUI_DIR']=str(Path(self.tmp.name)/'ComfyUI')
        c=web.comfy_path();(c/'output'/'H3FilmSimple'/'demo'/'_studio').mkdir(parents=True)
        (c/'input').mkdir()
        clip=c/'output'/'H3FilmSimple'/'demo'
        web.write_json(clip/'_studio'/'clips.json',{'clips':{'0001':{'clip':1,'video':'H3FilmSimple/demo/clips/missing.mp4 [output]','refs':[],'voices':[],'raw_pt':str(clip/'_state'/'1.pt')}}})
        self.server=web.ThreadingHTTPServer(('127.0.0.1',0),web.Handler)
        self.port=self.server.server_address[1]
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True)
        self.thread.start()
        self.addCleanup(self.server.shutdown)
        self.addCleanup(self.server.server_close)
        self.addCleanup(self._restore)
    def _restore(self):
        if self.old is None:os.environ.pop('COMFYUI_DIR',None)
        else:os.environ['COMFYUI_DIR']=self.old
    def get(self,u):
        with urlopen(f'http://127.0.0.1:{self.port}{u}',timeout=2) as f:return f.read(),f.status,f.headers
    def post(self,u,body=None,headers=None):
        b=json.dumps(body or {}).encode() if headers is None else body
        h={'Content-Type':'application/json'} if headers is None else headers
        with urlopen(Request(f'http://127.0.0.1:{self.port}{u}',data=b,headers=h,method='POST'),timeout=2) as f:return json.load(f)
    def test_ui_and_project(self):
        b,code,h=self.get('/');self.assertEqual(code,200);self.assertIn(b'FILM STUDIO',b)
        for path in ('/studio.css','/studio.js','/api/status','/api/project?name=demo'):
            b,code,h=self.get(path);self.assertEqual(code,200)
        data=json.loads(self.get('/api/project?name=demo')[0]);self.assertIn('0001',data['clips'])
    def test_upload_media_and_block_traversal(self):
        body=b'fake PNG image'
        answer=self.post('/api/upload',body,{'X-Filename':'test.png','Content-Type':'application/octet-stream'})
        self.assertTrue(Path(answer['path']).is_file())
        b,status,headers=self.get(answer['url'])
        self.assertEqual(b,body)
        with self.assertRaises(HTTPError):self.get('/media/output/../../../etc/passwd')
    def test_non_destructive_revision(self):
        # A past-clip edit is recorded, never falsely rendered.
        r=self.post('/api/revision',{'project':'demo','clip':1,'feedback':'Change camera angle'})
        self.assertTrue(r['ok']);self.assertIn('aucun rendu existant supprimé',r['message'])
        p=web.comfy_path()/'output'/'H3FilmSimple'/'demo'/'_studio'/'revisions.json'
        self.assertEqual(web.json_get(p)['items'][0]['invalidates_from'],1)

if __name__=='__main__':unittest.main(verbosity=2)
