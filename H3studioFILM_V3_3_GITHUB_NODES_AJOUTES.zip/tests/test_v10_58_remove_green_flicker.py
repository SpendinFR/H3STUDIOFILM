"""V10.58: late/olive green artifacts, moving masks, no swap changes."""
import pathlib
import subprocess
import sys
import tempfile
import unittest

import cv2
import numpy as np

ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_engine as engine


class TestRemoveGreenFlicker(unittest.TestCase):
    def test_olive_edge_and_genuine_green_and_black_chair(self):
        original=np.full((128,160,3),32,dtype=np.uint8)
        original[5:20,8:28]=(30,115,30)   # real green object in original shot
        output=original.copy()
        output[44:53,91:100]=(42,67,46) # olive fringe (G excess 21, below old 24)
        output[60:68,29:38]=(35,55,40)  # faint fringe (G excess 15)
        support=np.zeros((128,160),dtype=np.uint8)
        support[20:112,22:105]=1
        core=np.zeros_like(support);core[35:100,45:84]=1
        repair=engine._green_spill_mask(original,output,support,core)
        self.assertGreater(int(repair[48,94]),0)
        self.assertGreater(int(repair[64,33]),0)
        self.assertEqual(int(repair[8,10]),0)
        self.assertEqual(int(repair[44,54]),0)  # central part of actor is excluded
        self.assertEqual(int(repair[118,125]),0)

    def test_olive_green_remains_untouched_if_originally_green(self):
        source=np.full((80,80,3),40,dtype=np.uint8)
        source[20:32,18:36]=(38,74,35)
        output=source.copy()
        outmask=np.ones((80,80),dtype=np.uint8)
        core=np.zeros((80,80),dtype=np.uint8)
        repair=engine._green_spill_mask(source,output,outmask,core)
        self.assertEqual(int(repair.sum()),0)

    def test_shimmer_after_one_second_mask_motion_and_fps(self):
        with tempfile.TemporaryDirectory() as d:
            root=pathlib.Path(d)
            source=root/'original.mp4';render=root/'h3.mp4'
            w,h=160,128
            fourcc=cv2.VideoWriter_fourcc(*'mp4v')
            original=cv2.VideoWriter(str(source),fourcc,24,(w,h))
            output=cv2.VideoWriter(str(render),fourcc,24,(w,h))
            self.assertTrue(original.isOpened() and output.isOpened())
            masks=[]
            for i in range(48):
                a=np.full((h,w,3),42,dtype=np.uint8)
                a[4:18,4:18]=(30,146,27) # real bright green plant in scene
                b=a.copy()
                dx=0 if i<28 else 9
                # Two tiny residue patches, flickering only after 1s.
                if i>=26 and i%2==0:
                    b[58:68,28+dx:37+dx]=(30,79,33)
                if i>=25 and i%3!=0:
                    b[41:52,91+dx:99+dx]=(44,77,54) # dull olive halo
                mask=np.zeros((h,w),dtype=np.uint8)
                mask[24:99,48+dx:81+dx]=255
                path=root/f'mask_{i:03d}.png'
                cv2.imwrite(str(path),mask);masks.append(path)
                original.write(a);output.write(b)
            original.release();output.release()
            self.assertEqual(engine._video_metadata(render)['frames'],48)
            self.assertTrue(engine._remove_green_spill(source,render,masks))
            info=engine._video_metadata(render)
            self.assertEqual(info['frames'],48)
            self.assertAlmostEqual(info['fps'],24.0,places=2)
            c=cv2.VideoCapture(str(render))
            frames=[]
            while True:
                ok,frame=c.read()
                if not ok:break
                frames.append(frame)
            c.release()
            self.assertEqual(len(frames),48)
            # The newly green animated residue is eliminated (the chair stays dark).
            self.assertLess(int(frames[26][60,32,1]),60)
            self.assertLess(int(frames[29][44,94,1]),60)
            self.assertLess(int(frames[46][60,41,1]),60)
            # True green never lost, including across re-encoding.
            self.assertGreater(int(frames[29][10,10,1]),100)
            # Same input, second pass should not change the already clean video.
            self.assertFalse(engine._remove_green_spill(source,render,masks))

if __name__=='__main__':unittest.main()
