from pathlib import Path
import importlib
import json
import uuid
import pytest


def test_approve_and_continue_without_reencoding(tmp_path,monkeypatch):
    import studio_retouch_review as rev
    source=tmp_path/'result.mp4'
    source.write_bytes(b'\x00\x00\x00\x18ftypmp42'+b'video-content')
    ident=uuid.uuid4().hex
    row={'id':ident,'status':'complete','mode':'local_edit','source':{'type':'project','project':'film_test','clip':'1'}}
    monkeypatch.setattr(rev,'ROOT',tmp_path/'review_storage')
    monkeypatch.setattr(rev.legacy,'job',lambda got: row)
    monkeypatch.setattr(rev.legacy,'job_result',lambda got: source)
    saved=rev.decide('legacy',ident,'approve')
    assert saved['state']=='approved'
    target=rev.approved_file('legacy',ident)
    assert target and target.read_bytes()==source.read_bytes()
    assert source.read_bytes()==b'\x00\x00\x00\x18ftypmp42'+b'video-content'
    assert saved['project']=='film_test' and saved['clip']=='1'
    assert rev.choices()['legacy:'+ident]['state']=='approved'
    assert rev.result_path('legacy',ident)==source
    continued=rev.decide('legacy',ident,'continue')
    assert continued['state']=='continue'
    assert rev.result_path('legacy',ident)==source
    cancelled=rev.decide('legacy',ident,'cancel')
    assert cancelled['state']=='cancelled'
    assert rev.result_path('legacy',ident) is None
    assert target.read_bytes()==source.read_bytes()


def test_no_latent_fallback_for_new_engine(tmp_path,monkeypatch):
    import studio_retouch_review as rev
    source=tmp_path/'new.mp4';source.write_bytes(b'file')
    ident=uuid.uuid4().hex
    row={'id':ident,'mode':'precise','status':'complete','project':'movie','clip':'0001'}
    monkeypatch.setattr(rev,'ROOT',tmp_path/'review_storage')
    monkeypatch.setattr(rev.native,'job',lambda got: row)
    monkeypatch.setattr(rev.native,'output',lambda got: source)
    with pytest.raises(ValueError,match='latent H3'):
        rev.decide('new',ident,'continue')
    approved=rev.decide('new',ident,'approve')
    assert approved['project']=='movie' and approved['clip']=='0001'
    assert rev.approved_file('new',ident).read_bytes()==b'file'
    assert not list(tmp_path.rglob('*.pt'))
    with pytest.raises(ValueError):rev.decide('new','../../evil','approve')


def test_masks_and_incomplete_jobs_are_not_approvable(tmp_path,monkeypatch):
    import studio_retouch_review as rev
    ident=uuid.uuid4().hex
    monkeypatch.setattr(rev,'ROOT',tmp_path/'review_storage')
    monkeypatch.setattr(rev.legacy,'job',lambda _: {'status':'complete','mask_only':True})
    with pytest.raises(ValueError,match='aperçu'):
        rev.decide('legacy',ident,'approve')
    monkeypatch.setattr(rev.legacy,'job',lambda _: {'status':'rendering'})
    with pytest.raises(ValueError,match='terminé'):
        rev.decide('legacy',ident,'approve')


def test_filmmaker_raw_gate_scoped_to_project_and_clip(tmp_path,monkeypatch):
    import studio_web as web
    gate_folder=tmp_path/'_studio'/'gates';gate_folder.mkdir(parents=True)
    (gate_folder/'clip_0003.waiting.json').write_text('{}')
    monkeypatch.setattr(web,'active_folder',lambda:tmp_path/'session')
    monkeypatch.setattr(web,'json_get',lambda p,d=None:{'name':'movie'})
    monkeypatch.setattr(web,'load_project',lambda name:tmp_path if name=='movie' else None)
    good={'type':'project','project':'movie','clip':'3','variant':'raw'}
    assert web.film_raw_gate_allows_retouch(good)
    assert not web.film_raw_gate_allows_retouch(dict(good,clip='4'))
    assert not web.film_raw_gate_allows_retouch(dict(good,project='another'))
    assert not web.film_raw_gate_allows_retouch(dict(good,variant='hd'))
    (gate_folder/'clip_0003.decision.json').write_text('{}')
    assert not web.film_raw_gate_allows_retouch(good)
