"""V3.3 exact-source tracker staging and one terse Gemma semantic retry.
No ComfyUI service or GPU required: tests inspect the real files and inputs.
"""
import os
from pathlib import Path
import pytest
import retouches_next as studio
import retouches_llm_prompt_half_v82 as half_writer
import retouches_precise_half_v82 as half_window
import retouches_precise_center_v90 as validation


def test_tracker_copy_of_same_loaded_video_for_continued_clip(tmp_path):
    comfy=tmp_path/'ComfyUI'
    (comfy/'input').mkdir(parents=True)
    (comfy/'output').mkdir()
    ident='f'*32
    studio_session=tmp_path/'studio_sessions'/'retouches'/'results'
    studio_session.mkdir(parents=True)
    source=studio_session/'continued.mp4'
    source.write_bytes(b'video from Continue, good audio remains in original')
    name=studio._stage_input_video(source,comfy,ident,'source')
    safe=studio._stage_tracking_video(name,comfy,ident)
    assert safe.is_file()
    assert safe.is_relative_to((comfy/'output').resolve())
    assert safe.read_bytes()==source.read_bytes()==(comfy/'input'/name).read_bytes()
    # Neither modification nor replacement of the continuation MP4.
    assert source.is_file()
    safe.unlink()
    (comfy/'input'/name).unlink()
    assert source.is_file()


def test_tracker_uses_padded_or_preview_input_exactly(tmp_path):
    comfy=tmp_path/'ComfyUI';(comfy/'input').mkdir(parents=True)
    (comfy/'output').mkdir()
    ident='c'*32
    input_name=f'h3new_{ident}_insert_preroll.mp4'
    (comfy/'input'/input_name).write_bytes(b'17 technical preroll frames, NOT the pristine RAW')
    tracked=studio._stage_tracking_video(input_name,comfy,ident)
    assert tracked.read_bytes()==(comfy/'input'/input_name).read_bytes()
    assert tracked.name==f'h3new_{ident}_tracking.mp4'
    with pytest.raises(ValueError,match='déjà présent'):
        studio._stage_tracking_video(input_name,comfy,ident)


def test_tracker_rejects_unknown_external_or_absent_input(tmp_path):
    comfy=tmp_path/'ComfyUI';(comfy/'input').mkdir(parents=True)
    (comfy/'output').mkdir()
    ident='d'*32
    for filename in ('../../external.mp4','missing.mp4',f'h3new_{ident}_other.txt','bad.mp4'):
        with pytest.raises(ValueError):
            studio._stage_tracking_video(filename,comfy,ident)
    with pytest.raises(ValueError):
        studio._stage_tracking_video('missing.mp4',comfy,'bad')


def _gemma_text(window,blank=False):
    desc={'TRANSITION AVANT':'Elle regarde le mur puis sourit doucement.',
          'ACTION':'Elle tourne sa tête vers la caméra et lève lentement la main.',
          'TRANSITION APRÈS':'Elle repose doucement la main en reprenant son regard.'}
    grid=half_writer._grid(window)
    shots=[]
    for i,(role,a,b) in enumerate(grid,1):
        content=('TRANSITION AVANT' if blank and role=='TRANSITION AVANT' else desc[role])
        shots.append(f'[Shot {i}] {a:.3f}–{b:.3f}s {content}')
    return 'SCENE_CONTEXT: Une femme près du mur dans une pièce bien éclairée.\nNEW_TAKE:\n'+'\n'.join(shots)


def _mock_gemma(monkeypatch,answers):
    import h3film_studio_v3 as film
    calls=[];unloads=[]
    monkeypatch.setattr(half_writer.inherited,'choose_backend',lambda _:{'model':'gemma'})
    def director(backend,system,instruction,**settings):
        calls.append((system,instruction,settings))
        return answers[len(calls)-1]
    monkeypatch.setattr(film,'director_text',director)
    monkeypatch.setattr(film,'unload_text_backend',lambda *args:unloads.append(args))
    return calls,unloads


def test_valid_gemma_unchanged_one_generation(monkeypatch):
    window=half_window.select_window(37,124,3.6,4.5)
    calls,unloads=_mock_gemma(monkeypatch,[_gemma_text(window)])
    prompt,_=half_writer.write_prompt(mode='precise',performance_type='action',request='Sourire',
        source_prompt='',window=window,gpu_prepare=lambda:None)
    validation.verify_gemma_descriptions(prompt)
    assert len(calls)==len(unloads)==1
    assert calls[0][0]==half_writer.SYSTEM
    assert calls[0][2]['num_ctx']==16384
    assert calls[0][2]['num_predict']==1700
    assert 'Refais' not in calls[0][1]


def test_gemma_retries_only_once_with_one_short_sentence(monkeypatch):
    window=half_window.select_window(37,124,3.6,4.5)
    calls,unloads=_mock_gemma(monkeypatch,[_gemma_text(window,blank=True),_gemma_text(window)])
    revised,_=half_writer.write_prompt(mode='precise',performance_type='action',request='Sourire',
        source_prompt='',window=window,gpu_prepare=lambda:None)
    validation.verify_gemma_descriptions(revised)
    assert len(calls)==2 and len(unloads)==1
    assert calls[1][0]==calls[0][0]==half_writer.SYSTEM
    assert calls[1][2]==calls[0][2]
    assert calls[1][1]==calls[0][1]+'\nRefais : chaque [Shot] doit décrire un mouvement visible.'


def test_gemma_stops_after_second_invalid_response(monkeypatch):
    window=half_window.select_window(37,124,3.6,4.5)
    calls,unloads=_mock_gemma(monkeypatch,[_gemma_text(window,blank=True)]*2)
    with pytest.raises(RuntimeError,match='Shot sans description de mouvement'):
        half_writer.write_prompt(mode='precise',performance_type='action',request='Sourire',
            source_prompt='',window=window,gpu_prepare=lambda:None)
    assert len(calls)==2 and len(unloads)==1
