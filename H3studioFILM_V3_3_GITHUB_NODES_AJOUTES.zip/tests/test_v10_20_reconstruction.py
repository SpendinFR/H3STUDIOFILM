"""V10.20 targeted regression gates for cross-character, style graph, finished extension and Krea review."""
import json
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import h3film_studio_v3 as film
import h3_runtime_simple as rt
import studio_web

ROOT=Path(__file__).resolve().parents[1]


def test_brad_not_as_matt_even_when_mentioned_in_shot_one(tmp_path):
    canonical=tmp_path/'matt.png';canonical.write_bytes(b'canonical placeholder')
    video=[Path(f'obs_{i:02d}_t{i/2:.3f}s.jpg') for i in range(10)]
    prompt='''**[Shot 1] 0:00–2.5**
Gros plan macro sur le visage de Brad. Il lève les yeux vers Matt, se fâche.
Brad : Wesh c'est comment frero.
**[Shot 2] 2.5–5.0**
Plan moyen (Two-shot) montrant Matt de profil et Brad en face. Matt répond.''' 
    calls=[]
    def vlm(*a,**kw):
        calls.append(a[3]);return {'confidence':'HIGH','usable_image_numbers':[2]}
    with patch.object(film.rt,'ollama_json_images',side_effect=vlm):
        matt=film.select_character_appearance_frames('vision','Matt',video,{}, {},prompt,
                       candidate_characters=['Matt','Brad'], canonical_frame=canonical)
        brad=film.select_character_appearance_frames('vision','Brad',video,{}, {},prompt,
                       candidate_characters=['Matt','Brad'], canonical_frame=canonical)
    assert matt==[]  # Matt only in ambiguous joint shot, Brad's closeup not his image
    assert len(brad)==1 and film._observer_frame_timestamp(brad[0])<=2.65
    assert len(calls)==1 and calls[0][0]==canonical and len(calls[0])<=3


def test_no_canonical_file_means_keep_appearance(tmp_path):
    result=film.select_character_appearance_frames('vision','Matt',[Path('obs_t0.5s.jpg')],{}, {},
                     '**[Shot 1] 0.00–5.00**\nClose-up on Matt.',
                     candidate_characters=['Matt'],canonical_frame=tmp_path/'missing.png')
    assert result==[]


def test_style_workflow_uses_model_adapter_not_source_as_latent():
    base=json.loads((ROOT/'workflows/Krea_reference.json').read_text())
    style=json.loads((ROOT/'workflows/Krea_reference_sref.json').read_text())
    assert base['nodes']!=style['nodes']
    mapping={x['id']:x for x in style['nodes']}
    assert mapping[54]['type']=='KSampler'
    assert mapping[94]['type']=='LoadImage'
    assert mapping[95]['type']=='Krea2StyleReference'
    assert mapping[96]['type']=='Krea2StyleTransfer'
    assert next(i for i in mapping[54]['inputs'] if i['name']=='model')['link']==607
    assert next(i for i in mapping[54]['inputs'] if i['name']=='latent_image')['link']==79
    assert next(i for i in mapping[96]['inputs'] if i['name']=='model')['link']==604
    assert next(i for i in mapping[95]['inputs'] if i['name']=='reference_image')['link']==603
    # Comfy GUI -> API conversion preserves exact model/reference links.
    schemas={}
    for node in style['nodes']:
        req={i['name']:[i['type']] for i in node.get('inputs',[]) if i.get('link') is not None}
        schemas[node['type']]={'input':{'required':req}}
    api=rt.gui_to_api(style,schemas)
    assert api['54']['inputs']['model']==['96',0]
    assert api['54']['inputs']['latent_image']==['57',0]
    assert api['96']['inputs']['reference_latent']==['95',0]
    assert api['95']['inputs']['reference_image']==['94',0]


def test_finished_film_extension_keeps_completed_checkpoint(tmp_path,monkeypatch):
    p=tmp_path/'film';(p/'_studio').mkdir(parents=True)
    checkpoint=p/'_studio'/'resume_state.json'
    checkpoint.write_text(json.dumps({'completed':True,'completed_clip':12}))
    monkeypatch.setattr(studio_web,'load_project',lambda name:p if name=='film' else None)
    monkeypatch.setattr(studio_web,'restart_project',lambda name,**kw:{'project':name,'continued':kw['allow_finished_extension']})
    monkeypatch.setitem(studio_web.STATE,'proc',None)
    monkeypatch.setitem(studio_web.STATE,'session',None)
    class Request:
        path='/api/extend-timeline'
        def body(self):return {'project':'film','extra_seconds':60,'instructions':'Continue la confrontation'}
        def send_data(self,data,status=200):self.status,self.result=status,data
    r=Request();studio_web.Handler.do_POST(r)
    assert r.status==200,r.result
    assert r.result['launched']['continued'] is True
    pending=json.loads((p/'_studio'/'timeline_extension_pending.json').read_text())
    assert pending['extra_seconds']==60
    assert json.loads(checkpoint.read_text())=={'completed':True,'completed_clip':12}


def test_browser_krea_review_preserves_single_prompt_display():
    js=(ROOT/'studio_ui/studio.js').read_text()
    html=(ROOT/'studio_ui/index.html').read_text()
    assert 'kreaPreview=result' in js and "$('approveKreaClip').onclick" in js
    assert 'clipDraft.refs.push' in js[js.index("$('approveKreaClip').onclick"):]
    assert 'clipDraft.refs.push' not in js[js.index('async function generateKreaPreview'):js.index("$('approveKreaClip').onclick")]
    assert 'id="clipWorldCue"' not in html
    assert 'id="clipPrompt"' in html
    assert '<option value="style">' in html and '<option value="transform">' in html
    assert 'studio-v10-20.css' in html
    assert 'Content Director' in (ROOT/'studio_timeline_extension.py').read_text() or 'Content Director' in (ROOT/'h3film_studio_v3.py').read_text()
