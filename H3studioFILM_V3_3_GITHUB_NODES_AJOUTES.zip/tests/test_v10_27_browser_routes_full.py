"""V10.27 post-V10.19 UI regression gates, without ComfyUI or LLM.

Exercise the actual Studio script against the full HTML document, across
all review/answer stages and the back-navigation flow that regressed.
"""
from pathlib import Path
import pytest

ROOT=Path(__file__).resolve().parents[1]


def test_all_director_and_reference_stages_render_without_browser_exception():
    pwmod=pytest.importorskip('playwright.sync_api')
    with pwmod.sync_playwright() as pw:
        try:
            browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        except Exception:
            pytest.skip('Chromium unavailable')
        page=browser.new_page(viewport={'width':1280,'height':900})
        exceptions=[]
        page.on('pageerror',lambda e:exceptions.append(str(e)))
        html=(ROOT/'studio_ui/index.html').read_text('utf-8').replace('<script src="/studio.js"></script>','')
        page.set_content(html)
        page.add_script_tag(content=(ROOT/'studio_ui/studio.js').read_text('utf-8'))
        page.evaluate("() => { projectName='regression_film'; project={}; window.__answers=[]; answer=async (id,value) => window.__answers.push({id,value}); }")
        base={'running':True,'project':{'name':'regression_film'},'raw_gates':[]}
        questions=[
            ('Références canoniques proposées','choice',[{'value':'','label':'Parcourir'},{'value':'s','label':'Ignorer'}]),
            ('Mode Krea + image source — Nyx','choice',[{'value':'transform','label':'Transformer'},{'value':'style','label':'Style'}]),
            ('Image source pour Nyx','choice',[{'value':'f','label':'Importer'}]),
            ('Importer une source Krea','file',[]),
            ('Précisions Krea — Nyx','text',[]),
        ]
        for i,(title,itype,opts) in enumerate(questions):
            data={**base,'question':{'id':f'q{i}','context':{'title':title,'input_type':itype,'options':opts}}}
            page.evaluate("""d => {document.getElementById('questionArea').dataset.token=''; actionPanel(d)}""",data)
            assert page.locator('#decisionStatus').inner_text()=='ACTION REQUISE'
            assert page.locator('#deskTitle').inner_text()==title
            if opts:assert page.locator('#questionArea .decisionOption').count()==len(opts)
            if 'Précisions' in title or 'Mode Krea' in title or 'Image source pour' in title:
                page.locator('#questionArea #backKreaPrecisions, #questionArea #backKreaSourceChoice').click()
                assert page.evaluate('window.__answers.at(-1).value')=='__BACK_TO_KREA_CHOICES__'
            if 'Importer une source' in title:
                page.locator('#questionArea #backKreaFileImport').click()
                assert page.evaluate('window.__answers.at(-1).value')=='__BACK_TO_SOURCES__'
        for kind in ('content','scenes','plans','clips'):
            payload={'text':'[Shot 1] 0:00–5.0s\n<d>[French] Bonjour.</d>','refs':[],'audio_refs':[],'loras':[]}
            if kind=='clips':payload.update(dialogue_auto_changed=True,dialogue_previous='[Shot 1] 0:00–5.0s\n<d>[French] Bonjour tout le monde, comment allez-vous ?</d>')
            data={**base,'review':{'id':f'r{kind}','kind':kind,'title':kind,'payload':payload,'allow_revise':True,'allow_redo':True}}
            page.evaluate("""d => {document.getElementById('questionArea').dataset.token='';actionPanel(d)}""",data)
            assert page.locator('#decisionStatus').inner_text()=='DÉCISION REQUISE'
            assert page.locator('#approveReview').count()==1
        for name,data in (
            ('raw',{**base,'raw_gates':[{'clip':1,'raw_url':'/raw.mp4'}]}),
            ('reference planner',{**base,'stage':{'stage':'reference_planning','title':'Reference Planner — recherche des références du film'}}),
            ('motor error',{**base,'running':False,'error':'Worker failed','return_code':1}),
        ):
            page.evaluate("""d => {document.getElementById('questionArea').dataset.token='';actionPanel(d)}""",data)
            assert page.locator('#deskTitle').inner_text(),name
        assert exceptions==[],exceptions
        browser.close()


def test_reference_first_question_and_modals_have_no_new_tdz_shadow():
    js=(ROOT/'studio_ui/studio.js').read_text('utf-8')
    assert "const title=ctx.title||''" not in js
    assert 'const kreaBackButtons' in js
