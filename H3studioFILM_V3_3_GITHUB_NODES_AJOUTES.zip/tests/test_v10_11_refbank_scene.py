"""Regression tests: persistent RefBank edits, scope separation and scene redo."""
import copy
import json
from pathlib import Path
import pytest
import h3film_studio_v3 as f
import studio_refbank_edits as bank
import studio_web as web


def make(tmp_path):
    project=tmp_path/'H3FilmSimple'/'myfilm'
    refs_dir=project/'refs';refs_dir.mkdir(parents=True)
    comfy=tmp_path/'comfy';(comfy/'input').mkdir(parents=True)
    def ref(name,kind,role,key,filename):
        p=comfy/'input'/filename;p.write_bytes(b'image')
        return {'path':str(p),'annotated':f'{filename} [input]', 'kind':kind,'role':role,'subject_key':key,'subject_name':name,'strength':1.0}
    matt=ref('Matt','character','canonical_identity','canonical_matt','matt.png')
    nyx=ref('Nyx','character','canonical_identity','canonical_nyx','nyx.png')
    nyx_wrong=ref('Nyx','character','film_appearance','canonical_nyx','nyx_wrong.png')
    matt_bad=ref('Matt','character','film_appearance','canonical_matt','matt_bad.png')
    static=[matt,nyx]
    b={'characters':{},'character_appearance':{'Nyx':nyx_wrong,'Matt':matt_bad},'decor':{},'objects':{},'subjects':{},'history':[]}
    (refs_dir/'static_refs.json').write_text(json.dumps(static))
    (refs_dir/'ref_bank.json').write_text(json.dumps(b))
    active=[matt,nyx_wrong,nyx,matt_bad]
    for i,r in enumerate(active,1):r['picture_order']=i
    prompt=f.reference_prompt_prefix(active)+'\n\n**Director :**\nLook\n\n**description_multimodale_intégrée :**\nMatt catches the drone.'
    return project,comfy,active,prompt,matt_bad,nyx_wrong


def spec(active):
    return [{'media':'image','index':i,'name':r['subject_name'],'visual_type':'person'} for i,r in enumerate(active)]


def apply(project,comfy,active,prompt,rows,deletes=None,commit=True):
    return f.apply_clip_studio_edits({'edits':{'text':prompt,'refs':rows,'bank_deletes':deletes or []}},prompt,active,[],comfy,project,commit=commit)


def test_reassign_nyx_appearance_to_matt_persisted(tmp_path):
    project,comfy,active,prompt,_,bad=make(tmp_path)
    rows=spec(active)
    rows[1].update({'name':'Matt','bank_target':'Matt','bank_scope':'bank'})
    preview,pics,_=apply(project,comfy,active,prompt,rows,commit=False)
    before=json.loads((project/'refs/ref_bank.json').read_text())
    assert 'Nyx' in before['character_appearance']
    assert pics[1]['role']=='film_appearance'
    assert pics[1]['subject_key']==pics[0]['subject_key']
    assert 'is the latest rendered-film appearance state for the same <Subject 1>' in preview
    assert '<Picture 2>' in preview
    assert preview.count('REFERENCE AUTHORITY —')==1
    committed,pics2,_=apply(project,comfy,active,prompt,rows)
    assert committed==preview and pics2==pics
    after=json.loads((project/'refs/ref_bank.json').read_text())
    assert 'Nyx' not in after['character_appearance']
    assert after['character_appearance']['Matt']['path']==bad['path']
    assert Path(bad['path']).is_file(), 'Historic media must remain on disk'
    # resume path rereads updated RefBank
    disk=json.loads((project/'refs/ref_bank.json').read_text())
    next_clip=f.choose_active_refs(json.loads((project/'refs/static_refs.json').read_text()),disk,
       {'scene':2,'location':'Terrasse','description':'Matt stands'},
       {'plan':3,'action':'Matt turns to Nyx'},['Matt','Nyx'])
    assert any(r.get('role')=='film_appearance' and r.get('subject_name')=='Matt' and r['path']==bad['path'] for r in next_clip)


def test_remove_appearance_from_bank_but_preserve_canonical(tmp_path):
    project,comfy,active,prompt,matt_bad,_=make(tmp_path)
    rows=spec(active)[:-1]
    edited,pics,_=apply(project,comfy,active,prompt,rows,[3])
    b=json.loads((project/'refs/ref_bank.json').read_text())
    assert 'Matt' not in b['character_appearance']
    assert 'Matt' in [r['subject_name'] for r in json.loads((project/'refs/static_refs.json').read_text())]
    assert Path(matt_bad['path']).exists()
    assert '<Picture 4>' not in edited


def test_canonical_delete_bank_rejected_atomically(tmp_path):
    project,comfy,active,prompt,_,_=make(tmp_path)
    db= (project/'refs/ref_bank.json').read_bytes()
    with pytest.raises(ValueError,match='canonique'):
        apply(project,comfy,active,prompt,spec(active)[1:],[0])
    assert (project/'refs/ref_bank.json').read_bytes()==db


def test_clip_only_reassign_no_bank_writes(tmp_path):
    project,comfy,active,prompt,_,_=make(tmp_path)
    snapshot=(project/'refs/ref_bank.json').read_bytes()
    rows=spec(active);rows[1].update({'name':'Matt','bank_target':'Matt','bank_scope':'clip'})
    edited,pics,_=apply(project,comfy,active,prompt,rows)
    assert pics[1]['subject_key']==pics[0]['subject_key']
    assert (project/'refs/ref_bank.json').read_bytes()==snapshot
    assert 'is the latest rendered-film appearance state for the same <Subject 1>' in edited
    assert '<Picture 2>' in edited


def test_new_nikita_is_persisted_and_available(tmp_path):
    project,comfy,active,prompt,_,_=make(tmp_path)
    nik=comfy/'input'/'nikita.png';nik.write_bytes(b'nikita')
    rows=spec(active)+[{'media':'image','path':str(nik),'name':'Nikita','visual_type':'person','bank_scope':'bank'}]
    edited,pics,_=apply(project,comfy,active,prompt,rows)
    b=json.loads((project/'refs/ref_bank.json').read_text())
    assert 'Nikita' in b['characters']
    assert '<Subject 3> is Nikita' in edited
    assert nik.is_file()


def test_scene_review_redo_is_supported_and_prompt_keeps_boundaries():
    src=Path(f.__file__).read_text()
    assert "allow_revise=True,allow_redo=True" in src
    assert "if action=='redo':" in src
    assert "parse_scene_output(amended,part,next_scene_number)" in src
    assert "tested[-1]['end_seconds']!=part['end_seconds']" in src
    import inspect,studio_bridge
    assert 'allow_redo=False' in inspect.signature(studio_bridge.checkpoint).__str__()
    server_src=Path(web.__file__).read_text()
    assert "q.get('kind') in ('content','scenes')" in server_src


def test_deleted_bank_image_disappears_from_picker(tmp_path):
    """The RefBank picker lists registered references, not every orphan file."""
    from http.server import ThreadingHTTPServer
    from unittest.mock import patch
    from urllib.request import urlopen
    from threading import Thread
    project,comfy,active,prompt,matt_bad,_=make(tmp_path)
    with patch.object(web,'load_project',return_value=project),patch.object(web,'comfy_path',return_value=comfy):
        server=ThreadingHTTPServer(('127.0.0.1',0),web.Handler)
        t=Thread(target=server.serve_forever,daemon=True);t.start()
        try:
            endpoint=f'http://127.0.0.1:{server.server_port}/api/ref-images?name=myfilm'
            with urlopen(endpoint,timeout=5) as res: before=json.load(res)
            assert any('matt_bad.png' in x['path'] for x in before)
            apply(project,comfy,active,prompt,spec(active)[:-1],[3])
            with urlopen(endpoint,timeout=5) as res: after=json.load(res)
            assert not any('matt_bad.png' in x['path'] for x in after)
            assert Path(matt_bad['path']).exists()
        finally:
            server.shutdown();server.server_close();t.join(timeout=5)
