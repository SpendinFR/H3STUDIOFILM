from pathlib import Path
import pytest
ROOT=Path(__file__).resolve().parents[1]


def test_new_film_controls_display_and_payload_in_chromium():
    pw=pytest.importorskip('playwright.sync_api')
    with pw.sync_playwright() as pp:
        try:
            browser=pp.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        except Exception:
            pytest.skip('Chromium absent')
        page=browser.new_page(viewport={'width':1280,'height':900})
        faults=[]
        page.on('pageerror',lambda e:faults.append(str(e)))
        html=(ROOT/'studio_ui/index.html').read_text('utf-8').replace('<script src="/studio.js"></script>','')
        page.set_content(html)
        page.add_style_tag(content=(ROOT/'studio_ui/studio.css').read_text('utf-8'))
        page.add_style_tag(content=(ROOT/'studio_ui/studio-v10-32.css').read_text('utf-8'))
        page.add_script_tag(content=(ROOT/'studio_ui/studio.js').read_text('utf-8'))
        page.evaluate("""() => {
            window.__captured=null;
            request=async (url,payload)=>{
                if(url==='/api/start'){window.__captured=payload;return {session:'test'}}
                if(url==='/api/status')return {running:false,projects:[],project:null};
                return {};
            };
            refresh=async()=>{};
        }""")
        page.locator('#createModal').evaluate('(el)=>el.classList.remove("hidden")')
        assert page.locator('#contentType option').count()==11
        assert page.locator('#orientation option').count()==2
        assert page.locator('#contentType').input_value()=='film'
        assert page.locator('#orientation').input_value()=='landscape'
        page.locator('#filmName').fill('Test vertical')
        page.locator('#brief').fill('Un film en hauteur')
        page.locator('#duration').fill('10s')
        page.locator('#contentType').select_option('reseaux_sociaux')
        page.locator('#orientation').select_option('portrait')
        page.locator('#startFilm').click()
        page.wait_for_function('window.__captured!==null',timeout=2000)
        payload=page.evaluate('window.__captured')
        assert payload['content_type']=='reseaux_sociaux'
        assert payload['orientation']=='portrait'
        assert payload['mode']=='studio'
        assert not faults,faults
        browser.close()
