"""Tests spécifiques aux deux nouveaux modes — pas de rendu GPU simulé comme succès visuel."""
import copy
from pathlib import Path
import sys, tempfile, subprocess, shutil, unittest
from unittest.mock import patch
import numpy as np
import cv2
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_engine as eng
import retouches_pixel_tracker as pix
import retouches_masked_core as core
from retouches_remove_relay import intervals

class ElementModes(unittest.TestCase):
    def test_both_modes_actually_reuse_original_5s_h3_methods(self):
        self.assertEqual(eng.underlying_mode('remove_element'),'remove_person')
        self.assertEqual(eng.underlying_mode('replace_element'),'swap_person')
        self.assertEqual(eng.underlying_mode('remove_person'),'remove_person')
        self.assertEqual(eng.underlying_mode('swap_person'),'swap_person')
        self.assertEqual(len(intervals(124)),7)
        self.assertEqual(len(eng._swap_windows(124)),2)
        self.assertEqual(eng.WORKFLOWS['remove_element']['loras'],eng.WORKFLOWS['remove_person']['loras'])
        self.assertEqual(eng.WORKFLOWS['replace_element']['loras'],eng.WORKFLOWS['swap_person']['loras'])

    def test_existing_graph_not_changed_and_element_prompts_accurate(self):
        with patch.object(core,'_make',side_effect=lambda info,t,**x:{'class_type':t,'inputs':x}):
            for physical,name,ref,steps,sampler in (
                ('remove_person','remove_element','plate.png',12,'er_sde'),
                ('swap_person','replace_element','newobject.png',8,'euler')):
                a=core.build({},physical,'clip.mp4',ref,'unknown gizmo','','h3_ref2va.safetensors',
                             frames=22,width=128,height=96)
                b=copy.deepcopy(a)
                eng.apply_element_prompt(b,name,'unknown gizmo','Preserve surroundings.')
                self.assertEqual(a['33']['class_type'],'MiniMaxH3ReferenceToVideo')
                self.assertEqual(a['36']['inputs']['steps'],steps)
                self.assertEqual(a['37']['inputs']['sampler_name'],sampler)
                self.assertEqual(a['32']['inputs']['image'],ref)
                for k in a:
                    if k=='33':continue
                    self.assertEqual(a[k],b[k],f'Old H3 node {k} was unexpectedly modified')
                self.assertNotEqual(a['33']['inputs']['prompt'],b['33']['inputs']['prompt'])
                self.assertIn('unknown gizmo',b['33']['inputs']['prompt'])

    def test_pixel_graph_bypasses_sam_while_retaining_swap_crop_and_lora(self):
        with patch.object(core,'_make',side_effect=lambda info,t,**x:{'class_type':t,'inputs':x}):
            a=core.build({},'swap_person','clip.mp4','newobject.png','unknown gizmo','',
                         'h3_ref2va.safetensors',lora_name='h3_character_swap_pro4500_1000.safetensors',
                         frames=124,width=128,height=96,region=[.2,.2,.25,.3])
        pix.attach_mask_movie(a,'pixel_masks.mp4')
        for t in ('3','4','5','6','7','8'):self.assertNotIn(t,a)
        self.assertEqual(a['11']['inputs']['masks'],['72',0])
        self.assertEqual(a['44']['inputs']['expand'],26)
        self.assertEqual(a['24']['inputs']['lora_name'],'h3_character_swap_pro4500_1000.safetensors')
        self.assertEqual(a['25']['inputs']['masks'],['44',0])
        self.assertEqual(a['32']['inputs']['image'],'newobject.png')
        for k,node in a.items():
            for v in node['inputs'].values():
                if isinstance(v,list) and len(v)==2 and isinstance(v[0],str):
                    self.assertIn(v[0],a,f'Missing referenced node {k}->{v[0]}')

    @unittest.skipUnless(shutil.which('ffmpeg'),'FFmpeg required')
    def test_unknown_textured_object_tracked_by_pixels_and_encoded_frame_exact(self):
        rng=np.random.default_rng(123)
        with tempfile.TemporaryDirectory() as td:
            d=Path(td)
            w,h,n=160,96,39
            source=d/'moving.mp4'
            video=cv2.VideoWriter(str(source),cv2.VideoWriter_fourcc(*'mp4v'),24,(w,h))
            self.assertTrue(video.isOpened())
            texture=rng.integers(50,245,size=(28,30,3),dtype=np.uint8)
            for i in range(n):
                frame=np.full((h,w,3),35,np.uint8)
                frame[28:56,20+i:50+i]=texture
                video.write(frame)
            video.release()
            # Entire test uses ZERO SAM3 nodes or semantics.
            masks=pix.track_pixel_region(source,[20/w,28/h,30/w,28/h],d/'masks',expand=0)
            self.assertEqual(len(masks),n)
            c0=cv2.imread(str(masks[0]),cv2.IMREAD_GRAYSCALE)
            c1=cv2.imread(str(masks[-1]),cv2.IMREAD_GRAYSCALE)
            yy,xx=np.where(c0>100);first=float(np.mean(xx))
            yy,xx=np.where(c1>100);last=float(np.mean(xx))
            self.assertLess(abs((last-first)-(n-1)),4.0)
            movie=pix.encode_mask_movie(masks,d/'pixel_mask.mp4',w,h)
            capture=cv2.VideoCapture(str(movie));read=0
            while capture.read()[0]:read+=1
            capture.release()
            self.assertEqual(read,n)
            self.assertGreater(movie.stat().st_size,500)

    def test_unreliable_manual_selection_fails_before_gpu(self):
        with self.assertRaisesRegex(ValueError,'7 pixels'):
            pix._box([0.1,0.1,0.004,0.004],128,96)
        with self.assertRaisesRegex(ValueError,'Cadre trop grand'):
            pix._box([0,0,0.99,0.99],128,96)
        with self.assertRaisesRegex(ValueError,'cadre|Cadre'):
            pix._box([0.8,.2,.3,.3],128,96)

if __name__=='__main__': unittest.main()
