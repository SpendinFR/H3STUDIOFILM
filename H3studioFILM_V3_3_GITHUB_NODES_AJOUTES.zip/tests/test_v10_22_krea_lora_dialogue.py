"""V10.22 targeted invariants without GPU or ComfyUI process."""
import copy, json, os, sys, pathlib
from unittest.mock import patch
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import studio_lora as lora
import studio_dialogue_budget as dialogue


def schema():
    return {'LoraLoaderModelOnly':{'input':{'required':{'lora_name':[['m1.safetensors','m2.safetensors']],
       'strength_model':['FLOAT',{'default':1}]}}}}


def graph():
    return {'127':{'class_type':'UNETLoader','inputs':{}},
            '126':{'class_type':'BasicGuider','inputs':{'model':['127',0],'conditioning':['90',0]}},
            '176':{'class_type':'BasicScheduler','inputs':{'model':['127',0]}},
            '90':{'class_type':'Conditioning','inputs':{}}}


def test_disabled_lora_graph_is_byte_for_byte_unchanged():
    g=graph();baseline=json.dumps(g,ensure_ascii=False)
    assert lora.apply(g,[],{}) is g
    assert json.dumps(g,ensure_ascii=False)==baseline


def test_enabled_loras_chain_all_model_consumers_and_preserve_original():
    g=graph();original=copy.deepcopy(g)
    out=lora.apply(g,[{'name':'m1.safetensors','strength':.65},{'name':'m2.safetensors','strength':1.25}],schema())
    assert g==original
    assert out['177']['class_type']=='LoraLoaderModelOnly'
    assert out['177']['inputs']['model']==['127',0]
    assert out['178']['inputs']['model']==['177',0]
    assert out['126']['inputs']['model']==['178',0]
    assert out['176']['inputs']['model']==['178',0]
    assert out['126']['inputs']['conditioning']==['90',0]


def test_lora_bad_path_and_strength_rejected():
    import pytest
    for items in [[{'name':'missing.safetensors','strength':1}], [{'name':'m1.safetensors','strength':9}]]:
        with pytest.raises((ValueError,RuntimeError)):
            lora.apply(graph(),items,schema())


def test_speech_budget_shot_cumulative_and_language_tag():
    good='**[Shot 1] 0:00–2.5s**\nA: <d>[French] Bonjour je suis ici.</d>\n**[Shot 2] 2.5–5.0**\nB: <d>[French] Tu peux venir ?</d>'
    assert dialogue.check(good)==[]
    bad='**[Shot 1] 0:00–2.5s**\nA: <d>[French] Bonjour je suis ici pour te dire bonjour.</d>\nB: <d>[French] Et moi aussi.</d>\n**[Shot 2] 2.5–5.0**\n[quiet]'
    result=dialogue.check(bad)
    assert len(result)==1 and result[0]['shot']==1 and result[0]['words']==11 and result[0]['max_words']==7


def test_krea_layout_and_lora_ui_controls_present():
    html=(ROOT/'studio_ui/index.html').read_text(encoding='utf8')
    css=(ROOT/'studio_ui/studio-v10-22.css').read_text(encoding='utf8')
    script=(ROOT/'studio_ui/studio.js').read_text(encoding='utf8')
    for token in ['filmLoraEnabled','clipLoraEnabled','kreaBusyVisual','kreaResultImage']:
        assert token in html+script
    assert 'overflow:hidden' in css and 'object-fit:contain' in css
    assert 'selectedLoras' in script


def test_workflow_bytes_unchanged_from_v21():
    import zipfile
    baseline=ROOT.parent/'H3Film_STUDIO_V10_21_UI_AUTHORITY_TIMELINE_FIX.zip'
    if not baseline.exists():return
    with zipfile.ZipFile(baseline) as z:
        for n in ('workflows/H3Studio_1920_API_CLEAN.json','h3_runtime_simple.py','custom_nodes/H3RawLatentPersist/__init__.py'):
            if n in z.namelist():assert z.read(n)==(ROOT/n).read_bytes()


def test_krea_modal_image_stays_inside_frame_chromium():
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1180,'height':850})
        errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.set_content((ROOT/'studio_ui/index.html').read_text(encoding='utf8'))
        for f in ROOT.joinpath('studio_ui').glob('*.css'):
            page.add_style_tag(content=f.read_text(encoding='utf8'))
        page.add_script_tag(content=(ROOT/'studio_ui/studio.js').read_text(encoding='utf8'))
        page.evaluate('''() => {
            document.getElementById('kreaClipModal').classList.remove('hidden');
            document.getElementById('kreaStage').classList.remove('hidden');
            document.querySelector('#kreaClipModal .dialog').classList.add('kreaWorking');
            document.getElementById('kreaBusyVisual').classList.add('hidden');
            const img=document.getElementById('kreaResultImage');
            img.src='data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" width="1024" height="2048"%3E%3Crect width="1024" height="2048" fill="red"/%3E%3C/svg%3E';
            img.classList.remove('hidden');
        }''')
        page.locator('#kreaResultImage').wait_for(state='visible')
        dims=page.evaluate('''() => {
          const a=document.getElementById('kreaStage').getBoundingClientRect(),b=document.getElementById('kreaResultImage').getBoundingClientRect();
          return {stage:a.toJSON(), image:b.toJSON(), overflow:document.querySelector('#kreaClipModal .dialog').scrollWidth>document.querySelector('#kreaClipModal .dialog').clientWidth};
        }''')
        assert dims['image']['width']<=dims['stage']['width'] and dims['image']['height']<=dims['stage']['height']
        assert not dims['overflow']
        assert not errors,errors
        browser.close()
