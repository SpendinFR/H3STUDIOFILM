import unittest

import retouches_llm_prompt_v74 as mod


class RetakePromptLocalisationTests(unittest.TestCase):
    def test_auto_inline_localisation_repairs_missing_cue(self):
        text=("[Shot 1] 0.000–1.832s Elle rit doucement en regardant l'écran.\n"
              "[Shot 2] 1.832–5.167s Elle se recentre face caméra.")
        fixed=mod._auto_inline_localisation(text,0.137,1.832,5.167)
        self.assertIn("Pendant 0.137–1.832s :",fixed)

    def test_validate_accepts_inline_cue_without_boundaries(self):
        text=("[Shot 1] 0.000–1.832s Pendant 0.137–1.832s : Elle rit doucement en regardant l'écran.\n"
              "[Shot 2] 1.832–5.167s Elle se recentre face caméra.")
        out=mod.validate_edit_timeline(text,0.137,1.832,5.167,allow_inline_cue=True)
        self.assertEqual(out,[(0.0,1.832),(1.832,5.167)])


if __name__ == "__main__":
    unittest.main()
