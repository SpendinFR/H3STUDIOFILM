"""V10.105: assertions on the *executed* Insert path, not just unused helpers."""
from pathlib import Path
import sys, shutil
from unittest.mock import MagicMock
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import retouches_next as runner
import retouches_roycho_complete_v63 as roycho
import retouches_new_insert_guide as guide
import retouches_llm_prompt_insert_v104 as writer
import retouches_insert_preroll_v101 as lead

REQUIRED={
      'H3LoadRawLatentExact','H3RoychoAnimatedMaskV62','LoadVideo','GetVideoComponents',
      'MVEx_MaskCleanup','MVEx_SubjectCrop','MVEx_MaskToLatentSpace','MVEx_SubjectUncrop',
      'VAELoader','CLIPLoader','UNETLoader','MiniMaxH3SigmaShift','VAEEncode','GetImageSizeAndCount',
      'SetLatentNoiseMask','VAEEncodeAudio','LTXVConcatAVLatent','MiniMaxH3ReferenceToVideo',
      'BasicGuider','RandomNoise','BasicScheduler','KSamplerSelect','SamplerCustomAdvanced',
      'LTXVSeparateAVLatent','VAEDecode','CreateVideo','SaveVideo','LoadImage',
      'H3RoychoCropGuideV64','MiniMaxH3AddGuide'}

PARTS=("Une streameuse dans son studio avec lumière bleue.",
       "Une araignée noire descend puis remonte rapidement.",
       "Elle se déplace devant l'étagère avec profondeur et ombre.")


def _data_with_ref(has_ref):
    return writer.make_h3_prompt(PARTS,has_picture=has_ref,request='Une araignée descend puis remonte')


def test_gemma_insert_writer_only_one_source_and_neutral_krea(monkeypatch):
    import h3film_studio_v3 as film
    calls=[]
    monkeypatch.setattr(writer,'choose_backend',lambda _film: {'display':'Gemma 26B'})
    monkeypatch.setattr(film,'director_text',lambda _backend,_system,user,**_kw: (
        calls.append(user) or
        'SCENE_CONTEXT: '+PARTS[0]+'\nELEMENT: '+PARTS[1]+'\nINTEGRATION: '+PARTS[2]))
    monkeypatch.setattr(film,'unload_text_backend',lambda *a,**k: None)
    monkeypatch.setattr(film,'release_all_text_models_for_h3',lambda *a,**k: None)
    prompt,krea,method=writer.write_prompt(request='Une araignée descend puis remonte',
        source_prompt='ORIGINAL SCRIPT',start=0.,end=1.62,duration=124/24,
        has_picture=True,rect=(55.,2.,20.,20.),gpu_prepare=lambda:None)
    assert len(calls)==1
    assert 'ORIGINAL SCRIPT' in calls[0]
    assert '<Picture 1>' in prompt and 'Une araignée noire' in prompt
    assert 'portrait' in krea.lower() and 'NON-FIGURATIVE' in krea
    assert 'araignée' not in krea.lower()  # Krea NEVER describes the final element
    assert '<Picture 1>' not in krea and 'ORIGINAL SCRIPT' not in krea
    assert 'Gemma 26B' in method


def test_krea_graph_rejects_old_figurative_path_and_reference(monkeypatch):
    neutral=writer.make_krea_prompt(PARTS)
    fake={'6':{'inputs':{'text':'old subject portrait'}},'9':{'inputs':{}},'11':{'inputs':{}}}
    monkeypatch.setattr(guide.prior,'validate',lambda info:None)
    monkeypatch.setattr(guide.prior,'graph',lambda *args:fake)
    graph=guide.build_graph({},'frame.png','mask.png','une araignée','a'*32,
                            guide_prompt=neutral)
    assert graph['6']['inputs']['text']==neutral
    assert 'araignée' not in graph['6']['inputs']['text']
    assert graph['9']['inputs']['seed']==int('a'*8,16)
    with pytest.raises(ValueError,match='neutre'):
        guide.build_graph({},'frame.png','mask.png','une araignée','a'*32)
    with pytest.raises(ValueError,match='référence'):
        guide.build_graph({},'frame.png','mask.png','une araignée','a'*32,
                          reference_path='picture.png',guide_prompt=neutral)


@pytest.mark.parametrize('with_ref',[False,True])
def test_actual_runner_submits_correct_prompt_and_ref_and_17f(monkeypatch,tmp_path,with_ref):
    comfy=tmp_path/'ComfyUI';(comfy/'input').mkdir(parents=True);(comfy/'output').mkdir(parents=True)
    source=comfy/'output'/'original.mp4';source.write_bytes(b'original')
    latent=tmp_path/'original.pt';latent.write_bytes(b'latent')
    row={'id':'a'*32,'mode':'insert','instruction':'Une araignée descend puis remonte',
         'project':'demo','clip':'1','selected':True,'start':0.,'end':1.62,
         'region':[.55,.02,.2,.2],'playhead':0.,'test_clip':False,
         'performance_type':'action','reference_path':str(comfy/'input'/'picture.png') if with_ref else ''}
    if with_ref:(comfy/'input'/'picture.png').write_bytes(b'fake-png')
    monkeypatch.setattr(runner,'ROOT',tmp_path/'jobs')
    monkeypatch.setattr(runner,'RESULTS',tmp_path/'results')
    monkeypatch.setattr(runner,'job',lambda _id:row)
    updates=[]
    monkeypatch.setattr(runner,'_update',lambda _id,**kw:updates.append(kw))
    monkeypatch.setattr(runner,'_project',lambda *a,**k:(source,latent))
    monkeypatch.setattr(runner,'_metadata',lambda *a,**k:{'duration':124/24,'fps':24.,'frames':124,'width':640,'height':384})
    monkeypatch.setattr(runner,'_stage_input_video',lambda *a,**k:'input_source.mp4')
    # Fake ComfyUI tests use synthetic non-MP4 bytes; isolate only the staging.
    monkeypatch.setattr(runner,'_stage_tracking_video',lambda *a,**k:comfy/'output'/('h3new_'+'a'*32+'_tracking.mp4'))
    monkeypatch.setattr(runner,'_authoring_context',lambda *a,**k:('ORIGINAL PROMPT',[],[]))
    monkeypatch.setattr(runner,'_safe_comfy_free',lambda *a,**k: True)
    monkeypatch.setattr(runner,'_stage_insert_reference',lambda *a,**k:'picture.png')
    monkeypatch.setattr(runner,'_measured_visual_change',lambda *a,**k: 10.)
    monkeypatch.setattr(runner,'_preflight_graph_links',lambda *a,**k:None)
    monkeypatch.setattr(runner,'_preflight_required_inputs',lambda *a,**k:None)
    monkeypatch.setattr(runner,'_preflight_h3_numeric_inputs',lambda *a,**k:None)
    monkeypatch.setattr(runner.rt,'query_gpu_vram',lambda: {})
    monkeypatch.setattr(runner.time,'sleep',lambda *a:None)
    monkeypatch.setattr(lead,'stage_source',lambda *a,**k:(tmp_path/'lead.mp4','lead_input.mp4'))
    monkeypatch.setattr(lead,'stage_latent',lambda _src,name,_frames:tmp_path/(name+'.pt'))
    strip_called=[]
    def _strip(_generated,_src,target,num,comfy_path):
        strip_called.append(num);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b'final')
    monkeypatch.setattr(lead,'strip_warmup',_strip)
    expected_prompt=_data_with_ref(with_ref)
    actuals=[]
    def _write_mock(**kwargs):
        actuals.append(kwargs)
        return expected_prompt,writer.make_krea_prompt(PARTS),'Gemma 26B · VFX insertion'
    monkeypatch.setattr(writer,'write_prompt',_write_mock)
    krea_calls=[]
    def _guide_mock(info,_source,_comfy,_ident,seconds,instruction,rect,krea_prompt=None):
        krea_calls.append((seconds,instruction,rect,krea_prompt))
        assert krea_prompt == writer.make_krea_prompt(PARTS)
        assert '<Picture 1>' not in krea_prompt
        return tmp_path/'neutral_guide.png'
    monkeypatch.setattr(runner,'_prepare_true_insert_guide',_guide_mock)
    graphs=[]
    def fake_comfy(endpoint,payload=None,**kw):
        if endpoint=='/object_info':return {k:{} for k in REQUIRED}
        if endpoint=='/prompt':
            graphs.append(payload['prompt']);return {'prompt_id':'q123'}
        if endpoint=='/history/q123':return {'q123':{'status':{'status_str':'success'},'outputs':{'191':{}}}}
        raise AssertionError(endpoint)
    monkeypatch.setattr(runner.legacy,'comfy_json',fake_comfy)
    output=tmp_path/'fake-H3.mp4';output.write_bytes(b'generated')
    monkeypatch.setattr(runner,'_history_output',lambda *a,**k:output)
    runner._run(row['id'],lambda project:tmp_path,lambda:comfy)
    errors=[u['error'] for u in updates if 'error' in u]
    assert not errors,errors
    assert updates[-1].get('status')=='complete',updates[-3:]
    assert len(actuals)==1
    assert actuals[0]['source_prompt']=='ORIGINAL PROMPT'
    assert actuals[0]['start']==0.0 and actuals[0]['end']==1.62
    assert actuals[0]['has_picture']==with_ref
    assert len(krea_calls)==1
    assert krea_calls[0][0]['frames']==124  # Krea in original clock
    assert len(graphs)==1
    h3=graphs[0]
    assert h3['33']['inputs']['prompt']==expected_prompt
    assert h3['33']['inputs'].get('ref_images.ref_image_0') == (['46',0] if with_ref else None)
    assert h3['45']['inputs']['positive']==['33',0]
    assert h3['902']['inputs']['latent']==['901',0]
    assert h3['902']['inputs']['source_video']==str(comfy/'output'/('h3new_'+row['id']+'_tracking.mp4'))
    assert h3['901']['inputs']['latent_name'].endswith('insertmask_aaaaaaaa')
    assert h3['902']['inputs']['end_seconds']==pytest.approx(1.62+17/24)
    assert h3['41']['inputs']['original_images']==['2',0]
    assert strip_called==[124]
    saved=(runner.ROOT/row['id']/'shot_prompt_part1.txt').read_text(encoding='utf8')
    assert saved==h3['33']['inputs']['prompt']
    if with_ref:assert '<Picture 1>' in saved
    else:assert '<Picture 1>' not in saved


def test_actual_retake_and_performance_modules_bytewise_match_v101():
    base=Path('/mnt/data/v101')
    if not base.exists():pytest.skip('Local baseline archive not mounted in deployed environment')
    root=Path(__file__).resolve().parents[1]
    for name in (
        'retouches_llm_prompt_v74.py','retouches_llm_prompt_half_v82.py',
        'retouches_llm_prompt_center_v93.py','retouches_precise_half_v82.py',
        'retouches_precise_center_v90.py','retouches_performance_native_v96.py',
        'studio_ui/studio-new-retouches.js',
        'custom_nodes/H3StudioRetouchExtras/retouch_mask_math_v58.py',
    ):
        assert (root/name).read_bytes()==(base/name).read_bytes(), name


def test_actual_krea_preparation_sends_neutral_prompt_without_optional_picture(monkeypatch,tmp_path):
    from PIL import Image
    comfy=tmp_path/'ComfyUI';(comfy/'input').mkdir(parents=True)
    src=tmp_path/'source.mp4';src.write_bytes(b'x')
    image=comfy/'input'/'frame.png';Image.new('RGB',(64,64),(50,60,70)).save(image)
    monkeypatch.setattr(runner,'_screenshot',lambda *args:image)
    monkeypatch.setattr(guide.prior,'validate',lambda *_:None)
    monkeypatch.setattr(guide.prior,'graph',lambda *_:{
        '1':{'class_type':'LoadImage','inputs':{'image':'frame.png'}},
        '2':{'class_type':'LoadImageMask','inputs':{'image':'mask.png'}},
        '6':{'class_type':'CLIPTextEncode','inputs':{'text':'OLD SUBJECT'}},
        '9':{'class_type':'LanPaint_KSampler','inputs':{}},
        '11':{'class_type':'SaveImage','inputs':{}},
    })
    monkeypatch.setattr(runner,'_preflight_graph_links',lambda *a:None)
    monkeypatch.setattr(runner,'_preflight_required_inputs',lambda *a:None)
    captured=[]
    class ReachedComfySubmission(Exception):pass
    def send(endpoint,payload=None,**kwargs):
        assert endpoint=='/prompt'
        captured.append(payload['prompt'])
        raise ReachedComfySubmission()
    monkeypatch.setattr(runner.legacy,'comfy_json',send)
    neutral=writer.make_krea_prompt(PARTS)
    with pytest.raises(ReachedComfySubmission):
        runner._prepare_true_insert_guide({k:{} for k in REQUIRED},src,comfy,'f'*32,
            {'duration':124/24,'start':0.0,'end':1.62},'Une araignée',
            (55.,2.,20.,20.),krea_prompt=neutral)
    assert captured[0]['6']['inputs']['text']==neutral
    assert 'araignée' not in neutral.lower()
    assert len([n for n in captured[0].values() if n.get('class_type')=='LoadImage'])==1
    assert captured[0]['1']['inputs']['image']=='frame.png'
