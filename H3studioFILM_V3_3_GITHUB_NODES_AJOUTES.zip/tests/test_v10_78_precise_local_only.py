"""V10.78 regression: Retake local 39-frame window; unchanged Essai RAW.

Pure local tests, ffmpeg for stitching only. No Ollama/ComfyUI installed or accessed.
"""
from __future__ import annotations
import hashlib, os, json, re, shutil, subprocess, sys, tempfile, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import retouches_precise_local_v78 as v78
import retouches_next as engine

PROMPT="""<Video 1> = REAL SOURCE VIDEO. Visual reference.
SCENE CONTEXT (short visual description, no original timeline):
Streameuse, neon, lumiere.
NEW TAKE — THIS IS THE ONLY SHOT SCRIPT TO GENERATE:
[Shot 1] 0:00–2.500s Elle regarde l'écran.
[Shot 2] 2.500–4.145s Elle tourne la tête vers l'objectif.
[Shot 3] 4.145–5.167s Elle lève la main et la redescend.
Preserve total duration 5.167s, with requested edit interval 4.145–5.167s. Keep unaffected actions and dialogue."""

class TestV78(unittest.TestCase):
    def test_selection_near_end_correct(self):
        w=v78.select_window(37,124,4.145,5.167)
        self.assertEqual((w['first_frame'],w['last_frame']),(99,124))
        self.assertEqual((w['origin_frame'],w['end_frame']),(85,124))
        self.assertEqual((w['start_latent'],w['local_first'],w['local_last']),(25,14,39))
    def test_selection_start_uses_same_first_39(self):
        w=v78.select_window(37,124,0,1.593)
        self.assertEqual(w['start_latent'],0)
        self.assertEqual(w['origin_frame'],0)
    def test_any_middle_segment_short(self):
        for start,end in ((1.8,2.4),(.8,1.5),(2.8,3.5),(4.145,5.167)):
            w=v78.select_window(37,124,start,end)
            self.assertLessEqual(w['end_frame'],124)
            self.assertEqual(w['end_frame']-w['origin_frame'],39)
            self.assertGreaterEqual(w['first_frame'],w['origin_frame'])
            self.assertLessEqual(w['last_frame'],w['end_frame'])
    def test_invalid_geometry_rejected_before_h3(self):
        with self.assertRaisesRegex(ValueError,'incohérente'):
            v78.select_window(37,125,4.145,5.167)
        with self.assertRaisesRegex(ValueError,'39 images'):
            v78.select_window(37,124,0,2)
    def test_retime_validated_gemma_full_script_to_local(self):
        w=v78.select_window(37,124,4.145,5.167)
        h3=v78.local_prompt(PROMPT,w)
        self.assertIn('0.603–1.625s Elle lève la main',h3)
        self.assertIn('[Shot 1] 0.000–0.603s',h3)
        self.assertIn('LOCAL TAKE: exactly 1.625s',h3)
        self.assertNotIn('[Shot 3]',h3)
        self.assertNotIn('requested edit interval 4.145–5.167s',h3)
        self.assertEqual(h3.count('<Video 1>'),2) # frame authority + bottom reference
    def test_essai_raw_code_is_untouched_from_v77(self):
        # SHA256 of V10.77 original function sources. Portable without a second ZIP.
        import ast
        now=(ROOT/'retouches_next.py').read_text('utf8')
        golden={
            '_prepare_quick_payload':'dae2468ac66542be74ec0b6b75044a6d2e4b1f0e944a2b71afae3bc89e88d340',
            '_stage_short_source_video':'245a81358ee54782edbbeaaa9bff10e62b033e03f642ba06eb3bc1a461547b8d',
        }
        for name,digest in golden.items():
            node=next(n for n in ast.parse(now).body if isinstance(n,ast.FunctionDef) and n.name==name)
            fragment='\n'.join(now.splitlines()[node.lineno-1:node.end_lineno])
            self.assertEqual(hashlib.sha256(fragment.encode('utf8')).hexdigest(),digest,name)
        self.assertIn('quick_latent_name,quick_temp_path,settings=_prepare_quick_payload(',now)
        self.assertIn("row['mode']=='precise' and not row.get('test_clip')",now)
    @unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'ffmpeg absent')
    def test_reference_exact_39_frames(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);comfy=root/'comfy';comfy.mkdir()
            source=root/'source.mp4'
            p=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',
                '-f','lavfi','-i','testsrc2=size=96x64:rate=24','-frames:v','124',
                '-c:v','libx264','-pix_fmt','yuv420p',str(source)],capture_output=True,text=True,timeout=60)
            self.assertEqual(p.returncode,0,p.stderr[-500:])
            before=hashlib.sha256(source.read_bytes()).hexdigest()
            w=v78.select_window(37,124,4.145,5.167)
            name=v78.stage_reference(source,comfy,'f'*32,w)
            destination=comfy/'input'/name
            p=subprocess.run(['ffprobe','-v','quiet','-select_streams','v:0',
                '-show_entries','stream=nb_frames','-of','default=noprint_wrappers=1:nokey=1',str(destination)],
                capture_output=True,text=True,timeout=30)
            self.assertEqual(p.stdout.strip(),'39')
            self.assertEqual(before,hashlib.sha256(source.read_bytes()).hexdigest())
    def test_saved_window_is_isolated_and_shape_valid(self):
        import torch
        import retouches_new_windowing as win
        with tempfile.TemporaryDirectory() as td:
            src=Path(td)/'clip_0001_RAW_LATENT.pt'
            original={'samples':{'members':[
                {'tensor':torch.arange(37,dtype=torch.float32).reshape(1,1,37,1,1),'shape':(1,1,37,1,1),'device':'cpu'},
                {'tensor':torch.zeros(1,1,2,400),'shape':(1,1,2,400),'device':'cpu'}]},'noise_mask':None}
            torch.save(original,src)
            before=hashlib.sha256(src.read_bytes()).hexdigest()
            output=win.write_window(original,src,'_local_test',25)
            saved=torch.load(output,weights_only=True)
            self.assertEqual(saved['samples']['members'][0]['tensor'].shape[2],12)
            self.assertEqual(saved['samples']['members'][0]['tensor'][0,0,0,0,0].item(),25)
            self.assertEqual(before,hashlib.sha256(src.read_bytes()).hexdigest())

    @unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'ffmpeg absent')
    def test_retake_full_run_uses_local_h3_and_stitches(self):
        import torch
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);comfy=root/'comfy';comfy.mkdir();(comfy/'input').mkdir()
            source=root/'original.mp4';generated=root/'generated.mp4';latent=root/'clip_0001_RAW_LATENT.pt'
            def ff(cmd):
                p=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
                self.assertEqual(p.returncode,0,p.stderr[-500:])
            ff(['ffmpeg','-hide_banner','-loglevel','error','-y',
                '-f','lavfi','-i','testsrc2=size=96x64:rate=24',
                '-frames:v','124','-c:v','libx264','-pix_fmt','yuv420p',str(source)])
            ff(['ffmpeg','-hide_banner','-loglevel','error','-y',
                '-f','lavfi','-i','color=c=red:size=96x64:rate=24',
                '-frames:v','39','-c:v','libx264','-pix_fmt','yuv420p',str(generated)])
            payload={'samples':{'members':[
                {'tensor':torch.zeros(1,1,37,1,1),'shape':(1,1,37,1,1),'device':'cpu'},
                {'tensor':torch.zeros(1,1,2,400),'shape':(1,1,2,400),'device':'cpu'}]},'noise_mask':None}
            torch.save(payload,latent)
            ident='a'*32
            calls=[]
            def fake_build(info,mode,project,clip,src,id,seconds,instruction,rect,**kwargs):
                calls.append((mode,seconds,kwargs))
                return {'902':{'class_type':'H3RetouchMaskV58','inputs':{}},
                        '159':{'class_type':'H3StudioImageToVideo', 'inputs':{'ref_video_files':kwargs['conditioning_video_name']}}}
            def fake_comfy(endpoint,data=None,timeout=None):
                if endpoint=='/object_info':return {key:{} for key in engine.REQUIRED}
                if endpoint=='/prompt':return {'prompt_id':'pid'}
                if endpoint=='/history/pid':return {'pid':{'status':{'status_str':'success'},'outputs':{'191':{}}}}
                raise AssertionError(endpoint)
            def fake_prompt(**kwargs):
                self.assertEqual(kwargs['mode'],'precise')
                self.assertAlmostEqual(kwargs['window']['global_offset'],85/24,places=2)
                self.assertEqual(kwargs['window']['frames'],39)
                return ("<Video 1> = original 39 frames.\n"
                        "SCENE CONTEXT: streameuse devant camera.\n"
                        "NEW TAKE — ONLY THE SHORT LOCAL SHOTS TO GENERATE:\n"
                        "[Shot 1] 0.000–0.583s Elle regarde vers son écran et prépare le geste.\n"
                        "[Shot 2] 0.583–1.625s Elle lève la main puis la redescend.\n"
                        "LOCAL TAKE: exactly 1.625s.", 'gemma26 local stub')
            with patch.object(engine,'ROOT',root/'jobs_root'),patch.object(engine,'JOBS',root/'jobs_root'/'jobs'),\
                 patch.object(engine,'RESULTS',root/'jobs_root'/'results'),\
                 patch.object(engine,'_project',return_value=(source,latent)),\
                 patch.object(engine,'_metadata',return_value={'fps':24,'duration':124/24,'frames':124,'width':96,'height':64}),\
                 patch.object(engine,'_authoring_context',return_value=('Original script',[],[])),\
                 patch.object(engine,'build_graph',side_effect=fake_build),\
                 patch.object(engine.legacy,'comfy_json',side_effect=fake_comfy),\
                 patch.object(engine,'_history_output',return_value=generated),\
                 patch.object(engine,'_measured_visual_change',return_value=20.0),\
                 patch.object(engine.rt,'query_gpu_vram',return_value=None),\
                 patch('retouches_llm_prompt_local_v81.write_prompt',side_effect=fake_prompt),\
                 patch.object(engine.time,'sleep'):
                engine._save({'id':ident,'project':'a','clip':'1','mode':'precise',
                   'instruction':'elle lève la main 4.145–5.167', 'performance_type':'action',
                   'selected':True,'start':4.145,'end':5.167,'test_clip':False,'region':None})
                engine._run(ident,lambda p:root,lambda:comfy)
                record=engine.job(ident)
                self.assertEqual(record['status'],'complete',record.get('error'))
                self.assertEqual(record['engine_path'],'h3_local_retake_v81')
                self.assertEqual(len(calls),1)
                self.assertEqual(calls[0][0],'precise')
                self.assertEqual(calls[0][1]['frames'],39)
                self.assertEqual(calls[0][2]['latent_name'],'clip_0001_RAW_LATENT__local_aaaaaaaa')
                self.assertIn('0.583–1.625s Elle lève la main',calls[0][2]['revised_prompt'])
                self.assertTrue((root/'jobs_root'/'results'/(ident+'.mp4')).is_file())
                self.assertFalse((comfy/'input'/f'h3new_{ident}_precise_window.mp4').exists())
                self.assertFalse((latent.parent/(calls[0][2]['latent_name']+'.pt')).exists())

    @unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe'),'ffmpeg absent')
    def test_stitch_keeps_length_and_audio_and_unchanged_endpoints(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td);source=path/'original.mp4';generated=path/'generated.mp4';output=path/'output.mp4';comfy=path/'comfy';comfy.mkdir()
            # Source: 124 frames at 24fps with audio. Replacement: 39 contrasting frames.
            def run(cmd):
                p=subprocess.run(cmd,capture_output=True,text=True,timeout=90)
                self.assertEqual(p.returncode,0,p.stderr[-1000:])
            run(['ffmpeg','-hide_banner','-loglevel','error','-y',
                '-f','lavfi','-i','testsrc2=size=96x64:rate=24',
                '-f','lavfi','-i','sine=frequency=440:sample_rate=44100',
                '-frames:v','124','-c:v','libx264','-pix_fmt','yuv420p','-c:a','aac','-shortest',str(source)])
            run(['ffmpeg','-hide_banner','-loglevel','error','-y',
                '-f','lavfi','-i','color=c=red:size=96x64:rate=24',
                '-frames:v','39','-c:v','libx264','-pix_fmt','yuv420p',str(generated)])
            for start,end in ((4.145,5.167),(.7,1.3),(0,1.593)):
                w=v78.select_window(37,124,start,end)
                v78.stitch(source,generated,output,w,124,comfy)
                p=subprocess.run(['ffprobe','-v','quiet','-show_streams','-of','json',str(output)],capture_output=True,text=True,timeout=30)
                streams=json.loads(p.stdout)['streams']
                video=next(s for s in streams if s['codec_type']=='video')
                self.assertEqual(int(video['nb_frames']),124)
                self.assertEqual(video['width'],96)
                self.assertTrue(any(s['codec_type']=='audio' for s in streams))

if __name__=='__main__': unittest.main()
