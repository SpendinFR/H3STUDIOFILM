"""Studio UI-only RefBank corrections. Never changes H3/ComfyUI itself.

Appearance edits change only the registered reference, not underlying image bytes;
old clips keep their source files. Canonical character identities are immutable here.
"""
import copy
import json
import os
import re
import time
from pathlib import Path


def _key(name):
    return re.sub(r"[^a-z0-9]+", "_", str(name).casefold().strip()).strip("_")


def _read(file, fallback):
    try:
        return json.loads(file.read_text(encoding='utf-8'))
    except FileNotFoundError:
        return copy.deepcopy(fallback)


def _write(file, data):
    file.parent.mkdir(parents=True, exist_ok=True)
    tmp=file.with_suffix(file.suffix+'.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2),encoding='utf-8')
    os.replace(tmp,file)


def _media_id(r):
    if not isinstance(r,dict):return ''
    return str(r.get('path') or r.get('annotated') or '').replace('\\','/').split(' [input]')[0].casefold()


def _same(a,b):
    pa,pb=_media_id(a),_media_id(b)
    return bool(pa and pb and (pa==pb or pa.endswith('/'+pb) or pb.endswith('/'+pa)))


def _all_entries(static, bank):
    for i,r in enumerate(static):
        if isinstance(r,dict):yield ('static',i,r)
    for section in ('character_appearance','characters','decor','objects','subjects'):
        for key,r in (bank.get(section) or {}).items():
            if isinstance(r,dict):yield (section,key,r)
    if isinstance(bank.get('global_environment'),dict):yield ('global_environment',None,bank['global_environment'])


def _canonical(static,bank,name):
    for _,_,r in _all_entries(static,bank):
        if r.get('kind')=='character' and r.get('role')=='canonical_identity' and _key(r.get('subject_name'))==_key(name):
            return r
    return None


def existing_character_names(project_dir):
    project_dir=Path(project_dir)
    static=_read(project_dir/'refs/static_refs.json',[])
    bank=_read(project_dir/'refs/ref_bank.json',{})
    names=[]
    for _,_,r in _all_entries(static,bank):
        if r.get('kind')=='character':
            name=str(r.get('subject_name') or '').strip()
            if name and _key(name) not in {_key(x) for x in names}:names.append(name)
    return names


def _active_character(static, bank, original_refs, proposed_refs, name, exclude=None):
    """Resolve an explicit appearance target from real character images only.

    New manually-added characters may be in this clip but not yet in the bank;
    these must share the same Subject identity as their appearances.
    """
    canonical=_canonical(static,bank,name)
    if canonical:return canonical
    candidates=list(original_refs)+list(proposed_refs)
    for _,_,row in _all_entries(static,bank):
        candidates.append(row)
    for row in candidates:
        if not isinstance(row,dict) or row is exclude:continue
        if row.get('kind')!='character' or row.get('role') not in ('fully_preserved','canonical_identity'):continue
        if _key(row.get('subject_name'))==_key(name):return row
    return None


def _delete_media(static,bank,reference):
    kept=[];hits=0
    for r in static:
        if _same(r,reference):
            if r.get('role')=='canonical_identity':raise ValueError('Identité canonique protégée : impossible de la supprimer de RefBank')
            hits+=1
        else:kept.append(r)
    static[:]=kept
    for section in ('character_appearance','characters','decor','objects','subjects'):
        entries=bank.get(section) or {}
        for k,r in list(entries.items()):
            if _same(r,reference):
                if r.get('role')=='canonical_identity':raise ValueError('Identité canonique protégée')
                del entries[k];hits+=1
    if _same(bank.get('global_environment'),reference):bank['global_environment']=None;hits+=1
    return hits


def apply(project_dir, original_refs, proposed_refs, spec, deletes=None, commit=False):
    """Returns adjusted clip refs; optionally persists appearance corrections atomically.

    All validation happens on working copies before writing. The caller must commit
    only after the user explicitly approves their clip prompt.
    """
    if project_dir is None:
        if any(x.get('bank_scope')=='bank' for x in spec) or deletes:
            raise ValueError('Projet requis pour corriger RefBank')
        return proposed_refs
    project_dir=Path(project_dir)
    static=_read(project_dir/'refs/static_refs.json',[])
    bank=_read(project_dir/'refs/ref_bank.json',{})
    bank.setdefault('history',[])
    proposed=copy.deepcopy(proposed_refs)
    action_rows=[]
    image_no=0
    for item in spec:
        if item.get('media')!='image':continue
        ref=proposed[image_no];image_no+=1
        if 'index' in item:
            idx=item['index'];source=original_refs[idx]
            if source.get('role')=='canonical_identity' and (str(ref.get('subject_name'))!=str(source.get('subject_name')) or item.get('bank_scope')=='bank'):
                raise ValueError('Pour une identité canonique, modifie seulement son apparence, pas sa banque canonique.')
        else:source=None
        scope=str(item.get('bank_scope') or 'clip')
        if scope not in ('clip','bank'):raise ValueError('Portée RefBank invalide')
        # A film-appearance card being attributed to Matt must take Matt's real
        # Subject key so its Picture joins Matt's canonical reference in the prompt.
        if ref.get('kind')=='character' and ref.get('role')=='film_appearance':
            target=str(item.get('bank_target') or ref.get('subject_name') or '').strip()
            canon=_active_character(static,bank,original_refs,proposed,target,exclude=ref)
            if canon:
                # Appearance pictures MUST share their canonical character's
                # real Subject key even if their old source key was stale.
                ref['subject_name']=canon['subject_name']
                ref['subject_key']=canon.get('subject_key') or 'studio_character_'+_key(target)
            elif item.get('visual_type') == 'appearance':
                raise ValueError('Personnage canonique introuvable pour cette apparence : sélectionne un personnage déjà présent dans le clip ou la RefBank.')
            elif scope=='bank' or (source and ref.get('subject_name')!=source.get('subject_name')):
                # User explicitly moves this appearance to a new noncanonical
                # person; it must not masquerade as a canonical appearance.
                ref['subject_name']=target;ref['subject_key']='studio_character_'+_key(target)
                ref['role']='fully_preserved'
        if scope!='bank':continue
        if source and not any(_same(r,source) for _,_,r in _all_entries(static,bank)):
            raise ValueError('Cette image ne figure plus dans RefBank. Actualise avant de corriger la banque.')
        if ref.get('kind')=='character':
            target=str(item.get('bank_target') or ref.get('subject_name') or '').strip()
            if not target:raise ValueError('Choisis un personnage cible')
            canon=_active_character(static,bank,original_refs,proposed,target,exclude=ref)
            if canon:
                ref['kind']='character';ref['role']='film_appearance'
                ref['subject_name']=canon['subject_name'];ref['subject_key']=canon.get('subject_key') or 'studio_character_'+_key(target)
                section='character_appearance'
            else:
                ref['kind']='character'
                # Explicit new canonical pictures stay canonical when persisted.
                # Never silently downgrade them on commit to the RefBank.
                if ref.get('role') != 'canonical_identity':
                    ref['role']='fully_preserved'
                ref['subject_name']=target;ref['subject_key']='studio_character_'+_key(target)
                section='characters'
            slot=target
        elif ref.get('kind')=='decor':section='decor';slot=ref.get('subject_name')
        elif ref.get('kind')=='object':section='objects';slot=ref.get('subject_name')
        else:section='subjects';slot=ref.get('subject_name')
        if source:_delete_media(static,bank,source)
        # Only one active appearance per canonical character. Existing older
        # frames remain intact on disk for clips that already used them.
        bank.setdefault(section,{})[slot]=copy.deepcopy(ref)
        action_rows.append({'action':'assign','source':_media_id(source) if source else None,'target':slot,'section':section})
    for ix in deletes or []:
        if type(ix)!=int or ix<0 or ix>=len(original_refs):raise ValueError('Suppression RefBank invalide')
        source=original_refs[ix]
        if source.get('role')=='canonical_identity':raise ValueError('Identité canonique protégée : suppression impossible')
        count=_delete_media(static,bank,source)
        if not count:raise ValueError('Référence à supprimer introuvable dans RefBank')
        action_rows.append({'action':'remove','source':_media_id(source)})
    if commit and action_rows:
        bank['history'].append({'kind':'studio_reference_correction','at':time.time(),'changes':action_rows})
        _write(project_dir/'refs/static_refs.json',static)
        _write(project_dir/'refs/ref_bank.json',bank)
    return proposed
