"""Non-destructive review decisions and approved MP4 archive.

Never synthesizes or replaces an H3 latent. Project approvals are handoff
previews, NOT replacements for the RAW .pt consumed by Film Studio refine.
"""
from __future__ import annotations
import json
import os
import re
import shutil
import threading
import time
import uuid
from pathlib import Path
import retouches_engine as legacy
import retouches_next as native

ROOT = Path(__file__).resolve().parent / 'studio_sessions' / 'retouches' / 'review'
LOCK = threading.RLock()
ID = re.compile(r'[a-f0-9]{32}\Z')
KINDS = ('legacy','new')


def _validate(kind, ident):
    if kind not in KINDS or not ID.fullmatch(str(ident or '')):
        raise ValueError('Identifiant de rendu invalide')


def _entry(kind, ident):
    _validate(kind, ident)
    row = legacy.job(ident) if kind == 'legacy' else native.job(ident)
    if row.get('status') != 'complete':
        raise ValueError('Le rendu doit être terminé avant cette action')
    if bool(row.get('mask_only')):
        raise ValueError('Un aperçu de masque ne peut pas être validé comme rendu')
    path = legacy.job_result(ident) if kind == 'legacy' else native.output(ident)
    if not path or not Path(path).is_file():
        raise ValueError('Le MP4 du rendu n’est plus disponible')
    return row, Path(path)


def _decision_file(kind, ident):
    _validate(kind, ident)
    return ROOT / 'decisions' / f'{kind}_{ident}.json'


def _read(kind, ident):
    path=_decision_file(kind,ident)
    try:return json.loads(path.read_text(encoding='utf-8'))
    except (OSError,ValueError):return {}


def _save(record):
    path=_decision_file(record['kind'],record['id'])
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.'+uuid.uuid4().hex+'.tmp')
    try:
        tmp.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
        os.replace(tmp,path)
    finally:tmp.unlink(missing_ok=True)


def _origin(kind,row):
    if kind == 'new':
        return (str(row.get('project') or ''),str(row.get('clip') or ''))
    src=row.get('source') or {}
    # Follow both engine families. Only server-owned, completed job IDs may
    # establish provenance; a client cannot claim another project's RAW.
    seen=set()
    for _ in range(50):
        if src.get('type')=='project':
            return str(src.get('project') or ''),str(src.get('clip') or '')
        if src.get('type')!='review' or src.get('kind') not in KINDS:break
        ident=str(src.get('id') or '')
        key=(src['kind'],ident)
        if not ID.fullmatch(ident) or key in seen:break
        seen.add(key)
        try:
            parent=(legacy.job(ident) if src['kind']=='legacy' else native.job(ident))
            if parent.get('status')!='complete':break
            if _read(src['kind'],ident).get('state')=='cancelled':break
        except ValueError:break
        if src['kind']=='new':
            previous=parent.get('source') or {}
            src=previous if previous else {'type':'project','project':parent.get('project'),'clip':parent.get('clip')}
        else:
            src=parent.get('source') or {}
    return ('','')


def source_project_clip(kind, ident):
    """Retrieve an authenticated V2 result's originating FilmMaker RAW."""
    try:
        row,_path=_entry(kind,ident)
        if _read(kind,ident).get('state')=='cancelled':return ('','')
        return _origin(kind,row)
    except ValueError:return ('','')


def result_path(kind, ident):
    """Completed output from either family, for successive MP4 edits."""
    try:
        _row,path=_entry(kind,ident)
        if _read(kind,ident).get('state')=='cancelled':return None
        return path
    except ValueError:return None


def choices():
    result={}
    directory=ROOT/'decisions'
    for path in directory.glob('*.json') if directory.is_dir() else []:
        try:
            record=json.loads(path.read_text(encoding='utf-8'))
            _validate(record.get('kind'),record.get('id'))
            result[f"{record['kind']}:{record['id']}"]={k:record.get(k) for k in ('state','saved_url','project','clip','updated_at')}
        except (OSError,ValueError):continue
    return result


def decision(kind,ident):
    """Read server-owned decision; never trust client-declared ancestry."""
    _validate(kind,ident)
    return _read(kind,ident)


def approved_file(kind,ident):
    _validate(kind,ident)
    record=_read(kind,ident)
    if record.get('state') not in ('approved','continued'):return None
    path=ROOT/'approved'/f'{kind}_{ident}.mp4'
    return path if path.is_file() else None


def decide(kind, ident, action):
    if action not in ('redo','continue','approve','cancel'):
        raise ValueError('Décision inconnue')
    with LOCK:
        row,path=_entry(kind,ident)
        project,clip=_origin(kind,row)
        record=_read(kind,ident)
        if action in ('approve','continue'):
            dest=ROOT/'approved'/f'{kind}_{ident}.mp4'
            dest.parent.mkdir(parents=True,exist_ok=True)
            if not dest.is_file():
                tmp=dest.with_name(dest.name+'.'+uuid.uuid4().hex+'.tmp')
                try:
                    shutil.copyfile(path,tmp)
                    os.replace(tmp,dest)
                finally:tmp.unlink(missing_ok=True)
            record.update({'state':'approved' if action=='approve' else 'continued',
                           'saved_url':f'/api/retouches/review/saved/{kind}/{ident}',
                           'saved_path':str(dest)})
        else:
            record.update({'state':{'cancel':'cancelled','redo':'redo','continue':'continued'}[action]})
        record.update({'kind':kind,'id':ident,'project':project,'clip':clip,'updated_at':time.time()})
        _save(record)
        # Never alter original RAW/latent or Film Studio source registry.
        return {k:record.get(k) for k in ('kind','id','state','project','clip','saved_url','updated_at')}
