"""Safe Studio time-extension operations. Existing rendered clips are immutable.

No extension is applied in the middle of a scene. The engine accepts one request
at the next scene boundary, then Content and Scene Directors rebuild only the
unrendered suffix. The original H3 pipeline is untouched.
"""
from __future__ import annotations
import copy
import json
import os
from pathlib import Path
from typing import Any


def pending_path(project_dir: Path) -> Path:
    return Path(project_dir) / '_studio' / 'timeline_extension_pending.json'


def read_pending(project_dir: Path) -> dict[str, Any] | None:
    p = pending_path(project_dir)
    if not p.is_file():
        return None
    try:
        obj = json.loads(p.read_text(encoding='utf-8'))
        extra = int(obj['extra_seconds'])
        if extra < 0 or extra > 3600 or extra % 5:
            raise ValueError('extension time must be a multiple of 5 seconds, 0..3600')
        if not extra and not str(obj.get('instructions') or '').strip():
            raise ValueError('nothing to change')
        return obj
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise ValueError(f'Demande de prolongation invalide : {exc}') from exc


def extension_part(content: dict, all_scenes: list[dict], next_index: int,
                   extra_seconds: int, development: str, tc) -> tuple[dict, dict]:
    """Pure preparation. Never mutate current timeline before model validation."""
    old_end = int(all_scenes[-1]['end_seconds'])
    boundary = int(all_scenes[next_index]['start_seconds']) if next_index < len(all_scenes) else old_end
    if boundary > old_end or boundary < 0:
        raise ValueError('Frontière de scène invalide')
    end = old_end + int(extra_seconds)
    if end <= boundary:
        raise ValueError('Aucune scène restante à modifier : ajoute au moins 5 secondes')
    keep = []
    for raw in content['parts']:
        part = copy.deepcopy(raw)
        if int(part['start_seconds']) >= boundary:
            continue
        if int(part['end_seconds']) > boundary:
            part['end_seconds'] = boundary
            part['end'] = tc(boundary)
            part['duration_seconds'] = boundary-int(part['start_seconds'])
        if part['duration_seconds'] > 0:
            keep.append(part)
    number = max((int(x['part']) for x in content['parts']), default=0) + 1
    part = {
        'part': number, 'kind': 'PARTIE', 'label': f'Suite révisée {number}',
        'name': f'PARTIE {number} — suite révisée',
        'start_seconds': boundary, 'end_seconds': end,
        'duration_seconds': end-boundary,
        'start': tc(boundary), 'end': tc(end),
        'function': 'Continuer la narration depuis le dernier clip validé',
        'development': str(development).strip(),
        'source_block': str(development).strip(),
    }
    revised = copy.deepcopy(content)
    revised['parts'] = keep + [part]
    revised['requested_duration_seconds'] = end
    revised['requested_duration'] = tc(end)
    return revised, part


def validate_future_scenes(scenes: list[dict], part: dict, scene_number: int) -> None:
    if not scenes:
        raise ValueError('Le Scene Director n’a proposé aucune scène')
    if int(scenes[0]['start_seconds']) != int(part['start_seconds']):
        raise ValueError('La première scène ne commence pas à la frontière sûre')
    if int(scenes[-1]['end_seconds']) != int(part['end_seconds']):
        raise ValueError('La dernière scène ne couvre pas la durée prolongée')
    previous = int(part['start_seconds'])
    for offset, scene in enumerate(scenes):
        start, end = int(scene['start_seconds']), int(scene['end_seconds'])
        if int(scene['scene']) != scene_number+offset:
            raise ValueError('Numérotation des scènes non continue')
        if start != previous or not (5 <= end-start <= 60) or (end-start) % 5:
            raise ValueError(f'Scène {scene["scene"]}: trou, chevauchement ou durée hors contrat H3')
        previous = end


def atomic_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2),encoding='utf-8')
    os.replace(tmp, path)
