"""Dedicated Roycho/MVEx insertion graph, using *actual* upstream crop/uncrop nodes.

No Krea, no picture pasted into the shot. A user instruction and optional existing
rectangle are sufficient. The saved original RAW .pt is loaded only to recover
H3's exact time grid and never modified. MVEx SubjectCrop makes a *new* locally
encoded working latent: using a changing spatial crop directly on the original
full-frame .pt would be incorrect. Outside the edited region, SubjectUncrop
reuses the original source video's frames. Audio comes from the original clip.
"""
from __future__ import annotations

MODEL='Minimax-h3_Singularity_ref2va_Pruned_v1.3_int8.safetensors'
TEXT='qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors'
VIDEO_VAE='minimax_h3_video_vae_fp16.safetensors'
AUDIO_VAE='minimax_h3_audio_vae_fp32.safetensors'


def _node(class_type, **inputs):
    return {'class_type': class_type, 'inputs': inputs}


def _inputs_schema(info,kind):
    spec=(info.get(kind) or {}).get('input') or {}
    return {**(spec.get('required') or {}),**(spec.get('optional') or {})}


def _default(spec):
    if isinstance(spec,(list,tuple)) and len(spec)>1 and isinstance(spec[1],dict):
        return spec[1].get('default')
    return None


def build(info, *, ident, source, source_filename, project,clip,seconds,instruction,rect,latent_name,guide_image_name=None,insert_reference_name=None,model=MODEL,h3_prompt_override=None):
    """Build the complete Roycho-style isolated graph: no FilmMaker graph modified."""
    if not source_filename or '\\' in source_filename or '/' in source_filename:
        raise ValueError('Roycho : la vidéo source doit être dans ComfyUI/input')
    required={
      'H3LoadRawLatentExact','H3RoychoAnimatedMaskV62','LoadVideo','GetVideoComponents',
      'MVEx_MaskCleanup','MVEx_SubjectCrop','MVEx_MaskToLatentSpace','MVEx_SubjectUncrop',
      'VAELoader','CLIPLoader','UNETLoader','MiniMaxH3SigmaShift','VAEEncode','GetImageSizeAndCount',
      'SetLatentNoiseMask','VAEEncodeAudio','LTXVConcatAVLatent',
      'MiniMaxH3ReferenceToVideo','BasicGuider','RandomNoise','BasicScheduler',
      'KSamplerSelect','SamplerCustomAdvanced','LTXVSeparateAVLatent','VAEDecode',
      'CreateVideo','SaveVideo','LoadImage','H3RoychoCropGuideV64','MiniMaxH3AddGuide',
    }
    missing=sorted(required-set(info))
    if missing:
        raise RuntimeError('Roycho complet : nœuds absents : '+', '.join(missing)+'. Relance installateur et redémarre ComfyUI.')
    x,y,w,h=rect
    if not (0<=x<100 and 0<=y<100 and 0<w<=100-x and 0<h<=100-y):
        raise ValueError('Roycho : région d’insertion invalide')
    if not (0<=seconds['start']<seconds['end']<=seconds['duration']+.02):
        raise ValueError('Roycho : intervalle d’insertion invalide')
    if (int(seconds['frames'])-5)%17:
        raise ValueError('Roycho : la vidéo doit suivre la cadence MiniMax H3 5+17n')

    g={}
    def add(nid,kind,**kwargs):
        g[str(nid)]=_node(kind,**kwargs)
    add(901,'H3LoadRawLatentExact',project_name=project,latent_name=latent_name)
    add(1,'LoadVideo',file=source_filename)
    add(2,'GetVideoComponents',video=['1',0])
    add(902,'H3RoychoAnimatedMaskV62',latent=['901',0],source_video=str(source),
        start_seconds=float(seconds['start']),end_seconds=float(seconds['end']),
        x_pct=float(x),y_pct=float(y),w_pct=float(w),h_pct=float(h))
    # Authentic MaskVidExperiments chain from the Roycho graph. No synthetic
    # substitute for crop/uncrop: mask follows the original full clip timeline.
    add(11,'MVEx_MaskCleanup',masks=['902',0],threshold=.35,method='components',
        **{'method.min_pixels':24,'method.min_frames':1},edge_grow=4)
    add(25,'MVEx_SubjectCrop',original_images=['2',0],masks=['11',0],mode='tracked',
        **{'mode.crop_scale':1.8,'mode.padding':'firm',
           'mode.prefer':'stillness','mode.seamless_loop':False,
           'mode.aspect_ratio':0.0},
        divisible_by=32,upscale_megapixels=0.0,resize_method='auto')
    add(26,'GetImageSizeAndCount',image=['25',0])
    add(20,'VAELoader',vae_name=VIDEO_VAE)
    add(21,'VAELoader',vae_name=AUDIO_VAE)
    add(22,'CLIPLoader',clip_name=TEXT,type='minimax',device='default')
    add(23,'UNETLoader',unet_name=model,weight_dtype='default')
    add(24,'MiniMaxH3SigmaShift',model=['23',0],shift_video=12.0,shift_audio=3.0)
    add(27,'VAEEncode',pixels=['25',0],vae=['20',0])
    add(28,'MVEx_MaskToLatentSpace',masks=['25',1],vae=['20',0],
        compression='auto',spatial_method='max',temporal_method='max',
        grow_spatial=6,grow_temporal=1,grow_temp_mode='both')
    add(29,'SetLatentNoiseMask',samples=['27',0],mask=['28',0])
    add(30,'VAEEncodeAudio',audio=['2',1],vae=['21',0])
    add(31,'LTXVConcatAVLatent',video_latent=['29',0],audio_latent=['30',0])
    target_prompt=(
        'For the target video, <Video 1> is the existing real shot and determines '
        'the scene, camera motion, actor identities, environment and scale. '
        'Modify only the specified insertion region. [Shot 1] '+instruction.strip()+'. '
        'The introduced object or subject is physically part of the scene and must already be '
        'visible from the FIRST generated frame of the edited interval; no delayed appearance, '
        'fade-in or gradual arrival unless the instruction explicitly asks for it. '
        'Use any provided guide only as appearance support. Ensure correct depth, occlusion, '
        'perspective, shadows, interactions and persistent motion for as long as the described '
        'event requires. Do not paste a flat image, insert a picture frame, change the lens, or restage the shot.'
    )
    if h3_prompt_override is not None:
        # The real Gemma H3 prompt replaces the old fixed template, not merely
        # the metadata displayed by the Studio UI.
        target_prompt=str(h3_prompt_override).strip()
        if not target_prompt or '<Video 1>' not in target_prompt:
            raise ValueError('Insertion : prompt Gemma H3 manquant ou sans <Video 1>')
        if bool(insert_reference_name) != ('<Picture 1>' in target_prompt):
            raise ValueError('Insertion : référence <Picture 1> non cohérente avec le prompt Gemma')
    if insert_reference_name:
        # H3 image-reference channel, not an overlay or a static guide frame.
        if chr(92) in insert_reference_name or '/' in insert_reference_name:
            raise ValueError('Roycho : image de référence doit résider dans ComfyUI/input')
        add(46,'LoadImage',image=insert_reference_name)
        ref_inputs={'ref_videos.ref_video_0':['25',0], 'ref_images.ref_image_0':['46',0]}
        if h3_prompt_override is None:
            target_prompt += ' <Picture 1> is the APPEARANCE reference for the NEW element, not a picture to display in the scene.'
    else:
        ref_inputs={'ref_videos.ref_video_0':['25',0]}
    add(33,'MiniMaxH3ReferenceToVideo',clip=['22',0],vae=['20',0],audio_vae=['21',0],
        prompt=target_prompt,width=['26',1],height=['26',2],length=['26',3],
        ref_image_size='match',**ref_inputs)
    if not guide_image_name:
        raise ValueError('Roycho : aucun guide d’insertion validé. H3 refusé avant le GPU.')
    if '\\' in guide_image_name or '/' in guide_image_name:
        raise ValueError('Roycho : guide doit résider dans ComfyUI/input')
    add(43,'LoadImage',image=guide_image_name)
    add(44,'H3RoychoCropGuideV64',full_image=['43',0],bboxes=['25',2],
        cropped_images=['25',0],frame_index=min(int(seconds['frames'])-1,int(seconds['start']*24)))
    add(45,'MiniMaxH3AddGuide',positive=['33',0],latent=['31',0],vae=['20',0],
        image=['44',0],frame_idx=min(int(seconds['frames'])-1,int(seconds['start']*24)))
    add(34,'BasicGuider',model=['24',0],conditioning=['45',0])
    add(35,'RandomNoise',noise_seed=int(ident[:13],16) % (2**53))
    add(36,'BasicScheduler',model=['24',0],scheduler='simple',steps=20,denoise=1.)
    add(37,'KSamplerSelect',sampler_name='euler')
    add(38,'SamplerCustomAdvanced',noise=['35',0],guider=['34',0],
        sampler=['37',0],sigmas=['36',0],latent_image=['31',0])
    add(39,'LTXVSeparateAVLatent',av_latent=['38',1])
    add(40,'VAEDecode',samples=['39',0],vae=['20',0])
    add(41,'MVEx_SubjectUncrop',cropped_images=['40',0],original_images=['2',0],
        bboxes=['25',2],cropped_masks=['25',1],feather=16,resize_method='auto')
    cv=_inputs_schema(info,'CreateVideo')
    kwargs={'images':['41',0],'audio':['2',1]}
    if 'fps' in cv:kwargs['fps']=24.
    if 'frame_rate' in cv:kwargs['frame_rate']=24.
    if 'bit_depth' in cv:kwargs['bit_depth']=8
    if 'color_space' in cv:kwargs['color_space']='sRGB'
    if 'codec' in cv:kwargs['codec']='none'
    add(190,'CreateVideo',**kwargs)
    sv=_inputs_schema(info,'SaveVideo')
    kwargs={'video':['190',0],'filename_prefix':f'h3_roycho_v1064/{ident}_RAW'}
    for key,value in [('format','mp4'),('format.codec','h264'),
                      ('format.codec.encoding','re-encode'),('format.codec.encoding.crf',16)]:
        if key in sv or key.split('.')[0] in sv:kwargs[key]=value
    add(191,'SaveVideo',**kwargs)
    # Be strict: never silently replace the actual MVEx nodes with a homemade mask
    # or default to a prompt-only H3 generation.
    assert g['34']['inputs']['conditioning']==['45',0]
    assert g['38']['inputs']['latent_image']==['31',0]
    assert g['41']['inputs']['original_images']==['2',0]
    return g
