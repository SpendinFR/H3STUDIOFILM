"""V10.82 experimental precise Retake: generate roughly half the clip with one seam.

If the selected edit is in the first half of the clip, generate the first half
and keep the original suffix. If the selected edit is in the second half,
generate the second half and keep the original prefix.
"""
from __future__ import annotations
from pathlib import Path
import copy, json, shutil, subprocess
import torch

FPS=24

def _bin(comfy:Path,name:str)->str:
    return shutil.which(name) or str(comfy.parent/'ffmpeg'/'bin'/(name+'.exe'))


def _frame_count(path:Path,comfy:Path)->int:
    cmd=[_bin(comfy,'ffprobe'),'-v','error','-select_streams','v:0',
         '-count_frames','-show_entries','stream=nb_frames,nb_read_frames',
         '-of','json',str(path)]
    proc=subprocess.run(cmd,capture_output=True,text=True,timeout=45)
    if proc.returncode:
        raise RuntimeError('Retake demi-clip : vérification ffprobe impossible : '+proc.stderr[-500:])
    data=(json.loads(proc.stdout).get('streams') or [{}])[0]
    try:
        return int(data.get('nb_frames') or data.get('nb_read_frames'))
    except Exception as exc:
        raise RuntimeError('Retake demi-clip : nombre d’images indisponible pour '+path.name) from exc


def _window_frames_from_latent(window_t:int)->int:
    return round(5+17*(window_t-2)/5)


def select_window(total_latent:int,total_frames:int,begin:float,end:float)->dict:
    if total_latent<12:
        raise ValueError('Retake demi-clip : RAW trop court')
    expected=_window_frames_from_latent(total_latent)
    if expected != total_frames:
        raise ValueError(f'Retake demi-clip : durée MP4/RAW incohérente ({total_frames} images MP4, {expected} images déduites du RAW).')
    first=max(0,min(total_frames-1,int(round(begin*FPS))))
    last=max(first+1,min(total_frames,int(round(end*FPS))))
    midpoint=(first+last)/2.0
    half_t=max(12,(total_latent+1)//2)  # ceil(total_latent/2)
    frames=_window_frames_from_latent(half_t)
    if midpoint <= total_frames/2.0:
        start_latent=0
        origin=0
        seam_mode='suffix_only'
    else:
        start_latent=total_latent-half_t
        origin=round(start_latent*17/5)
        seam_mode='prefix_only'
    end_frame=min(total_frames, origin+frames)
    # V10.85: never crop the user's requested edit invisibly at the join.
    # The generated first/last half MUST contain the entire selected range.
    if first < origin or last > end_frame:
        raise ValueError('Retake demi-clip : la plage sélectionnée chevauche la jonction des deux moitiés '
                         'ou dépasse la demi-fenêtre choisie. Choisis un intervalle entièrement dans une seule moitié.')
    local_first=first-origin
    local_last=last-origin
    if not (0 <= local_first < local_last <= end_frame-origin):
        raise ValueError('Retake demi-clip : la sélection ne rentre pas dans la demi-fenêtre choisie.')
    return {
        'start_latent':start_latent,
        'latent_t':half_t,
        'origin_frame':origin,
        'end_frame':end_frame,
        'frames':end_frame-origin,
        'duration':(end_frame-origin)/FPS,
        'first_frame':first,
        'last_frame':last,
        'local_first':local_first,
        'local_last':local_last,
        'start':local_first/FPS,
        'end':local_last/FPS,
        'global_offset':origin/FPS,
        'seam_mode':seam_mode,
    }



def render_window_with_preroll(window:dict,total_latent:int,total_frames:int,preroll_tokens:int=3)->dict:
    """Render the late half with leading RAW temporal context.

    H3 39-frame retake previously discarded its first generated frames when
    stitching the user's selection. A 63-frame half-clip has *no* such warm-up
    at its first join. Generate a slightly longer window, discard its front,
    then use ALL 63 desired frames with exactly one boundary splice.
    Original RAW and final 63-frame half are never changed.
    """
    render=dict(window)
    render['preroll_frames']=0
    render['stitch_start_frame']=int(window['origin_frame'])
    render['stitch_frames']=int(window['frames'])
    if window['seam_mode']!='prefix_only' or int(window['start_latent'])==0:
        return render
    lead_t=min(preroll_tokens,int(window['start_latent']))
    first_t=int(window['start_latent'])-lead_t
    first_frame=round(first_t*17/5)
    offset=int(window['origin_frame'])-first_frame
    if offset<=0:
        raise ValueError('Retake H3 : pre-roll RAW absent')
    render['start_latent']=first_t
    render['latent_t']=int(window['latent_t'])+lead_t
    render['origin_frame']=first_frame
    render['frames']=_window_frames_from_latent(int(render['latent_t']))
    if render['frames'] != total_frames-first_frame:
        raise ValueError('Retake H3 : grille RAW de pré-roll désalignée')
    if int(render['latent_t'])+first_t!=total_latent:
        raise ValueError("Retake H3 : l'extension RAW ne finit pas sur le dernier token")
    render['end_frame']=total_frames
    render['duration']=render['frames']/FPS
    render['global_offset']=first_frame/FPS
    render['local_first']=int(window['first_frame'])-first_frame
    render['local_last']=int(window['last_frame'])-first_frame
    render['start']=render['local_first']/FPS
    render['end']=render['local_last']/FPS
    render['preroll_frames']=offset
    return render


def trim_preroll(generated:Path,window:dict,render_window:dict,comfy:Path,target:Path)->Path:
    """Trim ONLY the warm-up lead, preserving the full desired 63-frame half."""
    count=int(render_window['frames'])
    discard=int(render_window['preroll_frames'])
    expected=int(window['frames'])
    if discard==0:
        if count!=expected:raise ValueError('Retake : durée sans pre-roll incorrecte')
        return _normalize_generated_frames(generated,expected,comfy)
    if count-discard!=expected:
        raise ValueError('Retake H3 : pre-roll / moitié ne concordent pas')
    video=_normalize_generated_frames(generated,count,comfy)
    vf=f'trim=start_frame={discard}:end_frame={count},setpts=PTS-STARTPTS'
    cmd=[_bin(comfy,'ffmpeg'),'-hide_banner','-loglevel','error','-y','-i',str(video),
         '-vf',vf,'-an','-frames:v',str(expected),'-c:v','libx264',
         '-preset','veryfast','-crf','17','-pix_fmt','yuv420p',str(target)]
    proc=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
    if proc.returncode or not target.is_file():
        raise RuntimeError('Retake H3 : suppression du pre-roll échouée : '+proc.stderr[-900:])
    if _frame_count(target,comfy)!=expected:
        target.unlink(missing_ok=True)
        raise RuntimeError('Retake H3 : le découpage du pre-roll a changé la durée')
    return target

def write_window(saved:dict,latent_path:Path,latent_name:str,window:dict)->Path:
    members=(saved['samples'] or {}).get('members') or []
    if len(members)<2:
        raise ValueError('Latent H3 RAW incompatible')
    video=members[0].get('tensor'); audio=members[1].get('tensor')
    if not isinstance(video,torch.Tensor) or video.ndim!=5 or not isinstance(audio,torch.Tensor) or audio.ndim!=4:
        raise ValueError('Structure RAW H3 incompatible')
    total_t=int(video.shape[2])
    first=int(window['start_latent']); win_t=int(window['latent_t'])
    if first<0 or first+win_t>total_t:
        raise ValueError('Fenêtre demi-clip hors clip')
    orig_frames=_window_frames_from_latent(total_t)
    audio_size=int(audio.shape[-1])
    first_frame=int(window['origin_frame'])
    audio_first=round(audio_size*first_frame/max(1,orig_frames))
    audio_frames=max(1,round(audio_size*int(window['frames'])/max(1,orig_frames)))
    audio_first=min(audio_first,max(0,audio_size-audio_frames))
    v=video[:,:,first:first+win_t,:,:].contiguous()
    a=audio[...,audio_first:audio_first+audio_frames].contiguous()
    out=copy.copy(saved)
    pack=dict(saved['samples'])
    parts=[dict(x) for x in members]
    parts[0].update(tensor=v,shape=tuple(v.shape),device='cpu')
    parts[1].update(tensor=a,shape=tuple(a.shape),device='cpu')
    pack['members']=parts
    out.update(samples=pack,noise_mask=None)
    dest=latent_path.with_name(latent_name+'.pt')
    torch.save(out,dest)
    return dest


def stage_reference(source:Path,comfy:Path,ident:str,window:dict)->str:
    output=comfy/'input'/f'h3new_{ident}_precise_half_window.mp4'
    output.parent.mkdir(parents=True,exist_ok=True)
    filt=f'trim=start_frame={window["origin_frame"]}:end_frame={window["end_frame"]},setpts=PTS-STARTPTS'
    cmd=[_bin(comfy,'ffmpeg'),'-hide_banner','-loglevel','error','-y','-i',str(source),
         '-vf',filt,'-an','-frames:v',str(window['frames']),'-c:v','libx264','-preset','veryfast',
         '-crf','17','-pix_fmt','yuv420p','-movflags','+faststart',str(output)]
    proc=subprocess.run(cmd,capture_output=True,text=True,timeout=120)
    if proc.returncode or not output.is_file():
        raise RuntimeError('Retake demi-clip : extraction de la référence échouée : '+proc.stderr[-700:])
    if _frame_count(output,comfy)!=int(window['frames']):
        raise RuntimeError('Retake demi-clip : la référence recadrée ne contient pas le bon nombre d’images')
    return output.name


def _normalize_generated_frames(generated:Path,expected_frames:int,comfy:Path)->Path:
    actual=_frame_count(generated,comfy)
    if actual==expected_frames:
        return generated
    # Accept small drift from H3 / container muxing and normalize it.
    # Too-large mismatches still indicate the wrong clip was rendered.
    if actual<=0 or abs(actual-expected_frames)>12:
        raise RuntimeError(f'Retake demi-clip : H3 a rendu {actual} images au lieu de {expected_frames}. Raccord annulé.')
    normalized=generated.with_name(generated.stem+f'_norm_{expected_frames}f'+generated.suffix)
    vf=[]
    if actual<expected_frames:
        pad=expected_frames-actual
        vf.append(f'tpad=stop_mode=clone:stop_duration={pad/24.0:.6f}')
    vf.append(f'trim=start_frame=0:end_frame={expected_frames}')
    vf.append('setpts=PTS-STARTPTS')
    cmd=[_bin(comfy,'ffmpeg'),'-hide_banner','-loglevel','error','-y','-i',str(generated)]
    cmd+=['-vf',','.join(vf),'-frames:v',str(expected_frames),'-map','0:v:0','-map','0:a:0?','-c:v','libx264','-preset','veryfast','-crf','17','-pix_fmt','yuv420p','-c:a','aac','-ar','44100',str(normalized)]
    proc=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
    if proc.returncode or not normalized.is_file():
        raise RuntimeError('Retake demi-clip : normalisation du nombre d’images échouée : '+proc.stderr[-900:])
    fixed=_frame_count(normalized,comfy)
    if fixed!=expected_frames:
        raise RuntimeError(f'Retake demi-clip : normalisation incomplète ({fixed}/{expected_frames} images).')
    return normalized


def stitch(original:Path,generated:Path,target:Path,window:dict,total_frames:int,comfy:Path)->Path:
    """Single-seam Retake: restore the four-frame ORIGINAL/NEW blend from V10.78.

    V10.82/V10.83 accidentally replaced the proven four-frame transition
    with a hard concat. Fade only the junction of the half-clip; do not
    reconstruct or blend a second junction. Preserve original audio.
    """
    gen_frames=int(window['frames'])
    generated=_normalize_generated_frames(generated,gen_frames,comfy)
    mode=window['seam_mode']
    origin=int(window['origin_frame']); end=int(window['end_frame'])
    if end-origin!=gen_frames or origin<0 or end>total_frames:
        raise ValueError('Retake demi-clip : fenetre / index de raccord incoherents')
    if mode not in ('suffix_only','prefix_only'):
        raise ValueError('Retake demi-clip : mode de raccord inconnu')
    streams=[]; segments=[]
    # Four frames as used by the working 39-frame retake, not a new node or
    # a second interpolation engine. Any overlap is limited to the single cut.
    fade=min(4,gen_frames)
    if mode=='prefix_only':
        if origin:
            streams.append(f'[0:v]trim=start_frame=0:end_frame={origin},setpts=PTS-STARTPTS,format=yuv420p[p]')
            segments.append('[p]')
            # At the incoming boundary: original -> regenerated, 25/50/75/100%.
            streams.append(f'[0:v]trim=start_frame={origin}:end_frame={origin+fade},setpts=PTS-STARTPTS,format=yuv420p[old]')
            streams.append(f'[1:v]trim=start_frame=0:end_frame={fade},setpts=PTS-STARTPTS,format=yuv420p[new]')
            weight=f'min(1,(N+1)/{fade})'
            streams.append(f"[old][new]blend=all_expr='A*(1-({weight}))+B*({weight})'[transition]")
            segments.append('[transition]')
        else:
            fade=0
        if fade<gen_frames:
            streams.append(f'[1:v]trim=start_frame={fade}:end_frame={gen_frames},setpts=PTS-STARTPTS,format=yuv420p[generated]')
            segments.append('[generated]')
    else:
        if end<total_frames:
            keep=gen_frames-fade
            if keep:
                streams.append(f'[1:v]trim=start_frame=0:end_frame={keep},setpts=PTS-STARTPTS,format=yuv420p[generated]')
                segments.append('[generated]')
            # At the outgoing boundary: regenerated -> original, 25/50/75/100%.
            streams.append(f'[1:v]trim=start_frame={keep}:end_frame={gen_frames},setpts=PTS-STARTPTS,format=yuv420p[new]')
            streams.append(f'[0:v]trim=start_frame={end-fade}:end_frame={end},setpts=PTS-STARTPTS,format=yuv420p[old]')
            weight=f'min(1,(N+1)/{fade})'
            streams.append(f"[new][old]blend=all_expr='A*(1-({weight}))+B*({weight})'[transition]")
            segments.append('[transition]')
            streams.append(f'[0:v]trim=start_frame={end}:end_frame={total_frames},setpts=PTS-STARTPTS,format=yuv420p[s]')
            segments.append('[s]')
        else:
            streams.append(f'[1:v]trim=start_frame=0:end_frame={gen_frames},setpts=PTS-STARTPTS,format=yuv420p[generated]')
            segments.append('[generated]')
    if not segments:
        raise ValueError('Retake demi-clip : raccord vide')
    streams.append(''.join(segments)+f'concat=n={len(segments)}:v=1:a=0[outv]')
    target.parent.mkdir(parents=True,exist_ok=True)
    cmd=[_bin(comfy,'ffmpeg'),'-hide_banner','-loglevel','error','-y','-i',str(original),
         '-i',str(generated),'-filter_complex',';'.join(streams),
         '-map','[outv]','-map','0:a:0?',
         '-c:v','libx264','-preset','veryfast','-crf','17','-pix_fmt','yuv420p',
         '-c:a','aac','-ar','44100','-frames:v',str(total_frames),str(target)]
    proc=subprocess.run(cmd,capture_output=True,text=True,timeout=360)
    if proc.returncode or not target.is_file():
        raise RuntimeError('Retake demi-clip : raccord ffmpeg échoué : '+proc.stderr[-1300:])
    if _frame_count(target,comfy)!=total_frames:
        target.unlink(missing_ok=True)
        raise RuntimeError('Retake demi-clip : le raccord a modifié le nombre d’images. Sortie refusée.')
    return target
