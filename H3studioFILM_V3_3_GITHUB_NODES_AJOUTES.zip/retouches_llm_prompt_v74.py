"""V10.72 timeline-bound prompt + short scene context: short scene context + NEW TAKE, no source script: reuses FilmMaker's established LLM
loading, chat and unloading functions. H3's original RAW video/latent (not this
text) is the visual reference. This module never runs pip or installs models.
"""
from __future__ import annotations
import os
import re
import shutil
import subprocess
import time
from pathlib import Path

SYSTEM = """You are the shot director rewriting a COMPLETE existing MiniMax H3 clip.
You have the FULL ORIGINAL H3 PROMPT and a USER CHANGE. The real footage is
provided to the VIDEO GENERATOR as <Video 1> (you do not see frames yourself).
Your task is to author a NEW complete shot-by-shot prompt, not summarize the
existing one or append a little phrase inside an unchanged old shot.

INTERPRET THE USER REQUEST BY COMPARING IT WITH THE ORIGINAL SCRIPT:
- First identify the original action(s) the request refers to. Decide whether the
  request introduces a genuinely NEW action, refines an ALREADY EXISTING action,
  explicitly replaces an action, or changes the emotional performance.
- MODIFY_EXISTING: if the user changes an attribute, participant, target,
  direction, speed, object or quality for a gesture already described in the
  original shot, edit THAT SAME GESTURE IN THAT SAME SHOT. This is a correction,
  even when the user did not write 'remplace'. Keep the original action target,
  participants, setting and all unrelated attributes unless explicitly changed.
  Do NOT add a second occurrence, new event, new target or needless [Shot].
- ADD_NEW: a genuinely new, independent gesture is ADDED, not substituted. Layer
  it simultaneously with unchanged original actions when physically possible.
- REPLACE_EXISTING: an explicit 'remplace' / 'au lieu de' instruction substitutes
  ONLY the targeted gesture or event in context, keeping unrelated shots intact.
- EMOTION: keep the underlying physical events and dialogue words, but CHANGE
  THE ACTOR'S EMOTIONAL DELIVERY when necessary. Old expressions that contradict
  the requested emotion must be adapted; preserve the situation and words,
  but reinterpret any conflicting expressive behavior. Describe observable
  acting through expression, gaze, voice quality, breath, posture and motion,
  as appropriate to the request and the original scene. Avoid emotional labels
  without a discernible change in the performance.
- If the original prompt already contains the requested NEW action, first reason
  whether the user is asking to specify/correct it (MODIFY_EXISTING) or to add
  another distinct occurrence (ADD_NEW). Never present an unchanged old phrase
  as a successful new action.

OUTPUT AN EDIT_DECISION LABEL BEFORE SCENE_CONTEXT, EXACTLY ONE OF:
EDIT_DECISION: ADD_NEW / MODIFY_EXISTING / REPLACE_EXISTING / EMOTION
The EDIT_DECISION is only for the editing engine, not part of H3's video prompt.

TIMELINE CONTRACT — MANDATORY, NOT OPTIONAL:
- The USER EDIT WINDOW is an exact interval [start, end] supplied in the request.
  For ADD_NEW, create shot/beat boundaries at EXACTLY its start and end if the
  interval is partial. A [Shot N] is a chronological BEAT, not a camera cut.
- For MODIFY_EXISTING, REPLACE_EXISTING or EMOTION which alters the performance
  inside an existing shot, DO NOT invent a new shot merely to split the timeline.
  Keep the existing original [Shot N] start/end and write this exact in-shot cue:
  'Pendant START–ENDs : ...' with both numeric timestamps replaced by the user's
  exact times, followed by the modified action/delivery. Describe continuation
  of the SAME gesture before/after without duplicating it. The cue must appear
  inside ONE shot whose timestamp interval completely contains [start, end].
  If the interval crosses original shots, splitting is permitted where needed.
- Place the requested change at the user-selected time. The H3 video generator
  may regenerate the complete video for continuity, but this does not require
  changing existing shot boundaries for an in-shot modification.
- Outside the user window, preserve original scene events and dialogue. For an
  emotion change, preserve the original events but allow incompatible cheerful
  acting to be rewritten within the edit interval.
- For ADD_NEW, overlap with ongoing original events and dialogue when possible.
  For MODIFY_EXISTING, correct just the original gesture instead of duplicating it.
  For EMOTION, old facial expressions MAY change to reflect the new requested
  affect without deleting unrelated events or spoken words.
- Every [Shot N] MUST have explicit numeric START–END timestamps in seconds,
  with at most 3 decimals, continuous from 0.000s to full clip duration.
  For ADD_NEW, the new beat boundaries must match the USER EDIT WINDOW
  supplied dynamically with each request. For an in-shot MODIFY_EXISTING or
  EMOTION, retain the original shot boundaries and use the precise dynamic
  inline cue 'Pendant START–ENDs : ...' with actual supplied timestamps.
- If a selected interval is too short for a large motion, make the most plausible
  short motion possible; do not silently widen the user's narrative interval.

SHOT AUTHORING:
- Return ONLY EDIT_DECISION then SCENE_CONTEXT and NEW_TAKE with [Shot 1], [Shot 2] ... in
  chronological order, each with realistic timestamp ranges covering the
  original clip duration. YOU MAY change shot COUNT, boundaries and numbering
  to incorporate the request: an original [Shot 2] may become [Shot 3], or the
  new motion may occur DURING an existing shot. Never add a needless camera cut.
  '[Shot N]' can designate consecutive chronological beats of a continuous
  camera take, without a hard cut.
- Show the new behavior through observable body mechanics, spatial relations,
  gaze, actual hand/arm trajectories, reaction timing, and interactions.
  Include sensible transitions into and out of the added or replaced beat,
  reconnecting to the original action at the end of the editable time window.
  If the window is the entire clip, you may adapt the whole sequence instead.
- Preserve the same actor, identities, costumes, spatial setting, camera,
  soundscape, original spoken <d> tags / language and physical continuity
  unless explicitly changed. Preserve all original concurrent events where
  physically possible. Do not duplicate conflicting dialogue.
- The NEW shot script is the authority for the retake. The old prompt is only
  the blueprint from which to preserve unaffected beats. <Video 1> represents
  the source imagery in H3; never assert you have inspected unseen footage.
- Output EDIT_DECISION and EXACTLY TWO labeled text sections, all in FRENCH:
  SCENE_CONTEXT: 1-3 short sentences (MAXIMUM 500 characters) describing ONLY
  identity, place, costume, background, camera, light, sound of <Video 1>.
  NO chronology, no plot beats, no old [Shot] text, no restatement of the user's
  requested motion. This context is forwarded to H3 instead of the old prompt.
  NEW_TAKE: your NEW complete H3 [Shot 1], [Shot 2]... script with revised
  timings, original concurrent actions, physical transitions, original dialogue.
- No separate comparison, no original script repeated, no explanations or JSON.
- A successful ADD_NEW must visibly add new movement. MODIFY_EXISTING must
  change the specified attribute of the EXISTING gesture, without moving its
  target, inventing another gesture or copying the old phrase unchanged.
  EMOTION must be perceptibly different, not just a sentimental adjective.
"""


def ensure_ollama_running(film, *, timeout=28.0):
    """Use the same `ollama serve` startup method as FilmMaker's PowerShell.

    Does NOT install software, pull a model, change CUDA, or replace Python.
    Leaves the daemon running just like FilmMaker. The specific Gemma model is
    explicitly unloaded by FilmMaker after writing the prompt.
    """
    url = film.rt.OLLAMA_URL + '/api/tags'
    try:
        return film.rt.http_json(url, timeout=3)
    except Exception as exc:
        start_exc = exc
    exe=shutil.which('ollama.exe') or shutil.which('ollama')
    if not exe and os.name=='nt':
        candidates=[Path(os.environ.get('LOCALAPPDATA',''))/'Programs'/'Ollama'/'ollama.exe',
                    Path(os.environ.get('PROGRAMFILES','C:/Program Files'))/'Ollama'/'ollama.exe']
        exe=next((str(p) for p in candidates if p.is_file()),None)
    if not exe:
        raise RuntimeError('Retouches : Ollama est indisponible : ollama.exe introuvable. '
                           'Aucun modèle ni logiciel ne sera installé.') from start_exc
    kwargs={'stdin':subprocess.DEVNULL,'stdout':subprocess.DEVNULL,
            'stderr':subprocess.DEVNULL,'cwd':str(Path(exe).resolve().parent)}
    if os.name=='nt':
        kwargs['creationflags']=getattr(subprocess,'CREATE_NO_WINDOW',0)
    print('[RETOUCHES] Ollama arrêté : lancement automatique de ollama serve...',flush=True)
    try:
        proc=subprocess.Popen([exe,'serve'],**kwargs)
    except OSError as exc:
        raise RuntimeError('Impossible de lancer Ollama automatiquement : '+str(exc)) from exc
    end=time.monotonic()+float(timeout)
    last=None
    while time.monotonic()<end:
        try:
            tags=film.rt.http_json(url,timeout=3)
            print('[RETOUCHES] Ollama prêt, modèle non encore chargé.',flush=True)
            return tags
        except Exception as exc:
            last=exc
        if proc.poll() is not None:
            # It can exit because an existing Ollama instance took the port.
            # Try one more time; never terminate external processes.
            try:return film.rt.http_json(url,timeout=3)
            except Exception:break
        time.sleep(1)
    raise RuntimeError('Ollama ne répond pas après démarrage automatique : '
                       +str(last or 'processus terminé'))


def choose_backend(film):
    """Select ONLY the pre-installed Gemma 4 26B in Ollama (FilmMaker backend).

    Never fallback to Qwen3.8 27B / llama-server; no installation or download.
    Fail closed if Ollama or Gemma 26B is unavailable.
    """
    # The FilmMaker's actual model naming from select_text_backend():
    #   gemma4:26b-a4b-it-q4_K_M
    tags = ensure_ollama_running(film)
    names = film.installed_model_names(tags)
    # Prefer the exact GGUF/quant used by the existing Film Studio; accept
    # alternate 26B tags if a compatible variant is already installed.
    preferred = 'gemma4:26b-a4b-it-q4_k_m'
    model = next((n for n in names if n.casefold() == preferred), None)
    if model is None:
        model = next((n for n in names if n.casefold().startswith('gemma4:26b')), None)
    if not model:
        raise RuntimeError(
            'Retouches : Gemma 4 26B Ollama introuvable. '
            'Modele attendu : gemma4:26b-a4b-it-q4_K_M. '
            'Modeles Ollama presents : ' + (', '.join(names) or '(aucun)') + '. '
            'Qwen 27B interdit pour ce mode, rien ne sera telecharge.'
        )
    backend = film._ollama_backend(model)
    if backend.get('provider') != 'ollama':
        raise RuntimeError('Retouches : backend Ollama attendu, generation annulee.')
    print('[RETOUCHES] Modele de prompt : ' + model + ' | Ollama | PAS de Qwen 27B', flush=True)
    return backend


# ``[Shot N]`` is H3's real authoring format. Do not manufacture shot cuts.
SHOT_RE = re.compile(r"\[Shot\s+(\d+)\]", re.IGNORECASE)
# Timestamp grammar: 0.000, 0, 0:02.500, French commas; range dash/en-dash.
_TIME = r'(?:\d+:)?\d+(?:[.,]\d+)?'
SHOT_HEADER = re.compile(r'\[Shot\s+(\d+)\]\s*\*{0,2}\s*('
                         + _TIME + r')\s*(?:s\b)?\s*[-–—]\s*('
                         + _TIME + r')\s*(?:s\b)?', re.I)


def _seconds(stamp: str) -> float:
    stamp=stamp.strip().replace(',', '.')
    if ':' in stamp:
        mins,sec=stamp.split(':',1)
        return int(mins)*60+float(sec)
    return float(stamp)


def validate_edit_timeline(shot_text: str,start:float,end:float,duration:float,allow_inline_cue:bool=False) -> list[tuple[float,float]]:
    """Fail BEFORE H3 if Gemma misplaced a selected retake interval.

    A beat boundary is not a hard scene CUT: it represents physical choreography
    while H3 remains free to keep the original continuous camera movement.
    The semantic correctness of the new action is not provable from timestamps.
    """
    headers=list(SHOT_HEADER.finditer(shot_text))
    all_shots=list(SHOT_RE.finditer(shot_text))
    if len(headers)!=len(all_shots) or not headers:
        raise RuntimeError('Gemma : chaque [Shot N] doit porter des bornes temporelles numériques précises')
    intervals=[]
    tolerance=0.075  # approx 2 frames at 24fps; no invented shifts of seconds
    for i,m in enumerate(headers,1):
        if int(m.group(1))!=i:
            raise RuntimeError('Gemma : numérotation des shots non consécutive')
        a,b=_seconds(m.group(2)),_seconds(m.group(3))
        if not (0 <= a < b <= duration+tolerance):
            raise RuntimeError(f'Gemma : intervalle du Shot {i} invalide : {a}–{b}s')
        if intervals and abs(a-intervals[-1][1])>tolerance:
            raise RuntimeError(f'Gemma : trou ou chevauchement entre Shot {i-1} et Shot {i}')
        intervals.append((a,b))
    if abs(intervals[0][0])>tolerance or abs(intervals[-1][1]-duration)>tolerance:
        raise RuntimeError('Gemma : la nouvelle timeline ne couvre pas précisément toute la vidéo')
    boundaries=[a for a,b in intervals]+[intervals[-1][1]]
    cue=re.compile(r'(?i)Pendant\s+'+re.escape(f'{start:.3f}')
        +r'\s*[-–—]\s*'+re.escape(f'{end:.3f}')+r's?\s*:')
    inline_ok=False
    if allow_inline_cue:
        for i,(a,b) in enumerate(intervals):
            section=shot_text[headers[i].end():headers[i+1].start() if i+1<len(headers) else len(shot_text)]
            if a-tolerance<=start and end<=b+tolerance and cue.search(section):
                inline_ok=True
                break
    for label,value in [('début',start),('fin',end)]:
        # clip extremities are already part of the complete timeline
        if min(abs(value),abs(value-duration)) <= tolerance:
            continue
        if any(abs(v-value)<=tolerance for v in boundaries):
            continue
        if inline_ok:
            continue
        raise RuntimeError('Gemma : '+label+' de la fenêtre sélectionnée ('
            +f'{value:.3f}s) non respecté. ADD_NEW doit scinder le shot; '
             'MODIFY_EXISTING/EMOTION dans un shot nécessite « Pendant '
            +f'{start:.3f}–{end:.3f}s : » pour localiser la correction.')
    return intervals


def _auto_inline_localisation(shot_text: str,start: float,end: float,duration: float) -> str:
    """Repair a near-valid Gemma timeline by injecting the exact inline cue.

    This fixes the common failure mode where Gemma keeps a single correct shot
    over the user interval but forgets the mandatory localising phrase.
    """
    headers=list(SHOT_HEADER.finditer(shot_text))
    all_shots=list(SHOT_RE.finditer(shot_text))
    if len(headers)!=len(all_shots) or not headers:
        return shot_text
    tolerance=0.075
    cue_text=f'Pendant {start:.3f}–{end:.3f}s : '
    cue_re=re.compile(r'(?i)Pendant\s+'+re.escape(f'{start:.3f}')
        +r'\s*[-–—]\s*'+re.escape(f'{end:.3f}')+r's?\s*:')
    intervals=[]
    for m in headers:
        a,b=_seconds(m.group(2)),_seconds(m.group(3))
        intervals.append((a,b))
    if not (abs(intervals[0][0])<=tolerance and abs(intervals[-1][1]-duration)<=tolerance):
        return shot_text
    if not any(a-tolerance<=start and end<=b+tolerance for a,b in intervals):
        return shot_text
    start_on_boundary=any(abs(v-start)<=tolerance for ab in intervals for v in ab)
    end_on_boundary=any(abs(v-end)<=tolerance for ab in intervals for v in ab)
    if start_on_boundary and end_on_boundary:
        return shot_text
    parts=[]
    cursor=0
    changed=False
    for i,(a,b) in enumerate(intervals):
        h=headers[i]
        sec_start=h.end()
        sec_end=headers[i+1].start() if i+1<len(headers) else len(shot_text)
        parts.append(shot_text[cursor:sec_start])
        section=shot_text[sec_start:sec_end]
        if a-tolerance<=start and end<=b+tolerance and not cue_re.search(section) and not changed:
            stripped=section.lstrip()
            leading=section[:len(section)-len(stripped)]
            section=leading+cue_text+stripped
            changed=True
        parts.append(section)
        cursor=sec_end
    parts.append(shot_text[cursor:])
    return ''.join(parts)



def original_shots(source_prompt: str) -> list[int]:
    identifiers = [int(m.group(1)) for m in SHOT_RE.finditer(source_prompt or '')]
    # Some approved clips have no explicit markers; they are one continuous shot.
    return list(dict.fromkeys(identifiers)) or [1]


def requested_operation(request: str) -> str:
    """Only explicitly destructive wording warrants removing an original action."""
    text = ' '.join(str(request).casefold().split())
    # Explicit replacement remains valid for precision retake too, regardless
    # of whether the UI button says Action, Emotion or Retake.
    if re.search(r'\b(remplace[rz]?|remplacement|supprime[rz]?|retire[rz]?|efface[rz]?|au lieu de|instead of|replace|remove|delete)\b', text):
        return 'replace'
    if re.search(r'\b(ajoute[rz]?|ajout|en plus|additionne|add)\b', text):
        return 'add'
    return 'infer'


def build_request(mode,performance_type,request,source_prompt,start,end,duration):
    kind = 'Retake précis' if mode=='precise' else ('Performance Action' if performance_type=='action' else 'Performance Émotion')
    original=(source_prompt or '').strip() or '(Le prompt original du clip est absent. Référence visuelle: <Video 1>. Ne prétends pas connaître les actions inconnues.)'
    operation=('emotion' if mode=='performance' and performance_type=='emotion' else requested_operation(request))
    semantics = (
        'EMOTION: préserver les événements et les paroles, mais réinterpréter le jeu expressif pour rendre l’émotion demandée réellement perceptible, en adaptant les expressions qui lui sont incompatibles.'
        if operation=='emotion' else
        'ADDITION EXPLICITE: conserver les actions originales et superposer la nouvelle si possible.'
        if operation=='add' else
        'REMPLACEMENT EXPLICITE: ne retirer QUE le comportement ciblé; même shot si la cible est déjà décrite.'
        if operation=='replace' else
        'INTENTION A DEDUIRE DU SCRIPT: identifier si la demande précise un attribut d’un comportement DEJA PRESENT (MODIFY_EXISTING) ou introduit un comportement distinct (ADD_NEW). Ne pas dédoubler un événement existant ni inventer un autre shot sans nécessité. Préserver la cible spatiale et les autres attributs, dialogues et caméra sauf demande explicite.'
    )
    limit=('La fenêtre explicitement modifiable vaut '+f'{start:.3f}–{end:.3f}s. '           +'Toutes les actions hors de la fenêtre doivent rester identiques au clip source. '
           +'Intègre gestes et transitions dans la fenêtre, sans modifier la durée totale. '
           if start>.001 or end<duration-.015 else
           'La prise entière est modifiable pour réorganiser les beats sans changer la durée totale. ')
    return (
        'Tu prépares une NOUVELLE PRISE COMPLETE H3 basée sur une vidéo existante.\n'
        'La vidéo VRAIE à modifier est raccordée à H3 sous <Video 1>. '
        'Elle a été créée à partir du PROMPT ORIGINAL fourni plus bas. '
        'Le texte source est un historique, non une preuve que toutes ses actions furent visiblement réalisées.\n'
        f'MODE: {kind}\n'
        f'OPERATION: {operation.upper()} — {semantics}\n'
        f'CONSIGNE EXACTE UTILISATEUR: {request.strip()}\n'
        f'DUREE TOTALE: 0.000–{duration:.3f}s, vidéo H3 entière de même durée.\n'
        f'ZONE TEMPORELLE DU CHANGEMENT: {start:.3f}–{end:.3f}s. {limit}\n'
        'CONTRAINTE TEMPORELLE : pour ADD_NEW, sépare des beats aux limites '
        f'{start:.3f}s et {end:.3f}s si nécessaire. Pour MODIFY_EXISTING / '
        'REPLACE_EXISTING / EMOTION sur une action déjà dans un shot, NE CRÉE '
        'PAS de shot artificiel : conserve le shot existant et écris dans ce '
        f'shot exactement « Pendant {start:.3f}–{end:.3f}s : » suivi de la '
        'correction visible. La cible du mouvement original ne change '
        'pas si cela n’est pas explicitement demandé. Décris tous les '
        'shots originaux adaptés et couvre 0–durée du clip sans trou. '
        'Pour EMOTION, adapter la manière dont les événements sont joués '
        'à l’émotion demandée, même si elle contredit des expressions originales. '
        'Préserver les événements non concernés et les répliques. '
        'Précise en EDIT_DECISION ton choix raisonné.\n'
        'PROMPT ORIGINAL COMPLET — SCRIPT HISTORIQUE DU <Video 1> :\n'
        +original+'\n\n'
        'RENVOIE UNIQUEMENT EDIT_DECISION: (ADD_NEW / MODIFY_EXISTING / REPLACE_EXISTING / EMOTION), '
        'puis SCENE_CONTEXT: (resume global court, aucun ancien shot), '
        'puis NEW_TAKE: suivi de [Shot 1], [Shot 2] ... avec timings réadaptés. Aucun commentaire.'
    )


def _normalise(value):
    return re.sub(r'\s+',' ',str(value or '')).strip().casefold()


def _fallback_scene_context(source_prompt: str) -> str:
    """Safe minimal context when Gemma omits the header; NEVER pass old shots.

    Only take environment/look/sound fields from the source authoring text.
    Narrative chronology from the original shots is deliberately excluded.
    """
    original=str(source_prompt or '')
    snippets=[]
    for pattern in (
        r'(?im)^\*\*World ambience[^\n]*?:\*\*\s*([^\n]+)',
        r'(?im)^\*\*look_cam[ée]ra_et_lumi[èe]re\s*:\*\*\s*([^\n]+)',
        r'(?im)^\*\*soundscape_global\s*:\*\*\s*([^\n]+)',
    ):
        m=re.search(pattern,original)
        if m:
            val=m.group(1).strip()
            # No [Shot] header, no dialogue. Skip any accidental instruction.
            val=re.sub(r'<d>.*?</d>','',val,flags=re.I)
            if '[Shot' not in val:
                snippets.append(val)
    if not snippets:
        return ('Mêmes personnages, identité visuelle, lieu, accessoires, éclairage, '
                'cadrage et ambiance sonore que la vidéo de référence <Video 1>.')
    text=' '.join(snippets)
    if len(text)>500:
        text=text[:497].rsplit(' ',1)[0]+'...'
    return text


def _strip_fences(value):
    return re.sub(r'^```(?:[\w-]+)?\s*|\s*```$', '', str(value or '').strip()).strip()


def _split_scene_and_new_take(result,source_prompt):
    """Prefer Gemma's two sections; accept ordinary [Shot 1] output safely.

    The H3-facing prompt contains *exactly one* new shot sequence. The original
    prompt remains available to Gemma only, never to H3.
    """
    text=_strip_fences(result)
    header_context=re.search(r'(?im)^\s*(?:#{1,4}\s*)?(?:\*\*)?SCENE_CONTEXT\s*:\s*(?:\*\*)?\s*',text)
    header_take=re.search(r'(?im)^\s*(?:#{1,4}\s*)?(?:\*\*)?NEW_TAKE\s*:\s*(?:\*\*)?\s*',text)
    first_shot=SHOT_RE.search(text)
    if not first_shot:
        raise RuntimeError('Gemma Retake : aucune nouvelle timeline [Shot 1] produite ; H3 non lancé')
    if header_take and header_take.start()<first_shot.start():
        script=text[header_take.end():].strip()
    else:
        script=text[first_shot.start():].strip()
    context=None
    if header_context and header_context.end()<first_shot.start():
        ctx_end=header_take.start() if header_take and header_take.start()>header_context.end() else first_shot.start()
        context=text[header_context.end():ctx_end].strip()
    if not context:
        context=_fallback_scene_context(source_prompt)
    # A scene summary may never contain original shot actions, dialogue or
    # chronology. Fail closed if Gemma ignored the required context format.
    if SHOT_RE.search(context) or '<d>' in context.lower():
        context=_fallback_scene_context(source_prompt)
    context=re.sub(r'\s+',' ',context).strip()[:500]
    return context,script


def assemble(original_request,result,start,end,duration,source_prompt='',full_h3_window=False):
    """V10.71 H3-facing prompt: visual reference + SHORT scene + ONE new script.

    The detailed original prompt is used to instruct Gemma, *not* H3.
    Nothing here changes ComfyUI's RAW mask, denoise, video ref or sampler.
    """
    summary,new_shots=_split_scene_and_new_take(result,source_prompt)
    if len(new_shots)<80 or len(new_shots)>14000:
        raise RuntimeError('Gemma Retake : nouvelle timeline trop courte/longue ; H3 non lancé')
    shot_ids=[int(m.group(1)) for m in SHOT_RE.finditer(new_shots)]
    if shot_ids!=list(range(1,len(shot_ids)+1)):
        raise RuntimeError('Gemma Retake : shots non consécutifs [Shot 1], [Shot 2]... H3 non lancé')
    original=(source_prompt or '').strip()
    decision_match=re.search(r'(?im)^\s*(?:\*\*)?EDIT_DECISION\s*:\s*(?:\*\*)?\s*(ADD_NEW|MODIFY_EXISTING|REPLACE_EXISTING|EMOTION)\b',result or '')
    if not decision_match:
        raise RuntimeError('Gemma : décision ADD_NEW / MODIFY_EXISTING / REPLACE_EXISTING / EMOTION absente ; impossible de valider le découpage.')
    decision=decision_match.group(1).upper()
    explicit=requested_operation(original_request)
    if explicit=='add' and decision!='ADD_NEW':
        raise RuntimeError('Gemma : ajout explicite interprété comme autre opération ; corrige EDIT_DECISION.')
    if explicit=='replace' and decision!='REPLACE_EXISTING':
        raise RuntimeError('Gemma : remplacement explicite interprété comme autre opération ; corrige EDIT_DECISION.')
    new_shots=_auto_inline_localisation(new_shots,start,end,duration)
    validate_edit_timeline(new_shots,start,end,duration,
                           allow_inline_cue=True)
    if original and _normalise(new_shots)==_normalise(original):
        raise RuntimeError('Gemma a renvoyé le script original inchangé : H3 non lancé')
    # Preserve the exact Gemma shot boundaries; change ONLY H3's regeneration
    # permission displayed at the end of the prompt for Performance Action/Emotion.
    # The ComfyUI RAW temporal mask must independently receive the same full range.
    h3_start,h3_end=(0.0,duration) if full_h3_window else (start,end)
    return (
        '<Video 1> = REAL SOURCE VIDEO. Visual reference for the same people, faces, '
        'wardrobe, room, lighting, camera and ambient sound. The video is the '
        'reference, not an extra written script to replay.\n'
        'SCENE CONTEXT (short visual description, no original timeline):\n'
        +summary+'\n\n'
        'NEW TAKE — THIS IS THE ONLY SHOT SCRIPT TO GENERATE:\n'
        +new_shots+'\n'
        f'Preserve total duration {duration:.3f}s, with requested edit interval '
        f'{h3_start:.3f}–{h3_end:.3f}s. '
        + (f'The user-requested new action/emotion remains timed at {start:.3f}–{end:.3f}s in the NEW TAKE; '
           'full-clip H3 freedom is for physical continuity, not permission to move the requested action. '
           if full_h3_window else '')
        + 'Keep unaffected actions and dialogue. '
        'Use the real <Video 1> for continuity, with physically plausible motions and transitions.'
    )


def write_prompt(*,mode,performance_type,request,source_prompt,start,end,duration,gpu_prepare):
    if mode!='precise' and (mode!='performance' or performance_type not in ('action','emotion')):
        raise ValueError('Retake LLM réservé aux retouches visuelles, pas au dialogue')
    if not(0<=start<end<=duration+.03):raise ValueError('Intervalle retake invalide')
    import h3film_studio_v3 as film  # reuse *existing* FilmMaker LLM backend
    gpu_prepare()                     # release H3 memory before loading Gemma 4 26B
    backend=choose_backend(film)
    output=None
    try:
        instruction=build_request(mode,performance_type,request,source_prompt,start,end,duration)
        for attempt in range(2):
            output=film.director_text(backend,SYSTEM,instruction,
                                     label='RETOUCH DIRECTOR GEMMA 4 26B / OLLAMA',num_ctx=16384,num_predict=2000)
            try:
                final=assemble(request,output,start,end,duration,source_prompt,
                               full_h3_window=(mode=='performance' and performance_type in ('action','emotion')))
                break
            except RuntimeError as exc:
                if attempt:
                    raise RuntimeError('Gemma : seconde tentative également invalide. '+str(exc)) from exc
                # One correction in same loaded LLM session, BEFORE any H3 work.
                instruction += ('\n\nCORRECTION OBLIGATOIRE : la précédente timeline '
                    'ne respectait pas le contrat : '+str(exc)+'\n'
                    'Reprends le clip COMPLET et réponds à nouveau en deux sections '
                    'SCENE_CONTEXT et NEW_TAKE, sans conserver ce découpage faux. '
                    f'Bornes obligatoires : {start:.3f}s et {end:.3f}s. '
                    'Toute la timeline doit couvrir exactement 0.000–'
                    f'{duration:.3f}s. Aucun CUT caméra ajouté.')
                print('[RETOUCHES] Gemma : correction des bornes de shots avant H3 : '+str(exc),flush=True)
    finally:
        # H3 must not coexist with Gemma 26B loaded on a 16GB card.
        # FilmMaker owns/knows its own process; never kill external PIDs.
        try:
            film.unload_text_backend(backend,label='Avant retouche H3')
        finally:
            film.release_all_text_models_for_h3(label='Retouches : H3 prend le GPU')
    return final,'Gemma 26B · fenêtre vérifiée + NEW TAKE unique · '+str(backend.get('display') or backend.get('model'))
