"""V10.93 -- Prompt Gemma for the central two-seam retake ONLY.

Keeps V10.83's exact output grammar, beat grid, parse, assembly and local 63f
clock. Replaces the *input* role placeholders with concrete continuity requests
so the LLM has to describe plausible visible motion before/after the action.
Do not import this module in any single-seam, quick-preview, Performance or
Dialogue path.
"""
from __future__ import annotations
import retouches_llm_prompt_half_v82 as v83

SYSTEM = """Tu es le réalisateur de prises alternatives pour MiniMax H3.
Écris uniquement le petit segment vidéo local, en français. La grille de
secondes locale commence toujours à 0.000s.

Ta mission : à partir du scénario original, inventer des descriptions
PHYSIQUES et VISIBLES de continuité, jamais des intitulés de transition.
- Avant l'action demandée : décrire brièvement le mouvement naturel déjà en
  cours (regard, posture, tête, mains) pour retrouver la prise originale.
- Pendant l'action : décrire le geste demandé clairement et précisément.
- Après : décrire brièvement l'achèvement du geste et le retour naturel à
  l'attitude ou l'activité qui se poursuivait dans le plan original.
N'invente pas de dialogue, d'événement ni de nouveau mouvement de caméra ;
si le scénario n'indique pas un geste spécifique, décris une continuité
simple et discrète compatible avec la référence visuelle.
Les [Shot] représentent des mouvements continus, jamais des coupes caméra.
Respecte STRICTEMENT les bornes horaires et le nombre de [Shot] de la grille.
N'écris ni nom de rôle, ni mot d'attente, ni consigne : chaque [Shot] doit
contenir uniquement la description concrète de ce qu'on verrait à l'écran.

FORMAT EXACT :
SCENE_CONTEXT: une ou deux phrases courtes sur la scène.
NEW_TAKE:
[Shot 1] <secondes locales fournies> — <description concrète du mouvement>
[Shot 2] ...
"""


def _instruction(*,request:str,source_prompt:str,window:dict)->str:
    schedule=v83._grid(window)
    source, anchor=v83._source_excerpt(source_prompt,window)
    templates={
        'TRANSITION AVANT': (
            'Décris en une phrase le bref mouvement original qui précède le geste demandé : '
            'posture, direction du regard, mouvement de tête ou des mains, sans ajout d’événement.'),
        'ACTION': (
            'Décris explicitement ce geste demandé, avec la bonne main, le mouvement '
            'et son début et sa fin, sans le décaler dans le temps.'),
        'TRANSITION APRÈS': (
            'Décris en une phrase comment le geste se termine et comment la personne '
            'reprend naturellement son attitude, son mouvement ou son interaction d’origine.'),
    }
    grid='\n'.join(f'[Shot {i}] {a:.3f}–{b:.3f}s — {templates[role]}'
                   for i,(role,a,b) in enumerate(schedule,1))
    return (
        'MODIFICATION DEMANDÉE : '+str(request).strip()+'\n'
        f'SÉQUENCE SOURCE (secondes de la vidéo originale) : '
        f'{float(window["global_offset"]):.3f}–'
        f'{float(window["global_offset"])+float(window["duration"]):.3f}s.\n'
        f'GESTE DEMANDÉ (TEMPS LOCAL) : '
        f'{float(window["start"]):.3f}–{float(window["end"]):.3f}s.\n'
        'Ces secondes sont définies techniquement, ne les recalcule pas. '
        'Rédige UNIQUEMENT la description du mouvement correspondant à chaque '
        '[Shot] de la grille suivante, sans nouveau [Shot] :\n'
        +grid+'\n'
        'CONTEXTE DU SCÉNARIO ORIGINAL (à utiliser seulement pour assurer '
        'la continuité du plan, pas pour remplacer le geste demandé) :\n'
        +source+'\n'
        'APRÈS LE SEGMENT : '+anchor+'\n'
        'Si tu ne sais pas précisément ce que fait le personnage avant/après, '
        'décris un mouvement discret de posture/regard qui ne contredit pas la '
        'référence vidéo. MiniMax se chargera de l’ajustement visuel.\n'
        'Retourne uniquement SCENE_CONTEXT et NEW_TAKE avec les secondes EXACTES de la grille. '
        'Ne copie pas les instructions après le tiret : écris une prise de vue réalisable.'
    )


def write_prompt(*,mode,performance_type,request,source_prompt,window,gpu_prepare):
    if mode!='precise':
        raise ValueError('Gemma central V10.93 réservé au Retake précis')
    import h3film_studio_v3 as film
    gpu_prepare()
    backend=v83.inherited.choose_backend(film)
    try:
        instruction=_instruction(request=request,source_prompt=source_prompt,window=window)
        errors=[]
        for attempt in range(3):
            result=film.director_text(backend,SYSTEM,instruction,
                label='RETOUCH CENTRAL GEMMA 26B / OLLAMA',num_ctx=16384,num_predict=1700)
            try:
                context,shots=v83._extract(result,window)
                text=v83._assemble(context,shots,window)
                # Keep all existing central validation checks, including when
                # placeholders start with punctuation or an em-dash.
                from retouches_precise_center_v90 import verify_gemma_descriptions
                verify_gemma_descriptions(text)
                return text,'gemma4:26b-a4b-it-q4_K_M + Retake HALF-CLIP V10.82'
            except (RuntimeError,ValueError) as exc:
                errors.append(str(exc))
                if attempt==2:
                    raise RuntimeError('Gemma central : trois tentatives sans transitions décrites ; '
                        'aucun rendu H3 lancé. Dernière erreur : '+str(exc)) from exc
                instruction += (
                    '\nCORRECTION : ta précédente réponse n’est pas une prise de vue exploitable ('
                    +str(exc)+'). Réécris CHAQUE [Shot] comme une phrase qui décrit '
                    'réellement ce que fait le personnage physiquement, avec les mêmes '
                    'temps, et l’action demandée au centre. Aucune étiquette de rôle.'
                )
    finally:
        try:
            film.unload_text_backend(backend)
        except Exception:
            pass
