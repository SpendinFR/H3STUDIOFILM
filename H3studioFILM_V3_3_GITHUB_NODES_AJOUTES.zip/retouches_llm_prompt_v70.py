"""V10.66 H3 visual-retake prompt writer: reuses FilmMaker's established LLM
loading, chat and unloading functions. H3's original RAW video/latent (not this
text) is the visual reference. This module never runs pip or installs models.
"""
from __future__ import annotations
import os
import re
import shutil
import subprocess
import time
from pathlib import Path

SYSTEM = """You are the shot director rewriting a COMPLETE existing MiniMax H3 clip.
You have the FULL ORIGINAL H3 PROMPT and a USER CHANGE. The real footage is
provided to the VIDEO GENERATOR as <Video 1> (you do not see frames yourself).
Your task is to author a NEW complete shot-by-shot prompt, not summarize the
existing one or append a little phrase inside an unchanged old shot.

INTERPRET THE USER REQUEST CORRECTLY:
- ADD / 'ajoute' / default non-destructive change: the NEW action must happen
  IN ADDITION TO the ORIGINAL actions. Make it simultaneous / overlapping with
  the filmed performance WHEN PHYSICALLY POSSIBLE (e.g. she looks into the camera
  WHILE raising her arm). Keep the original laughter, dialogue, interaction,
  camera movement and actions. Do not automatically move the new action into
  a separate earlier or later shot. Re-time, merge or split beats only when
  continuity requires it. Do not secretly delete an original beat to make room.
- REPLACE / 'remplace' / 'au lieu de': remove ONLY the specific targeted action
  and write its replacement in the same narrative context. Keep all unaffected
  original events. If intent is ambiguous, prefer additive rather than destructive.
- EMOTION: layer the new emotional acting on the existing action/dialogue,
  unless the user explicitly requests replacement.
- The ORIGINAL PROMPT may ALREADY MENTION the desired gesture (e.g. raising
  the right hand). That historical phrase is NOT proof you created a NEW
  requested change. Rewrite the target beat so the new performance is visibly
  distinguishable, e.g. a clear raised arm maintained while she continues her
  original address to camera; retain the original action too. Do not merely
  paste or re-label an old sentence as the new action.

SHOT AUTHORING:
- Return ONLY a NEW, FULL MiniMax H3 prompt, with [Shot 1], [Shot 2] ... in
  chronological order, each with realistic timestamp ranges covering the
  original clip duration. YOU MAY change shot COUNT, boundaries and numbering
  to incorporate the request: an original [Shot 2] may become [Shot 3], or the
  new motion may occur DURING an existing shot. Never add a needless camera cut.
  '[Shot N]' can designate consecutive chronological beats of a continuous
  camera take, without a hard cut.
- Show the new behavior through observable body mechanics, spatial relations,
  gaze, actual hand/arm trajectories, reaction timing, and interactions.
  Include sensible transitions into and out of the added or replaced beat,
  reconnecting to the original action at the end of the editable time window.
  If the window is the entire clip, you may adapt the whole sequence instead.
- Preserve the same actor, identities, costumes, spatial setting, camera,
  soundscape, original spoken <d> tags / language and physical continuity
  unless explicitly changed. Preserve all original concurrent events where
  physically possible. Do not duplicate conflicting dialogue.
- The NEW shot script is the authority for the retake. The old prompt is only
  the blueprint from which to preserve unaffected beats. <Video 1> represents
  the source imagery in H3; never assert you have inspected unseen footage.
- NO explanations, NO JSON, NO comparison, NO "ORIGINAL" wrapper: only the
  finished NEW SHOT PROMPT with [Shot N] timestamps and any appropriate
  original style / soundscape details after it.
"""


def ensure_ollama_running(film, *, timeout=28.0):
    """Use the same `ollama serve` startup method as FilmMaker's PowerShell.

    Does NOT install software, pull a model, change CUDA, or replace Python.
    Leaves the daemon running just like FilmMaker. The specific Gemma model is
    explicitly unloaded by FilmMaker after writing the prompt.
    """
    url = film.rt.OLLAMA_URL + '/api/tags'
    try:
        return film.rt.http_json(url, timeout=3)
    except Exception as exc:
        start_exc = exc
    exe=shutil.which('ollama.exe') or shutil.which('ollama')
    if not exe and os.name=='nt':
        candidates=[Path(os.environ.get('LOCALAPPDATA',''))/'Programs'/'Ollama'/'ollama.exe',
                    Path(os.environ.get('PROGRAMFILES','C:/Program Files'))/'Ollama'/'ollama.exe']
        exe=next((str(p) for p in candidates if p.is_file()),None)
    if not exe:
        raise RuntimeError('Retouches : Ollama est indisponible : ollama.exe introuvable. '
                           'Aucun modèle ni logiciel ne sera installé.') from start_exc
    kwargs={'stdin':subprocess.DEVNULL,'stdout':subprocess.DEVNULL,
            'stderr':subprocess.DEVNULL,'cwd':str(Path(exe).resolve().parent)}
    if os.name=='nt':
        kwargs['creationflags']=getattr(subprocess,'CREATE_NO_WINDOW',0)
    print('[RETOUCHES] Ollama arrêté : lancement automatique de ollama serve...',flush=True)
    try:
        proc=subprocess.Popen([exe,'serve'],**kwargs)
    except OSError as exc:
        raise RuntimeError('Impossible de lancer Ollama automatiquement : '+str(exc)) from exc
    end=time.monotonic()+float(timeout)
    last=None
    while time.monotonic()<end:
        try:
            tags=film.rt.http_json(url,timeout=3)
            print('[RETOUCHES] Ollama prêt, modèle non encore chargé.',flush=True)
            return tags
        except Exception as exc:
            last=exc
        if proc.poll() is not None:
            # It can exit because an existing Ollama instance took the port.
            # Try one more time; never terminate external processes.
            try:return film.rt.http_json(url,timeout=3)
            except Exception:break
        time.sleep(1)
    raise RuntimeError('Ollama ne répond pas après démarrage automatique : '
                       +str(last or 'processus terminé'))


def choose_backend(film):
    """Select ONLY the pre-installed Gemma 4 26B in Ollama (FilmMaker backend).

    Never fallback to Qwen3.8 27B / llama-server; no installation or download.
    Fail closed if Ollama or Gemma 26B is unavailable.
    """
    # The FilmMaker's actual model naming from select_text_backend():
    #   gemma4:26b-a4b-it-q4_K_M
    tags = ensure_ollama_running(film)
    names = film.installed_model_names(tags)
    # Prefer the exact GGUF/quant used by the existing Film Studio; accept
    # alternate 26B tags if a compatible variant is already installed.
    preferred = 'gemma4:26b-a4b-it-q4_k_m'
    model = next((n for n in names if n.casefold() == preferred), None)
    if model is None:
        model = next((n for n in names if n.casefold().startswith('gemma4:26b')), None)
    if not model:
        raise RuntimeError(
            'Retouches : Gemma 4 26B Ollama introuvable. '
            'Modele attendu : gemma4:26b-a4b-it-q4_K_M. '
            'Modeles Ollama presents : ' + (', '.join(names) or '(aucun)') + '. '
            'Qwen 27B interdit pour ce mode, rien ne sera telecharge.'
        )
    backend = film._ollama_backend(model)
    if backend.get('provider') != 'ollama':
        raise RuntimeError('Retouches : backend Ollama attendu, generation annulee.')
    print('[RETOUCHES] Modele de prompt : ' + model + ' | Ollama | PAS de Qwen 27B', flush=True)
    return backend


# ``[Shot N]`` is H3's real authoring format. Do not manufacture shot cuts.
SHOT_RE = re.compile(r"\[Shot\s+(\d+)\]", re.IGNORECASE)


def original_shots(source_prompt: str) -> list[int]:
    identifiers = [int(m.group(1)) for m in SHOT_RE.finditer(source_prompt or '')]
    # Some approved clips have no explicit markers; they are one continuous shot.
    return list(dict.fromkeys(identifiers)) or [1]


def requested_operation(request: str) -> str:
    """Only explicitly destructive wording warrants removing an original action."""
    text = ' '.join(str(request).casefold().split())
    # Explicit replacement remains valid for precision retake too, regardless
    # of whether the UI button says Action, Emotion or Retake.
    if re.search(r'\b(remplace[rz]?|remplacement|supprime[rz]?|retire[rz]?|efface[rz]?|au lieu de|instead of|replace|remove|delete)\b', text):
        return 'replace'
    return 'add'


def build_request(mode,performance_type,request,source_prompt,start,end,duration):
    kind = 'Retake précis' if mode=='precise' else ('Performance Action' if performance_type=='action' else 'Performance Émotion')
    original=(source_prompt or '').strip() or '(Le prompt original du clip est absent. Référence visuelle: <Video 1>. Ne prétends pas connaître les actions inconnues.)'
    operation=requested_operation(request)
    semantics = (
        'ADDITION / SUPERPOSITION: maintenir et faire coexister les actions et dialogues originaux; le geste demandé peut se produire EN MEME TEMPS. ' 
        'Adapte les bornes et les shots sans sacrifier des actions existantes.'
        if operation=='add' else
        'REMPLACEMENT EXPLICITE: ne retirer QUE le comportement ciblé, préserver toutes les autres actions.'
    )
    limit=('La fenêtre explicitement modifiable vaut '+f'{start:.3f}–{end:.3f}s. '           +'Toutes les actions hors de la fenêtre doivent rester identiques au clip source. '
           +'Intègre gestes et transitions dans la fenêtre, sans modifier la durée totale. '
           if start>.001 or end<duration-.015 else
           'La prise entière est modifiable pour réorganiser les beats sans changer la durée totale. ')
    return (
        'Tu prépares une NOUVELLE PRISE COMPLETE H3 basée sur une vidéo existante.\n'
        'La vidéo VRAIE à modifier est raccordée à H3 sous <Video 1>. '
        'Elle a été créée à partir du PROMPT ORIGINAL fourni plus bas. '
        'Le texte source est un historique, non une preuve que toutes ses actions furent visiblement réalisées.\n'
        f'MODE: {kind}\n'
        f'OPERATION: {operation.upper()} — {semantics}\n'
        f'CONSIGNE EXACTE UTILISATEUR: {request.strip()}\n'
        f'DUREE TOTALE: 0.000–{duration:.3f}s, vidéo H3 entière de même durée.\n'
        f'ZONE TEMPORELLE DU CHANGEMENT: {start:.3f}–{end:.3f}s. {limit}\n'
        'REECRIS TOUTE LA TIMELINE. Tu peux ajouter un nouveau [Shot N], scinder '
        'un shot, fusionner deux beats, ou superposer le nouveau geste à une '
        'action existante. Réattribue les numéros [Shot 1], [Shot 2], etc. '
        'et les timings sur l’ensemble de la durée, dans l’ordre. '
        'La nouvelle action doit être VISIBLE et CONCRETE, pas seulement citée. '
        'Prévois une transition physique cohérente avant et après. '
        'Si le geste demandé existe déjà en texte dans le PROMPT ORIGINAL, '
        'ne le recopie pas comme s’il était nouveau: intègre une réalisation '
        'visuellement distincte qui satisfera la nouvelle consigne. '
        'Ne transforme pas une ADDITION en remplacement automatique.\n'
        'PROMPT ORIGINAL COMPLET — SCRIPT HISTORIQUE DU <Video 1> :\n'
        +original+'\n\n'
        'RENVOIE UNIQUEMENT LE NOUVEAU PROMPT H3 COMPLET, [Shot 1] puis '
        '[Shot 2] ... avec timings réadaptés. Aucun commentaire.'
    )


def _normalise(value):
    return re.sub(r'\s+',' ',str(value or '')).strip().casefold()


def assemble(original_request,result,start,end,duration,source_prompt=''):
    """Render-time prompt explicitly contains BOTH histories and NEW instructions.

    Keeping the original prompt solely in Gemma's context was the V10.69 bug:
    H3 saw an 'original' video without any original script. The source script is
    contextual, *new* script is last/authoritative to reduce old-action echo.
    """
    result=str(result or '').strip()
    result=re.sub(r'^```(?:[\w-]+)?\s*|\s*```$','',result).strip()
    if not result or len(result)<80:
        raise RuntimeError('Gemma Retake : nouvelle timeline H3 absente ou trop courte ; H3 non lancé')
    if len(result)>14000:
        raise RuntimeError('Gemma Retake : nouvelle timeline trop longue ; H3 non lancé')
    shot_ids=[int(m.group(1)) for m in SHOT_RE.finditer(result)]
    if not shot_ids or shot_ids != list(range(1,len(shot_ids)+1)):
        raise RuntimeError('Gemma Retake : les nouveaux shots doivent être numérotés [Shot 1], [Shot 2] ... sans doublon. H3 non lancé')
    original=(source_prompt or '').strip()
    if original and _normalise(result)==_normalise(original):
        raise RuntimeError('Gemma a renvoyé le prompt original inchangé : action demandée absente, H3 non lancé')
    historical=original or '(Prompt historique indisponible : seule la vidéo <Video 1> fournit la référence originale.)'
    operation=requested_operation(original_request)
    instruction=('AJOUTER cette action tout en CONSERVANT les actions originales et en les superposant si possible: '
                 if operation=='add' else
                 'REMPLACER uniquement le comportement explicitement visé par: ')+original_request.strip()
    return (
        '<Video 1> = VIDEO ORIGINALE REELLE DE REFERENCE. Même acteur, visage, vêtements, décor, caméra, lumière et environnement sonore.\n'
        'ORIGINAL H3 CLIP PROMPT — DESCRIPTION DE LA VIDEO DE REFERENCE <Video 1> ; '
        'CONTEXTE HISTORIQUE, PAS UN ORDRE DE REJOUER CES SHOTS :\n'
        '----- BEGIN ORIGINAL VIDEO PROMPT -----\n'+historical+'\n----- END ORIGINAL VIDEO PROMPT -----\n\n'
        'NEW RETAKE / PERFORMANCE MODIFICATION DEMANDEE :\n'+instruction+'\n'
        f'DUREE TOTALE INCHANGEE : {duration:.3f}s. Zone demandée : {start:.3f}–{end:.3f}s. '
        'Ne pas modifier les scènes hors zone.\n\n'
        'NEW TAKE — NOUVEAU PROMPT H3 COMPLET, AUTORITE POUR CE RENDU '
        '(la timeline ci-dessous prévaut sur l’ancien script en cas de différence) :\n'
        +result+'\n'
        'One continuous physically coherent new take based on <Video 1>, same size and total duration. '
        'Preserve unrelated original actions; the requested change is visibly integrated, '
        'with seamless transitions and no unwanted reset.'
    )



def write_prompt(*,mode,performance_type,request,source_prompt,start,end,duration,gpu_prepare):
    if mode!='precise' and (mode!='performance' or performance_type not in ('action','emotion')):
        raise ValueError('Retake LLM réservé aux retouches visuelles, pas au dialogue')
    if not(0<=start<end<=duration+.03):raise ValueError('Intervalle retake invalide')
    import h3film_studio_v3 as film  # reuse *existing* FilmMaker LLM backend
    gpu_prepare()                     # release H3 memory before loading Gemma 4 26B
    backend=choose_backend(film)
    output=None
    try:
        output=film.director_text(backend,SYSTEM,build_request(mode,performance_type,request,source_prompt,start,end,duration),
                                 label='RETOUCH DIRECTOR GEMMA 4 26B / OLLAMA',num_ctx=16384,num_predict=1700)
    finally:
        # H3 must not coexist with Gemma 26B loaded on a 16GB card.
        # FilmMaker owns/knows its own process; never kill external PIDs.
        try:
            film.unload_text_backend(backend,label='Avant retouche H3')
        finally:
            film.release_all_text_models_for_h3(label='Retouches : H3 prend le GPU')
    return assemble(request,output,start,end,duration,source_prompt),'Gemma 26B · nouveau script adaptatif + original complet · '+str(backend.get('display') or backend.get('model'))
