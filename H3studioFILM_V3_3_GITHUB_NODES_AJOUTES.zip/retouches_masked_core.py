"""Self-contained MiniMax H3 masked-video graph, inspired by the *node contracts*
used in Roycho's v7.4 workflow and drozbay/MaskVidExperiments.

Does not import demonstration graphs/prompts/refbank or change Film Studio RAW/HD.
A graph is constructed against live ComfyUI /object_info. No model download here.
"""
from __future__ import annotations
from pathlib import Path
import re

MASK_MODES={'remove_person','swap_person','local_edit','replace_background'}

_TARGET_ALIASES={
    'femme':'woman','la femme':'woman','une femme':'woman','woman':'woman','the woman':'woman',
    'homme':'man',"l'homme":'man','un homme':'man','man':'man','the man':'man',
    'personne':'person','la personne':'person','une personne':'person','person':'person',
    'fille':'girl','la fille':'girl','girl':'girl','garcon':'boy','garçon':'boy','boy':'boy',
    'acteur':'actor','actrice':'actress','micro':'microphone','microphone':'microphone',
    'sac':'bag','voiture':'car',
}

def _normalize_target(text):
    raw=' '.join(str(text or '').strip().split())
    if not raw:return ''
    key=raw.lower()
    if key in _TARGET_ALIASES:return _TARGET_ALIASES[key]
    for fr,en in _TARGET_ALIASES.items():
        if re.search(rf'(^|\W){re.escape(fr)}(\W|$)', key):
            return re.sub(rf'(^|\W){re.escape(fr)}(\W|$)', lambda m:(m.group(1) or '')+en+(m.group(2) or ''), key)
    return raw

def _normalize_instruction(mode,target,instruction):
    text=' '.join(str(instruction or '').strip().split())
    tgt=_normalize_target(target) or 'subject'
    if mode=='local_edit':
        if not text:
            return f'Replace only the selected {tgt}; preserve the rest of the shot exactly.'
        low=text.lower()
        if len(text.split())<=4 and not any(k in low for k in ('replace','change','swap','remove','turn','make','keep','preserve')):
            return f'Replace only the selected {tgt} with {text}. Preserve the rest of the shot exactly.'
    return text


def _schema(info, typ):
    if typ not in info:
        raise RuntimeError('Node ComfyUI manquant : '+typ)
    data=info[typ].get('input',{})
    return {**data.get('required',{}),**data.get('optional',{})}


def _make(info,typ,**arguments):
    allowed=_schema(info,typ)
    accepted={k:v for k,v in arguments.items() if k in allowed or ('.' in k and k.split('.')[0] in allowed)}
    absent=[]
    for k,v in (info[typ].get('input',{}).get('required') or {}).items():
        if k in accepted or any(k+'.' in n for n in accepted):continue
        if isinstance(v,(tuple,list)) and len(v)>1 and isinstance(v[1],dict) and 'default' in v[1]:
            accepted[k]=v[1]['default'];continue
        absent.append(k)
    if absent:
        raise RuntimeError(f'{typ}: champs obligatoires non branchés : '+", ".join(absent))
    return {'class_type':typ,'inputs':accepted}


def _ref(node,port=0):return [str(node),int(port)]


def build(info, mode, source_filename, reference_filename, target, instruction,
          model_name, lora_name=None, frames=22, width=768, height=448,
          quality='test', job_id='preview',region=None, conditioned_video_filename=None,
          allow_missing_reference=False):
    """Build the four masked retouch graphs.

    swap_person follows the Roycho-style MVEx crop/latent-mask path as closely
    as this Studio can expose programmatically.

    remove_person follows the Akatz contract more closely: original video for
    SAM3 tracking, optional green-masked conditioning video for Ref2VA, an
    explicit clean first-frame image as ref_image_0, 22-frame compatible H3
    lengths, Person Remover LoRA, and no crop/uncrop stage.
    """
    if mode not in MASK_MODES:raise ValueError('Mode non masqué')
    if not target and not region:raise ValueError('Cible SAM3 obligatoire')
    target=_normalize_target(target)
    if not target:target='object'
    instruction=_normalize_instruction(mode,target,instruction)
    if width%32 or height%32 or frames<5 or (frames-5)%17:
        raise ValueError('Dimensions/longueur H3 non compatibles')
    prefix='H3FilmSimple/retouches/'+job_id
    g={}
    def add(nid,typ,**kwargs):g[str(nid)]=_make(info,typ,**kwargs)

    # Original clip = authority for tracking and final audio.
    add(1,'LoadVideo',file=source_filename)
    add(2,'GetVideoComponents',video=_ref(1))
    add(3,'CheckpointLoaderSimple',ckpt_name='sam3.1_multiplex_fp16.safetensors')
    add(4,'ImageFromBatch',image=_ref(2),batch_index=0,length=1)
    add(5,'CLIPTextEncode',clip=_ref(3,1),text=target)
    coordinates={}
    if region:
        import json
        x,y,w,h=map(float,region)
        coordinates['positive_coords']=json.dumps([{'x':round((x+w/2)*width), 'y':round((y+h/2)*height)}])
    add(6,'SAM3_Detect',model=_ref(3),image=_ref(4),conditioning=_ref(5),
        threshold=0.4,refine_iterations=2,individual_masks=(mode=='replace_background'),**coordinates)
    add(7,'SAM3_VideoTrack',images=_ref(2),model=_ref(3),initial_mask=_ref(6),
        conditioning=_ref(5),detect_interval=6 if mode=='swap_person' else 12,detection_threshold=0.5,
        max_objects=16 if mode=='replace_background' else 1)
    add(8,'SAM3_TrackToMask',track_data=_ref(7),object_indices='')
    add(9,'MaskToImage',mask=_ref(8))
    add(10,'SaveImage',images=_ref(9),filename_prefix=prefix+'_tracking_mask')

    # Keep thin connected hair strands when swapping.  The legacy shrink_grow
    # (erosion 4px) eliminated some of them before paste-back.
    if mode=='swap_person':
        add(11,'MVEx_MaskCleanup',masks=_ref(8),threshold=0.3,
            method='components',edge_grow=4, **{'method.min_pixels':24,'method.min_frames':2})
    else:
        cleanup_edge=5 if mode=='remove_person' else 8
        add(11,'MVEx_MaskCleanup',masks=_ref(8),threshold=0.3,
            method='shrink_grow',edge_grow=cleanup_edge, **{'method.shrink':4,'method.min_frames':1})
    mask=_ref(11)
    if mode in ('remove_person','swap_person'):
        # MVEx_MaskCleanup edge_grow only grows the retention *gate*, not the
        # actual mask values (it returns original_masks * gate).  The legacy
        # workflow consequently kept old hair and shoulders outside the paste.
        # Core ComfyUI GrowMask genuinely expands the grayscale matte.
        add(44,'GrowMask',mask=mask,expand=26 if mode=='swap_person' else 12,
            tapered_corners=True)
        mask=_ref(44)
        # Export the exact mask subsequently used by H3, not the original SAM
        # outline, so green conditioning/clean plate and latent editing agree.
        g['9']['inputs']['mask']=mask
    if mode=='replace_background':
        add(12,'InvertMask',mask=mask)
        mask=_ref(12)

    # Optional Akatz-style green-masked conditioning clip.
    conditioning_components=_ref(2)
    if mode=='remove_person' and conditioned_video_filename:
        add(13,'LoadVideo',file=conditioned_video_filename)
        add(14,'GetVideoComponents',video=_ref(13))
        conditioning_components=_ref(14)

    add(20,'VAELoader',vae_name='minimax_h3_video_vae_fp16.safetensors')
    add(21,'VAELoader',vae_name='minimax_h3_audio_vae_fp32.safetensors')
    add(22,'CLIPLoader',clip_name='qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors',type='minimax',device='default')
    add(23,'UNETLoader',unet_name=model_name,weight_dtype='default')
    model=_ref(23)
    if mode=='remove_person' and not lora_name:
        lora_name='H3-Person-Remover-V1.safetensors'
    if lora_name:
        add(24,'LoraLoaderModelOnly',model=model,lora_name=lora_name,strength_model=1.0)
        model=_ref(24)

    h3_source_images=conditioning_components
    video_masks=mask
    bboxes=None

    # Akatz remover works on the whole frame. Roycho/MVEx swap keeps crop/uncrop.
    if mode in ('swap_person','local_edit'):
        crop_scale=1.75
        add(25,'MVEx_SubjectCrop',original_images=h3_source_images,masks=mask,
            mode='tracked', **{'mode.crop_scale':crop_scale,'mode.padding':'firm',
                'mode.prefer':'stillness','mode.seamless_loop':False,'mode.aspect_ratio':0.0,
                'divisible_by':32,'upscale_megapixels':0.0,'resize_method':'auto'})
        h3_source_images=_ref(25,0)
        video_masks=_ref(25,1)
        bboxes=_ref(25,2)

    add(26,'GetImageSizeAndCount',image=h3_source_images)
    add(27,'VAEEncode',pixels=h3_source_images,vae=_ref(20))
    grow_spatial=8 if mode=='swap_person' else (5 if mode=='remove_person' else 8)
    add(28,'MVEx_MaskToLatentSpace',masks=video_masks,vae=_ref(20),
        compression='auto',spatial_method='max',temporal_method='max',
        grow_spatial=grow_spatial,grow_temporal=1,grow_temp_mode='both')
    add(29,'SetLatentNoiseMask',samples=_ref(27),mask=_ref(28))
    add(30,'VAEEncodeAudio',audio=_ref(2,1),vae=_ref(21))
    add(31,'LTXVConcatAVLatent',video_latent=_ref(29),audio_latent=_ref(30))

    if mode=='swap_person' and not reference_filename and not allow_missing_reference:
        raise ValueError('Image de nouvelle apparence manquante')
    if mode in ('swap_person','remove_person') and reference_filename:
        add(32,'LoadImage',image=reference_filename)

    if mode=='replace_background':
        prompt='Replace the environment with '+instruction+'. Keep all unmasked people perfectly unchanged, including clothing, faces and poses.'
    elif mode=='remove_person':
        extra=(' '+instruction) if instruction else ''
        prompt='Remove the green-masked '+target+' and reconstruct the background. Preserve the rest of the video, including its camera motion and frame timing.'+extra
    elif mode=='swap_person':
        extra=(' '+instruction) if instruction else ''
        prompt='Swap only the '+target+' in <Video 1> with <Picture 1>. Maintain the new identity, hair and outfit consistently.'+extra
    else:
        prompt=instruction if instruction else ('Replace only the selected ' + target + '. Preserve the rest of the shot exactly.')

    refs={'ref_videos.ref_video_0':h3_source_images,'ref_video_audios.ref_video_audio_0':_ref(2,1)}
    if mode in ('swap_person','remove_person') and reference_filename:
        refs['ref_images.ref_image_0']=_ref(32)

    if 'fl2va' in model_name.lower() and mode not in ('swap_person','remove_person'):
        add(33,'MiniMaxH3ImageToVideo',clip=_ref(22),vae=_ref(20),audio_vae=_ref(21),
            prompt=prompt,width=_ref(26,1),height=_ref(26,2),length=_ref(26,3))
    else:
        add(33,'MiniMaxH3ReferenceToVideo',clip=_ref(22),vae=_ref(20),audio_vae=_ref(21),
            prompt=prompt,width=_ref(26,1),height=_ref(26,2),length=_ref(26,3),
            ref_image_size='max',**refs)
    add(34,'BasicGuider',model=model,conditioning=_ref(33))
    add(35,'RandomNoise',noise_seed=904234)
    steps=12 if mode=='remove_person' else 8
    sampler_name='er_sde' if mode=='remove_person' else 'euler'
    add(36,'BasicScheduler',model=model,scheduler='simple',steps=steps,denoise=1.0)
    add(37,'KSamplerSelect',sampler_name=sampler_name)
    add(38,'SamplerCustomAdvanced',noise=_ref(35),guider=_ref(34),sampler=_ref(37),
        sigmas=_ref(36),latent_image=_ref(31))
    add(39,'LTXVSeparateAVLatent',av_latent=_ref(38,1))
    add(40,'VAEDecode',samples=_ref(39),vae=_ref(20))
    images=_ref(40)
    if bboxes is not None:
        original_images=_ref(2) if mode=='swap_person' else conditioning_components
        add(41,'MVEx_SubjectUncrop',cropped_images=images,original_images=original_images,
            bboxes=bboxes,cropped_masks=video_masks,feather=32 if mode=='swap_person' else 16,resize_method='auto')
        images=_ref(41)
    add(42,'CreateVideo',images=images,audio=_ref(2,1),fps=24,bit_depth='auto',color_space='sRGB',codec='none')
    add(43,'SaveVideo',video=_ref(42),filename_prefix=prefix,format='mp4',**{'format.codec':'h264','format.codec.encoding':'re-encode','format.codec.encoding.crf':16})
    return g
