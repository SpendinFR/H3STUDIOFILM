# Dépannage EXPLICITE des anciennes V10.x uniquement. Ne s'exécute jamais au lancement normal.
$ErrorActionPreference = 'Stop'
$comfy = 'C:\AI\ComfyUI_windows_portable\ComfyUI'
$workers = @(Get-CimInstance Win32_Process | Where-Object {
    $_.Name -match '^python(?:\.exe)?$' -and $_.CommandLine -match 'h3film_studio_v3\.py'
})
$gates = @()
$out = Join-Path $comfy 'output\H3FilmSimple'
if (Test-Path $out) {
    $gates = @(Get-ChildItem -Path $out -Recurse -File -Filter '*.waiting.json' -ErrorAction SilentlyContinue | Where-Object { $_.Directory.Name -eq 'gates' })
}
Write-Host '--- Processus FilmMaker presents ---' -ForegroundColor Cyan
if ($workers.Count) { $workers | Select-Object ProcessId,CommandLine | Format-List } else { Write-Host 'Aucun processus FilmMaker repere.' }
Write-Host '--- Validations RAW encore ouvertes ---' -ForegroundColor Cyan
if ($gates.Count) { $gates | Select-Object FullName | Format-List } else { Write-Host 'Aucune validation RAW ouverte.' }
if (-not $workers.Count -and -not $gates.Count) { Write-Host 'Rien a debloquer.'; exit 0 }
$answer=Read-Host 'Pour annuler ces productions FilmMaker et leurs validations RAW, tape OUI (sinon ne rien faire)'
if ($answer -cne 'OUI') { Write-Host 'Annule, aucune action.'; exit 0 }
# Stopper D'ABORD les workers pour eviter qu'un RAW refuse ne regenere le clip.
foreach ($w in $workers) {
    try { Stop-Process -Id $w.ProcessId -Force -ErrorAction Stop; Write-Host "Worker FilmMaker PID $($w.ProcessId) arrete." }
    catch { Write-Warning "PID $($w.ProcessId): $($_.Exception.Message)" }
}
# Debloquer UNIQUEMENT les portes RAW existantes, sans toucher aux projets complets.
foreach ($gate in $gates) {
    $target = $gate.FullName -replace '\.waiting\.json$','.decision.json'
    # JSON UTF-8 SANS BOM : Windows PowerShell 5.1 écrirait un BOM avec -Encoding UTF8,
    # et le plugin H3 lit ce fichier avec Python json.loads(encoding="utf-8").
    $json = @{action='redo';feedback='Annulation explicite de l ancien Studio'} | ConvertTo-Json -Compress
    [System.IO.File]::WriteAllText($target, $json, (New-Object System.Text.UTF8Encoding($false)))
    Write-Host "Validation RAW annulee : $target"
}
Write-Host 'Les portes RAW devraient sortir sous quelques secondes. Si un sampling tourne encore'
Write-Host 'dans ComfyUI 8188, utilise son bouton Interrupt. Ne vide pas la queue des autres projets.'
