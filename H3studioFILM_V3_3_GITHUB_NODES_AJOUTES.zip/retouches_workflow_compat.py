"""Convert author ComfyUI UI graphs (including nested subgraphs and Get/Set
variable reroutes) to reachable API nodes. Used only by the isolated Retouches
runner. No modifications to ComfyUI nor H3 Film Studio's core workflow.
"""
from __future__ import annotations
import copy


def _socket_name(name, allowed):
    if name in allowed:return name
    if isinstance(name,str) and '.' in name:
        parent,child=name.split('.',1)
        if parent in allowed and child and (parent in ('values','ref_images','ref_videos','ref_video_audios','ref_audios') or 'AUTOGROW' in str(allowed[parent]).upper()):return name
        alias=name.rsplit('.',1)[-1]
        if alias in allowed:return alias
    return None


def _var_name(node):
    named=node.get('widgets_values_named') or {}
    for key in ('variable','variable_name','name','value'):
        v=named.get(key)
        if isinstance(v,str) and v.strip():return v.strip()
    for v in (node.get('widgets_values') or []):
        if isinstance(v,str) and v.strip():return v.strip()
    return str(node.get('title') or '').strip()


def flatten_to_api(ui, object_info, input_mapper, overrides=None):
    """Reachability-based API compilation from SaveVideo targets.

    Root/child subgraph sockets are traced by actual LiteGraph links. This
    avoids treating visual subgraph UUIDs and GetNode/SetNode as backend nodes.
    """
    if 'nodes' not in ui:
        return {str(k):copy.deepcopy(v) for k,v in ui.items() if isinstance(v,dict) and 'class_type' in v}
    definitions={str(v.get('id')):v for v in (ui.get('definitions') or {}).get('subgraphs',[])}
    overrides=overrides or {}
    results={}
    stack=set()

    class Scope:
        def __init__(self,graph,prefix,parent=None,sub_inputs=None,creator=None):
            self.graph=graph;self.prefix=prefix;self.parent=parent;self.sub_inputs=sub_inputs or {};self.creator=creator
            self.nodes={str(n['id']):n for n in graph.get('nodes',[]) if 'id' in n}
            self.links={str(l.get('id') if isinstance(l,dict) else l[0]):l for l in graph.get('links',[])}
            self.sub_scopes={}
            self.setters={}
            for n in self.nodes.values():
                if n.get('type')=='SetNode':
                    self.setters.setdefault(_var_name(n),[]).append(n)
        def locate_link(self,ident):
            link=self.links.get(str(ident))
            if link is None:raise ValueError(f'Lien de workflow introuvable : {ident}')
            if isinstance(link,dict):return str(link['origin_id']),int(link['origin_slot'])
            return str(link[1]),int(link[2])
        def ref_for_link(self,ident):
            if ident is None:raise ValueError('Lien de workflow absent')
            origin,slot=self.locate_link(ident)
            return self.ref(origin,slot)
        def _find_setter(self,name):
            current=self
            while current:
                if name in current.setters:return current,current.setters[name][-1]
                current=current.parent
            raise ValueError(f'Variable GetNode introuvable : {name}')
        def ref(self,nid,slot=0):
            key=(self.prefix,nid,slot)
            if key in stack:raise ValueError('Cycle dans les liens du workflow : '+str(key))
            stack.add(key)
            try:return self._ref(nid,slot)
            finally:stack.remove(key)
        def _ref(self,nid,slot):
            if nid=='-10':
                if slot in self.sub_inputs:return self.sub_inputs[slot]
                # A subgraph may expose an input with an explicit widget
                # default instead of a LiteGraph link. Preserve that value.
                meta=(self.graph.get('inputs') or [])
                item=meta[slot] if slot<len(meta) else {}
                port_name=str(item.get('name') or '')
                parent_node=self.creator or {}
                current=(parent_node.get('widgets_values_named') or {})
                sentinel=object()
                val=current.get(port_name,sentinel)
                if val is sentinel:
                    for key in ('default','defaultValue','default_value','value','widget_value'):
                        if key in item and item[key] is not None:
                            val=item[key];break
                typename=str(item.get('type') or '').upper()
                if val is sentinel and 'MOGE_MODEL' not in typename and port_name!='moge_model':
                    raise ValueError('Entrée de sous-graphe non reliée : '+str(slot)+' ('+port_name+')')
                if 'FLOAT' in typename:kind='PrimitiveFloat'
                elif 'INT' in typename:kind='PrimitiveInt'
                elif 'STRING' in typename:kind='PrimitiveString'
                elif 'MOGE_MODEL' in typename or port_name=='moge_model':
                    if 'LoadMoGeModel' not in object_info:
                        raise ValueError('LoadMoGeModel absent : ce workflow nécessite le modèle géométrique MoGe')
                    model_list=((((object_info['LoadMoGeModel'].get('input') or {}).get('required') or {}).get('model_name')) or [[]])[0]
                    choices=[str(v) for v in model_list] if isinstance(model_list,list) else []
                    choice=next((x for x in choices if 'moge_2_vitl_normal' in x.lower()),None)
                    if not choice:
                        raise ValueError('MoGe2 non trouvé dans models/geometry_estimation')
                    ident=self.prefix+'auto_moge_'+str(slot)
                    results[ident]={'class_type':'LoadMoGeModel','inputs':{'model_name':choice}}
                    self.sub_inputs[slot]=[ident,0]
                    return self.sub_inputs[slot]
                else:raise ValueError('Entrée de sous-graphe non reliée sans type scalaire : '+str(slot)+' ('+port_name+')')
                if kind not in object_info:
                    raise ValueError('Node de valeur par défaut manquant : '+kind)
                ident=self.prefix+'default_'+str(slot)
                results[ident]={'class_type':kind,'inputs':{'value':val}}
                self.sub_inputs[slot]=[ident,0]
                return self.sub_inputs[slot]
            n=self.nodes.get(nid)
            if not n:raise ValueError('Node de workflow introuvable : '+nid)
            t=str(n.get('type') or '')
            if t in definitions:
                child=self.sub_scopes.get(nid)
                if child is None:
                    inputs={}
                    for i,entry in enumerate(n.get('inputs') or []):
                        if entry.get('link') is not None:
                            inputs[i]=self.ref_for_link(entry['link'])
                    child=Scope(definitions[t],self.prefix+nid+'_',self,inputs,creator=n)
                    self.sub_scopes[nid]=child
                for link in definitions[t].get('links',[]):
                    tid=link.get('target_id') if isinstance(link,dict) else link[3]
                    tslot=link.get('target_slot') if isinstance(link,dict) else link[4]
                    if str(tid)=='-20' and int(tslot)==slot:
                        return child.ref_for_link(link['id'] if isinstance(link,dict) else link[0])
                outs=(definitions[t].get('outputs') or [])
                if slot<len(outs):
                    ids=outs[slot].get('linkIds') or []
                    if ids:return child.ref_for_link(ids[0])
                raise ValueError('Sortie de sous-graphe non reliée : '+t+'/'+str(slot))
            if t=='GetNode':
                scope,setter=self._find_setter(_var_name(n))
                entry=next((x for x in setter.get('inputs',[]) if x.get('link') is not None),None)
                if not entry:raise ValueError('Variable SetNode sans source : '+_var_name(n))
                return scope.ref_for_link(entry['link'])
            if t in ('SetNode','Reroute') or n.get('mode')==4:
                incoming=[x for x in n.get('inputs',[]) if x.get('link') is not None]
                preferred=next((x for x in incoming if x.get('type')=='MODEL'),None)
                entry=preferred or next(iter(incoming),None)
                if not entry:raise ValueError('Reroute ou node désactivé sans entrée : '+t)
                return self.ref_for_link(entry['link'])
            if t not in object_info:
                raise ValueError('Node nécessaire absent de ComfyUI : '+t)
            keyid=self.prefix+nid
            if keyid not in results:
                spec=object_info[t]
                inputs=input_mapper(n,spec)
                allowed={**spec.get('input',{}).get('required',{}),**spec.get('input',{}).get('optional',{})}
                # Set provisional entry first; recursion guard above handles cycles.
                results[keyid]={'class_type':t,'inputs':inputs}
                for inp in n.get('inputs',[]):
                    if inp.get('link') is None:continue
                    name=_socket_name(inp.get('name'),allowed)
                    if name:
                        inputs[name]=self.ref_for_link(inp['link'])
            return [keyid,slot]
        def populate_save(self,n):
            self.ref(str(n['id']),0)

    root=Scope(ui,'')
    save_like={'SaveVideo','VHS_VideoCombine','SaveAnimatedWEBP','SaveWEBM','SaveMp4','VideoCombine'}
    outputs=[n for n in ui.get('nodes',[]) if n.get('type') in save_like and n.get('mode')!=4]
    if not outputs:
        raise ValueError('Aucun export vidéo actif dans ce workflow')
    # Leave only one final MP4, never select auxiliary warp/preview exports.
    def score(n):
        named=(n.get('widgets_values_named') or {})
        text=(str(n.get('title') or '')+' '+str(named.get('filename_prefix',''))+' '+str(named.get('filename',''))).lower()
        return (8 if any(x in text for x in ('final','output','edited','result')) else 0)-(20 if any(x in text for x in ('preview','compare','warp','mask','source','original')) else 0)
    errors=[]
    for final in sorted(outputs,key=score,reverse=True):
        results.clear();stack.clear();root.sub_scopes.clear()
        try:
            root.populate_save(final)
            if results:return copy.deepcopy(results)
        except (ValueError,RuntimeError) as exc:
            errors.append(str(exc))
    raise ValueError('Aucun export CrossView compilable : '+' | '.join(errors[:3])[:600])
