@echo off
rem Point d'entree Retouches historique : meme serveur que Film Studio.
call "%~dp0LANCER-STUDIO-UNIFIE-7861.cmd"
