$ErrorActionPreference = 'Stop'
$comfy = 'C:\AI\ComfyUI_windows_portable\ComfyUI'
$plugin = Join-Path $comfy 'custom_nodes\H3StudioRetouchExtras\__init__.py'
Write-Host 'DIAGNOSTIC COMFYUI (lecture seule) : aucun logiciel modifie.' -ForegroundColor Cyan
Write-Host ('Module sur disque : '+ (Test-Path -LiteralPath $plugin))
try {
    $response = Invoke-RestMethod -Uri 'http://127.0.0.1:8188/object_info' -TimeoutSec 12
    foreach ($name in @('H3StudioImageToVideo','H3RetouchMaskV58','H3RoychoAnimatedMaskV62','H3LoadRawLatentExact','MVEx_SubjectCrop')) {
        $exists = ($response.PSObject.Properties.Name -contains $name)
        Write-Host ('{0} : {1}' -f $name, $(if ($exists) { 'CHARGE' } else { 'ABSENT DU SERVEUR' }))
    }
} catch {
    Write-Host ('ComfyUI ne repond pas sur 8188 : '+$_.Exception.Message) -ForegroundColor Red
}
try {
  Get-CimInstance Win32_Process | Where-Object { $_.Name -like 'python*' -and $_.CommandLine -like '*main.py*' } | ForEach-Object {
      Write-Host ('Processus ComfyUI PID '+$_.ProcessId+' : '+$_.CommandLine)
  }
} catch {
  Write-Host ('Chemin du processus non consultable : '+$_.Exception.Message)
}
Write-Host 'Si le fichier est present mais les nodes absents du serveur, redemarrer COMFYUI (pas seulement le Studio), puis relancer ce diagnostic.' -ForegroundColor Yellow
