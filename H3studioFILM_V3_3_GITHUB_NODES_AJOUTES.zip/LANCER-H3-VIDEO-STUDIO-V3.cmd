@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-H3Video-STUDIO-V3.ps1" %*
pause
