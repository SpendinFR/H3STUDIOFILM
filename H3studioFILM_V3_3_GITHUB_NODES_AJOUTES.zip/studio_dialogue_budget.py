"""Dialogue pacing check on FINAL Clip Director shot intervals, not all script prose.

No effect on scenes without <d>...</d> dialogue. Never rewrites a story itself.
"""
from __future__ import annotations
import re

# Match the Clip Director's normal timing syntax, including user-edited
# parentheses and spacing. Header discovery remains separate: a malformed
# explicit header must never silently skip its dialogue budget.
SHOT = re.compile(
    r'(?im)^[ \t]*(?:[-*][ \t]+)?(?:\*\*)?\[Shot[ \t]+\d+\]'
    r'[ \t]*\(?[ \t]*([0-9]+(?::[0-9]+)?(?:[.,][0-9]+)?)'
    r'[ \t]*s?[ \t]*[–—-][ \t]*'
    r'([0-9]+(?::[0-9]+)?(?:[.,][0-9]+)?)[ \t]*s?[ \t]*\)?'
)
SHOT_LABEL = re.compile(r'(?im)^[ \t]*(?:[-*][ \t]+)?(?:\*\*)?\[Shot[ \t]+\d+\]')
OPEN_D = re.compile(r'<d\s*>', re.I)
CLOSE_D = re.compile(r'</d\s*>', re.I)

class DialogueBudgetError(ValueError):
    """Unsafe dialogue or timing; never treat this as a GPU render failure."""
SPOKEN = re.compile(r'<d\s*>\s*(.*?)\s*</d\s*>',re.I|re.S)
LANG = re.compile(r'^\s*\[[^\]]{1,35}\]\s*')
WORDS = re.compile(r"[^\W_]+(?:[’'\-][^\W_]+)*",re.UNICODE)

def seconds(raw):
    s=str(raw).replace(',', '.')
    return sum(float(x)*m for x,m in zip(reversed(s.split(':')),[1,60,3600]))

def check(text, limit=3.0):
    """Validate *every* spoken line, including edited and RAW-retake prompts.

    An undecodable shot header must fail closed: assigning its dialogue an
    invented duration would let an overlong line reach ComfyUI.
    """
    text=str(text or '')
    dialogue=list(SPOKEN.finditer(text))
    if not dialogue and not OPEN_D.search(text) and not CLOSE_D.search(text):
        return []
    def issue(label, words, allowed, seconds, lines, start=0.0, end=0.0):
        return {'shot':label,'start':start,'end':end,'words':words,
                'max_words':allowed,'seconds':seconds,'lines':lines}
    if len(list(OPEN_D.finditer(text))) != len(dialogue) or len(list(CLOSE_D.finditer(text))) != len(dialogue):
        return [issue('balise <d> invalide',len(dialogue),0,0.0,[])]
    # Speech budget is only about actual spoken words: a silent [Shot] may
    # have an undecodable/zero-length interval without blocking the entire film.
    # A totally silent prompt has no words to fit into any speech window.
    if not any(WORDS.search(LANG.sub('',m.group(1))) for m in dialogue):
        return []
    found=list(SHOT.finditer(text))
    labels=list(SHOT_LABEL.finditer(text))
    if len(labels) != len(found):
        return [issue('horaires [Shot] illisibles',sum(len(WORDS.findall(LANG.sub('',m.group(1)))) for m in dialogue),0,0.0,
                      [m.group(1) for m in dialogue])]
    # No shot headers is permitted by the existing Clip Director; in that
    # case apply the hard five-second clip budget, never an unlimited pass.
    if not found and dialogue:
        spoken=[LANG.sub('',m.group(1).strip()) for m in dialogue]
        words=sum(len(WORDS.findall(x)) for x in spoken)
        maximum=int(5.0*limit+1e-7)
        return [issue('clip sans [Shot]',words,maximum,5.0,spoken,0.0,5.0)] if words>maximum else []
    warnings=[]
    if found and any(m.end() <= found[0].start() for m in dialogue):
        early=[LANG.sub('',m.group(1).strip()) for m in dialogue if m.end() <= found[0].start()]
        warnings.append(issue('hors fenêtre',sum(len(WORDS.findall(x)) for x in early),0,0.0,early))
    prior_end=-1.0
    for i,m in enumerate(found):
        start,end=seconds(m.group(1)),seconds(m.group(2))
        block=text[m.end():found[i+1].start() if i+1<len(found) else len(text)]
        sentences=[LANG.sub('',s.strip()) for s in SPOKEN.findall(block)]
        words=sum(len(WORDS.findall(s)) for s in sentences)
        if not (0<=start<end<=5.01) or start < prior_end-0.05:
            # No spoken words in this shot: do not block the film for a
            # dialogue-window error unrelated to speech.
            if words:
                warnings.append(issue(f'{i+1} (fenêtre invalide)',words,0,0.0,sentences,start,end))
            continue
        prior_end=end
        budget=int((end-start)*limit+1e-7)
        if words>budget:
            warnings.append(issue(i+1,words,budget,round(end-start,2),sentences,start,end))
    return warnings


def feedback(warnings):
    if not warnings:return ''
    return '\n'.join(f"Shot {x['shot']} ({x['seconds']} s) : {x['words']} mots prononcés, maximum {x['max_words']}." for x in warnings)


def _shot_segments(text):
    found = list(SHOT.finditer(str(text or '')))
    return [(seconds(m.group(1)), seconds(m.group(2)),
             str(text)[m.end():found[i+1].start() if i+1<len(found) else len(str(text))])
            for i,m in enumerate(found)]


def transplant_spoken(original, proposal):
    """Keep EVERY non-dialogue byte of the approved H3 prompt unchanged.

    The LLM may suggest new wording, but not reassign a character's <d> span
    to a different shot/speaker, or change camera, actions or references.
    """
    src, dst = _shot_segments(original), _shot_segments(proposal)
    if not src or len(src) != len(dst):
        raise ValueError('Le Director a changé le nombre de shots')
    replacements=[]
    for (a,b,orig),(c,d,new) in zip(src,dst):
        if abs(a-c)>0.05 or abs(b-d)>0.05:
            raise ValueError('Le Director a déplacé une fenêtre de shot')
        old_lines=list(SPOKEN.finditer(orig));new_lines=list(SPOKEN.finditer(new))
        if len(old_lines)!=len(new_lines):
            raise ValueError('Le Director a changé les prises de parole ou leur attribution')
        for old,updated in zip(old_lines,new_lines):
            new_text=updated.group(1).strip()
            if not LANG.match(new_text):
                language=LANG.match(old.group(1))
                if language:new_text=language.group(0).strip()+' '+new_text
            if not WORDS.search(LANG.sub('',new_text)):
                raise ValueError('Le Director a vidé une réplique')
            replacements.append(new_text)
    existing=list(SPOKEN.finditer(original))
    if len(existing)!=len(replacements):
        raise ValueError('Le nombre de répliques ne correspond pas au prompt approuvé')
    chunks=[];at=0
    for line,new_text in zip(existing,replacements):
        chunks.append(original[at:line.start(1)]);chunks.append(new_text);at=line.end(1)
    chunks.append(original[at:])
    return ''.join(chunks)


def repair(prompt, director, max_attempts=3):
    """Try a bounded number of LLM-only dialogue fixes; never permit GPU overflow."""
    current=prompt
    issues=check(current)
    for attempt in range(1,max_attempts+1):
        if not issues:return current, []
        try:
            reply=director(current, issues, attempt)
            candidate=transplant_spoken(current,reply)
            if candidate==current:continue
            current=candidate
            issues=check(current)
        except Exception:
            # A malformed Director output must not corrupt the approved prompt.
            continue
    return current,issues
