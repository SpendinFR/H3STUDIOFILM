# Installation manuelle de secours des trois JSON auteurs, sans aucun poids de modele.
$ErrorActionPreference = 'Stop'
$folder = Join-Path $PSScriptRoot 'retouches_workflows'
New-Item -ItemType Directory -Force -Path $folder | Out-Null
$files = @(
  @{Name='remove_person.json'; URL='https://huggingface.co/akatz-ai/MiniMax-H3-Person-Remover-LoRA/resolve/main/examples/Person-Remover-Window-Reroll-V1.json'},
  @{Name='swap_person.json'; URL='https://huggingface.co/akatz-ai/MiniMax-H3-Character-Swap-LoRA/resolve/main/examples/H3%20Character%20Swap%20v1%20Ref2VA.json'},
  @{Name='move_camera.json'; URL='https://huggingface.co/datasets/Cseti/ComfyUI-Workflows/resolve/main/minimax-h3/crossview-warp/crossview-warp-h3.json'}
)
foreach ($item in $files) {
  $dest = Join-Path $folder $item.Name
  if (Test-Path -LiteralPath $dest) {
    Write-Host "Deja present : $($item.Name)" -ForegroundColor Green
    continue
  }
  $tmp = "$dest.part"
  Write-Host "Telechargement : $($item.Name)" -ForegroundColor Cyan
  & curl.exe -fL --retry 2 --connect-timeout 25 --max-time 180 -o $tmp $item.URL
  if ($LASTEXITCODE -ne 0) {
    Remove-Item -LiteralPath $tmp -ErrorAction SilentlyContinue
    Write-Warning "Echec du telechargement : $($item.Name)"
    continue
  }
  try {
    $data = Get-Content -LiteralPath $tmp -Raw -Encoding UTF8 | ConvertFrom-Json
    if (!$data -or (!$data.nodes -and !$data.PSObject.Properties['1'])) {
      throw 'JSON workflow invalide'
    }
    Move-Item -LiteralPath $tmp -Destination $dest
    Write-Host "OK : $($item.Name)" -ForegroundColor Green
  } catch {
    Remove-Item -LiteralPath $tmp -ErrorAction SilentlyContinue
    Write-Warning "Fichier non valide : $($item.Name) / $_"
  }
}
