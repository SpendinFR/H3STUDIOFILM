"""Additive V10.53 RAW-only natural-language retouch engines.

Never modifies original FilmMaker H3 workflow, the five legacy Retouches builders,
or their render output. Every job has its own API graph, output prefix and status.
"""
from __future__ import annotations
import copy, json, os, re, subprocess, time, uuid, threading, shutil, urllib.request, urllib.error, base64, math
import torch
from pathlib import Path
from urllib.parse import quote
import h3_runtime_simple as rt
import retouches_engine as legacy
import retouches_new_windowing as windows
import retouches_precise_local_v78 as precise_local
import retouches_precise_half_v82 as precise_half
import retouches_precise_center_v90 as precise_center
import retouches_roycho_complete_v63 as roycho63

HERE=Path(__file__).resolve().parent
SOURCE_COPY=HERE/'retouches_new_workflows'/'RAW_ENGINE_SOURCE_COPY.json'
ROOT=HERE/'studio_sessions'/'retouches'/'new_engines'
JOBS=ROOT/'jobs'
RESULTS=ROOT/'results'
MODES={'extend':'Prolongation','performance':'Performance','precise':'Retake précis','insert':'Ajouter élément'}
REQUIRED={'H3RetouchMaskV58','H3LoadRawLatentExact','H3StudioImageToVideo','SamplerCustomAdvanced','SaveVideo'}
EXTRA_REQUIRED={'precise':set(),'insert':{'H3RoychoAnimatedMaskV62','MVEx_MaskCleanup','MVEx_SubjectCrop','MVEx_MaskToLatentSpace','MVEx_SubjectUncrop'},'performance':set()}
LOCK=threading.RLock()
ACTIVE=set()
CANCELLED=set()


def _mode_required_nodes(mode):
    # Retake preserves exactly the V94 required-node contract.
    if mode=='precise':return REQUIRED|EXTRA_REQUIRED['precise']
    if mode=='insert':return {'H3LoadRawLatentExact'}|EXTRA_REQUIRED['insert']
    return {'H3StudioImageToVideo','SamplerCustomAdvanced','SaveVideo'}


def _jobfile(ident):
    if not re.fullmatch(r'[0-9a-f]{32}',str(ident)):
        raise ValueError('Identifiant invalide')
    return JOBS/(ident+'.json')

def _save(row):
    JOBS.mkdir(parents=True,exist_ok=True)
    p=_jobfile(row['id']);tmp=p.with_suffix('.tmp')
    tmp.write_text(json.dumps(row,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,p)

def job(ident):
    try:return json.loads(_jobfile(ident).read_text(encoding='utf-8'))
    except OSError:raise ValueError('Rendu introuvable')

def jobs():
    if not JOBS.is_dir():return []
    out=[]
    for path in sorted(JOBS.glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True)[:35]:
        try:out.append(json.loads(path.read_text(encoding='utf-8')))
        except (OSError,ValueError):continue
    return out

def _update(ident,**updates):
    with LOCK:
        r=job(ident);r.update(updates);_save(r)

def readiness():
    try:
        info=legacy.comfy_json('/object_info',timeout=5)
    except Exception as exc:
        return {'ready':False,'missing':['ComfyUI arrêté'], 'detail':str(exc)[:300]}
    missing=sorted({'H3StudioImageToVideo','SamplerCustomAdvanced','SaveVideo'}-set(info))
    return {'ready':not missing,'missing':missing,'source_copy':SOURCE_COPY.is_file()}

def _project(project,clip,load_project,comfy,require_latent=True):
    if not re.fullmatch(r'[A-Za-z0-9_-]+',str(project or '')):raise ValueError('Projet RAW invalide')
    if not re.fullmatch(r'[0-9]+',str(clip or '')):raise ValueError('Numéro du clip RAW invalide')
    root=load_project(project)
    if root is None:raise ValueError('Projet introuvable')
    registry_path=root/'_studio'/'clips.json'
    registry=json.loads(registry_path.read_text(encoding='utf-8')) if registry_path.is_file() else {'clips':{}}
    entry=(registry.get('clips') or {}).get(str(clip)) or {}
    raw=entry.get('raw')
    # A paused FilmMaker clip's newest RAW is authoritative, even when an
    # older registry entry exists. This guarantees the first Retake/Insert uses
    # the same original MP4 shown in Direction and its matching .pt, with NO
    # video re-encode, modified mask, or alternate sampling route.
    # Check for the explicit pending FilmMaker gate. Otherwise use registry.
    if (root/'_studio'/'gates'/f'clip_{int(clip):04d}.retouch.requested.json').is_file():
        pending=root/'_studio'/'gates'/f'clip_{int(clip):04d}.retouch.requested.json'
        session_root=Path(__file__).resolve().parent/'studio_sessions'
        marker=json.loads(pending.read_text('utf-8')) if pending.is_file() else {}
        session=session_root/str(marker.get('session') or '')
        stage=session/'stage.json'
        phase=json.loads(stage.read_text('utf-8')) if stage.is_file() else {}
        if marker.get('project')==str(project) and int(marker.get('clip') or 0)==int(clip) and phase.get('stage')=='raw_retouch':
            videos=sorted((root/'raw').glob(f'clip_{int(clip):04d}_RAW_MC*.mp4'))
            if videos:raw=str(videos[-1])
    if not raw:raise ValueError('Ce clip ne possède pas de vidéo RAW')
    source=Path(str(raw).split(' [',1)[0]);source=source if source.is_absolute() else comfy/('input' if '[input]' in str(raw) else 'output')/source
    source=source.resolve()
    if not source.is_relative_to((comfy/'output').resolve()) or not source.is_file():
        raise ValueError('Fichier RAW en sortie ComfyUI introuvable')
    # There is no MP4-to-VAE fallback. Exact original H3 latent is obligatory.
    latent=(root/'_state'/f'clip_{int(clip):04d}_RAW_LATENT.pt').resolve()
    if require_latent and not latent.is_file():raise ValueError('Latent RAW exact absent pour ce clip (.pt). Aucun réencodage MP4 autorisé.')
    output_state=(comfy/'output'/'H3FilmSimple'/project/'_state').resolve()
    if latent.parent!=output_state:
        raise ValueError('Latent RAW hors du stockage officiel H3Studio')
    return source,latent

def _encode_continuation_mp4_as_h3_latent(source:Path, comfy:Path, project:str, clip:str,
                                          ident:str, info:dict, meta:dict) -> Path:
    """Isolated VIDEO -> H3 AV V2V latent stage for a subsequent Retake/Insert.

    Not an original exact H3 generation latent: it is an explicitly labelled,
    newly VAE-encoded continuation copy. The original FilmMaker RAW .pt stays
    immutable. Never use this path for the FIRST retouch of a project RAW.
    """
    if not (23.5 <= meta['fps'] <= 24.5):
        raise ValueError('Continuation H3 : source MP4 à 24 images/s requise')
    if meta['width'] % 32 or meta['height'] % 32:
        raise ValueError('Continuation H3 : dimensions de vidéo non alignées sur 32')
    if 'H3StoreRawLatentExact' not in info or 'H3StudioImageToVideo' not in info:
        raise RuntimeError('Continuation native : nœuds H3StoreRawLatentExact / H3StudioImageToVideo manquants')
    gui=_snapshot_gui()
    graph=rt.gui_to_api(gui,info)
    rt.patch_models(graph,info)
    found=[(nid,node) for nid,node in graph.items() if node['class_type']=='H3StudioImageToVideo']
    if len(found)!=1:raise RuntimeError('Continuation H3 : encodeur H3Studio non unique')
    h3id,h3=found[0]
    rt.reset_h3_optional_inputs(h3,info)
    h3in=h3['inputs']
    input_video=_stage_input_video(source,comfy,ident,'continuation_source')
    supported=set(rt.input_schema(info,'H3StudioImageToVideo')[0]) | set(rt.input_schema(info,'H3StudioImageToVideo')[1])
    if 'v2v_video_file' not in supported:
        raise RuntimeError('Continuation H3 : V2V indisponible dans ce nœud H3Studio')
    for key in ('ref_image_files','ref_audio_files','ref_video_files','first_frame_file',
                'last_frame_file','motion_context_file','timed_text','ref_spec','ref_video_spec'):
        if key in h3in:h3in[key]=''
    h3in.update({'v2v_video_file':input_video,'v2v_start_seconds':0.0,
                 'v2v_end_seconds':0.0,'v2v_denoise':0.0,'v2v_noise':0.0,
                 'width':meta['width'],'height':meta['height'],'length':meta['frames']})
    _h3_context_off(h3in,info)
    if 'ref_video_crops' in h3in:h3in['ref_video_crops']=''
    if 'v2v_crop' in h3in:h3in['v2v_crop']=''
    temp_name=f'clip_{int(clip):04d}_CHAIN_ENCODE_{ident}'
    store_id='999991'
    graph[store_id]={
        'class_type':'H3StoreRawLatentExact',
        'inputs':{'latent':[str(h3id),1],'project_name':project,
                  'latent_name':temp_name},
        '_meta':{'title':'Continuation MP4 — H3 AV V2V latent (not original RAW)'}}
    # Execute through the existing RAW SaveVideo output node: ComfyUI prunes
    # non-output disconnected stores otherwise. RAW sampler is bypassed, so
    # the only costly operations are V2V video/audio encode + VAE decode.
    # The RAW SaveVideo dependency closure does NOT contain the optional
    # LTXVSeparateAVLatent node 183: the original RAW decoders are linked
    # directly to H3RawCacheHold. V3 assumed that split was present, which
    # rejected *every* Retake -> Insert (and Insert -> Retake) continuation.
    # Build a tiny, self-contained AV decoder for the V2V-encoded latent.
    # This only operates on subsequent retouches, never on the V10.108 first
    # retouch or on Film Directions' established RAW/HD workflow.
    save=graph.get('191')
    video_decode=graph.get('188')
    audio_decode=graph.get('189')
    create_video=graph.get('190')
    if (not save or save.get('class_type')!='SaveVideo' or
        not video_decode or video_decode.get('class_type')!='VAEDecode' or
        not audio_decode or audio_decode.get('class_type')!='VAEDecodeAudio' or
        not create_video or create_video.get('class_type')!='CreateVideo'):
        raise RuntimeError('Continuation : décodeurs AV/SaveVideo du RAW source introuvables')
    if 'LTXVSeparateAVLatent' not in info:
        raise RuntimeError('Continuation : nœud ComfyUI LTXVSeparateAVLatent manquant')
    split_id='183'
    split=graph.get(split_id)
    if split is None:
        # Exact official node type: one H3 AV latent in, separate video/audio
        # latents out. No change to any source workflow file.
        graph[split_id]={'class_type':'LTXVSeparateAVLatent',
                         'inputs':{'av_latent':[store_id,0]}}
    elif split.get('class_type')=='LTXVSeparateAVLatent':
        split['inputs']['av_latent']=[store_id,0]
    else:
        raise RuntimeError('Continuation : ID 183 occupé par un autre nœud')
    video_decode['inputs']['samples']=[split_id,0]
    audio_decode['inputs']['samples']=[split_id,1]
    save['inputs']['filename_prefix']='h3retouch_encode/'+ident+'_V2V_DECODE_TEST'
    upstream={'191'};todo=['191']
    while todo:
        node=graph[todo.pop()]
        for v in node.get('inputs',{}).values():
            if isinstance(v,list) and len(v)==2 and str(v[0]) in graph:
                nid=str(v[0])
                if nid not in upstream:upstream.add(nid);todo.append(nid)
    graph={k:v for k,v in graph.items() if str(k) in upstream}
    if store_id not in graph:
        raise RuntimeError('Continuation : store H3 AV déconnecté du rendu')
    if any(n['class_type'] in ('SamplerCustomAdvanced','KSampler') for n in graph.values()):
        raise RuntimeError('Continuation : encodeur V2V contient un sampler interdit')
    _preflight_graph_links(graph)
    _preflight_required_inputs(graph,info)
    _preflight_h3_numeric_inputs(graph,info)
    encoded=(comfy/'output'/'H3FilmSimple'/project/'_state'/(temp_name+'.pt')).resolve()
    encoded.unlink(missing_ok=True)
    _update(ident,stage='Continuation : réencodage MP4 en latent H3 AV isolé (sans génération RAW)')
    pid=rt.queue_graph(graph,uuid.uuid4().hex)
    _update(ident,prompt_id=pid,continuation_encode_only=True)
    deadline=time.monotonic()+240
    try:
        while time.monotonic()<deadline:
            if ident in CANCELLED:raise InterruptedError('Continuation annulée')
            queued=legacy.comfy_json('/queue',timeout=7)
            present=any(str(item[1])==pid for k in ('queue_running','queue_pending')
                        for item in queued.get(k,[]) if len(item)>1)
            history=legacy.comfy_json('/history/'+pid,timeout=7).get(pid,{})
            status=(history.get('status') or {}).get('status_str')
            if status in ('error','interrupted','cancelled','canceled'):
                raise RuntimeError('Conversion du MP4 en latent H3 échouée : '+str((history.get('status') or {}).get('messages') or status)[-900:])
            if status=='success' and not present:
                if not encoded.is_file():raise RuntimeError('Encodage terminé, fichier .pt de continuation absent')
                payload=_load_payload(encoded)
                if not isinstance(payload,dict) or 'samples' not in payload:
                    raise RuntimeError('Encodage AV de continuation incompatible avec H3')
                _members,v,a=windows._video_members(payload)
                expected=round(5+17*(int(v.shape[2])-2)/5)
                if abs(expected-int(meta['frames']))>1:
                    raise RuntimeError(f'Latent V2V temporel incompatible : {expected} images pour {meta["frames"]} images MP4')
                _update(ident,continuation_latent_origin='MP4 V2V encoder (not original exact RAW)',
                        continuation_latent_file=str(encoded))
                return encoded
            time.sleep(1.2)
        raise RuntimeError('Encodage du MP4 en latent H3 trop long (>240s), aucune retouche lancée')
    except BaseException:
        encoded.unlink(missing_ok=True)
        raise
    finally:
        _update(ident,prompt_id=None,continuation_encode_only=False)
        # A continuation input is an isolated *copy*. No source assets change.
        (comfy/'input'/input_video).unlink(missing_ok=True)


def _metadata(source,comfy):
    ffprobe=shutil.which('ffprobe') or str((comfy.parent/'ffmpeg'/'bin'/'ffprobe.exe'))
    p=subprocess.run([ffprobe,'-v','error','-select_streams','v:0','-show_entries','stream=width,height,r_frame_rate,nb_frames,duration','-show_entries','format=duration','-of','json',str(source)],capture_output=True,text=True,timeout=35)
    if p.returncode:raise ValueError('FFprobe ne peut pas lire ce RAW: '+p.stderr[-200:])
    j=json.loads(p.stdout);v=(j.get('streams') or [{}])[0];fps=v.get('r_frame_rate','24/1')
    a,b=(fps.split('/')+['1'])[:2];rate=float(a)/max(1,float(b))
    duration=float(v.get('duration') or j.get('format',{}).get('duration') or 0)
    if not duration:raise ValueError('Durée RAW invalide')
    frames=int(v.get('nb_frames') or 0) or round(duration*rate)
    return {'duration':duration,'fps':rate,'frames':frames,'width':int(v.get('width') or 0),'height':int(v.get('height') or 0)}

def _screenshot(source,comfy,ident,second):
    inp=comfy/'input';inp.mkdir(parents=True,exist_ok=True)
    path=inp/('h3new_'+ident+'_frame.png')
    ffmpeg=shutil.which('ffmpeg') or str(comfy.parent/'ffmpeg'/'bin'/'ffmpeg.exe')
    proc=subprocess.run([ffmpeg,'-hide_banner','-loglevel','error','-y','-ss',str(max(0.,second)),'-i',str(source),'-frames:v','1',str(path)],capture_output=True,text=True,timeout=45)
    if proc.returncode or not path.is_file():raise RuntimeError('Extraction frame RAW échouée : '+proc.stderr[-500:])
    return path


def _stage_input_video(source:Path, comfy:Path, ident:str, tag:str)->str:
    """Stage a source video into ComfyUI/input and return the filename only.

    H3Studio media fields typically expect a filename located in ComfyUI/input.
    Retouches therefore hard-link/copy the original RAW clip there, without ever
    replacing the original output file.
    """
    inp=comfy/'input'; inp.mkdir(parents=True,exist_ok=True)
    ext=(source.suffix or '.mp4').lower()
    name=f'h3new_{ident}_{tag}{ext}'
    dst=(inp/name).resolve()
    if dst.exists():
        return name
    try:
        os.link(source,dst)
    except OSError:
        shutil.copy2(source,dst)
    return name


def _stage_tracking_video(input_name:str,comfy:Path,ident:str)->Path:
    """Roycho's protected optical-flow node reads ONLY ComfyUI/output.

    Track the *same* video that ComfyUI/LoadVideo reads from input (including
    39-frame previews and 17-frame insertion prerolls). This fixes continued
    MP4s stored under studio_sessions without widening the node's safe paths.
    """
    if not re.fullmatch(r'[0-9a-f]{32}',str(ident)):
        raise ValueError('Suivi Roycho : identifiant de rendu invalide')
    if not input_name or Path(input_name).name!=input_name:
        raise ValueError('Suivi Roycho : nom de vidéo ComfyUI/input invalide')
    src=(comfy/'input'/input_name).resolve()
    root=(comfy/'input').resolve()
    if (not src.is_relative_to(root) or not src.is_file() or
            src.suffix.lower() not in ('.mp4','.mov','.mkv') or
            not src.name.startswith('h3new_'+ident+'_')):
        raise ValueError('Suivi Roycho : source de travail non autorisée')
    directory=comfy/'output'/'h3_retouch_tracking'
    directory.mkdir(parents=True,exist_ok=True)
    dst=(directory/('h3new_'+ident+'_tracking'+src.suffix.lower())).resolve()
    if dst.exists():
        raise ValueError('Suivi Roycho : fichier de travail déjà présent')
    try:
        os.link(src,dst)  # same bytes, no re-encoding or disk duplication
    except OSError:
        shutil.copy2(src,dst)
    return dst

def _stage_insert_reference(path,comfy,ident):
    p=Path(path).resolve()
    allowed=((comfy/'input').resolve(),(comfy/'output').resolve())
    if not p.is_file() or p.suffix.lower() not in ('.png','.jpg','.jpeg','.webp') or not any(p.is_relative_to(root) for root in allowed):
        raise ValueError('Image de référence Ajouter élément introuvable ou non autorisée')
    dest=comfy/'input'/f'h3new_{ident}_insert_reference{p.suffix.lower()}'
    if p!=dest.resolve():shutil.copy2(p,dest)
    return dest.name


def _stage_short_source_video(source:Path,comfy:Path,ident:str,frames:int)->str:
    """Use the first H3-valid 39 frames for the 0.9s quick preview.

    The cropped MVEx video and source latent MUST have identical time grids.
    We write only an isolated input copy; the original RAW mp4 is untouched.
    """
    if frames!=39:raise ValueError('Quick preview expects exact 39-frame H3 grid')
    dest=comfy/'input'/f'h3new_{ident}_roycho_quick.mp4'
    dest.parent.mkdir(parents=True,exist_ok=True)
    ffmpeg=shutil.which('ffmpeg') or str(comfy.parent/'ffmpeg'/'bin'/'ffmpeg.exe')
    args=[ffmpeg,'-hide_banner','-loglevel','error','-y','-i',str(source),
          '-frames:v',str(frames),'-c:v','libx264','-preset','veryfast','-crf','16',
          '-c:a','aac','-t',str(frames/24.),'-movflags','+faststart',str(dest)]
    result=subprocess.run(args,capture_output=True,text=True,timeout=140)
    if result.returncode or not dest.is_file():
        raise RuntimeError('Quick Roycho: impossible de préparer les 39 frames : '+result.stderr[-700:])
    return dest.name


def _attach_source_video_conditioning(h3in:dict, mode:str, performance_type:str, clip_name:str, seconds:dict)->None:
    """Attach the existing clip itself as H3 video reference / video-to-video authority.

    This is the critical difference versus a prompt-only rewrite: the original
    video is explicitly provided back to H3 so the retouch modifies a known
    existing shot rather than hallucinating a brand-new one from text.
    """
    if not clip_name:
        return
    # v2v carries the temporal/pose/camera authority. ref_video gives the model
    # an additional explicit video reference channel when the installed schema
    # supports it.
    if 'v2v_video_file' in h3in:
        h3in['v2v_video_file']=clip_name
    if 'v2v_start_seconds' in h3in:
        h3in['v2v_start_seconds']=0
    if 'v2v_end_seconds' in h3in:
        h3in['v2v_end_seconds']=0
    if 'v2v_crop' in h3in:
        h3in['v2v_crop']=''
    if 'v2v_noise' in h3in:
        h3in['v2v_noise']=0
    if 'v2v_noise_declare' in h3in:
        h3in['v2v_noise_declare']=1
    # V10.72: increased V2V freedom for requested NEW actions/emotions.
    # V10.71 source-conditioning was 0.28 action, 0.24 emotion, 0.18 precise;
    # highly conservative versus a novel gesture. This is an experimental
    # single-variable change in *video conditioning*; native RAW mask/time,
    # H3's sampler, inserted elements and working Dialogue stay untouched.
    denoise=0.48
    if mode=='precise': denoise=0.44
    elif mode=='insert': denoise=0.24
    elif mode=='performance' and performance_type=='dialogue': denoise=0.22
    elif mode=='performance' and performance_type=='emotion': denoise=0.38
    # Advanced A/B tests can override ONLY the targeted mode via an explicit
    # process-local env var, without editing ComfyUI or any installed model.
    key=('H3_RETOUCH_V2V_PRECISE' if mode=='precise' else
         ('H3_RETOUCH_V2V_EMOTION' if mode=='performance' and performance_type=='emotion' else
          ('H3_RETOUCH_V2V_ACTION' if mode=='performance' and performance_type=='action' else None)))
    if key and os.environ.get(key):
        try: candidate=float(os.environ[key])
        except ValueError as exc: raise ValueError(f'{key} doit être un nombre entre 0.10 et 0.85') from exc
        if not (0.10<=candidate<=0.85) or not math.isfinite(candidate):
            raise ValueError(f'{key} doit être compris entre 0.10 et 0.85')
        denoise=candidate
    if 'v2v_denoise' in h3in:
        h3in['v2v_denoise']=round(denoise,3)
    if 'ref_video_files' in h3in:
        h3in['ref_video_files']=clip_name
    if 'ref_video_spec' in h3in:
        h3in['ref_video_spec']='1.0'
    if 'ref_video_crops' in h3in:
        h3in['ref_video_crops']=''




def _state_latent_name(clip:str)->str:
    return f'clip_{int(clip):04d}_RAW_LATENT'

def _load_payload(path:Path):
    try:return torch.load(path,map_location='cpu',weights_only=True)
    except TypeError:return torch.load(path,map_location='cpu')

def _prepare_quick_payload(latent_path:Path, job_id:str, project:str, clip:str, start:float, end:float):
    payload=_load_payload(latent_path)
    if not isinstance(payload,dict) or 'samples' not in payload:
        raise ValueError('Latent RAW exact incompatible pour essai court')
    samples=copy.deepcopy(payload.get('samples') or {})
    members=samples.get('members') or []
    if len(members)<2 or not isinstance(members[0],dict) or not isinstance(members[1],dict):
        raise ValueError('Payload RAW H3 inattendu pour essai court')
    video=members[0].get('tensor'); audio=members[1].get('tensor')
    if not (isinstance(video,torch.Tensor) and isinstance(audio,torch.Tensor)):
        raise ValueError('Tenseurs RAW H3 absents pour essai court')
    if video.ndim!=5 or audio.ndim!=4:
        raise ValueError('Structure RAW H3 inattendue pour essai court')
    total_t=int(video.shape[2]); window_t=12
    if total_t<window_t: raise ValueError('RAW trop court pour essai H3 39 images')
    # H3's first two latent tokens have special initial-frame semantics.
    # A slice starting in the middle of the RAW tensor is NOT a valid
    # independent H3 clip and was an important source of bogus quick tests.
    if end>39/24+1e-3:
        raise ValueError('Essai court exact uniquement pour les 1,6 premières secondes. Utilise Générer RAW pour un passage plus tardif.')
    first=0
    window_start=0.0
    full_frames=5+17*(total_t-2)/5
    audio_len=int(audio.shape[-1])
    start_frame=first*17/5
    audio_first=round(audio_len*start_frame/full_frames)
    audio_count=max(1,round(audio_len*39/full_frames))
    audio_first=min(audio_first,max(0,audio_len-audio_count))
    new_video=video[:,:,first:first+window_t,:,:].detach().cpu().contiguous()
    new_audio=audio[...,audio_first:audio_first+audio_count].detach().cpu().contiguous()
    members[0]['tensor']=new_video; members[0]['shape']=tuple(int(x) for x in new_video.shape); members[0]['device']='cpu'
    members[1]['tensor']=new_audio; members[1]['shape']=tuple(int(x) for x in new_audio.shape); members[1]['device']='cpu'
    payload2=dict(payload)
    payload2['samples']=samples
    payload2['noise_mask']=None
    latent_name=f'{_state_latent_name(clip)}__quick_{job_id[:8]}'
    out=latent_path.with_name(latent_name+'.pt')
    torch.save(payload2,out)
    new_start=max(0.0,min(39/24,start-window_start))
    new_end=max(new_start+0.01,min(39/24,end-window_start))
    return latent_name,out,{'start':new_start,'end':new_end,'duration':39/24,'frames':39,'first_latent':first}

PERFORMANCE_TYPES=('action','dialogue','emotion')


def _safe_line(value:str)->str:
    """Keep the actor's exact instruction, but never smuggle a spoken editor directive into dialogue."""
    line=' '.join(str(value).strip().split())
    if not line:raise ValueError('Consigne de retouche vide')
    return line


def _context_hint(source_prompt:str)->str:
    """Reuse only shot look/setting, never source dialogue or old gestures.

    Original latent pins the actual scene. Reprinting the full old prompt caused
    H3 to speak old dialogue and repeat original gestures in V10.56.
    """
    for line in str(source_prompt or '').splitlines():
        cleaned=line.strip(' *\t')
        if re.match(r'(?i)^(look_cam[eé]ra_et_lumi[eè]re|camera_and_lighting|visual_style|style_visuel)\s*:',cleaned):
            val=cleaned.split(':',1)[-1].strip(' *\t')
            # Forbid old speech directives from creeping into the new scene.
            val=re.split(r'<d>|\b(?:elle|il) dit\s*:',val,flags=re.I)[0]
            return val[:240].rstrip(' .')
    return ''


def _rewrite_shot(mode,request,original,start,end,part=1,parts=1,performance_type='action'):
    """Deterministic, short H3 result prompt. No Ollama and no intent classification.

    A user selects Action/Dialogue/Emotion. The original RAW latent is the
    reference; only a non-conflicting look hint is copied from the old prompt.
    """
    request=_safe_line(request)
    look=_context_hint(original)
    intro=('Single continuous film shot. Same original actor, identity, wardrobe, set, '
           'camera, framing and light. The unedited RAW video is the visual authority. '
           'Only the selected region and time may change.')
    if mode=='performance':
        if performance_type not in PERFORMANCE_TYPES:
            raise ValueError('Choisis Action, Dialogue ou Emotion')
        if performance_type=='dialogue':
            # The textarea IS the line to be spoken; no "ici elle dit" prefix.
            if '<d>' in request or '</d>' in request:
                raise ValueError('Écris seulement la réplique, sans balises H3')
            change=('The onscreen speaker delivers exactly this single spoken line, '
                    'with natural synchronized mouth motion; no extra spoken words: '
                    '<d>[French]'+request+'</d>')
            preserve='Preserve the original non-speech ambience and unrelated actions.'
        elif performance_type=='action':
            change=('Modify the existing onscreen performance so the performer now does this targeted action: '+request)
            preserve=('Keep the same shot and performer. Do not regenerate a different scene or replay a conflicting original gesture. Preserve other movements and the soundscape outside the edited moment.')
        else:
            change=('Modify the existing onscreen performance so the performer expresses this emotion or delivery: '+request)
            preserve=('Express it through face, gaze, posture and natural acting inside the selected interval. Preserve original speech unless the user explicitly wrote an emotional delivery.')
    elif mode=='precise':
        change='The corrected content in this segment is: '+request
        preserve='Only the selected segment is corrected. The first and final original states remain unchanged. Do not repeat the defective motion, contact, event or outcome.'
    elif mode=='insert':
        change=('Physically generate a new, fully integrated three-dimensional scene element in the editable area: '+request)
        preserve=('The new element enters or appears in coherent depth, casting shadows and obeying occlusion. '
                  'It is part of the actual environment, not a framed photo, sticker, overlay, inset or picture-in-picture. '
                  'Keep original actors, background and sound unchanged outside the editable area.')
    elif mode=='extend':
        intro='Same film and actors. Continue the current camera movement from the final RAW images; no new establishing shot.'
        change='Next continuous shot action: '+request
        preserve='Do not repeat the preceding five seconds. Continue its temporal and spatial motion naturally.'
    else:raise ValueError('Moteur RAW inconnu')
    parts_out=[intro]
    if look and mode!='extend':parts_out.append('Original visual appearance: '+look+'.')
    parts_out.append('[Shot 1] '+change)
    parts_out.append(preserve)
    if mode!='extend':parts_out.append('Edit only %.2f–%.2f seconds of the original shot.'%(start,end))
    return '\n'.join(parts_out),'Gabarit H3 déterministe · '+(performance_type if mode=='performance' else mode)

def _authoring_context(project,clip,load_project):
    """Only read established FilmMaker per-clip prompt/ref data; never mutate it."""
    folder=load_project(project)
    if not folder:return '',[],[]
    path=folder/'prompts'/('clip_%04d.txt'%int(clip))
    try:
        original=path.read_text(encoding='utf-8')[:16000]
    except OSError:original=''
    try:
        db=json.loads((folder/'_studio'/'clips.json').read_text(encoding='utf-8'))
        entry=((db.get('clips') or {}).get(str(clip)) or {})
        refs=[str(v) for v in (entry.get('refs') or []) if isinstance(v,str)][:8]
        voices=[str(v) for v in (entry.get('voices') or []) if isinstance(v,str)][:4]
    except (OSError,ValueError):refs=[];voices=[]
    if not refs and not voices:
        # A film being retouched at its RAW gate has no completed clips.json yet.
        try:
            meta=json.loads((folder/'prompts'/('clip_%04d.json'%int(clip))).read_text('utf-8'))
            refs=[str(x['annotated']) for x in meta.get('active_references',[]) if isinstance(x,dict) and x.get('annotated')]
            voices=[str(x['annotated']) for x in meta.get('active_audio_references',[]) if isinstance(x,dict) and x.get('annotated')]
        except (OSError,ValueError,KeyError,TypeError):pass
    return original,refs,voices



def _natural_time_range(instruction:str, duration:float):
    """Honor an explicit natural-language time range when no UI timeline is selected.

    No inference about unstated seconds: a single mention of a time may describe
    an event, not necessarily a strict replacement interval.
    """
    phrase=str(instruction or '').lower().replace(',', '.')
    patterns=(
      r'\bentre\s+(\d+(?:\.\d+)?)\s*(?:s|secondes?)?\s+et\s+(\d+(?:\.\d+)?)\s*(?:s|secondes?)?\b',
      r'\bde\s+(\d+(?:\.\d+)?)\s*(?:s|secondes?)?\s+à\s+(\d+(?:\.\d+)?)\s*(?:s|secondes?)?\b',
      r'\bfrom\s+(\d+(?:\.\d+)?)\s*(?:s|seconds?)?\s+to\s+(\d+(?:\.\d+)?)\s*(?:s|seconds?)?\b',
    )
    for pattern in patterns:
        found=re.search(pattern,phrase)
        if not found:continue
        a,b=map(float,found.groups())
        if 0<=a<b<=duration+.05:return (a,min(duration,b))
    return None

def _auto_rect(mode,instruction):
    # A full-frame temporal mask is preferable to silently editing the WRONG person.
    # Spatial inference is limited to explicit positioning expressed in the user's text.
    if mode in ('extend','precise'):return (0,0,100,100)
    txt=instruction.lower()
    x=0;y=0;w=100;h=100
    # Insertion into EMPTY SPACE: initial mask is a generated box, never SAM object tracking.
    if mode=='insert':
        w=48;h=74;x=26;y=13
        if any(s in txt for s in ('à gauche','sur la gauche','left side','on the left')):x=4
        if any(s in txt for s in ('à droite','sur la droite','right side','on the right')):x=48
        if any(s in txt for s in ('au fond','en arrière-plan','in background','far away')):w=40;h=54;y=15
        if any(s in txt for s in ('ciel','dans le ciel','sky','above')):y=0;h=42
    return (x,y,w,h)

def _vision_rectangle(mode, instruction, source, comfy, ident, at_second):
    """Optionally localize a requested subject/empty placement via an EXISTING local vision model.

    No masks/refs are requested from the operator. Falls back to explicit natural-language
    placement rules when a local vision LLM is unavailable. Never sends images to cloud.
    """
    baseline=_auto_rect(mode,instruction)
    if mode=='extend':return baseline
    tags=None
    try:
        with urllib.request.urlopen('http://127.0.0.1:11434/api/tags',timeout=3) as rsp:
            tags=json.load(rsp)
    except (OSError,ValueError):return baseline
    models=[str(x.get('name') or x.get('model') or '') for x in (tags.get('models') or [])]
    choices=[x for x in models if any(tag in x.lower() for tag in ('qwen3-vl','qwen2.5-vl','llama3.2-vision'))]
    if not choices:return baseline
    snap=_screenshot(source,comfy,ident,at_second)
    try:
        image_data=base64.b64encode(snap.read_bytes()).decode('ascii')
        system='You are a film VFX placement/localization assistant. Return ONLY valid JSON with x,y,w,h in percentage 0..100. The rectangle must cover the target region for the requested change. For an inserted object choose empty space, not the original subject. If action/emotion/dialogue choose the subject body/face. For fine repair choose the defect. Do not make huge masks for small objects.'
        req={'model':choices[0],'messages':[{'role':'system','content':system},{'role':'user','content':f'Editing mode: {mode}. User instruction: {instruction}. Locate best rectangle in the attached frame.', 'images':[image_data]}], 'stream':False,'format':'json','options':{'temperature':0.1,'num_predict':120},'keep_alive':0}
        payload=json.dumps(req).encode('utf-8')
        with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:11434/api/chat',data=payload,headers={'Content-Type':'application/json'}),timeout=100) as response:
            obj=json.load(response)
        content=(obj.get('message') or {}).get('content') or ''
        located=json.loads(content)
        if not isinstance(located,dict):return baseline
        values=[float(located[k]) for k in ('x','y','w','h')]
        x,y,w,h=values
        if not all(math.isfinite(z) for z in values) or not (0<=x<100 and 0<=y<100 and 2<=w<=100-x and 2<=h<=100-y):return baseline
        return (round(x,2),round(y,2),round(w,2),round(h,2))
    except (OSError,ValueError,KeyError,TypeError):return baseline
    finally:snap.unlink(missing_ok=True)

def _measured_visual_change(original,output,start,end,rect):
    """Simple QC: did sampled frames in edited ROI actually change?

    This is NOT a semantic check that a requested action/object is correct.
    """
    try:
        import cv2,numpy as np
        first=cv2.VideoCapture(str(original));second=cv2.VideoCapture(str(output))
        try:
            diffs=[]
            for t in np.linspace(max(.05,start+.1),max(start+.15,end-.1),num=5):
                first.set(cv2.CAP_PROP_POS_MSEC,float(t)*1000)
                second.set(cv2.CAP_PROP_POS_MSEC,float(t)*1000)
                ok1,a=first.read();ok2,b=second.read()
                if not(ok1 and ok2):continue
                if a.shape!=b.shape:
                    b=cv2.resize(b,(a.shape[1],a.shape[0]))
                x,y,w,h=rect
                hh,ww=a.shape[:2]
                ax=int(x*ww/100);ay=int(y*hh/100)
                bx=max(ax+1,int((x+w)*ww/100));by=max(ay+1,int((y+h)*hh/100))
                roi=(abs(a[ay:by,ax:bx].astype(np.float32)-b[ay:by,ax:bx].astype(np.float32))).mean()
                diffs.append(float(roi))
            return round(sum(diffs)/len(diffs),2) if diffs else None
        finally:first.release();second.release()
    except Exception:return None

def _snapshot_gui():
    raw=json.loads(SOURCE_COPY.read_text(encoding='utf-8'))
    # Select only the dependency closure of the existing RAW SaveVideo node.
    nodes={n['id']:n for n in raw['nodes']}
    links={l[0]:l for l in raw['links'] if isinstance(l,list) and len(l)>=5}
    need={191};todo=[191]
    while todo:
        n=nodes[todo.pop()]
        for inp in n.get('inputs',[]) or []:
            lid=inp.get('link')
            if lid in links:
                origin=links[lid][1]
                if origin in nodes and origin not in need:need.add(origin);todo.append(origin)
    raw['nodes']=[n for n in raw['nodes'] if n['id'] in need]
    raw['links']=[l for l in raw['links'] if isinstance(l,list) and l[1] in need and l[3] in need]
    return raw

def _h3_context_off(inputs, info):
    """Empty context file DISABLES MC; integer widgets still obey ComfyUI min=1.

    Historical regression: V10.55 wrote 0 and ComfyUI rejected the whole graph.
    Use the current live schema's default, falling back to the FilmMaker's known
    22-frame value. Never change the original FilmMaker workflow or custom node.
    """
    required, optional=rt.input_schema(info,'H3StudioImageToVideo')
    specs={**required,**optional}
    inputs['motion_context_file']=''
    for field in ('motion_context_frames','motion_context_audio_frames'):
        spec=specs.get(field)
        config=spec[1] if isinstance(spec,(list,tuple)) and len(spec)>1 and isinstance(spec[1],dict) else {}
        default=config.get('default',22)
        minimum=config.get('min',1)
        maximum=config.get('max',39)
        try:
            value=max(int(minimum),min(int(maximum),int(default)))
        except (ValueError,TypeError):
            value=22
        inputs[field]=value
    inputs['motion_context_reuse_latent']=False


def _preflight_h3_numeric_inputs(graph, info):
    """Catch server-side numeric input validation errors before POST /prompt.

    Checks active API nodes against the connected ComfyUI /object_info schema.
    Connections are left untouched; H3's dynamic parameters absent from schema
    remain ComfyUI's responsibility.
    """
    if not info:
        return  # Only contract/mocked graph-building tests omit object_info.
    for node_id,node in graph.items():
        ctype=node.get('class_type')
        if ctype not in info:
            # ComfyUI will otherwise fail with class_type not found; say which.
            raise RuntimeError(f'ComfyUI : nœud manquant {ctype} (n° {node_id}). Redémarre ComfyUI si tu viens de l’installer.')
        req,opt=rt.input_schema(info,ctype)
        specs={**req,**opt}
        for name,value in (node.get('inputs') or {}).items():
            if name not in specs or (isinstance(value,list) and len(value)==2 and isinstance(value[0],str) and value[0] in graph):
                continue
            spec=specs[name]
            if not isinstance(spec,(list,tuple)) or not spec:
                continue
            kind=spec[0]
            if kind not in ('INT','FLOAT') or isinstance(value,bool):
                continue
            if not isinstance(value,(int,float)):
                raise ValueError(f'Paramètre ComfyUI invalide : {ctype}.{name} = {value!r} (nombre attendu)')
            bounds=spec[1] if len(spec)>1 and isinstance(spec[1],dict) else {}
            minimum,maximum=bounds.get('min'),bounds.get('max')
            if (minimum is not None and value<minimum) or (maximum is not None and value>maximum):
                lim=f'{minimum if minimum is not None else "-∞"} à {maximum if maximum is not None else "+∞"}'
                raise ValueError(f'Paramètre ComfyUI hors limites : {ctype}.{name} = {value} (autorisé : {lim}, nœud {node_id}).')


def _preflight_graph_links(graph):
    """Reject dangling graph references before spending GPU time.

    Catch removed LoRA nodes and incorrect fixed output IDs before POST.
    String-list settings are not treated as node links unless the source is an
    explicit numeric ComfyUI node identifier.
    """
    for target_id,node in graph.items():
        for name,value in (node.get('inputs') or {}).items():
            if isinstance(value,list) and len(value)==2 and isinstance(value[0],str) and value[0].isdigit():
                if value[0] not in graph:
                    raise ValueError(f'Graphe H3 incomplet : nœud {target_id}.{name} réfère au nœud absent {value[0]}')
                if isinstance(value[1],bool) or not isinstance(value[1],int) or value[1]<0:
                    raise ValueError(f'Graphe H3 invalide : sortie {target_id}.{name}={value!r}')


def _preflight_required_inputs(graph,info):
    """Verify required input names for any upstream nodes with known schemas."""
    if not info:return
    for ident,node in graph.items():
        req,_=rt.input_schema(info,node['class_type'])
        missing=set(req).difference(node.get('inputs') or {})
        # Dynamic *indexed* multimodal sockets are optional in the resulting API graph.
        missing={field for field in missing if '.' not in field}
        if missing:
            raise ValueError(f'Nœud ComfyUI {node["class_type"]} ({ident}) : champs requis absents : '+', '.join(sorted(missing)))


def _configure_undistilled_inpaint_graph(graph):
    """Use an independent native H3 inpaint sampler path, not the film's turbo LoRA.

    The official panghea H3 inpaint examples use plain REF2VA +
    SigmaShift(12,3) + Euler + BasicScheduler(simple,8,1.0) + actual noise.
    A 4-step Turbo LoRA applied for 8 normal steps is not this workflow.
    """
    if '127' not in graph or graph['127']['class_type']!='UNETLoader':
        raise RuntimeError('Missing H3 model loader for independent inpaint path')
    for key,node in list(graph.items()):
        if node['class_type']=='MiniMaxH3SigmaShift':
            node['inputs']['model']=['127',0]
        if node['class_type']=='BasicScheduler':
            node['inputs']['scheduler']='simple'
            node['inputs']['steps']=8
            node['inputs']['denoise']=1.0
        if node['class_type']=='KSamplerSelect':
            node['inputs']['sampler_name']='euler'
    # Unused LoRA nodes must not be POSTed as independent graph outputs.
    graph.pop('173',None)
    graph.pop('224',None)
    if '129' not in graph or graph['129']['class_type']!='RandomNoise':
        raise RuntimeError('Real RandomNoise source is required for H3 inpainting')
    if '207' not in graph or graph['207']['class_type']!='SamplerCustomAdvanced':
        raise RuntimeError('H3 RAW sampler 207 unavailable')
    return graph

def _full_clip_h3_for_performance(mode:str, performance_type:str)->bool:
    """V10.73: user timeline guides Gemma; Action/Emotion H3 may regenerate all video tokens.

    Audio remains protected via track='video only'. Dialogue, Precise Retake,
    insertion and extension keep their V10.72 masking policy unchanged.
    """
    return mode=='performance' and performance_type in ('action','emotion')


def build_graph(info,mode,project,clip,source,ident,seconds,instruction,rect,segment=1,revised_prompt=None,refs=None,voices=None,test_clip=False,latent_name=None,performance_type='action',director_video_name=None,guide_image_name=None,director_base_frames=None,conditioning_video_name=None,insert_reference_name=None,performance_seed=None):
    if mode=='performance':
        import retouches_performance_native_v96 as native
        return native.build(info,source,ident,seconds,revised_prompt or instruction,performance_seed,
            first_frame_name=director_video_name,
            snapshot=_snapshot_gui,metadata=_metadata,comfy=Path(os.getenv('COMFYUI_DIR','C:/AI/ComfyUI_windows_portable/ComfyUI')),
            rt=rt,preflight=lambda g,i: (_preflight_graph_links(g),_preflight_required_inputs(g,i),_preflight_h3_numeric_inputs(g,i)))
    if mode=='insert':
        # The full Roycho/MVEx pipeline is an independent cropped-video graph.
        # In particular, do not feed the original full-frame .pt directly to
        # the crop sampler: cropped video has a DIFFERENT latent geometry.
        graph=roycho63.build(info,ident=ident,source=source,
            source_filename=conditioning_video_name,project=project,clip=clip,
            seconds=seconds,instruction=instruction,rect=rect,
            latent_name=latent_name or _state_latent_name(clip),guide_image_name=guide_image_name,
            insert_reference_name=insert_reference_name,h3_prompt_override=revised_prompt)
        _preflight_graph_links(graph)
        _preflight_required_inputs(graph,info)
        _preflight_h3_numeric_inputs(graph,info)
        return graph
    gui=_snapshot_gui()
    graph=rt.gui_to_api(gui,info)
    rt.patch_models(graph,info)
    # The original RAW cache HOLD is FilmMaker's private continuity state; bypass it in new jobs.
    for node in graph.values():
        for name,value in list(node['inputs'].items()):
            if isinstance(value,list) and value and str(value[0])=='201':
                node['inputs'][name]=['207',0]
    graph.pop('201',None)
    if mode!='extend':_configure_undistilled_inpaint_graph(graph)
    # Source RAW-only copy, never patch workflows/H3Studio_1920_API_CLEAN.json.
    h3id,h3=next(((key,node) for key,node in graph.items() if node['class_type']=='H3StudioImageToVideo'))
    rt.reset_h3_optional_inputs(h3,info)
    meta=_metadata(source,Path(os.getenv('COMFYUI_DIR','C:/AI/ComfyUI_windows_portable/ComfyUI')))
    prompt=revised_prompt or _rewrite_shot(mode,instruction,'',seconds['start'],seconds['end'],performance_type=performance_type)[0]
    h3in=h3['inputs']
    h3in.update({'prompt':prompt,'width':meta['width'],'height':meta['height']})
    # RAW dimensions come from the real RAW source. H3Studio expects width/height in multiples of 32.
    if meta['width']%32 or meta['height']%32:raise ValueError('RAW H3 dimensions non alignées sur 32')
    for key in ('ref_image_files','ref_audio_files','ref_video_files','first_frame_file','last_frame_file','motion_context_file','timed_text','v2v_video_file','ref_spec','ref_video_spec'):
        if key in h3in:h3in[key]=''
    # Automatically reuse FilmMaker's canonical references for this exact RAW clip.
    if refs and 'ref_image_files' in h3in:
        h3in['ref_image_files']='\n'.join(refs)
        if 'ref_spec' in h3in:h3in['ref_spec']='\n'.join(['1.0']*len(refs))
        if 'ref_image_size' in h3in:h3in['ref_image_size']='max'
    if voices and 'ref_audio_files' in h3in:h3in['ref_audio_files']='\n'.join(voices)
    if mode in ('performance','precise','insert'):
        _attach_source_video_conditioning(h3in,mode,performance_type,conditioning_video_name or '',seconds)
        if mode=='precise' or (mode=='performance' and performance_type in ('action','emotion')):
            if not conditioning_video_name or h3in.get('ref_video_files')!=conditioning_video_name:
                raise RuntimeError('H3 : le canal vidéo <Video 1> (ref_video_files) manque au schéma H3StudioImageToVideo. Aucun rendu ne sera lancé avec une fausse référence.')
    if mode=='extend':
        h3in['length']=56 if test_clip else 141  # 22-frame context + 119 regenerated frames, H3Studio's known validated cadence.
        h3in['motion_context_file']=str(source)
        h3in['motion_context_frames']=22
        h3in['motion_context_audio_frames']=22
        h3in['motion_context_strength']=1.0
        h3in['motion_context_reuse_latent']=False
        h3in['motion_context_anchor_brightness']=True
        h3in['motion_context_end_seconds']=0.0
    else:
        h3in['length']=int(seconds['frames'])
        _h3_context_off(h3in,info)
        # Keep original latent pixels as the visual authority instead of regenerating shot from one screenshot.
        graph['901']={'class_type':'H3LoadRawLatentExact','inputs':{'project_name':project,'latent_name':latent_name or _state_latent_name(clip)},'_meta':{'title':'Retouches — original RAW exact'}}
        x,y,w,h=rect
        kind='both' if mode=='performance' and performance_type=='dialogue' else 'video only'
        latent_source=['901',0]
        # V10.73: this is THE real H3 RAW noise mask, not just a text hint.
        # Gemma already used seconds['start']..seconds['end'] for its shots;
        # only Performance Action/Emotion gets full-clip video generation.
        # Never expand Dialogue or Precise Retake implicitly.
        if _full_clip_h3_for_performance(mode, performance_type):
            mask_start=0.0
            mask_end=100.0
        elif test_clip:
            mask_start=100*seconds['start']/max(0.001,seconds['duration'])
            mask_end=100*seconds['end']/max(0.001,seconds['duration'])
        else:
            mask_start=seconds['start']/seconds['duration']*100
            mask_end=seconds['end']/seconds['duration']*100
        if mode=='insert':
            # Roycho animated mask -> upstream MVEx mask-to-H3-latent -> exact H3 AV RAW.
            # IMPORTANT: the MVEx output (not our approximation) determines every
            # editable video token; its auto geometry honors H3's VAE frame cycle.
            graph['902']={'class_type':'H3RoychoAnimatedMaskV62','inputs':{
                'latent':latent_source,'source_video':str(source),
                'start_seconds':float(seconds['start']),'end_seconds':float(seconds['end']),
                'x_pct':x,'y_pct':y,'w_pct':w,'h_pct':h},
                '_meta':{'title':'Roycho — automatic animated region on original video'}}
            graph['905']={'class_type':'MVEx_MaskToLatentSpace','inputs':{
                'masks':['902',0],'vae':['119',0],
                'compression':{'compression':'auto'},
                'spatial_method':'max','temporal_method':'max',
                'grow_spatial':0,'grow_temporal':0,'grow_temp_mode':'both'},
                '_meta':{'title':'MVEx ORIGINAL — mask to exact H3 VAE latent geometry'}}
            graph['906']={'class_type':'H3RoychoApplyMVExMaskV62','inputs':{
                'latent':latent_source,'mask':['905',0]},
                '_meta':{'title':'Roycho — attach upstream MVEx mask to original RAW AV'}}
        else:
            graph['902']={'class_type':'H3RetouchMaskV58','inputs':{'latent':latent_source, 'track':kind,
                'start_pct':max(0.,min(99.99,mask_start)),'end_pct':min(100.,mask_end),
                'x_pct':x,'y_pct':y,'w_pct':w,'h_pct':h,'time_feather_pct':(9.0 if test_clip else 2.5),
                'spatial_feather_pct':(7.0 if mode=='performance' else 4.0), 'strength':1.0},
                '_meta':{'title':'Panghea — inpaint latent RAW ciblé'}}
        graph['207']['inputs']['latent_image']=['906',0] if mode=='insert' else ['902',0]
        # No Krea pre-render / no forced still guide: H3 synthesizes the object.
        # The animated ROI, rather than a composited photograph, dictates where.
    # Avoid forcing a whole second FilmStudio job: output only RAW clip in dedicated namespace.
    graph['191']['inputs']['filename_prefix']='h3retake_v1059/'+ident+'_part'+str(segment).zfill(2)+'_RAW'
    for node in graph.values():
        if node['class_type']=='CreateVideo':
            schema=(info.get('CreateVideo',{}).get('input') or {})
            valid=set(schema.get('required',{}))|set(schema.get('optional',{}))
            if 'frame_rate' in valid:node['inputs']['frame_rate']=24
            if 'fps' in valid:node['inputs']['fps']=24
            if 'color_space' in valid:node['inputs']['color_space']='sRGB'
        if node['class_type']=='RandomNoise':node['inputs']['noise_seed']=int(uuid.UUID(ident))% (2**53)
    _preflight_graph_links(graph)
    _preflight_required_inputs(graph,info)
    _preflight_h3_numeric_inputs(graph,info)
    return graph

def _history_output(record,comfy,ident):
    # Read ONLY the exact output of our own SaveVideo 191; no old file lookup.
    result_node=(record.get('outputs') or {}).get('191') or {}
    videos=[]
    for key in ('video','videos','gifs','images'):
        data=result_node.get(key) or []
        videos.extend(data if isinstance(data,list) else [data])
    if not videos:
        for k,v in (record.get('outputs') or {}).items():
            if k=='191':videos=v.get('videos') or v.get('filenames') or []
    for item in videos:
        if not isinstance(item,dict):continue
        filename=item.get('filename') or ''
        sub=item.get('subfolder') or ''
        path=(comfy/'output'/sub/filename).resolve()
        if filename and path.is_relative_to((comfy/'output').resolve()) and path.is_file() and path.suffix.lower()=='.mp4' and ident in path.name:
            return path
    # ComfyUI's SaveVideo may provide file metadata via a different output key.
    for value in ((record.get('outputs') or {}).get('191') or {}).values():
        if isinstance(value,list):
            for item in value:
                if isinstance(item,dict) and ident in str(item.get('filename','')):
                    path=(comfy/'output'/str(item.get('subfolder') or '')/item['filename']).resolve()
                    if path.is_file() and path.is_relative_to((comfy/'output').resolve()):return path
    raise RuntimeError('RAW SaveVideo a terminé sans sortie identifiée pour ce nouveau moteur')

def _requested_seconds(text):
    """One written request can trigger several five-second H3 continuation shots."""
    t=text.lower().replace(',', '.')
    m=re.search(r'(?:de\s+|pendant\s+|ajoute\s+|\+\s*)(\d+(?:\.\d+)?)\s*(minutes?|min|secondes?|secs?|s)(?!\w)',t)
    if not m:return 5.
    value=float(m.group(1))*(60 if m.group(2).startswith('min') else 1)
    if not 0.4<=value<=30:raise ValueError('Prolongation : durée entre 0,4 et 30 secondes maximum')
    return value


def _cut_extend(src,generated,ident,comfy,requested):
    RESULTS.mkdir(parents=True,exist_ok=True)
    # All snippets are H3 RAW AV; trim their 22-frame context, then append to original.
    dest=RESULTS/(ident+'.mp4')
    ffmpeg=shutil.which('ffmpeg') or str(comfy.parent/'ffmpeg'/'bin'/'ffmpeg.exe')
    tails=[]
    try:
        for i,video in enumerate(generated):
            remain=requested-5*i
            if remain<=0:break
            tail=RESULTS/(ident+'_tail_'+str(i)+'.mp4')
            cmd=[ffmpeg,'-hide_banner','-loglevel','error','-y','-ss',str(22/24),'-i',str(video),'-t',str(min(5,remain)),
                 '-c:v','libx264','-preset','veryfast','-crf','18','-c:a','aac',str(tail)]
            proc=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
            if proc.returncode:raise RuntimeError('Trim Motion Context : '+proc.stderr[-700:])
            tails.append(tail)
        cmd=[ffmpeg,'-hide_banner','-loglevel','error','-y','-i',str(src)]
        for part in tails:cmd+=['-i',str(part)]
        if not tails:raise RuntimeError('Prolongation sans nouvelle image H3')
        chains=''.join('[%d:v][%d:a]'%(i,i) for i in range(1+len(tails)))
        cmd+=['-filter_complex',chains+'concat=n='+str(1+len(tails))+':v=1:a=1[outv][outa]',
              '-map','[outv]','-map','[outa]','-c:v','libx264','-preset','veryfast','-crf','18','-c:a','aac',str(dest)]
        proc=subprocess.run(cmd,capture_output=True,text=True,timeout=240)
        if proc.returncode:raise RuntimeError('Assemblage prolongation : '+proc.stderr[-800:])
        return dest
    finally:
        for tail in tails:tail.unlink(missing_ok=True)

def _temporal_change_qc(original, rendered, start, end, rect):
    """Detect no-op or grossly unrelated edits, NOT semantic correctness.

    We do not claim to know whether an object or gesture was generated.
    Reports an explicit warning rather than marking an unchanged clip successful.
    """
    inside=_measured_visual_change(original,rendered,start,end,rect)
    if inside is None:
        return {'mean_change':None,'warning':'Rendu calculé ; modification visuelle non vérifiée.'}
    warning=('Aucune modification visible significative détectée dans la zone.'
             if inside<2.0 else '')
    return {'mean_change':inside,'warning':warning}


def _prepare_true_insert_guide(info, source, comfy, ident, seconds, instruction, rect, krea_prompt=None):
    """Generate and verify a REAL 2D inpainted insertion guide before H3 runs.

    Uses the isolated pre-existing Krea2/LanPaint inpaint graph, *not* a picture
    overlay. The guide is then crop-aligned and encoded as an H3 frame anchor.
    """
    import retouches_new_insert_guide as guides
    import retouches_clean_plate as plate
    guides.prior.validate(info)
    # Select the beginning of insertion (not always the first frame).
    at=min(float(seconds['duration'])-.02, max(0.,float(seconds['start'])))
    original=_screenshot(source,comfy,ident,at)
    mask_path=comfy/'input'/f'h3new_{ident}_insert_mask.png'
    guides.make_mask(original,mask_path,rect)
    if not krea_prompt or not str(krea_prompt).strip():
        raise RuntimeError('Insertion : guide Krea neutre absent ; génération bloquée')
    graph=guides.build_graph(info,original.name,mask_path.name,instruction,ident,
                              guide_prompt=krea_prompt)
    _preflight_graph_links(graph)
    _preflight_required_inputs(graph,info)
    ans=legacy.comfy_json('/prompt',{'prompt':graph,'client_id':'studio_insert_guide_'+ident},timeout=60)
    pid=ans.get('prompt_id')
    if not pid:raise RuntimeError('Guide Krea2 refusé avant H3 : '+str(ans.get('node_errors') or ans)[:950])
    _update(ident,stage='Guide d’insertion Krea2 (avant H3)',prompt_id=pid)
    deadline=time.monotonic()+2400
    while time.monotonic()<deadline:
        if ident in CANCELLED:raise InterruptedError('Guide d’insertion annulé')
        time.sleep(3)
        record=legacy.comfy_json('/history/'+str(pid),timeout=20).get(str(pid))
        if not record:continue
        if (record.get('status') or {}).get('status_str')=='error':
            raise RuntimeError('Guide Krea2 : '+str(record.get('status',{}).get('messages',[]))[-1100:])
        if (record.get('status') or {}).get('status_str') in ('success','completed') or record.get('outputs'):
            rendered=plate.resolve_generated_png(record,comfy,output_node='11')
            score=guides.verify_visual_change(original,rendered,mask_path)
            _update(ident,insert_guide_change=round(score,2))
            return guides.stage_generated_guide(comfy,ident,rendered)
    raise RuntimeError('Guide Krea2 : délai dépassé avant le rendu H3')


def _safe_comfy_free(label,ident,require_idle=True):
    """Unloads cached ComfyUI models ONLY when queue is completely idle.

    Unlike FilmMaker's emergency comfy_hard_free, this routine never sends an
    interrupt and never clears someone else's queued/running jobs.
    """
    try:
        queue=legacy.comfy_json('/queue',timeout=10)
        if not isinstance(queue,dict):
            raise RuntimeError('Etat de file ComfyUI indisponible')
        active=queue.get('queue_running') or []
        waiting=queue.get('queue_pending') or []
        if active or waiting:
            msg=f'{label} : file ComfyUI non vide ({len(active)} actifs, {len(waiting)} en attente)'
            if require_idle:raise RuntimeError(msg+' ; libération VRAM refusée pour protéger les autres rendus')
            return False
        before=rt.query_gpu_vram()
        # /free is the native supported endpoint; no global queue mutation.
        rt.http_json(rt.COMFY_URL+'/free','POST',{'unload_models':True,'free_memory':True},timeout=20)
        time.sleep(2)
        # /free is async. Another job could have started since our first
        # queue check; never run a second model unload against that job.
        queue_second=legacy.comfy_json('/queue',timeout=10)
        if not isinstance(queue_second,dict) or queue_second.get('queue_running') or queue_second.get('queue_pending'):
            raise RuntimeError(f'{label} : un autre travail ComfyUI a démarré pendant la libération ; deuxième /free abandonné')
        rt.http_json(rt.COMFY_URL+'/free','POST',{'unload_models':True,'free_memory':True},timeout=20)
        time.sleep(1)
        after=rt.query_gpu_vram()
        if after and after['free'] < 2048:
            print(f'  [RETOUCHES WARN] VRAM encore occupée après libération ComfyUI: '
                  f'{after["used"]}/{after["total"]} MiB ; risque offload RAM et it/s lents',flush=True)
        result={'phase':label,'before':before,'after':after}
        _update(ident,last_gpu_release=result)
        return True
    except Exception as exc:
        if require_idle:raise
        _update(ident,gpu_release_warning=str(exc)[:400])
        return False


def _run(ident,load_project,comfy_fn):
    try:
        row=job(ident);comfy=comfy_fn()
        if (row.get('source') or {}).get('type')=='review':
            import studio_retouch_review as approval_registry
            ref=row['source']
            source=approval_registry.result_path(ref['kind'],ref['id'])
            if source is None:raise ValueError('MP4 de continuation validé introuvable')
            source=Path(source).resolve()
            for root in (legacy.RESULTS,RESULTS):
                if source.is_relative_to(Path(root).resolve()):break
            else:raise ValueError('Source de continuation hors des résultats vérifiés')
            latent=None
        else:
            source,latent=_project(row['project'],row['clip'],load_project,comfy,require_latent=(row['mode']!='performance'))
        meta=_metadata(source,comfy)
        _update(ident,actual_input_mp4=str(source),source_frames=meta['frames'],
                source_dimensions=[meta['width'],meta['height']],
                latent_policy=('encode_continued_mp4' if (row.get('source') or {}).get('type')=='review'
                               else 'original_v108_raw_exact'))
        if (row.get('source') or {}).get('type')=='review' and row['mode'] in ('precise','insert'):
            info_encoder=legacy.comfy_json('/object_info',timeout=30)
            latent=_encode_continuation_mp4_as_h3_latent(source,comfy,row['project'],row['clip'],ident,info_encoder,meta)
        duration=meta['duration']
        if not (23.5<=meta['fps']<=24.5):raise ValueError('RAW à 24 images/s requis : '+str(meta['fps']))
        if row['mode']!='extend':
            phrase_range=_natural_time_range(row['instruction'],duration) if not row['selected'] else None
            playhead=min(max(0.,float(row.get('playhead') or 0.)),duration)
            segment_retake=(row['mode']=='precise' or (row['mode']=='performance' and row.get('performance_type') in ('action','emotion')))
            # V10.70 NEW TAKE: if the user did not choose a timeline, give H3
            # the whole clip, not a hidden 1.25-second gesture window. The
            # explicit UI range and natural-language range still take priority.
            default_a=0.0 if segment_retake else 0.
            default_b=min(duration,39/24) if row.get('test_clip') and segment_retake else duration
            start=row['start'] if row['selected'] else (phrase_range[0] if phrase_range else default_a)
            end=row['end'] if row['selected'] else (phrase_range[1] if phrase_range else default_b)
            if not 0<=start<end<=duration+.01:raise ValueError('Timeline hors de la durée du clip')
        else:start=0.0;end=duration
        if row.get('test_clip') and row['mode']!='extend' and end>39/24+1e-3:
            raise ValueError('Essai RAW 39 images réservé aux 1,6 premières secondes ; utilise Générer RAW pour ce passage.')
        # V10.85: the obsolete V10.80 39-frame guard must not reject selected
        # half-clip Retakes. The actual half-window validator below is authoritative.
        # V10.66: ALL performance/retake jobs use the existing ComfyUI H3 RAW
        # inpainting path. Never execute the obsolete DiffSynth subprocess.
        # No silent MP4 latent reconstruction, the original .pt is required.
        _update(ident,status='preparing',stage='Chargement du RAW exact',effective_start=start,effective_end=end)
        info=legacy.comfy_json('/object_info',timeout=30)
        # V96: check ONLY nodes needed by the selected engine.
        missing=_mode_required_nodes(row['mode'])-set(info)
        if missing:raise RuntimeError("Nodes ComfyUI non installés : "+', '.join(sorted(missing))+". Lance l'installateur des nouveaux moteurs puis redémarre ComfyUI.")
        region=row.get('region')
        if region is not None:
            if not isinstance(region,list) or len(region)!=4:raise ValueError('Encadrement invalide')
            try:x,y,w,h=(float(v)*100 for v in region)
            except (TypeError,ValueError):raise ValueError('Encadrement invalide')
            if not (0<=x<100 and 0<=y<100 and 2<=w<=100-x and 2<=h<=100-y):raise ValueError('Encadrement hors cadre')
            rect=(x,y,w,h)
        else:
            # No LLM or VLM is called in the V10.57 retouch runtime.
            # A drawn rectangle always wins; otherwise use a conservative
            # placement default / an explicit left-right placement hint.
            rect=_auto_rect(row['mode'],row['instruction'])
            if row['mode']=='performance' and row.get('performance_type','action') in ('action','emotion'):
                # V10.75: both Action and Emotion get the FULL spatial frame.
                # A single-frame face detector can miss profiles or constrain
                # expression through its face ROI. Only an explicit user-drawn
                # rectangle (handled above) may narrow the spatial window.
                rect=(0.,0.,100.,100.)
        # For the Retake Stitch the original MP4 is only a splice source.
        # The editable latent ALWAYS remains the exact .pt (no MP4/VAE fallback).
        director_video_name=None
        staged_director=None
        guide_image=None
        conditioning_video_name=None
        if row['mode'] in ('precise','insert'):
            if row['mode']=='insert' and row.get('test_clip'):
                conditioning_video_name=_stage_short_source_video(source,comfy,ident,39)
            else:
                conditioning_video_name=_stage_input_video(source,comfy,ident,'source')
        # No Director stitch or separate DiffSynth process in V10.66.
        guide_image=None  # H3 creates the element from text; no Krea 2D pre-insertion.
        # Allow lead-in and follow-through for a physical motion. Dialogue must
        # stay in the exact speech window. Retake is 17-frame aligned upstream.
        requested_window=(start,end)
        if row['mode']=='insert':
            # Temporal latitude is for contextual conditioning only. MVEx masks and
            # the H3 prompt refer to the user's EXACT selected edit interval.
            context_start=max(0.,start-.18)
            context_end=min(duration,end+.30)
            _update(ident,technical_window=[round(context_start,3),round(context_end,3)],
                    user_window=[round(start,3),round(end,3)],
                    effective_start=start,effective_end=end)
        settings={'start':start,'end':end,'duration':duration,'frames':meta['frames'],
                  'user_start':requested_window[0],'user_end':requested_window[1]}
        quick_latent_name=None
        quick_temp_path=None
        temp_latents=[]
        long_insertion=False  # One continuous RAW H3 pass; never reset inserted object between windows.
        saved_payload=None
        starts=[]
        # V10.78: ONLY the full Retake button with a short, explicitly chosen
        # interval uses the experimental 39-frame local pass. In particular,
        # Essai debut RAW still enters _prepare_quick_payload unchanged above.
        local_retake=None
        render_retake=None
        center_retake=False
        if (row['mode']=='precise' and not row.get('test_clip')
                and row.get('selected')):
            saved_payload=_load_payload(latent)
            _,video_track,_=windows._video_members(saved_payload)
            total_latent=int(video_track.shape[2])
            try:
                local_retake=precise_half.select_window(total_latent,meta['frames'],start,end)
            except ValueError as exc:
                # Only selections spanning the midpoint fall back to the new
                # centered mode. All other V88 validation stays untouched.
                if 'chevauche la jonction' not in str(exc) and 'demi-fenêtre choisie' not in str(exc):
                    raise
                local_retake,render_retake=precise_center.select_window(
                    total_latent,meta['frames'],start,end)
                center_retake=True
            if not center_retake:
                render_retake=precise_half.render_window_with_preroll(
                    local_retake,total_latent,meta['frames'])
            local_name=f'{_state_latent_name(row["clip"])}__{("center" if center_retake else "half")}_{ident[:8]}'
            # Identical V88 method for RAW .pt slicing and reference video.
            temp_latents.append(precise_half.write_window(saved_payload,latent,local_name,render_retake))
            if conditioning_video_name:
                (comfy/'input'/conditioning_video_name).unlink(missing_ok=True)
            conditioning_video_name=precise_half.stage_reference(source,comfy,ident,render_retake)
            settings={'start':render_retake['start'],'end':render_retake['end'],
                      'duration':render_retake['duration'],'frames':int(render_retake['frames']),
                      'user_start':start,'user_end':end}
            _update(ident,stage=('Retake central — H3 marge double + deux raccords V10.88' if center_retake else 'Retake demi-clip — fenetre plus longue preparee'),
                    local_window={k:round(v,4) if isinstance(v,float) else v for k,v in local_retake.items()},
                    h3_render_window={k:round(v,4) if isinstance(v,float) else v for k,v in render_retake.items()},
                    experimental_window=True)
        if long_insertion:
            saved_payload=_load_payload(latent)
            _,video_track,_=windows._video_members(saved_payload)
            starts=windows.plan_windows(int(video_track.shape[2]))
        if row.get('test_clip') and row['mode'] not in ('extend','performance'):
            quick_latent_name,quick_temp_path,settings=_prepare_quick_payload(latent,ident,row['project'],row['clip'],start,end)
        # V10.101 — INSERT ONLY. H3 pins the full Krea still at generated frame 0.
        # Give it 17 *technical* frames to integrate the element before the actual
        # original first frame; remove exactly these 17 frames after sampling.
        # Retake, Performance and their prompts/latents are never touched.
        insert_preroll=False
        insert_padded_source=None
        insert_original_settings=None
        insert_source_name=None
        insert_mask_latent_name=None
        if row['mode']=='insert' and not row.get('test_clip') and start<=(1/24+1e-6):
            import retouches_insert_preroll_v101 as insert_lead
            insert_original_settings=dict(settings)
            insert_padded_source,insert_source_name=insert_lead.stage_source(source,comfy,ident,meta['frames'])
            insert_mask_latent_name=f'{_state_latent_name(row["clip"])}__insertmask_{ident[:8]}'
            temp_latents.append(insert_lead.stage_latent(latent,insert_mask_latent_name,meta['frames']))
            if conditioning_video_name:
                (comfy/'input'/conditioning_video_name).unlink(missing_ok=True)
            conditioning_video_name=insert_source_name
            settings=insert_lead.seconds_for_h3(settings)
            insert_preroll=True
            _update(ident,stage='Insertion : 17 images de préparation avant la première frame réelle',
                    insert_preroll_frames=insert_lead.LEAD_FRAMES,
                    insert_original_window=[round(start,3),round(end,3)],
                    insert_h3_window=[0,round(settings['duration'],3)])
        if ident in CANCELLED:raise InterruptedError('Rendu annulé')
        import retouches_performance_native_v96 as native
        workspace=ROOT/ident;workspace.mkdir(parents=True,exist_ok=True)
        count=(len(starts) if long_insertion else (1 if row.get('test_clip') else (math.ceil(_requested_seconds(row['instruction'])/5) if row['mode']=='extend' else 1)))
        original_prompt,refs,voices=_authoring_context(row['project'],row['clip'],load_project)
        previous=insert_padded_source if insert_preroll else source
        generated=[]
        for part in range(1,count+1):
            if ident in CANCELLED:raise InterruptedError('Rendu annulé')
            this_settings=settings
            if row['mode']=='performance' and row.get('test_clip'):
                this_settings=dict(settings,frames=39,duration=39/24,start=0.,end=39/24)
            this_name=(insert_mask_latent_name if insert_preroll else
                       (local_name if local_retake else quick_latent_name or (latent.stem if (row.get('source') or {}).get('type')=='review' and latent else None)))
            if long_insertion:
                beginning=starts[part-1]
                local_a,local_b,intersects=windows.local_interval(start,end,beginning)
                if not intersects:
                    generated.append(None)
                    _update(ident,stage='Fenêtre originale conservée',part=part,parts=count)
                    continue
                this_settings={'start':local_a,'end':local_b,'duration':39/24,'frames':39}
                this_name=f'{_state_latent_name(row["clip"])}__retake_{ident[:8]}_{part:02d}'
                temp_latents.append(windows.write_window(saved_payload,latent,this_name,beginning))
            _update(ident,status='preparing',stage='Préparation du prompt H3 ciblé',part=part,parts=count)
            if row['mode']=='precise' or (row['mode']=='performance' and row.get('performance_type') in ('action','emotion')):
                # V10.77 Performance: short Dialogue-style Gemma prompt, no forced
                # [Shot] timeline or old scene script sent to H3. Retake Precise
                # keeps its prior v74 code path without modification.
                if row['mode']=='performance':
                    import retouches_llm_prompt_v74 as llm_writer
                    _update(ident,stage='Gemma — Performance : nouvelle génération complète')
                else:
                    import retouches_llm_prompt_v74 as llm_writer
                    _update(ident,stage='Gemma réalisateur — Retake précis inchangé')
                llm_began=time.monotonic()
                if local_retake:
                    # Only local Retake uses the V10.80 Gemma authoring route.
                    # The existing Essai debut RAW writer/path is preserved.
                    import retouches_llm_prompt_half_v82 as local_writer
                    _update(ident,stage='Gemma — Retake demi-clip V10.82, temps locaux 0.000s')
                    if center_retake:
                        # V10.93 CENTRAL ONLY: same V83 formatting/parsing and
                        # same 63f H3/reference/latent clock, but meaningful
                        # before/action/after motion guidance instead of naked
                        # TRANSITION AVANT/APRES roles that Gemma copied.
                        import retouches_llm_prompt_center_v93 as center_writer
                        revised,rewriter=center_writer.write_prompt(
                            mode='precise',performance_type=row.get('performance_type','action'),
                            request=row['instruction'],source_prompt=original_prompt,
                            window=local_retake,
                            gpu_prepare=lambda: _safe_comfy_free('Avant LLM',ident,require_idle=True),
                        )
                    else:
                        # One-seam V10.88 path, byte-for-byte unchanged prompt
                        # author and parameter routing.
                        revised,rewriter=local_writer.write_prompt(
                            mode='precise',performance_type=row.get('performance_type','action'),
                            request=row['instruction'],source_prompt=original_prompt,
                            window=local_retake,
                            gpu_prepare=lambda: _safe_comfy_free('Avant LLM',ident,require_idle=True),
                        )
                        precise_center.verify_gemma_descriptions(revised)
                    # For CENTRAL, Gemma writes only the 63f human scene.
                    # Technical 10f pre/postroll are mapped afterward to H3's
                    # aligned 83f RAW and video reference, without another LLM
                    # call and without inventing a Shot or shifting the action.
                    if center_retake:
                        (workspace/('gemma_center_63f_part'+str(part)+'.txt')).write_text(
                            revised,encoding='utf-8')
                        revised=precise_center.prepare_prompt(revised,local_retake,render_retake)
                    # For the proven SIMPLE late-half case, the exact V88
                    # adapter still adds its 10-frame lead AFTER Gemma.
                    if (not center_retake and int(render_retake.get('preroll_frames',0))):
                        from retouches_preroll_prompt_v88 import prepare_for_h3
                        (workspace/('gemma_halfclip_part'+str(part)+'.txt')).write_text(
                            revised,encoding='utf-8')
                        revised=prepare_for_h3(revised,local_retake,render_retake)
                else:
                    revised,rewriter=llm_writer.write_prompt(
                        mode=row['mode'],performance_type=row.get('performance_type','action'),
                        request=row['instruction'],source_prompt=original_prompt,
                        start=float(this_settings['start']),end=float(this_settings['end']),
                        duration=float(this_settings['duration']),
                        gpu_prepare=lambda: _safe_comfy_free('Avant LLM',ident,require_idle=True),
                    )
                # The V10.82/V10.93 *local* Retake prompt writers unload their
                # own Gemma backend but (unlike the V10.74 writer) do not clear
                # OTHER Ollama Director models that may remain in a unified
                # Film Studio session. Keep the validated text, video graph,
                # scheduler, seed, and seam logic completely unchanged.
                if row['mode']=='precise' and local_retake:
                    import h3film_studio_v3 as film_memory
                    _update(ident,stage='Retake — vérification décharge de tous les modèles Director avant H3')
                    film_memory.release_all_text_models_for_h3(
                        label='Retake local — décharge complète Ollama avant H3')
                _update(ident,stage='LLM déchargé — préparation du H3 RAW',llm_seconds=round(time.monotonic()-llm_began,2))
            elif row['mode']=='insert':
                # V10.105: this is the ACTUAL Insert branch. Gemma's H3 prompt
                # and its neutral Krea placement prompt are two separate outputs.
                # Both use original clip seconds, never the 17-frame preroll clock.
                import retouches_llm_prompt_insert_v104 as insert_writer
                prompt_settings=(insert_original_settings if insert_preroll else this_settings)
                _update(ident,stage='Gemma — rédaction de l’insertion et du guide neutre')
                llm_began=time.monotonic()
                revised,krea_prompt,rewriter=insert_writer.write_prompt(
                    request=row['instruction'],source_prompt=original_prompt,
                    start=float(prompt_settings['start']),end=float(prompt_settings['end']),
                    duration=float(prompt_settings['duration']),
                    has_picture=bool(row.get('reference_path')),rect=rect,
                    gpu_prepare=lambda: _safe_comfy_free('Avant Gemma insertion',ident,require_idle=True))
                (workspace/('krea_insert_prompt_part'+str(part)+'.txt')).write_text(krea_prompt,encoding='utf-8')
                _update(ident,stage='Gemma déchargé — préparation du guide Krea neutre',
                        llm_seconds=round(time.monotonic()-llm_began,2))
            else:
                revised,rewriter=_rewrite_shot(row['mode'],row['instruction'],original_prompt,
                    this_settings['start'],this_settings['end'],part,count,
                    performance_type=row.get('performance_type','action'))
            _update(ident,prompt_method=rewriter,source_prompt_available=bool(original_prompt),engine_path=(('h3_center_v94_63f_semantic_83f_h3_double_10f_margin' if center_retake else 'h3_halfclip_retake_v82') if local_retake else {'extend':'motion_context_h3','precise':'h3_new_take_timeline_v72','insert':'roycho_mvex_crop_guided_vram_v66','performance':'h3_fresh_generation_full_prompt_v96'}[row['mode']]),
                    gemma_requested_window=[round(start,3),round(end,3)] if local_retake else [round(this_settings['start'],3),round(this_settings['end'],3)],
                    h3_generation_window=([0.0,round(this_settings['duration'],3)] if local_retake or _full_clip_h3_for_performance(row['mode'],row.get('performance_type','action')) else [round(this_settings['start'],3),round(this_settings['end'],3)]))
            (workspace/('shot_prompt_part'+str(part)+'.txt')).write_text(revised,encoding='utf-8')
            # An inserted subject requires an actual conditioned image appearance.
            # Without it a video mask only indicates WHERE H3 MAY change pixels.
            if row['mode']=='insert':
                _update(ident,stage='Insertion — libération VRAM H3 résiduelle avant Krea2')
                _safe_comfy_free('Avant Krea2',ident,require_idle=True)
                _update(ident,stage='Insertion — création et vérification du guide visuel Krea2')
                guide_image=_prepare_true_insert_guide(info,source,comfy,ident,
                    insert_original_settings if insert_preroll else this_settings,
                    row['instruction'],rect,krea_prompt=krea_prompt)
                # Krea2 guide job finished; unload Krea's models without any
                # /interrupt or /queue clear. Avoid impacting unrelated jobs.
                _update(ident,stage='Guide validé — libération VRAM Krea avant H3')
                _safe_comfy_free('Krea2 → H3',ident,require_idle=True)
            insert_reference_name=None
            if row['mode']=='insert' and row.get('reference_path'):
                insert_reference_name=_stage_insert_reference(row['reference_path'],comfy,ident)
            if row['mode']=='performance':
                # Source frame zero is the exact visual anchor from the original shot,
                # staged only for the new generation; no H3 RAW latent is loaded.
                director_video_name=_screenshot(source,comfy,ident,0.0).name
                seed_known=native.original_seed_known(row['project'],row['clip'],load_project)
                _update(ident,performance_original_seed_found=seed_known,
                        performance_visual_anchor=director_video_name,
                        performance_seed_note=('Graine originale retrouvée' if seed_known
                          else 'Graine originale absente des métadonnées : graine stable de remplacement'))
            graph=build_graph(info,row['mode'],row['project'],row['clip'],previous,ident,this_settings,row['instruction'],rect,segment=part,revised_prompt=revised,refs=refs,voices=voices,test_clip=bool(row.get('test_clip')),latent_name=this_name,performance_type=row.get('performance_type','action'),director_video_name=director_video_name,guide_image_name=(guide_image.name if guide_image else None),director_base_frames=meta['frames'],conditioning_video_name=conditioning_video_name,insert_reference_name=insert_reference_name,performance_seed=(native.seed_for_source(row['project'],row['clip'],load_project) if row['mode']=='performance' else None))
            if row['mode']=='insert':
                # LoadVideo uses the staged ComfyUI/input clip. The Roycho
                # optical-flow node independently insists on ComfyUI/output.
                # Give both nodes the same video bytes, even after Continue,
                # short previews or 17-frame warmup. Never relax validate_source.
                mask=graph.get('902') or {}
                if mask.get('class_type')!='H3RoychoAnimatedMaskV62':
                    raise RuntimeError('Insertion : graphe de suivi Roycho absent')
                if 'tracking_video' not in locals():
                    tracking_video=_stage_tracking_video(conditioning_video_name,comfy,ident)
                mask['inputs']['source_video']=str(tracking_video)
            # READ-ONLY diagnostic: proof of the exact masking actually sent to
            # ComfyUI. Krea2 runs only for 'insert', never Action/Emotion/Retake.
            if row['mode']=='precise':
                mask_node=graph.get('902',{})
                h3_node=next((n for n in graph.values() if n.get('class_type')=='H3StudioImageToVideo'),{})
                mask_record={
                    'mode':row['mode'],'performance_type':row.get('performance_type'),
                    'mask_node':mask_node.get('class_type'),
                    'mask_inputs':mask_node.get('inputs',{}),
                    'v2v_denoise':h3_node.get('inputs',{}).get('v2v_denoise'),
                    'video_reference_enabled':bool(h3_node.get('inputs',{}).get('ref_video_files')),
                    'krea_mask_used':False,
                    'gemma_requested_window_seconds':[round(this_settings['start'],3),round(this_settings['end'],3)],
                    'h3_generation_window_seconds':([0.0,round(this_settings['duration'],3)] if _full_clip_h3_for_performance(row['mode'],row.get('performance_type','action')) else [round(this_settings['start'],3),round(this_settings['end'],3)]),
                    'note':'V10.77: Performance Action/Emotion use full-frame spatial and full-clip temporal RAW masks by default, while Gemma describes the request at the user-selected time in a short prompt. A user-drawn spatial region remains respected. Dialogue/Precise unchanged; V2V and sampler unchanged from V10.75.'
                }
                (workspace/('mask_diagnostic_part'+str(part)+'.json')).write_text(
                    json.dumps(mask_record,ensure_ascii=False,indent=2),encoding='utf-8')
            if row['mode']=='insert':
                # Fail closed: both real prompt and optional image must reach the
                # graph H3 will execute; the UI preview must match exactly.
                h3_inputs=(graph.get('33') or {}).get('inputs',{})
                actual_h3=h3_inputs.get('prompt')
                if actual_h3 != revised:
                    raise RuntimeError('Insertion : le prompt visible diffère du véritable prompt MiniMax H3')
                actual_ref=h3_inputs.get('ref_images.ref_image_0')
                if bool(row.get('reference_path')) != bool(actual_ref):
                    raise RuntimeError('Insertion : liaison <Picture 1> incohérente avec la référence H3')
                if bool(row.get('reference_path')) != ('<Picture 1>' in actual_h3):
                    raise RuntimeError('Insertion : marqueur <Picture 1> incohérent dans le prompt H3')
                (workspace/('shot_prompt_part'+str(part)+'.txt')).write_text(actual_h3,encoding='utf-8')
            (workspace/('submitted_api_part'+str(part)+'.json')).write_text(json.dumps(graph,ensure_ascii=False,indent=2),encoding='utf-8')
            # ComfyUI can retain V2V/RAW decode tensors, previous H3/Krea
            # weights and conditioning between clips. On a 16 GB card this may
            # spill sampling into RAM and severely reduce it/s. Clear only the
            # idle ComfyUI model cache, AFTER LLM/Krea and BEFORE submitting H3.
            # No interrupt, queue clear, new model, steps or sampler change.
            if row['mode'] in ('precise','insert'):
                _update(ident,stage='Avant H3 — libération mémoire entre clips')
                if not (row['mode']=='precise' and local_retake):
                    # Local retake already released every Director model above.
                    import h3film_studio_v3 as film_memory
                    film_memory.release_all_text_models_for_h3(
                        label='Retouches H3 — contrôle Ollama avant sampler')
                if row['mode']=='precise':
                    # Insert already called Krea2 → H3 cleanup just above.
                    _safe_comfy_free('Avant sampler H3 RAW',ident,require_idle=True)
            # Read-only GPU observation: distinguish a memory-constrained H3 pass
            # from time spent in Gemma; record AFTER ComfyUI release.
            vram_before_h3=rt.query_gpu_vram()
            if vram_before_h3:
                print('  [RETOUCHES] H3 pré-sampler : VRAM '
                      f'{vram_before_h3["used"]}/{vram_before_h3["total"]} MiB, '
                      f'libre {vram_before_h3["free"]} MiB', flush=True)
            # Log ACTUAL submitted scheduler values: Roycho insertion may use
            # 20 steps whereas V10.108 precise Retake remains at 8. This is
            # telemetry only: never rewrite the sampler or its scheduler.
            graph_steps=sorted({int(n['inputs']['steps']) for n in graph.values()
                                if n.get('class_type')=='BasicScheduler'
                                and isinstance(n.get('inputs',{}).get('steps'),int)})
            _update(ident,h3_vram_before=vram_before_h3,
                    h3_steps=(max(graph_steps) if graph_steps else None),
                    h3_scheduler_steps=graph_steps,
                    h3_reference_video=bool(conditioning_video_name))
            h3_began=time.monotonic()
            answer=legacy.comfy_json('/prompt',{'prompt':graph,'client_id':'studio_retouches_new_'+ident},timeout=65)
            pid=answer.get('prompt_id')
            if not pid:raise RuntimeError('ComfyUI a refusé le workflow : '+str(answer.get('node_errors') or answer)[:1400])
            _update(ident,status='rendering',stage='Génération H3 dans ComfyUI',prompt_id=pid,part=part)
            until=time.monotonic()+5400
            result=None
            while time.monotonic()<until:
                if ident in CANCELLED:raise InterruptedError('Rendu annulé')
                time.sleep(3)
                hist=legacy.comfy_json('/history/'+str(pid),timeout=20).get(str(pid))
                if not hist:continue
                state=(hist.get('status') or {}).get('status_str')
                if state=='error':raise RuntimeError('ComfyUI : '+str(hist.get('status',{}).get('messages',[]))[-1700:])
                if state in ('success','completed') or hist.get('outputs'):
                    result=_history_output(hist,comfy,ident)
                    break
            if result is None:raise RuntimeError('Délai H3 dépassé ; vérifier ComfyUI avant de relancer')
            generated.append(result)
            _update(ident,h3_seconds=round(time.monotonic()-h3_began,2),
                    h3_vram_after=rt.query_gpu_vram())
            previous=result  # last generated H3 RAW becomes Motion Context for next shot
        _update(ident,status='compositing',stage='Assemblage du rendu RAW')
        RESULTS.mkdir(parents=True,exist_ok=True)
        dest=RESULTS/(ident+'.mp4')
        if row['mode']=='extend':
            dest=_cut_extend(source,generated,ident,comfy,(22/24 if row.get('test_clip') else _requested_seconds(row['instruction'])))
        elif local_retake:
            _update(ident,stage='Retake local — raccord image + audio original')
            # Render extra context, then discard it BEFORE the one and only
            # midpoint join. Full 63 wanted frames are retained after warm-up.
            import tempfile
            if center_retake:
                # Two *unaltered* V88 stitch() calls: generated->original tail,
                # then original head->resulting tail. Original audio preserved.
                precise_center.stitch(source,generated[0],dest,local_retake,render_retake,meta['frames'],comfy)
            else:
                with tempfile.TemporaryDirectory(prefix='h3_half_preroll_') as tmp:
                    trimmed=precise_half.trim_preroll(
                        generated[0],local_retake,render_retake,comfy,
                        Path(tmp)/'h3_half_63f.mp4')
                    precise_half.stitch(source,trimmed,dest,local_retake,meta['frames'],comfy)
        elif long_insertion:
            windows.stitch_windows(generated,starts,source,dest,meta['frames'],comfy)
        elif insert_preroll:
            _update(ident,stage='Insertion : suppression des 17 images techniques (audio original inchangé)')
            insert_lead.strip_warmup(generated[0],source,dest,meta['frames'],comfy)
        else:
            shutil.copy2(generated[0],dest)
        measured=None
        if row['mode'] in ('insert','precise') or (row['mode']=='performance' and row.get('performance_type')!='dialogue'):
            # Read the MP4 ONLY for a cheap post-render change check, never
            # for an H3 VAE encode. Do not confuse change with semantic success.
            measured=_measured_visual_change(source,dest,start,end,rect)
        warning=('Aucune modification visible significative détectée dans la zone.'
                 if measured is not None and measured<1.5 else '')
        _update(ident,status='complete',finished_at=time.time(),visual_change_score=measured,
                review_warning=warning,visual_result_unverified=True,url='/api/retouches/new/output/'+ident)
        return
    except Exception as exc:
        _update(ident,status='cancelled' if ident in CANCELLED else 'error',error=str(exc)[:1700],finished_at=time.time())
    finally:
        try:
            if 'quick_temp_path' in locals() and quick_temp_path:
                Path(quick_temp_path).unlink(missing_ok=True)
            for tmp in locals().get('temp_latents',[]):
                Path(tmp).unlink(missing_ok=True)
            for key in ('staged_director','guide_image','original_guide_frame','insertion_guide_mask'):
                q=locals().get(key)
                if q:Path(q).unlink(missing_ok=True)
            # Input staging is disposable. It may be a hardlink to the source,
            # but unlinking only this isolated input name NEVER deletes RAW.
            tracker=locals().get('tracking_video')
            if tracker and 'comfy' in locals():
                allowed=(comfy/'output'/'h3_retouch_tracking').resolve()
                p=Path(tracker).resolve()
                if p.parent==allowed and p.name.startswith('h3new_'+ident+'_tracking'):
                    p.unlink(missing_ok=True)
            staged=locals().get('conditioning_video_name')
            if staged and 'comfy' in locals() and str(staged).startswith('h3new_'+ident+'_'):
                (comfy/'input'/str(staged)).unlink(missing_ok=True)
            padded=locals().get('insert_padded_source')
            if padded and 'comfy' in locals():
                allowed=(comfy/'output'/'h3retouch_insert_preroll').resolve()
                p=Path(padded).resolve()
                if p.is_relative_to(allowed):p.unlink(missing_ok=True)
            staged_ref=locals().get('insert_reference_name')
            if staged_ref and 'comfy' in locals() and str(staged_ref).startswith('h3new_'+ident+'_'):
                (comfy/'input'/str(staged_ref)).unlink(missing_ok=True)
            # Temporary Krea input images and short source clips belong to this
            # job alone; never delete a shared RAW output / model / user input.
            if 'comfy' in locals():
                for suffix in ('_frame.png','_insert_mask.png','_roycho_quick.mp4',
                               '_inserted_keyframe.png','_director.mp4','_precise_window.mp4'):
                    (comfy/'input'/('h3new_'+ident+suffix)).unlink(missing_ok=True)
        except Exception:
            pass
        with LOCK:ACTIVE.discard(ident);CANCELLED.discard(ident)

def start(data,load_project,comfy_fn):
    if not isinstance(data,dict):raise ValueError('Demande invalide')
    mode=str(data.get('mode') or '')
    if mode not in MODES:raise ValueError('Nouveau moteur inconnu')
    source=data.get('source') or {}
    if not isinstance(source,dict):raise ValueError('Source Retake/Ajouter élément invalide')
    if source.get('type')=='review':
        import studio_retouch_review as approval_registry
        if approval_registry.decision(str(source.get('kind') or ''),str(source.get('id') or '')).get('state')!='continued':
            raise ValueError('Ce MP4 doit être validé avec « Continuer modifications »')
        project,clip=approval_registry.source_project_clip(str(source.get('kind') or ''),str(source.get('id') or ''))
        if not project or not clip:raise ValueError('Origine du clip de continuation introuvable')
        if approval_registry.result_path(str(source['kind']),str(source['id'])) is None:
            raise ValueError('MP4 précédent absent')
        source={'type':'review','kind':str(source['kind']),'id':str(source['id']), 'project':project,'clip':clip}
    elif source.get('type')!='project' or source.get('variant')!='raw':
        raise ValueError('Choisis un RAW du film ou un MP4 validé par Continuer')
    instruction=str(data.get('instruction') or '').strip()
    performance_type=str(data.get('performance_type') or 'action')
    if mode=='performance':performance_type='action'  # one full-shot natural-language mode
    if not 5<=len(instruction)<=1800:raise ValueError('Écris ta consigne en langage naturel (5 à 1800 caractères)')
    try:start_s=float(data.get('start') or 0);end_s=float(data.get('end') or 0)
    except Exception:raise ValueError('Timeline invalide')
    selected=bool(data.get('selected'))
    test_clip=bool(data.get('test_clip'))
    region=data.get('region')
    if selected and not 0<=start_s<end_s<=120:raise ValueError('Timeline de début/fin invalide')
    comfy=comfy_fn()
    if source.get('type')=='project':
        _project(source.get('project'),source.get('clip'),load_project,comfy,require_latent=(mode!='performance'))
    with LOCK:
        if ACTIVE:raise ValueError('Un nouveau moteur travaille déjà : ne lance pas deux H3 en parallèle')
        if legacy.RUNNING:raise ValueError('Un moteur de retouches existant est en cours : attends sa fin')
        ident=uuid.uuid4().hex
        record={'id':ident,'mode':mode,'name':MODES[mode],'instruction':instruction,'performance_type':performance_type,'project':source['project'],
          'clip':str(source['clip']),'source':source,'selected':selected,'start':start_s,'end':end_s,
          'status':'queued','created_at':time.time(),'test_clip':test_clip,'region':region,'playhead':float(data.get('playhead') or 0),
          'reference_path':str(data.get('reference_path') or '').strip()}
        _save(record);ACTIVE.add(ident)
    threading.Thread(target=_run,args=(ident,load_project,comfy_fn),daemon=True,name='H3-new-'+ident[:7]).start()
    return {'id':ident,'status':'queued'}

def prompt_preview(ident):
    r=job(ident)
    path=ROOT/ident/'shot_prompt_part1.txt'
    if not path.is_file():raise ValueError('Prompt H3 pas encore préparé')
    return {'id':ident,'mode':r.get('mode'),'method':r.get('prompt_method'),
            'source_prompt_available':r.get('source_prompt_available',False), 'performance_type':r.get('performance_type'),
            'text':path.read_text(encoding='utf-8')[:22000]}


def stop(ident):
    with LOCK:
        r=job(ident)
        if r['status'] in ('complete','error','cancelled'):return {'id':ident,'status':r['status']}
        CANCELLED.add(ident);pid=r.get('prompt_id')
        _update(ident,status='cancelling')
    if pid:
        try:legacy.comfy_json('/queue',{'delete':[pid]},timeout=7)
        except Exception:pass
        try:legacy.comfy_json('/interrupt',{'prompt_id':pid},timeout=7)
        except Exception:pass
    return {'id':ident,'status':'cancelling'}

def output(ident):
    r=job(ident)
    p=RESULTS/(ident+'.mp4')
    return p if r.get('status')=='complete' and p.is_file() else None
