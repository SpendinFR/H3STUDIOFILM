$comfy = "C:\AI\ComfyUI_windows_portable\ComfyUI"
$base = Join-Path $comfy 'custom_nodes'
if (!(Test-Path (Join-Path $comfy 'main.py'))) { throw "ComfyUI introuvable : $comfy" }
$target = Join-Path $base 'MaskVidExperiments'
if (Test-Path $target) {
    Write-Host "MaskVidExperiments est deja installe : $target" -ForegroundColor Green
} else {
    git clone 'https://github.com/drozbay/MaskVidExperiments.git' $target
    if ($LASTEXITCODE -ne 0) { throw "Impossible d'installer MaskVidExperiments" }
}
Write-Host "Redemarre ComfyUI pour charger MVEx_SubjectCrop, MVEx_MaskToLatentSpace et MVEx_SubjectUncrop." -ForegroundColor Cyan
