$ErrorActionPreference='Stop'
$comfy='C:\AI\ComfyUI_windows_portable\ComfyUI'
if (!(Test-Path -LiteralPath $comfy)) { throw "ComfyUI introuvable : $comfy" }
$src=Join-Path $PSScriptRoot 'custom_nodes\H3StudioRetouchExtras'
$dst=Join-Path $comfy 'custom_nodes\H3StudioRetouchExtras'
New-Item -ItemType Directory -Path $dst -Force | Out-Null
@('__init__.py','retouch_mask_math_v58.py','retouch_upstream_adapters_v59.py','retouch_motion_mask_v60.py','retouch_roycho_mvex_v62.py','retouch_roycho_guide_v64.py') | ForEach-Object {
  $from=Join-Path $src $_
  if (!(Test-Path -LiteralPath $from)) { throw "Module manquant : $from" }
  Copy-Item -LiteralPath $from -Destination $dst -Force
}
Write-Host '[OK] Modules H3 RAW/MVEx copiés; aucun pip / Python / CUDA / PyTorch modifié.' -ForegroundColor Green
$custom=Join-Path $comfy 'custom_nodes'
$installedMVEx=Get-ChildItem $custom -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'nodes_mask_to_latent.py') } | Select-Object -First 1
if (!$installedMVEx) {
  if (!(Get-Command git -ErrorAction SilentlyContinue)) { throw 'MVEx introuvable : git requis pour installer MaskVidExperiments uniquement.' }
  $mvex=Join-Path $custom 'H3RetouchMVExV1066'
  & git clone --depth 1 https://github.com/drozbay/MaskVidExperiments.git $mvex
  if ($LASTEXITCODE -ne 0) { throw 'MVEx GitHub : clone échoué.' }
  Write-Host '[OK] MVEx installé (code de nodes uniquement, aucun pip).' -ForegroundColor Green
} else { Write-Host '[OK] MVEx déjà présent.' -ForegroundColor Green }
Write-Host 'Si un node nouveau a été ajouté, redémarre ComfyUI avant le rendu.' -ForegroundColor Yellow
