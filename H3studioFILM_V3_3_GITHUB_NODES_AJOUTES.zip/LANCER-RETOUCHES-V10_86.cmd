@echo off
setlocal
set "H3_RETOUCH_ONLY=1"
set "COMFYUI_DIR=C:\AI\ComfyUI_windows_portable\ComfyUI"
set "PY=C:\AI\ComfyUI_windows_portable\python_embeded\python.exe"
if not exist "%PY%" (
 echo ERREUR : Python embarque ComfyUI introuvable.
 pause
 exit /b 1
)
cd /d "%~dp0"
echo V10.86 - Retake demi-clip: source originale preservee hors zone + raccord unique 4 images.
echo Essai debut RAW, Performance, Dialogue, FilmMaker inchanges.
echo Aucun pip, DiffSynth, CUDA ou modele installe.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALLER-NOUVEAUX-MOTEURS-V10_66.ps1"
if errorlevel 1 (
 echo Verification des nodes ComfyUI en echec.
 pause
 exit /b 1
)
echo Studio Retouches V10.86 : http://127.0.0.1:7861/
"%PY%" -u "%~dp0studio_web.py" --port 7861
if errorlevel 1 pause
endlocal
