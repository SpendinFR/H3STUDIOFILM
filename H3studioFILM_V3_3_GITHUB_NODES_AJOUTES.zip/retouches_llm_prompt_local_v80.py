"""V10.80: isolated Gemma authoring for the V10.78 local 39-frame Retake.

The successful 'Essai debut RAW' does NOT import this file. The long Retake,
Action/Emotion and Dialogue still use their existing writers unchanged.
"""
from __future__ import annotations
import re

import retouches_llm_prompt_v74 as inherited

DURATION=39/24
SYSTEM='''You are the MiniMax H3 local RETAKE DIRECTOR. Your output will be used
for ONE AND ONLY ONE short video segment of exactly 39 frames, 24 FPS,
1.625 seconds. You cannot see the footage; <Video 1> provides the local
visual reference to the video generator, NOT a script to replay.

The user-selected action MUST visibly occur inside the assigned ACTION beat.
Write ONLY this local segment, not the rest of the original video. The original
scenario excerpt is context to understand visual/action continuity, not text
to copy. Never output any original global timeline or unrelated full-clip shots.

The input gives an EXACT BEAT GRID. Output every required [Shot N] header
with these EXACT local times and in this order. Each beat is continuous
choreography, NOT a camera cut. Do not introduce cuts or teleports.

- TRANSITION BEFORE: a SHORT distinct [Shot] that naturally prepares for the
  action and maintains the prior body pose, gaze, identity and movement.
- ACTION: a separate [Shot] where the requested change is clearly and
  physically performed, not merely mentioned as a future intention.
- TRANSITION AFTER: a SHORT distinct [Shot] that completes the action or leads
  toward the ORIGINAL continuation after this 39-frame segment.
- Include before and/or after only if the grid actually provides these beats.
- The original story may have its next beat at a later timestamp (for example
  2.500s). Such a future beat is a CONTINUITY TARGET, not frames to generate.
  Your generated [Shot]s must STOP at 1.625s; never give an out-of-window
  time inside [Shot] headers or a new action after the local take ends.
- Preserve identities, clothing, background, ambience, camera and physical
  continuity unless the user explicitly changes them.
- Be concise: usually one or two vivid French sentences per short shot.
- No duplicated 'Pendant... Pendant...'; no old full-clip script, no extra
  dialogue unless explicitly required. The original audio remains unless a
  separate audio retouch is performed.

OUTPUT ONLY:
SCENE_CONTEXT: 1-2 French sentences about visible environment and actor.
NEW_TAKE:
[Shot 1] <EXACT ASSIGNED LOCAL TIMES> <French visible action>
...
No markdown fences, explanations, headings, global-script notes or JSON.
'''


def _grid(window:dict)->list[tuple[str,float,float]]:
    """A single edit shot, optionally with short distinct transition shots.

    Frames are the only timing authority. Do not manufacture beats <3 frames.
    """
    frames=int(window.get('frames',39))
    if frames!=39:raise ValueError('Retake local V10.80 requiert 39 images')
    a=int(window['local_first']);b=int(window['local_last'])
    if not 0<=a<b<=frames:raise ValueError('Fenêtre locale hors 39 images')
    # If a transition is shorter than 3 frames, merge those frames into the
    # action rather than demand an impossible separate cinematic beat.
    first=a if a>=3 else 0
    last=b if frames-b>=3 else frames
    out=[]
    if first:out.append(('TRANSITION AVANT',0,first/24))
    out.append(('ACTION',first/24,last/24))
    if last<frames:out.append(('TRANSITION APRÈS',last/24,DURATION))
    return out


def _source_excerpt(source_prompt:str,window:dict)->tuple[str,str]:
    """Allow reading only shots near the selected local window, plus a future anchor.

    This preserves contextual beats (e.g. the original shot's ending at 2.500s)
    without writing that future timeline to H3.
    """
    source=source_prompt or ''
    headers=list(inherited.SHOT_HEADER.finditer(source))
    if not headers:
        return source[:3200] or '(source scenario unavailable)', ''
    lo=float(window['global_offset']);hi=lo+DURATION
    parts=[]; future=[]
    for i,h in enumerate(headers):
        a,b=inherited._seconds(h.group(2)),inherited._seconds(h.group(3))
        body=source[h.end(): headers[i+1].start() if i+1<len(headers) else len(source)].strip()
        if b>lo-0.03 and a<hi+0.03:
            parts.append(f'Original [Shot {h.group(1)}] {a:.3f}–{b:.3f}s : {body[:1450]}')
        if b>hi+0.04:
            future.append(b)
        if a>hi+0.04:
            future.append(a)
    nearest=min(future) if future else None
    anchor=(f'Prochain repère original après ce segment : {nearest:.3f}s. '
            'Le mouvement de transition peut mener vers cet événement, '
            'mais ces secondes ne seront PAS générées.' if nearest is not None else
            'La suite originale commence immédiatement après cette portion.')
    return '\n'.join(parts)[:4100] or source[:2600],anchor


def _instruction(*,request:str,source_prompt:str,window:dict)->str:
    schedule=_grid(window)
    material,anchor=_source_excerpt(source_prompt,window)
    lines=[f'[Shot {idx}] {a:.3f}–{b:.3f}s — {role}' for idx,(role,a,b) in enumerate(schedule,1)]
    return ('USER CHANGE (apply it, do not merely repeat old acting): '+str(request).strip()+'\n'
            f'LOCAL SOURCE WINDOW: {float(window["global_offset"]):.3f}–'
            f'{float(window["global_offset"])+DURATION:.3f}s in the original clip.\n'
            f'USER EDIT TIME INSIDE THIS WINDOW: {float(window["start"]):.3f}–'
            f'{float(window["end"]):.3f}s.\n'
            'EXACT LOCAL BEAT GRID — reproduce each as its own [Shot], with no extra shots:\n'
            + '\n'.join(lines)+'\n'
            'The ACTION [Shot] must perform the entire requested action within its allowed time. '
            'Every TRANSITION [Shot] must be short and physically connect to its neighbor. '
            'No full-clip script and no global timestamps in the output.\n'
            'SOURCE EXCERPT — reference to understand existing movement, NOT to replay:\n'
            +material+'\n'
            'CONTINUITY TOWARD THE REST OF THE ORIGINAL CLIP: '+anchor+'\n'
            'Return only SCENE_CONTEXT and NEW_TAKE with the EXACT beat grid above.')


def _extract(output:str,window:dict)->tuple[str,str]:
    src=inherited._strip_fences(output)
    m=re.search(r'(?im)^\s*(?:\*\*)?SCENE_CONTEXT\s*:\s*(?:\*\*)?',src)
    n=re.search(r'(?im)^\s*(?:\*\*)?NEW_TAKE\s*:\s*(?:\*\*)?',src)
    if not m or not n or n.start()<m.end():
        raise RuntimeError('Gemma local : SCENE_CONTEXT ou NEW_TAKE absent')
    context=re.sub(r'\s+',' ',src[m.end():n.start()]).strip()
    if not 15<=len(context)<=600 or '[Shot' in context or '<d>' in context.lower():
        raise RuntimeError('Gemma local : SCENE_CONTEXT invalide')
    text=src[n.end():].strip()
    headers=list(inherited.SHOT_HEADER.finditer(text))
    all_shots=list(inherited.SHOT_RE.finditer(text))
    schedule=_grid(window)
    if len(headers)!=len(schedule) or len(all_shots)!=len(schedule):
        raise RuntimeError(f'Gemma local : attendu {len(schedule)} shots (action et transitions séparées), reçu {len(all_shots)}')
    pieces=[]
    for i,(role,first,last) in enumerate(schedule):
        h=headers[i]
        if int(h.group(1))!=i+1:
            raise RuntimeError('Gemma local : numérotation incorrecte des shots')
        a,b=inherited._seconds(h.group(2)),inherited._seconds(h.group(3))
        # A few milliseconds of natural rounding are safe: the precise frame
        # grid below remains the authority, NOT model-invented timings.
        if abs(a-first)>.045 or abs(b-last)>.045:
            raise RuntimeError(f'Gemma local : Shot {i+1} hors grille ({a:.3f}–{b:.3f}s au lieu de {first:.3f}–{last:.3f}s)')
        body=text[h.end():headers[i+1].start() if i+1<len(headers) else len(text)].strip()
        if not body or len(body)<14:raise RuntimeError(f'Gemma local : Shot {i+1} vide')
        # Remove doubled exact inline cues when the model emits them twice.
        body=re.sub(r'(?i)(Pendant\s+[\d:.,]+\s*[-–—]\s*[\d:.,]+s?\s*:\s*)\1+',r'\1',body)
        pieces.append(f'[Shot {i+1}] {first:.3f}–{last:.3f}s {body}')
    return context,'\n'.join(pieces)


def _assemble(context:str,shots:str,window:dict)->str:
    offset=float(window['global_offset']);start=float(window['start']);end=float(window['end'])
    return ('<Video 1> = REAL SOURCE VIDEO, isolated 39-frame visual reference. '
            'Same person, face, wardrobe, room, lighting and camera. Reference the visuals, '
            'NOT the original performance as a script.\n'
            'SCENE CONTEXT (local only): '+context+'\n'
            'NEW TAKE — ONLY THE SHORT LOCAL SHOTS TO GENERATE:\n'+shots+'\n'
            f'LOCAL TAKE: exactly 1.625s, from original {offset:.3f}–{offset+DURATION:.3f}s. '
            f'Action assigned within the local take at {start:.3f}–{end:.3f}s. '
            'Distinct [Shot]s are continuous motion beats, never camera cuts. '
            'Any transition prepares the action or smoothly leads toward the ORIGINAL '
            'continuation after the local take. Do not generate beyond 1.625s. '
            'Preserve visual identity and physical continuity.')


def write_prompt(*,mode,performance_type,request,source_prompt,window,gpu_prepare):
    if mode!='precise':raise ValueError('Gemma local V10.80 réservé au Retake précis')
    schedule=_grid(window)
    import h3film_studio_v3 as film
    gpu_prepare()
    backend=inherited.choose_backend(film)
    try:
        instruction=_instruction(request=request,source_prompt=source_prompt,window=window)
        for attempt in range(2):
            output=film.director_text(backend,SYSTEM,instruction,
                        label='RETOUCH LOCAL GEMMA 26B / OLLAMA',num_ctx=16384,num_predict=1450)
            try:
                context,shots=_extract(output,window)
                break
            except RuntimeError as exc:
                if attempt:
                    raise RuntimeError('Gemma local : seconde tentative incorrecte. '+str(exc)) from exc
                instruction+=('\nCORRECTION: '+str(exc)+'\nRecommence les '+str(len(schedule))+
                              ' shots EXACTS, avec les bornes et rôles imposés dans la grille. '
                              'Aucun shot extérieur à 0.000–1.625s.')
    finally:
        try: film.unload_text_backend(backend,label='Avant retouche H3')
        finally:film.release_all_text_models_for_h3(label='Retouches : H3 prend le GPU')
    return _assemble(context,shots,window),('Gemma 26B · Retake LOCAL transitions en shots distincts V10.80 · '
                                       +str(backend.get('display') or backend.get('model')))
