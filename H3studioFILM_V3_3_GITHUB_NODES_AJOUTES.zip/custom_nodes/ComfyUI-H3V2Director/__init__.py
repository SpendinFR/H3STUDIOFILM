import glob
import importlib
import os
import sys

import numpy as np
import torch
from PIL import Image, ImageOps

import folder_paths
from comfy_api.latest import ComfyExtension, io


def _h3_cls():
    # H3Studio is loaded before this pack alphabetically on the user's install.
    for mod in list(sys.modules.values()):
        if mod is not None and hasattr(mod, "H3StudioImageToVideo"):
            cls = getattr(mod, "H3StudioImageToVideo")
            if getattr(cls, "__module__", "").endswith("h3_studio"):
                return cls
    for name in (
        "ComfyUI-H3Studio.h3_studio",
        "custom_nodes.ComfyUI-H3Studio.h3_studio",
    ):
        try:
            mod = importlib.import_module(name)
            return mod.H3StudioImageToVideo
        except Exception:
            pass
    raise RuntimeError(
        "H3 V2 Director: ComfyUI-H3Studio is not loaded. Install/restart H3Studio first."
    )


def _load_png(path):
    img = Image.open(path)
    img = ImageOps.exif_transpose(img).convert("RGB")
    arr = np.asarray(img, dtype=np.float32) / 255.0
    return torch.from_numpy(arr)[None]


def _latest(prefix):
    out = folder_paths.get_output_directory()
    matches = glob.glob(os.path.join(out, prefix + "*.png"))
    if not matches:
        raise ValueError(f"H3 V2 Director: aucun fichier '{prefix}*.png' dans {out}")
    # Latest actual output, independent per family. This intentionally supports
    # master _00003 with refs _00002, which is the current KREA workflow behavior.
    return max(matches, key=lambda p: (os.path.getmtime(p), p))


class H3V2LatestRefs(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="H3V2LatestRefs",
            display_name="H3 V2 - AUTO latest MASTER + 4 REFS",
            category="H3 V2 Director",
            description="Charge automatiquement les derniers outputs KREA1 master + 4 refs, sans numéro codé en dur.",
            inputs=[],
            outputs=[
                io.Image.Output(display_name="MASTER"),
                io.Image.Output(display_name="PORTRAIT"),
                io.Image.Output(display_name="FULL BODY"),
                io.Image.Output(display_name="SCENE WIDE"),
                io.Image.Output(display_name="DECOR"),
            ],
            not_idempotent=True,
        )

    @classmethod
    def execute(cls):
        paths = [
            _latest("KREA1_MASTER_UPSCALED_"),
            _latest("KREA1_REF_1_PERSONNAGE_PORTRAIT_"),
            _latest("KREA1_REF_2_PERSONNAGE_FULL_BODY_"),
            _latest("KREA1_REF_3_SCENE_WIDE_"),
            _latest("KREA1_REF_4_DECOR_LOCATION_"),
        ]
        print("H3 V2 Director refs:")
        for p in paths:
            print("  ", os.path.basename(p))
        return io.NodeOutput(*[_load_png(p) for p in paths])


class H3V2Scene(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="H3V2Scene",
            display_name="H3 V2 - SCENE",
            category="H3 V2 Director",
            description=(
                "Une scène contrôlée par toi. START=master en first frame; "
                "CONTINUE=dernière frame précédente; NEW PLAN=pas de first frame, "
                "les 5 images deviennent des références pour libérer le nouveau cadrage."
            ),
            inputs=[
                io.Clip.Input("clip"),
                io.Vae.Input("vae"),
                io.Vae.Input("audio_vae"),
                io.Image.Input("master"),
                io.Image.Input("ref_portrait"),
                io.Image.Input("ref_full_body"),
                io.Image.Input("ref_scene_wide"),
                io.Image.Input("ref_decor"),
                io.Image.Input("previous_last", optional=True, lazy=True),
                io.Combo.Input("mode", options=["START", "CONTINUE", "NEW PLAN"], default="CONTINUE"),
                io.String.Input("prompt", multiline=True, dynamic_prompts=True,
                                default="Describe exactly what happens in this scene."),
                io.String.Input("camera", multiline=True, dynamic_prompts=True,
                                default="medium shot, subtle natural camera movement"),
                io.Float.Input("duration_seconds", default=6.0, min=2.0, max=15.0, step=0.5),
                io.Float.Input("ref_megapixels", default=0.70, min=0.1, max=2.0, step=0.05),
                io.Float.Input("motion_scale", default=1.0, min=0.5, max=1.5, step=0.05),
            ],
            outputs=[
                io.Conditioning.Output(display_name="positive"),
                io.Latent.Output(display_name="LATENT"),
                io.Float.Output(display_name="v2v_denoise"),
            ],
        )

    @classmethod
    def check_lazy_status(cls, mode, previous_last=None, **kwargs):
        if mode == "CONTINUE" and previous_last is None:
            return ["previous_last"]
        return []

    @classmethod
    def execute(
        cls, clip, vae, audio_vae,
        master, ref_portrait, ref_full_body, ref_scene_wide, ref_decor,
        mode, prompt, camera, duration_seconds, ref_megapixels, motion_scale,
        previous_last=None,
    ):
        mode = str(mode)
        if mode == "CONTINUE" and previous_last is None:
            raise ValueError("H3 V2 Director: CONTINUE nécessite la dernière frame de la scène précédente.")

        if mode == "START":
            first = master
            refs = [ref_portrait, ref_full_body, ref_scene_wide, ref_decor]
            ref_spec = "1.00\n0.95\n0.82\n0.82"
            mapping = (
                "<Picture 1> is the MASTER first frame. "
                "<Picture 2> is the exact face/identity reference. "
                "<Picture 3> is the full-body/outfit reference. "
                "<Picture 4> is the scene-wide/location reference. "
                "<Picture 5> is the decor/atmosphere reference."
            )
            mode_note = "Start from the master composition."
        elif mode == "CONTINUE":
            first = previous_last
            refs = [ref_portrait, ref_full_body, ref_scene_wide, ref_decor]
            ref_spec = "1.00\n0.95\n0.82\n0.82"
            mapping = (
                "<Picture 1> is the exact final frame of the previous scene and must be the opening continuity frame. "
                "<Picture 2> is the exact face/identity reference. "
                "<Picture 3> is the full-body/outfit reference. "
                "<Picture 4> is the scene-wide/location reference. "
                "<Picture 5> is the decor/atmosphere reference."
            )
            mode_note = "Continue seamlessly from Picture 1 while following the requested action and camera movement."
        else:  # NEW PLAN
            # No first frame on purpose: a first-frame keyframe fixes shot geometry.
            # The master becomes an ordinary reference so the requested new angle can actually happen.
            first = None
            refs = [master, ref_portrait, ref_full_body, ref_scene_wide, ref_decor]
            ref_spec = "0.85\n1.00\n0.95\n0.82\n0.82"
            mapping = (
                "<Picture 1> is the MASTER visual reference. "
                "<Picture 2> is the exact face/identity reference. "
                "<Picture 3> is the full-body/outfit reference. "
                "<Picture 4> is the scene-wide/location reference. "
                "<Picture 5> is the decor/atmosphere reference."
            )
            mode_note = (
                "This is a NEW SHOT. Do not copy the previous shot composition. "
                "Create the newly requested framing/camera angle while preserving character, outfit, place and visual continuity."
            )

        user_prompt = str(prompt).strip()
        camera_prompt = str(camera).strip()
        full_prompt = (
            f"{mapping}\n\n{mode_note}\n\n"
            f"SCENE: {user_prompt}\n"
            f"CAMERA / SHOT: {camera_prompt}\n\n"
            "Ultra realistic photographic motion. Preserve exact character identity, hair, body proportions, outfit, "
            "location, decor, lighting and material details unless the scene prompt explicitly changes them. "
            "Natural anatomy and physically plausible motion."
        )

        length = max(5, int(round(float(duration_seconds) * 24.0)))
        ref_images = {f"ref_image_{i}": image for i, image in enumerate(refs)}
        h3 = _h3_cls()
        return h3.execute(
            clip=clip,
            vae=vae,
            audio_vae=audio_vae,
            prompt=full_prompt,
            width=768,
            height=1152,
            length=length,
            first_frame_strength=1.0,
            last_frame_strength=1.0,
            first_frame=first,
            ref_images=ref_images,
            ref_spec=ref_spec,
            ref_image_size="match",
            ref_megapixels=float(ref_megapixels),
            motion_context_reuse_latent=True,
            motion_context_anchor_brightness=False,
            motion_context_strength=0.92,
            motion_scale=float(motion_scale),
        )


class H3V2LastFrame(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="H3V2LastFrame",
            display_name="H3 V2 - LAST FRAME auto",
            category="H3 V2 Director",
            inputs=[io.Image.Input("images")],
            outputs=[io.Image.Output(display_name="LAST FRAME")],
        )

    @classmethod
    def execute(cls, images):
        if images is None or images.shape[0] < 1:
            raise ValueError("H3 V2 Director: batch vidéo vide.")
        return io.NodeOutput(images[-1:].clone())


class H3V2FinalSelector(io.ComfyNode):
    MAX_SCENES = 20

    @classmethod
    def define_schema(cls):
        inputs = [io.Int.Input("scene_count", default=3, min=1, max=cls.MAX_SCENES, step=1)]
        for i in range(1, cls.MAX_SCENES + 1):
            inputs.append(io.Image.Input(f"images_{i}", optional=True, lazy=True, display_name=f"VIDEO jusqu'à scène {i}"))
            inputs.append(io.Audio.Input(f"audio_{i}", optional=True, lazy=True, display_name=f"AUDIO jusqu'à scène {i}"))
        return io.Schema(
            node_id="H3V2FinalSelector",
            display_name="H3 V2 - NOMBRE DE SCENES",
            category="H3 V2 Director",
            description="Choisis 1 à 20. Seules les scènes nécessaires au final choisi sont évaluées.",
            inputs=inputs,
            outputs=[io.Image.Output(display_name="FINAL FRAMES"), io.Audio.Output(display_name="FINAL AUDIO")],
        )

    @classmethod
    def check_lazy_status(cls, scene_count, **kwargs):
        n = int(scene_count)
        needed = []
        for key in (f"images_{n}", f"audio_{n}"):
            if kwargs.get(key) is None:
                needed.append(key)
        return needed

    @classmethod
    def execute(cls, scene_count, **kwargs):
        n = int(scene_count)
        images = kwargs.get(f"images_{n}")
        audio = kwargs.get(f"audio_{n}")
        if images is None or audio is None:
            raise ValueError(f"H3 V2 Director: sortie cumulée de la scène {n} non connectée.")
        return io.NodeOutput(images, audio)


class H3V2DirectorExtension(ComfyExtension):
    async def get_node_list(self):
        return [H3V2LatestRefs, H3V2Scene, H3V2LastFrame, H3V2FinalSelector]


async def comfy_entrypoint() -> H3V2DirectorExtension:
    return H3V2DirectorExtension()


__all__ = ["comfy_entrypoint"]
