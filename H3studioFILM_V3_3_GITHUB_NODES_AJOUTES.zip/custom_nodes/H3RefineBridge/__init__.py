import sys, logging
import os, time
import torch
from server import PromptServer
from aiohttp import web
from comfy.model_management import InterruptProcessingException
import comfy.nested_tensor
import torch.nn.functional as F

_saved_raw_cache = None

def _cache_mod():
    for name, mod in list(sys.modules.items()):
        if name.endswith("h3_latent_cache") and hasattr(mod, "get") and hasattr(mod, "_last"):
            return mod
    raise RuntimeError("H3RefineBridge V6: H3Studio h3_latent_cache not found")

def _video_from_latent(latent):
    s = latent["samples"]
    parts = list(s.unbind()) if hasattr(s, "unbind") else [s]
    return parts[0]

def _resize(z, h, w):
    if not isinstance(z, torch.Tensor): return z
    if z.shape[-2:] == (h,w): return z
    dt, dev = z.dtype, z.device
    if z.ndim == 5:
        b,c,t,oh,ow=z.shape
        x=z.permute(0,2,1,3,4).reshape(b*t,c,oh,ow)
        if x.dtype in (torch.float16, torch.bfloat16): x=x.float()
        x=F.interpolate(x, size=(h,w), mode="nearest-exact")
        x=x.reshape(b,t,c,h,w).permute(0,2,1,3,4)
        return x.to(device=dev,dtype=dt)
    if z.ndim == 4:
        x=z.float() if z.dtype in (torch.float16, torch.bfloat16) else z
        return F.interpolate(x,size=(h,w),mode="nearest-exact").to(device=dev,dtype=dt)
    return z

class H3RefineResizeConditioning:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required":{"conditioning":("CONDITIONING",),"target_latent":("LATENT",)}}
    RETURN_TYPES=("CONDITIONING",); RETURN_NAMES=("conditioning",)
    FUNCTION="run"; CATEGORY="conditioning/minimax"
    def run(self, conditioning, target_latent):
        v=_video_from_latent(target_latent); h,w=int(v.shape[-2]),int(v.shape[-1])
        out=[]
        for entry in conditioning:
            if not isinstance(entry,(list,tuple)) or len(entry)<2:
                out.append(entry); continue
            emb,meta=entry[0],entry[1]; d=dict(meta)
            refs=meta.get("minimax_refs")
            if refs is not None:
                nr=[]
                for r in refs:
                    x=dict(r)
                    if x.get("kind") != "audio" and isinstance(x.get("latent"),torch.Tensor):
                        z=_resize(x["latent"],h,w); x["latent"]=z
                        x["latent_h"]=int(z.shape[-2]); x["latent_w"]=int(z.shape[-1])
                        if z.ndim==5 and "latent_t" in x: x["latent_t"]=int(z.shape[2])
                    nr.append(x)
                d["minimax_refs"]=nr
            kfs=meta.get("minimax_keyframes")
            if kfs is not None:
                nk=[]
                for k in kfs:
                    x=dict(k)
                    if isinstance(x.get("latent"),torch.Tensor): x["latent"]=_resize(x["latent"],h,w)
                    nk.append(x)
                d["minimax_keyframes"]=nk
            hard=meta.get("minimax_hard_video")
            if hard is not None:
                nh=[]
                for e in hard:
                    x=dict(e)
                    if isinstance(x.get("latent"),torch.Tensor): x["latent"]=_resize(x["latent"],h,w)
                    nh.append(x)
                d["minimax_hard_video"]=nh
            out.append([emb,d])
        logging.info("H3RefineBridge V6: resized MiniMax conditioning to %dx%d latent grid; MC keyframes preserved.",w,h)
        return (out,)

class H3RefineResizeConditioningDropRefVideo:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required":{"conditioning":("CONDITIONING",),"target_latent":("LATENT",)}}
    RETURN_TYPES=("CONDITIONING",); RETURN_NAMES=("conditioning",)
    FUNCTION="run"; CATEGORY="conditioning/minimax"
    def run(self, conditioning, target_latent):
        v=_video_from_latent(target_latent); h,w=int(v.shape[-2]),int(v.shape[-1])
        out=[]; removed_total=0
        for entry in conditioning:
            if not isinstance(entry,(list,tuple)) or len(entry)<2:
                out.append(entry); continue
            emb,meta=entry[0],entry[1]; d=dict(meta)
            refs=meta.get("minimax_refs")
            if refs is not None:
                nr=[]
                for r in refs:
                    x=dict(r)
                    kind=str(x.get("kind",""))
                    if kind in ("video","video_audio"):
                        removed_total += 1
                        continue
                    if kind != "audio" and isinstance(x.get("latent"),torch.Tensor):
                        z=_resize(x["latent"],h,w); x["latent"]=z
                        x["latent_h"]=int(z.shape[-2]); x["latent_w"]=int(z.shape[-1])
                        if z.ndim==5 and "latent_t" in x: x["latent_t"]=int(z.shape[2])
                    nr.append(x)
                d["minimax_refs"]=nr
            kfs=meta.get("minimax_keyframes")
            if kfs is not None:
                nk=[]
                for k in kfs:
                    x=dict(k)
                    if isinstance(x.get("latent"),torch.Tensor): x["latent"]=_resize(x["latent"],h,w)
                    nk.append(x)
                d["minimax_keyframes"]=nk
            hard=meta.get("minimax_hard_video")
            if hard is not None:
                nh=[]
                for e in hard:
                    x=dict(e)
                    if isinstance(x.get("latent"),torch.Tensor): x["latent"]=_resize(x["latent"],h,w)
                    nh.append(x)
                d["minimax_hard_video"]=nh
            out.append([emb,d])
        if removed_total:
            logging.info("H3RefineBridge V16.1: stripped %d ref-video block(s) from refine conditioning; ref images/audio + MC keyframes kept. Resized to %dx%d latent grid.", removed_total, w, h)
        else:
            logging.info("H3RefineBridge V16.1: no ref-video blocks found; refine conditioning unchanged apart from resize to %dx%d.", w, h)
        return (out,)

class H3RawCacheHold:
    @classmethod
    def INPUT_TYPES(cls): return {"required":{"latent":("LATENT",)}}
    RETURN_TYPES=("LATENT",); FUNCTION="run"; CATEGORY="latent/minimax"
    def run(self, latent):
        global _saved_raw_cache
        _saved_raw_cache=_cache_mod().get()
        logging.info("H3RefineBridge V6: RAW H3Studio cache preserved before refine.")
        return (latent,)

class H3RawCacheRestore:
    @classmethod
    def INPUT_TYPES(cls): return {"required":{"latent":("LATENT",)}}
    RETURN_TYPES=("LATENT",); FUNCTION="run"; CATEGORY="latent/minimax"
    def run(self, latent):
        global _saved_raw_cache
        if _saved_raw_cache is not None:
            _cache_mod()._last=_saved_raw_cache
            logging.info("H3RefineBridge V6: RAW H3Studio cache restored after refine.")
        return (latent,)

# Legacy node kept so older workflows still open.
class H3RefineStripKeyframes:
    @classmethod
    def INPUT_TYPES(cls): return {"required":{"conditioning":("CONDITIONING",)}}
    RETURN_TYPES=("CONDITIONING",); FUNCTION="run"; CATEGORY="conditioning/minimax"
    def run(self, conditioning):
        out=[]
        for emb,meta in conditioning:
            d=dict(meta); d.pop("minimax_keyframes",None); d.pop("minimax_hard_video",None); out.append([emb,d])
        return (out,)


def _h3_reel_module():
    for name, mod in list(sys.modules.items()):
        if name.endswith("h3_reel") and all(hasattr(mod, x) for x in ("_level_match", "_region_match", "_luma_match")):
            return mod
    raise RuntimeError("H3RefineBridge V6: H3Studio h3_reel module not found")

class H3VisibleJoinMatch:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required":{"previous_images":("IMAGE",),"new_images":("IMAGE",)}}
    RETURN_TYPES=("IMAGE",)
    RETURN_NAMES=("matched_new_images",)
    FUNCTION="run"
    CATEGORY="image/video"
    def run(self, previous_images, new_images):
        if previous_images is None or new_images is None:
            return (new_images,)
        if previous_images.shape[0] < 3 or new_images.shape[0] < 3:
            return (new_images,)
        reel=_h3_reel_module()
        fixed=new_images.clone().to(torch.float32)
        prev=previous_images.to(torch.float32)
        fixed=reel._level_match(prev, fixed)
        fixed=reel._region_match(prev, fixed)
        fixed=reel._luma_match(fixed)
        fixed=fixed.to(dtype=new_images.dtype, device=new_images.device)
        logging.info("H3RefineBridge V6: H3Studio visible join-fix applied (level + regional 24f + head luma 6f; no crossfade).")
        return (fixed,)


# ---------------------------------------------------------------------------
# V8: HD overlap lock for pass-2 continuation.
# This is the same core idea used by Tr1dae's historical H3 chunked pass-2:
# copy previous sampled HD latent tail into current prefix and set noise_mask=0
# on that overlap so sampler 2 cannot rewrite the continuation anchor.
# ---------------------------------------------------------------------------
_prev_hd_tail = None
_MC22_OFFSETS = {0, 1, 5, 9, 13, 17, 18}
_PERSIST_VERSION = 10
_PERSIST_FILENAME = "H3_HDTAIL_LAST_V10.pt"


def _persist_path():
    # Always keep the sidecar with the user's H3Studio outputs.
    import folder_paths
    root = folder_paths.get_output_directory()
    folder = os.path.join(root, "video", "H3studio")
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, _PERSIST_FILENAME)


def _serialize_tail(tail):
    members, nested = _extract_members(tail["samples"])
    cpu_members = [x.detach().to("cpu", copy=True) for x in members]
    return {
        "version": _PERSIST_VERSION,
        "created_unix": float(time.time()),
        "nested": bool(nested),
        "members": cpu_members,
    }


def _deserialize_tail(payload):
    if not isinstance(payload, dict) or int(payload.get("version", -1)) != _PERSIST_VERSION:
        raise ValueError("H3 V10: invalid or incompatible persistent HD-tail sidecar")
    members = payload.get("members")
    if not isinstance(members, list) or not members or not all(isinstance(x, torch.Tensor) for x in members):
        raise ValueError("H3 V10: persistent HD-tail sidecar has no valid tensor members")
    return {"samples": _wrap_members(members, bool(payload.get("nested", False)))}


def _save_persistent_tail(tail):
    path = _persist_path()
    tmp = path + ".tmp"
    payload = _serialize_tail(tail)
    torch.save(payload, tmp)
    os.replace(tmp, path)
    return path


def _load_persistent_tail():
    path = _persist_path()
    if not os.path.isfile(path):
        return None, path
    # Sidecar is generated by this local plugin and contains only tensors/primitives.
    try:
        payload = torch.load(path, map_location="cpu", weights_only=True)
    except TypeError:
        # Compatibility with older torch versions lacking weights_only.
        payload = torch.load(path, map_location="cpu")
    return _deserialize_tail(payload), path


def _clear_persistent_tail():
    path = _persist_path()
    try:
        if os.path.isfile(path):
            os.remove(path)
            logging.info("H3RefineBridge V10: new chain detected -> cleared old persistent HD tail: %s", path)
    except Exception as e:
        logging.warning("H3RefineBridge V10: could not clear stale persistent HD tail: %s", e)


def _is_nested(obj):
    return isinstance(obj, comfy.nested_tensor.NestedTensor) or getattr(obj, "is_nested", False)


def _extract_members(samples):
    if _is_nested(samples):
        ts=list(samples.unbind())
        if not ts:
            raise ValueError("H3 V8: empty NestedTensor")
        return ts, True
    if isinstance(samples, torch.Tensor):
        return [samples], False
    raise TypeError(f"H3 V8: unsupported latent samples type {type(samples)}")


def _wrap_members(members, nested):
    if nested:
        return comfy.nested_tensor.NestedTensor(members)
    if len(members) != 1:
        raise ValueError("H3 V8: plain latent expected one tensor")
    return members[0]


def _has_mc22(conditioning):
    found=set()
    for entry in conditioning or []:
        if not isinstance(entry,(list,tuple)) or len(entry)<2:
            continue
        meta=entry[1]
        for kf in meta.get("minimax_keyframes") or []:
            if isinstance(kf,dict) and "resolved_frame_index" in kf:
                try: found.add(int(kf["resolved_frame_index"]))
                except Exception: pass
    return _MC22_OFFSETS.issubset(found)


class H3V8LockPreviousHDPrefix:
    """
    V10 persistent lock:
    - same-session: use RAM tail
    - after ComfyUI restart: automatically reload the exact HD tail from disk
    - new chain (no MC22): reset RAM + remove old sidecar
    """
    @classmethod
    def INPUT_TYPES(cls):
        return {"required":{"latent":("LATENT",),"conditioning":("CONDITIONING",)}}
    RETURN_TYPES=("LATENT",)
    RETURN_NAMES=("locked_latent",)
    FUNCTION="run"
    CATEGORY="latent/minimax"

    def run(self, latent, conditioning):
        global _prev_hd_tail

        # Clip 1 / new chain: explicitly invalidate previous chain state.
        if not _has_mc22(conditioning):
            _prev_hd_tail = None
            _clear_persistent_tail()
            logging.info(
                "H3RefineBridge V10: no 22-frame MC detected -> new chain; "
                "persistent HD-tail state reset."
            )
            return (latent,)

        # Continuation after restart: recover exact refined HD overlap from disk.
        if _prev_hd_tail is None:
            try:
                loaded, path = _load_persistent_tail()
                if loaded is not None:
                    _prev_hd_tail = loaded
                    logging.info(
                        "H3RefineBridge V10: RESTORED persistent refined HD tail from disk: %s",
                        path
                    )
                else:
                    logging.warning(
                        "H3RefineBridge V10: MC22 detected but neither RAM nor persistent HD tail exists (%s). "
                        "This link cannot be HD-locked.",
                        path
                    )
                    return (latent,)
            except Exception as e:
                logging.warning(
                    "H3RefineBridge V10: persistent HD-tail reload failed (%s); "
                    "this link cannot be HD-locked.", e
                )
                return (latent,)

        cur, nested = _extract_members(latent["samples"])
        prev, _ = _extract_members(_prev_hd_tail["samples"])
        video = cur[0]
        prev_v = prev[0]

        if video.ndim != 5 or prev_v.ndim != 5:
            raise ValueError(
                f"H3 V10: expected BxCxTxHxW video latents, "
                f"got {tuple(video.shape)} / {tuple(prev_v.shape)}"
            )
        if tuple(prev_v.shape[1:2] + prev_v.shape[3:]) != tuple(video.shape[1:2] + video.shape[3:]):
            raise ValueError(
                f"H3 V10: persistent HD overlap geometry mismatch "
                f"previous {tuple(prev_v.shape)} current {tuple(video.shape)}"
            )

        v_keep = max(0, min(7, int(video.shape[2]) - 1, int(prev_v.shape[2])))
        if v_keep <= 0:
            return (latent,)

        out_v = video.clone()
        out_v[:, :, :v_keep] = prev_v[:, :, -v_keep:].to(
            device=out_v.device, dtype=out_v.dtype
        )
        out_members = [out_v]

        a_keep = 0
        audio = None
        if nested and len(cur) >= 2 and len(prev) >= 2:
            audio = cur[1].clone()
            prev_a = prev[1]
            want = int(round(v_keep / max(1, int(video.shape[2])) * int(audio.shape[-1])))
            a_keep = max(0, min(want, int(audio.shape[-1]) - 1, int(prev_a.shape[-1])))
            if a_keep > 0:
                audio[..., :a_keep] = prev_a[..., -a_keep:].to(
                    device=audio.device, dtype=audio.dtype
                )
            out_members.append(audio)
            out_members.extend(cur[2:])
        else:
            out_members.extend(cur[1:])

        out = latent.copy()
        out["samples"] = _wrap_members(out_members, nested)

        # 0 = frozen / preserve copied overlap, 1 = denoise.
        vmask = torch.ones(
            (out_v.shape[0], 1, out_v.shape[2], out_v.shape[3], out_v.shape[4]),
            device=out_v.device, dtype=torch.float32
        )
        vmask[:, :, :v_keep] = 0.0

        if nested and audio is not None:
            amask = torch.ones(
                (audio.shape[0], 1, audio.shape[2], audio.shape[3]),
                device=audio.device, dtype=torch.float32
            )
            if a_keep > 0:
                amask[..., :a_keep] = 0.0
            out["noise_mask"] = _wrap_members([vmask, amask], True)
        else:
            out["noise_mask"] = vmask

        logging.info(
            "H3RefineBridge V10: LOCKED persistent refined HD tail into pass-2 prefix — "
            "%d video latent tokens (=22 frames), %d audio steps; noise_mask=0 on overlap.",
            v_keep, a_keep
        )
        return (out,)


class H3V8StoreHDTail:
    """
    V10 store:
    keep tail in RAM AND atomically persist it to
    output/video/H3studio/H3_HDTAIL_LAST_V10.pt
    so continuation survives ComfyUI/Windows restart.
    """
    @classmethod
    def INPUT_TYPES(cls):
        return {"required":{"latent":("LATENT",)}}
    RETURN_TYPES=("LATENT",)
    RETURN_NAMES=("latent",)
    FUNCTION="run"
    CATEGORY="latent/minimax"

    def run(self, latent):
        global _prev_hd_tail

        members, nested = _extract_members(latent["samples"])
        video = members[0]
        v_keep = min(7, int(video.shape[2]))

        saved = [video[:, :, -v_keep:].detach().to("cpu", copy=True)]

        if nested and len(members) >= 2:
            audio = members[1]
            a_keep = max(
                1,
                int(round(v_keep / max(1, int(video.shape[2])) * int(audio.shape[-1])))
            )
            a_keep = min(a_keep, int(audio.shape[-1]))
            saved.append(audio[..., -a_keep:].detach().to("cpu", copy=True))
            for extra in members[2:]:
                saved.append(extra.detach().to("cpu", copy=True))

        _prev_hd_tail = {"samples": _wrap_members(saved, nested)}

        try:
            path = _save_persistent_tail(_prev_hd_tail)
            logging.info(
                "H3RefineBridge V10: STORED refined HD tail in RAM + disk — "
                "%d video latent tokens; persistent file: %s",
                v_keep, path
            )
        except Exception as e:
            logging.warning(
                "H3RefineBridge V10: RAM tail stored, but persistent disk save failed: %s", e
            )

        return (latent,)



# ---------------------------------------------------------------------------
# V11: HUMAN REVIEW PAUSE — exactly after RAW SaveVideo.
#
# CONTINUER:
#   releases the SAME in-memory low-res H3 latent to the existing V10
#   upscale/refine/final branch. Nothing is regenerated.
#
# REFAIRE:
#   interrupts this prompt, clears H3Studio's transient RAW latent cache
#   (important: otherwise a rejected RAW could be mistaken for the source
#   context on the next attempt), then the frontend queues the CURRENT graph
#   again exactly like pressing Execute.
#
# The persistent HD sidecar from the last ACCEPTED visible clip is NOT touched
# by a rejected RAW, because H3V8StoreHDTail runs only after CONTINUER.
# ---------------------------------------------------------------------------

class H3RawReviewPause:
    status_by_id = {}

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "latent": ("LATENT",),
                "raw_video_saved": ("VIDEO",),
            },
            "hidden": {
                "id": "UNIQUE_ID",
            },
        }

    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("latent_after_review",)
    FUNCTION = "run"
    CATEGORY = "H3Studio/V11"
    OUTPUT_NODE = True

    @classmethod
    def IS_CHANGED(cls, **kwargs):
        # Always stop for review on every queued run, even if Comfy cache says
        # the inputs are identical.
        return float("nan")

    def run(self, latent, raw_video_saved, id=None):
        node_id = str(id)
        self.status_by_id[node_id] = "paused"

        logging.info(
            "H3RefineBridge V11: RAW saved. PAUSED for human review — "
            "CONTINUER keeps this RAW; REFAIRE restarts from the beginning."
        )
        PromptServer.instance.send_sync(
            "h3_raw_review_paused",
            {"node_id": node_id}
        )

        try:
            while self.status_by_id.get(node_id) == "paused":
                time.sleep(0.10)

            status = self.status_by_id.get(node_id)

            if status == "retry":
                # Crucial safety for a retry:
                # after generating a rejected RAW, H3Studio's one-slot latent
                # cache now contains that rejected RAW tail. The motion_context
                # file still points to the last accepted RAW. Force the next
                # prompt to re-encode that real file instead of reusing the
                # rejected tail by mistake.
                global _saved_raw_cache
                _saved_raw_cache = None
                try:
                    mod = _cache_mod()
                    mod._last = None
                    logging.info(
                        "H3RefineBridge V11: REFAIRE — rejected RAW cache cleared; "
                        "next run will restart safely from the selected Motion Context file."
                    )
                except Exception as e:
                    logging.warning(
                        "H3RefineBridge V11: REFAIRE — could not clear transient "
                        "H3Studio RAW cache (%s).", e
                    )

                raise InterruptProcessingException()

            logging.info(
                "H3RefineBridge V11: CONTINUER — same accepted RAW latent released "
                "to the existing V10 upscale/refine/final branch."
            )
            return (latent,)

        finally:
            self.status_by_id.pop(node_id, None)


@PromptServer.instance.routes.post("/h3_raw_review/continue/{node_id}")
async def h3_raw_review_continue(request):
    node_id = request.match_info["node_id"].strip()
    H3RawReviewPause.status_by_id[node_id] = "continue"
    return web.json_response({"status": "ok", "action": "continue"})


@PromptServer.instance.routes.post("/h3_raw_review/retry/{node_id}")
async def h3_raw_review_retry(request):
    node_id = request.match_info["node_id"].strip()
    H3RawReviewPause.status_by_id[node_id] = "retry"
    return web.json_response({"status": "ok", "action": "retry"})


class H3V12PreviewReviewPause:
    status_by_id = {}

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "noise": ("NOISE",),
                "preview_video_saved": ("VIDEO",),
            },
            "hidden": {"id": "UNIQUE_ID"},
        }

    RETURN_TYPES = ("NOISE",)
    RETURN_NAMES = ("noise_after_preview",)
    FUNCTION = "run"
    CATEGORY = "H3Studio/V12"

    @classmethod
    def IS_CHANGED(cls, **kwargs):
        return float("nan")

    def run(self, noise, preview_video_saved, id=None):
        node_id = str(id)
        self.status_by_id[node_id] = "paused"

        logging.info(
            "H3RefineBridge V12: FAST PREVIEW saved. PAUSED before the real RAW — "
            "CONTINUER runs the normal 8-step RAW, then PAUSE 2; "
            "REFAIRE reruns the preview from the beginning."
        )
        PromptServer.instance.send_sync("h3_v12_preview_paused", {"node_id": node_id})

        try:
            while self.status_by_id.get(node_id) == "paused":
                time.sleep(0.10)

            status = self.status_by_id.get(node_id)

            if status == "retry":
                try:
                    mod = _cache_mod()
                    mod._last = None
                    logging.info(
                        "H3RefineBridge V12: REFAIRE PREVIEW — transient H3Studio "
                        "cache cleared; next attempt will safely reload the selected "
                        "previous RAW Motion Context."
                    )
                except Exception as e:
                    logging.warning(
                        "H3RefineBridge V12: could not clear preview cache on retry (%s).", e
                    )
                raise InterruptProcessingException()

            logging.info(
                "H3RefineBridge V12: CONTINUER PREVIEW — accepted; releasing the "
                "same seed/noise to the real 8-step RAW pipeline; PAUSE 2 will stop before refine."
            )
            return (noise,)

        finally:
            self.status_by_id.pop(node_id, None)


@PromptServer.instance.routes.post("/h3_v12_preview/continue/{node_id}")
async def h3_v12_preview_continue(request):
    node_id = request.match_info["node_id"].strip()
    H3V12PreviewReviewPause.status_by_id[node_id] = "continue"
    return web.json_response({"status": "ok", "action": "continue"})


@PromptServer.instance.routes.post("/h3_v12_preview/retry/{node_id}")
async def h3_v12_preview_retry(request):
    node_id = request.match_info["node_id"].strip()
    H3V12PreviewReviewPause.status_by_id[node_id] = "retry"
    return web.json_response({"status": "ok", "action": "retry"})


class H3V12TaperPreviousHDPrefix:
    """
    V12 visual seam taper.
    V10/V11 remain available unchanged through H3V8LockPreviousHDPrefix.
    """
    @classmethod
    def INPUT_TYPES(cls):
        return {"required":{"latent":("LATENT",),"conditioning":("CONDITIONING",)}}

    RETURN_TYPES=("LATENT",)
    RETURN_NAMES=("locked_latent",)
    FUNCTION="run"
    CATEGORY="latent/minimax"

    def run(self, latent, conditioning):
        global _prev_hd_tail

        if not _has_mc22(conditioning):
            _prev_hd_tail = None
            _clear_persistent_tail()
            logging.info(
                "H3RefineBridge V12: no MC22 -> new chain; persistent HD-tail state reset."
            )
            return (latent,)

        if _prev_hd_tail is None:
            try:
                loaded, path = _load_persistent_tail()
                if loaded is not None:
                    _prev_hd_tail = loaded
                    logging.info(
                        "H3RefineBridge V12: RESTORED persistent refined HD tail from disk: %s",
                        path
                    )
                else:
                    logging.warning(
                        "H3RefineBridge V12: MC22 detected but no RAM/disk HD tail exists (%s); "
                        "taper lock unavailable on this link.", path
                    )
                    return (latent,)
            except Exception as e:
                logging.warning(
                    "H3RefineBridge V12: persistent HD-tail reload failed (%s); "
                    "taper lock unavailable.", e
                )
                return (latent,)

        cur, nested = _extract_members(latent["samples"])
        prev, _ = _extract_members(_prev_hd_tail["samples"])
        video = cur[0]
        prev_v = prev[0]

        if video.ndim != 5 or prev_v.ndim != 5:
            raise ValueError(
                f"H3 V12: expected BxCxTxHxW video latents, "
                f"got {tuple(video.shape)} / {tuple(prev_v.shape)}"
            )
        if tuple(prev_v.shape[1:2] + prev_v.shape[3:]) != tuple(video.shape[1:2] + video.shape[3:]):
            raise ValueError(
                f"H3 V12: persistent HD overlap geometry mismatch "
                f"previous {tuple(prev_v.shape)} current {tuple(video.shape)}"
            )

        v_keep = max(0, min(7, int(video.shape[2]) - 1, int(prev_v.shape[2])))
        if v_keep <= 0:
            return (latent,)

        out_v = video.clone()
        out_v[:, :, :v_keep] = prev_v[:, :, -v_keep:].to(
            device=out_v.device, dtype=out_v.dtype
        )
        out_members = [out_v]

        a_keep = 0
        audio = None
        if nested and len(cur) >= 2 and len(prev) >= 2:
            audio = cur[1].clone()
            prev_a = prev[1]
            want = int(round(v_keep / max(1, int(video.shape[2])) * int(audio.shape[-1])))
            a_keep = max(0, min(want, int(audio.shape[-1]) - 1, int(prev_a.shape[-1])))
            if a_keep > 0:
                audio[..., :a_keep] = prev_a[..., -a_keep:].to(
                    device=audio.device, dtype=audio.dtype
                )
            out_members.append(audio)
            out_members.extend(cur[2:])
        else:
            out_members.extend(cur[1:])

        out = latent.copy()
        out["samples"] = _wrap_members(out_members, nested)

        vmask = torch.ones(
            (out_v.shape[0], 1, out_v.shape[2], out_v.shape[3], out_v.shape[4]),
            device=out_v.device, dtype=torch.float32
        )
        hard = min(5, v_keep)
        if hard > 0:
            vmask[:, :, :hard] = 0.0
        if v_keep >= 6:
            vmask[:, :, 5] = 0.25
        if v_keep >= 7:
            vmask[:, :, 6] = 0.65

        if nested and audio is not None:
            amask = torch.ones(
                (audio.shape[0], 1, audio.shape[2], audio.shape[3]),
                device=audio.device, dtype=torch.float32
            )
            if a_keep > 0:
                amask[..., :a_keep] = 0.0
            out["noise_mask"] = _wrap_members([vmask, amask], True)
        else:
            out["noise_mask"] = vmask

        logging.info(
            "H3RefineBridge V12: TAPERED persistent HD overlap — %d tokens copied; "
            "tokens 0..4 frozen, token5 mask=0.25, token6 mask=0.65, then normal refine; "
            "%d audio steps remain hard-locked.",
            v_keep, a_keep
        )
        return (out,)


# ---------------------------------------------------------------------------
# V13: no-OOM final assembly.
# Join matching still happens on IMAGE tensors, but the cumulative FINAL no
# longer batches all previous frames into one giant IMAGE tensor.
# Instead we build the matched current clip as VIDEO, then append it to the
# previously loaded FINAL via ffmpeg concat on disk (copy first, re-encode
# fallback). Peak RAM stays low and user usage stays identical.
# ---------------------------------------------------------------------------
import subprocess
import shutil
import uuid


def _h3studio_dir():
    import folder_paths
    root = folder_paths.get_output_directory()
    folder = os.path.join(root, "video", "H3studio")
    os.makedirs(folder, exist_ok=True)
    return folder


def _h3_tmp_path(stem: str, suffix: str = ".mp4"):
    folder = os.path.join(_h3studio_dir(), "_bridge_tmp")
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, f"{stem}_{int(time.time()*1000)}_{uuid.uuid4().hex[:8]}{suffix}")


def _find_ffmpeg():
    exe = shutil.which("ffmpeg") or shutil.which("ffmpeg.exe")
    if exe:
        return exe
    try:
        import imageio_ffmpeg
        exe = imageio_ffmpeg.get_ffmpeg_exe()
        if exe and os.path.isfile(exe):
            return exe
    except Exception:
        pass
    raise RuntimeError("H3RefineBridge V13: ffmpeg not found in PATH and imageio_ffmpeg unavailable")


def _video_src_path(video, stem: str):
    # Reuse source file directly only if there is no active trim window.
    try:
        if hasattr(video, "get_stream_source") and hasattr(video, "get_active_trim_window"):
            start_time, duration = video.get_active_trim_window()
            src = video.get_stream_source()
            if abs(float(start_time)) < 1e-9 and abs(float(duration)) < 1e-9 and isinstance(src, (str, os.PathLike)) and os.path.isfile(src):
                return str(src), False
    except Exception:
        pass
    path = _h3_tmp_path(stem, ".mp4")
    # Default save_to settings keep H264/AAC compatible with SaveVideo auto.
    video.save_to(path)
    return path, True


def _video_has_audio(path: str) -> bool:
    import av
    with av.open(path, mode="r") as c:
        return len(c.streams.audio) > 0


def _ffmpeg_concat(prev_path: str, cur_path: str, out_path: str):
    ff = _find_ffmpeg()
    list_path = _h3_tmp_path("concat_list", ".txt")

    def esc(p: str) -> str:
        return p.replace("'", "'\\''")

    with open(list_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(f"file '{esc(os.path.abspath(prev_path))}'\n")
        f.write(f"file '{esc(os.path.abspath(cur_path))}'\n")

    copy_cmd = [ff, "-y", "-f", "concat", "-safe", "0", "-i", list_path, "-c", "copy", "-movflags", "+faststart", out_path]
    copy_run = subprocess.run(copy_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if copy_run.returncode == 0 and os.path.isfile(out_path) and os.path.getsize(out_path) > 0:
        return "copy"

    has_a0 = _video_has_audio(prev_path)
    has_a1 = _video_has_audio(cur_path)
    if has_a0 and has_a1:
        filt = "[0:v][0:a][1:v][1:a]concat=n=2:v=1:a=1[v][a]"
        maps = ["-map", "[v]", "-map", "[a]"]
        extra = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-c:a", "aac", "-b:a", "192k"]
    else:
        filt = "[0:v][1:v]concat=n=2:v=1:a=0[v]"
        maps = ["-map", "[v]"]
        extra = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "18"]

    recode_cmd = [ff, "-y", "-i", prev_path, "-i", cur_path, "-filter_complex", filt, *maps, *extra, "-movflags", "+faststart", out_path]
    recode_run = subprocess.run(recode_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if recode_run.returncode != 0 or not os.path.isfile(out_path) or os.path.getsize(out_path) <= 0:
        raise RuntimeError(
            "H3RefineBridge V13: ffmpeg concat failed. copy stderr\n"
            + copy_run.stderr[-4000:]
            + "\n--- reencode stderr ---\n"
            + recode_run.stderr[-4000:]
        )
    return "reencode"


class H3ConcatVideosNoOOM:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"previous_video": ("VIDEO",), "current_video": ("VIDEO",)}}

    RETURN_TYPES = ("VIDEO",)
    RETURN_NAMES = ("video",)
    FUNCTION = "run"
    CATEGORY = "video/H3studio"

    def run(self, previous_video, current_video):
        from comfy_api.latest import InputImpl

        prev_path = cur_path = None
        prev_temp = cur_temp = False
        try:
            prev_path, prev_temp = _video_src_path(previous_video, "prev_final")
            cur_path, cur_temp = _video_src_path(current_video, "current_matched")
            out_path = _h3_tmp_path("final_concat_nooom", ".mp4")
            mode = _ffmpeg_concat(prev_path, cur_path, out_path)
            logging.info(
                "H3RefineBridge V13: cumulative FINAL assembled without IMAGE batch OOM — %s append: %s + %s -> %s",
                mode,
                os.path.basename(prev_path),
                os.path.basename(cur_path),
                os.path.basename(out_path),
            )
            return (InputImpl.VideoFromFile(out_path),)
        finally:
            for p, is_temp in ((prev_path, prev_temp), (cur_path, cur_temp)):
                if is_temp and p and os.path.isfile(p):
                    try:
                        os.remove(p)
                    except Exception:
                        pass


# ---------------------------------------------------------------------------
# V15 — PROJECT ISOLATION + ULTRAFAST PREVIEW
# ---------------------------------------------------------------------------

_v15_project_tails = {}


def _v15_project_slug(name):
    s = str(name or "").strip()
    if not s:
        s = "Projet_01"
    for ch in '<>:"/\\|?*':
        s = s.replace(ch, "_")
    s = "_".join(s.split())
    s = s.strip(" ._") or "Projet_01"
    return s[:80]


def _v15_project_root(project_name):
    import folder_paths
    slug = _v15_project_slug(project_name)
    root = os.path.join(folder_paths.get_output_directory(), "video", "H3studio", slug)
    for sub in ("preview", "raw", "visible", "final", "_state", "_tmp"):
        os.makedirs(os.path.join(root, sub), exist_ok=True)
    return slug, root


def _v15_state_path(project_name):
    slug, root = _v15_project_root(project_name)
    return slug, os.path.join(root, "_state", "H3_HDTAIL_LAST_V15.pt")


def _v15_save_project_tail(project_name, tail):
    slug, path = _v15_state_path(project_name)
    tmp = path + ".tmp"
    payload = _serialize_tail(tail)
    torch.save(payload, tmp)
    os.replace(tmp, path)
    return slug, path


def _v15_load_project_tail(project_name):
    slug, path = _v15_state_path(project_name)
    if not os.path.isfile(path):
        return slug, None, path
    try:
        payload = torch.load(path, map_location="cpu", weights_only=True)
    except TypeError:
        payload = torch.load(path, map_location="cpu")
    return slug, _deserialize_tail(payload), path


def _v15_clear_project_tail(project_name):
    slug, path = _v15_state_path(project_name)
    _v15_project_tails.pop(slug, None)
    try:
        if os.path.isfile(path):
            os.remove(path)
            logging.info(
                "H3RefineBridge V15 [%s]: new chain -> cleared project HD tail: %s",
                slug, path
            )
    except Exception as e:
        logging.warning(
            "H3RefineBridge V15 [%s]: could not clear project HD tail: %s", slug, e
        )


class H3V15Project:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "project_name": ("STRING", {"default": "Projet_01", "multiline": False})
        }}

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("project",)
    FUNCTION = "run"
    CATEGORY = "H3Studio/V15"

    @classmethod
    def IS_CHANGED(cls, project_name):
        return str(project_name)

    def run(self, project_name):
        slug, root = _v15_project_root(project_name)
        logging.info("H3RefineBridge V15: active project = %s | %s", slug, root)
        return (slug,)


class H3V15ProjectSaveVideo:
    KIND = {
        "preview": ("preview", "H3_FAST_PREVIEW"),
        "raw":     ("raw",     "H3_RAW_CLIP"),
        "visible": ("visible", "H3_VISIBLE_CLIP_1920"),
        "final":   ("final",   "H3_VISIBLE_FINAL_1920"),
    }

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "video": ("VIDEO",),
            "project_name": ("STRING", {"forceInput": True}),
            "kind": (["preview", "raw", "visible", "final"], {"default": "visible"}),
        }}

    RETURN_TYPES = ("VIDEO",)
    RETURN_NAMES = ("video",)
    FUNCTION = "run"
    CATEGORY = "H3Studio/V15"
    OUTPUT_NODE = True

    def run(self, video, project_name, kind):
        import folder_paths
        from comfy_api.latest import InputImpl

        slug, root = _v15_project_root(project_name)
        subdir, stem = self.KIND[str(kind)]
        target_dir = os.path.join(root, subdir)
        os.makedirs(target_dir, exist_ok=True)

        counter = 1
        while True:
            filename = f"{stem}_{counter:05}_.mp4"
            path = os.path.join(target_dir, filename)
            if not os.path.exists(path):
                break
            counter += 1

        video.save_to(path)

        try:
            if hasattr(video, "get_stream_source"):
                src = video.get_stream_source()
                tmp_root = os.path.abspath(os.path.join(root, "_tmp"))
                if isinstance(src, (str, os.PathLike)):
                    src_abs = os.path.abspath(str(src))
                    if src_abs.startswith(tmp_root + os.sep) and src_abs != os.path.abspath(path):
                        try:
                            os.remove(src_abs)
                        except Exception:
                            pass
        except Exception:
            pass

        rel_subfolder = os.path.relpath(
            target_dir, folder_paths.get_output_directory()
        ).replace("\\", "/")

        logging.info(
            "H3RefineBridge V15 [%s]: saved %s -> %s", slug, kind, path
        )
        # Legacy/custom-node video previews in ComfyUI are exposed under
        # the "gifs" UI key even when the payload is an MP4. Using "videos"
        # records the file in history but does not render the inline player in
        # this custom node on the user's ComfyUI build.
        return {
            "ui": {
                "gifs": [{
                    "filename": filename,
                    "subfolder": rel_subfolder,
                    "type": "output",
                    "format": "video/h264-mp4",
                    "frame_rate": 24,
                }]
            },
            "result": (InputImpl.VideoFromFile(path),)
        }


class H3V15PreviewDownscaleLatent:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "latent": ("LATENT",),
            "width": ("INT", {"default": 576, "min": 320, "max": 1152, "step": 16}),
            "height": ("INT", {"default": 320, "min": 176, "max": 640, "step": 16}),
        }}

    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("preview_latent",)
    FUNCTION = "run"
    CATEGORY = "H3Studio/V15"

    def run(self, latent, width, height):
        width = max(16, int(width) // 16 * 16)
        height = max(16, int(height) // 16 * 16)
        tw, th = width // 16, height // 16

        members, nested = _extract_members(latent["samples"])
        if not members:
            return (latent,)

        small_v = _resize(members[0], th, tw)
        out_members = [small_v]
        out_members.extend(members[1:])

        out = latent.copy()
        out["samples"] = _wrap_members(out_members, nested)
        out.pop("noise_mask", None)

        logging.info(
            "H3RefineBridge V15: ULTRAFAST preview %dx%d px (%dx%d latent); "
            "real RAW stays full-size.",
            width, height, tw, th
        )
        return (out,)


class H3V15ProjectHardLock:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "latent": ("LATENT",),
            "conditioning": ("CONDITIONING",),
            "project_name": ("STRING", {"forceInput": True}),
        }}

    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("locked_latent",)
    FUNCTION = "run"
    CATEGORY = "latent/minimax"

    def run(self, latent, conditioning, project_name):
        slug = _v15_project_slug(project_name)

        if not _has_mc22(conditioning):
            _v15_clear_project_tail(slug)
            logging.info(
                "H3RefineBridge V15 [%s]: no MC22 -> new chain; project state reset.",
                slug
            )
            return (latent,)

        tail = _v15_project_tails.get(slug)
        if tail is None:
            try:
                _, tail, path = _v15_load_project_tail(slug)
                if tail is None:
                    logging.warning(
                        "H3RefineBridge V15 [%s]: MC22 but no project HD tail (%s). "
                        "This first link cannot be HD-locked.",
                        slug, path
                    )
                    return (latent,)
                _v15_project_tails[slug] = tail
                logging.info(
                    "H3RefineBridge V15 [%s]: RESTORED project HD tail: %s",
                    slug, path
                )
            except Exception as e:
                logging.warning(
                    "H3RefineBridge V15 [%s]: project HD-tail reload failed (%s).",
                    slug, e
                )
                return (latent,)

        cur, nested = _extract_members(latent["samples"])
        prev, _ = _extract_members(tail["samples"])
        video, prev_v = cur[0], prev[0]

        if video.ndim != 5 or prev_v.ndim != 5:
            raise ValueError(
                f"H3 V15 [{slug}]: expected BxCxTxHxW video latents, "
                f"got {tuple(video.shape)} / {tuple(prev_v.shape)}"
            )
        if tuple(prev_v.shape[1:2] + prev_v.shape[3:]) != tuple(video.shape[1:2] + video.shape[3:]):
            raise ValueError(
                f"H3 V15 [{slug}]: HD overlap geometry mismatch "
                f"previous {tuple(prev_v.shape)} current {tuple(video.shape)}"
            )

        v_keep = max(0, min(7, int(video.shape[2]) - 1, int(prev_v.shape[2])))
        if v_keep <= 0:
            return (latent,)

        out_v = video.clone()
        out_v[:, :, :v_keep] = prev_v[:, :, -v_keep:].to(
            device=out_v.device, dtype=out_v.dtype
        )
        out_members = [out_v]

        a_keep = 0
        audio = None
        if nested and len(cur) >= 2 and len(prev) >= 2:
            audio = cur[1].clone()
            prev_a = prev[1]
            want = int(round(
                v_keep / max(1, int(video.shape[2])) * int(audio.shape[-1])
            ))
            a_keep = max(
                0, min(want, int(audio.shape[-1]) - 1, int(prev_a.shape[-1]))
            )
            if a_keep > 0:
                audio[..., :a_keep] = prev_a[..., -a_keep:].to(
                    device=audio.device, dtype=audio.dtype
                )
            out_members.append(audio)
            out_members.extend(cur[2:])
        else:
            out_members.extend(cur[1:])

        out = latent.copy()
        out["samples"] = _wrap_members(out_members, nested)

        vmask = torch.ones(
            (out_v.shape[0], 1, out_v.shape[2], out_v.shape[3], out_v.shape[4]),
            device=out_v.device, dtype=torch.float32
        )
        vmask[:, :, :v_keep] = 0.0

        if nested and audio is not None:
            amask = torch.ones(
                (audio.shape[0], 1, audio.shape[2], audio.shape[3]),
                device=audio.device, dtype=torch.float32
            )
            if a_keep > 0:
                amask[..., :a_keep] = 0.0
            out["noise_mask"] = _wrap_members([vmask, amask], True)
        else:
            out["noise_mask"] = vmask

        logging.info(
            "H3RefineBridge V15 [%s]: LOCKED project HD tail — "
            "%d video latent tokens (=22 frames), %d audio steps; noise_mask=0.",
            slug, v_keep, a_keep
        )
        return (out,)


class H3V15ProjectStoreHDTail:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "latent": ("LATENT",),
            "project_name": ("STRING", {"forceInput": True}),
        }}

    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("latent",)
    FUNCTION = "run"
    CATEGORY = "latent/minimax"

    def run(self, latent, project_name):
        slug = _v15_project_slug(project_name)
        members, nested = _extract_members(latent["samples"])
        video = members[0]
        v_keep = min(7, int(video.shape[2]))

        saved = [video[:, :, -v_keep:].detach().to("cpu", copy=True)]

        if nested and len(members) >= 2:
            audio = members[1]
            a_keep = max(
                1,
                int(round(
                    v_keep / max(1, int(video.shape[2])) * int(audio.shape[-1])
                ))
            )
            a_keep = min(a_keep, int(audio.shape[-1]))
            saved.append(audio[..., -a_keep:].detach().to("cpu", copy=True))
            for extra in members[2:]:
                saved.append(extra.detach().to("cpu", copy=True))

        tail = {"samples": _wrap_members(saved, nested)}
        _v15_project_tails[slug] = tail

        try:
            _, path = _v15_save_project_tail(slug, tail)
            logging.info(
                "H3RefineBridge V15 [%s]: STORED HD tail — %d tokens; %s",
                slug, v_keep, path
            )
        except Exception as e:
            logging.warning(
                "H3RefineBridge V15 [%s]: RAM tail stored, disk save failed: %s",
                slug, e
            )

        return (latent,)


def _v15_tmp_path(project_name, stem, suffix=".mp4"):
    slug, root = _v15_project_root(project_name)
    return slug, os.path.join(
        root, "_tmp",
        f"{stem}_{int(time.time()*1000)}_{uuid.uuid4().hex[:8]}{suffix}"
    )


def _v15_video_src_path(video, project_name, stem):
    try:
        if hasattr(video, "get_stream_source") and hasattr(video, "get_active_trim_window"):
            start_time, duration = video.get_active_trim_window()
            src = video.get_stream_source()
            if (
                abs(float(start_time)) < 1e-9
                and abs(float(duration)) < 1e-9
                and isinstance(src, (str, os.PathLike))
                and os.path.isfile(src)
            ):
                return str(src), False
    except Exception:
        pass

    _, path = _v15_tmp_path(project_name, stem, ".mp4")
    video.save_to(path)
    return path, True


def _v15_ffmpeg_concat(project_name, prev_path, cur_path, out_path):
    ff = _find_ffmpeg()
    _, list_path = _v15_tmp_path(project_name, "concat_list", ".txt")

    def esc(p):
        return p.replace("'", "'\\''")

    with open(list_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(f"file '{esc(os.path.abspath(prev_path))}'\n")
        f.write(f"file '{esc(os.path.abspath(cur_path))}'\n")

    try:
        copy_cmd = [
            ff, "-y", "-f", "concat", "-safe", "0", "-i", list_path,
            "-c", "copy", "-movflags", "+faststart", out_path
        ]
        copy_run = subprocess.run(
            copy_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )
        if (
            copy_run.returncode == 0
            and os.path.isfile(out_path)
            and os.path.getsize(out_path) > 0
        ):
            return "copy"

        has_a0 = _video_has_audio(prev_path)
        has_a1 = _video_has_audio(cur_path)
        if has_a0 and has_a1:
            filt = "[0:v][0:a][1:v][1:a]concat=n=2:v=1:a=1[v][a]"
            maps = ["-map", "[v]", "-map", "[a]"]
            extra = [
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
                "-c:a", "aac", "-b:a", "192k"
            ]
        else:
            filt = "[0:v][1:v]concat=n=2:v=1:a=0[v]"
            maps = ["-map", "[v]"]
            extra = ["-c:v", "libx264", "-preset", "veryfast", "-crf", "18"]

        recode_cmd = [
            ff, "-y", "-i", prev_path, "-i", cur_path,
            "-filter_complex", filt, *maps, *extra,
            "-movflags", "+faststart", out_path
        ]
        recode_run = subprocess.run(
            recode_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
        )
        if (
            recode_run.returncode != 0
            or not os.path.isfile(out_path)
            or os.path.getsize(out_path) <= 0
        ):
            raise RuntimeError(
                "H3RefineBridge V15: ffmpeg concat failed. copy stderr\n"
                + copy_run.stderr[-4000:]
                + "\n--- reencode stderr ---\n"
                + recode_run.stderr[-4000:]
            )
        return "reencode"
    finally:
        try:
            os.remove(list_path)
        except Exception:
            pass


class H3V15ConcatVideosNoOOM:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "previous_video": ("VIDEO",),
            "current_video": ("VIDEO",),
            "project_name": ("STRING", {"forceInput": True}),
        }}

    RETURN_TYPES = ("VIDEO",)
    RETURN_NAMES = ("video",)
    FUNCTION = "run"
    CATEGORY = "H3Studio/V15"

    def run(self, previous_video, current_video, project_name):
        from comfy_api.latest import InputImpl

        slug = _v15_project_slug(project_name)
        prev_path = cur_path = None
        prev_temp = cur_temp = False

        try:
            prev_path, prev_temp = _v15_video_src_path(
                previous_video, slug, "prev_final"
            )
            cur_path, cur_temp = _v15_video_src_path(
                current_video, slug, "current_matched"
            )
            _, out_path = _v15_tmp_path(slug, "final_concat_nooom", ".mp4")
            mode = _v15_ffmpeg_concat(slug, prev_path, cur_path, out_path)
            logging.info(
                "H3RefineBridge V15 [%s]: cumulative FINAL NO-OOM — "
                "%s append: %s + %s -> %s",
                slug, mode, os.path.basename(prev_path),
                os.path.basename(cur_path), os.path.basename(out_path)
            )
            return (InputImpl.VideoFromFile(out_path),)
        finally:
            for p, is_temp in ((prev_path, prev_temp), (cur_path, cur_temp)):
                if is_temp and p and os.path.isfile(p):
                    try:
                        os.remove(p)
                    except Exception:
                        pass



# ---------------------------------------------------------------------------
# V16: QUICK CONTROLS UI source-of-truth near the RAW review area.
# The frontend mirrors these two widgets into the actual H3Studio prompt
# widget and the actual RandomNoise noise_seed widget before a new queue.
# This node itself does not alter the rendering graph.
# ---------------------------------------------------------------------------
class H3V16QuickControls:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "prompt": ("STRING", {"multiline": True, "default": ""}),
                "noise_seed": ("INT", {
                    "default": 0,
                    "min": 0,
                    "max": 0xffffffffffffffff,
                    "control_after_generate": False,
                }),
            }
        }

    RETURN_TYPES = ("STRING", "INT")
    RETURN_NAMES = ("prompt", "noise_seed")
    FUNCTION = "run"
    CATEGORY = "H3Studio/V16"

    def run(self, prompt, noise_seed):
        return (prompt, int(noise_seed))



class H3V18MicroRawPreviewLatent:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "latent": ("LATENT",),
            "conditioning": ("CONDITIONING",),
            "new_video_tokens": ("INT", {"default": 2, "min": 1, "max": 8, "step": 1}),
        }}

    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("preview_latent",)
    FUNCTION = "run"
    CATEGORY = "H3Studio/V18"

    def run(self, latent, conditioning, new_video_tokens):
        members, nested = _extract_members(latent["samples"])
        if not members:
            return (latent,)

        video = members[0]
        if not isinstance(video, torch.Tensor) or video.ndim != 5:
            raise ValueError(f"H3 V18: expected BxCxTxHxW video latent, got {type(video)} {getattr(video, 'shape', None)}")

        total_v = int(video.shape[2])
        # H3Studio MC22 occupies 7 video-latent tokens. Keep those anchors plus
        # only the requested NEW tokens so continuation previews show the next shot,
        # not merely the old overlap. Clip 1 has no prefix.
        mc_prefix = 7 if _has_mc22(conditioning) else 0
        wanted_new = max(1, int(new_video_tokens))
        keep_v = max(1, min(total_v, mc_prefix + wanted_new))

        out_members = [video[:, :, :keep_v].clone()]
        keep_a = None
        if nested and len(members) >= 2:
            audio = members[1]
            if isinstance(audio, torch.Tensor) and audio.ndim >= 1:
                keep_a = max(1, int(round(keep_v / max(1, total_v) * int(audio.shape[-1]))))
                keep_a = min(keep_a, int(audio.shape[-1]))
                out_members.append(audio[..., :keep_a].clone())
                out_members.extend(members[2:])
            else:
                out_members.extend(members[1:])
        else:
            out_members.extend(members[1:])

        out = latent.copy()
        out["samples"] = _wrap_members(out_members, nested)

        # Preserve/crop an existing mask if H3Studio supplied one.
        mask = latent.get("noise_mask")
        if mask is not None:
            try:
                mm, mnested = _extract_members(mask)
                m_out=[]
                if mm:
                    vm=mm[0]
                    if isinstance(vm, torch.Tensor) and vm.ndim >= 3:
                        vm=vm[:, :, :keep_v].clone()
                    m_out.append(vm)
                    if mnested and len(mm)>=2:
                        am=mm[1]
                        if keep_a is not None and isinstance(am, torch.Tensor):
                            am=am[..., :keep_a].clone()
                        m_out.append(am)
                        m_out.extend(mm[2:])
                    else:
                        m_out.extend(mm[1:])
                    out["noise_mask"]=_wrap_members(m_out,mnested)
            except Exception as e:
                logging.warning("H3RefineBridge V18: could not crop preview noise_mask (%s); removing it for preview only.", e)
                out.pop("noise_mask", None)

        logging.info(
            "H3RefineBridge V18: MICRO-RAW preview keeps %d/%d video latent tokens (%d MC + %d new)%s; RAW latent remains untouched.",
            keep_v, total_v, mc_prefix, max(0, keep_v-mc_prefix),
            (f", audio steps={keep_a}" if keep_a is not None else "")
        )
        return (out,)



class H3V19MicroRawPreviewLatent:
    """Preview-only latent: keep MC anchors + N new video tokens, then resize spatially.
    The original H3Studio latent is never modified, so CONTINUE still launches the normal RAW.
    """
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "latent": ("LATENT",),
            "conditioning": ("CONDITIONING",),
            "new_video_tokens": ("INT", {"default": 1, "min": 1, "max": 8, "step": 1}),
            "width": ("INT", {"default": 1024, "min": 320, "max": 1152, "step": 16}),
            "height": ("INT", {"default": 576, "min": 176, "max": 640, "step": 16}),
        }}

    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("preview_latent",)
    FUNCTION = "run"
    CATEGORY = "H3Studio/V19"

    def run(self, latent, conditioning, new_video_tokens, width, height):
        members, nested = _extract_members(latent["samples"])
        if not members:
            return (latent,)

        video = members[0]
        if not isinstance(video, torch.Tensor) or video.ndim != 5:
            raise ValueError(f"H3 V19: expected BxCxTxHxW video latent, got {type(video)} {getattr(video, 'shape', None)}")

        # H3 video VAE spatial factor is 16. Keep values aligned so preview dimensions
        # are predictable and user-editable directly in pixels.
        width = max(16, int(width) // 16 * 16)
        height = max(16, int(height) // 16 * 16)
        tw, th = width // 16, height // 16

        total_v = int(video.shape[2])
        mc_prefix = 7 if _has_mc22(conditioning) else 0
        wanted_new = max(1, int(new_video_tokens))
        keep_v = max(1, min(total_v, mc_prefix + wanted_new))

        # Temporal crop first, spatial resize second. This branch is preview-only.
        v = video[:, :, :keep_v].clone()
        v = _resize(v, th, tw)
        out_members = [v]

        keep_a = None
        if nested and len(members) >= 2:
            audio = members[1]
            if isinstance(audio, torch.Tensor) and audio.ndim >= 1:
                keep_a = max(1, int(round(keep_v / max(1, total_v) * int(audio.shape[-1]))))
                keep_a = min(keep_a, int(audio.shape[-1]))
                out_members.append(audio[..., :keep_a].clone())
                out_members.extend(members[2:])
            else:
                out_members.extend(members[1:])
        else:
            out_members.extend(members[1:])

        out = latent.copy()
        out["samples"] = _wrap_members(out_members, nested)

        # Preserve the preview noise mask when possible: crop time and match the preview grid.
        mask = latent.get("noise_mask")
        if mask is not None:
            try:
                mm, mnested = _extract_members(mask)
                m_out = []
                if mm:
                    vm = mm[0]
                    if isinstance(vm, torch.Tensor):
                        if vm.ndim >= 3:
                            vm = vm[:, :, :keep_v].clone()
                        if vm.ndim in (4, 5):
                            vm = _resize(vm, th, tw)
                    m_out.append(vm)
                    if mnested and len(mm) >= 2:
                        am = mm[1]
                        if keep_a is not None and isinstance(am, torch.Tensor):
                            am = am[..., :keep_a].clone()
                        m_out.append(am)
                        m_out.extend(mm[2:])
                    else:
                        m_out.extend(mm[1:])
                    out["noise_mask"] = _wrap_members(m_out, mnested)
            except Exception as e:
                logging.warning("H3RefineBridge V19: preview noise_mask resize failed (%s); removing preview mask only.", e)
                out.pop("noise_mask", None)

        logging.info(
            "H3RefineBridge V19: RAW-LIKE preview %dx%d, 8-step sampler branch, keeps %d/%d video tokens (%d MC + %d new)%s; RAW untouched.",
            width, height, keep_v, total_v, mc_prefix, max(0, keep_v-mc_prefix),
            (f", audio steps={keep_a}" if keep_a is not None else "")
        )
        return (out,)


class H3V19LastVideoTokenLatent:
    """After preview sampling, keep only the newest video latent token for a 1-frame decode."""
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"latent": ("LATENT",)}}

    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("one_frame_latent",)
    FUNCTION = "run"
    CATEGORY = "H3Studio/V19"

    def run(self, latent):
        members, nested = _extract_members(latent["samples"])
        if not members:
            return (latent,)
        video = members[0]
        if not isinstance(video, torch.Tensor) or video.ndim != 5:
            raise ValueError(f"H3 V19: expected video latent BxCxTxHxW, got {getattr(video, 'shape', None)}")

        out_members = [video[:, :, -1:].clone()]
        # Audio is not connected on the preview output; keep remaining members intact only
        # so NestedTensor structure stays compatible with ComfyUI's H3 latent handling.
        out_members.extend(members[1:])
        out = latent.copy()
        out["samples"] = _wrap_members(out_members, nested)
        out.pop("noise_mask", None)
        logging.info("H3RefineBridge V19: preview decode reduced to newest single video latent token.")
        return (out,)



class H3V18ForceFreshLatent:
    """Pass-through latent whose change token is always fresh on a newly queued run.

    This makes REFAIRE really recompute the progressive preview sampler instead of
    allowing ComfyUI to reuse a cached intermediate RAW latent. It does NOT alter
    the latent tensor and is not involved when CONTINUER resumes the same running prompt.
    """
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"latent": ("LATENT",)}}

    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("latent",)
    FUNCTION = "run"
    CATEGORY = "H3Studio/V18.2"

    @classmethod
    def IS_CHANGED(cls, **kwargs):
        # NaN is the standard ComfyUI pattern for "always changed".
        # Dependents are therefore recomputed on every NEW queue (REFAIRE / Execute).
        return float("nan")

    def run(self, latent):
        logging.info("H3RefineBridge V18.2: fresh-queue gate -> progressive RAW preview will recompute.")
        return (latent,)


class H3V18ProgressivePreviewPause:
    """Pause after the first sigma segment of the *real* RAW trajectory.

    CONTINUER returns the exact intermediate RAW latent to the remaining-sigmas sampler.
    REFAIRE aborts the current prompt and the frontend queues the whole current graph again.
    """
    status_by_id = {}

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "latent": ("LATENT",),
                "preview_video_saved": ("VIDEO",),
            },
            "hidden": {"id": "UNIQUE_ID"},
        }

    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("latent_after_preview",)
    FUNCTION = "run"
    CATEGORY = "H3Studio/V18.2"
    OUTPUT_NODE = True

    @classmethod
    def IS_CHANGED(cls, **kwargs):
        return float("nan")

    def run(self, latent, preview_video_saved, id=None):
        node_id = str(id)
        self.status_by_id[node_id] = "paused"
        logging.info(
            "H3RefineBridge V18.2: TRUE RAW progressive preview saved. PAUSE 1 — "
            "CONTINUER resumes the SAME intermediate RAW; REFAIRE aborts and requeues from the preview."
        )
        PromptServer.instance.send_sync(
            "h3_v18_progressive_preview_paused",
            {"node_id": node_id}
        )

        try:
            while self.status_by_id.get(node_id) == "paused":
                time.sleep(0.10)

            status = self.status_by_id.get(node_id)
            if status == "retry":
                # A rejected attempt must not become the Motion Context source of the next try.
                global _saved_raw_cache
                _saved_raw_cache = None
                try:
                    mod = _cache_mod()
                    mod._last = None
                    logging.info(
                        "H3RefineBridge V18.2: REFAIRE PREVIEW — transient H3Studio cache cleared; "
                        "new queue will recompute the preview from the selected Motion Context file."
                    )
                except Exception as e:
                    logging.warning(
                        "H3RefineBridge V18.2: could not clear transient H3Studio cache on preview retry (%s).",
                        e,
                    )
                raise InterruptProcessingException()

            logging.info(
                "H3RefineBridge V18.2: CONTINUER PREVIEW — releasing the exact same intermediate RAW latent "
                "to the remaining sigma segment."
            )
            return (latent,)
        finally:
            self.status_by_id.pop(node_id, None)


@PromptServer.instance.routes.post("/h3_v18_progressive_preview/continue/{node_id}")
async def h3_v18_progressive_preview_continue(request):
    node_id = request.match_info["node_id"].strip()
    H3V18ProgressivePreviewPause.status_by_id[node_id] = "continue"
    return web.json_response({"status": "ok", "action": "continue"})


@PromptServer.instance.routes.post("/h3_v18_progressive_preview/retry/{node_id}")
async def h3_v18_progressive_preview_retry(request):
    node_id = request.match_info["node_id"].strip()
    H3V18ProgressivePreviewPause.status_by_id[node_id] = "retry"
    return web.json_response({"status": "ok", "action": "retry"})

NODE_CLASS_MAPPINGS={
 "H3RefineResizeConditioning":H3RefineResizeConditioning,
 "H3RefineResizeConditioningDropRefVideo":H3RefineResizeConditioningDropRefVideo,
 "H3RawCacheHold":H3RawCacheHold,
 "H3RawCacheRestore":H3RawCacheRestore,
 "H3RefineStripKeyframes":H3RefineStripKeyframes,
 "H3VisibleJoinMatch":H3VisibleJoinMatch,
 "H3V8LockPreviousHDPrefix":H3V8LockPreviousHDPrefix,
 "H3V8StoreHDTail":H3V8StoreHDTail,
 "H3RawReviewPause":H3RawReviewPause,
 "H3V12PreviewReviewPause":H3V12PreviewReviewPause,
 "H3V12TaperPreviousHDPrefix":H3V12TaperPreviousHDPrefix,
 "H3ConcatVideosNoOOM":H3ConcatVideosNoOOM,
 "H3V15Project":H3V15Project,
 "H3V15ProjectSaveVideo":H3V15ProjectSaveVideo,
 "H3V15PreviewDownscaleLatent":H3V15PreviewDownscaleLatent,
 "H3V15ProjectHardLock":H3V15ProjectHardLock,
 "H3V15ProjectStoreHDTail":H3V15ProjectStoreHDTail,
 "H3V15ConcatVideosNoOOM":H3V15ConcatVideosNoOOM,
 "H3V16QuickControls":H3V16QuickControls,
 "H3V18MicroRawPreviewLatent":H3V18MicroRawPreviewLatent,
 "H3V19MicroRawPreviewLatent":H3V19MicroRawPreviewLatent,
 "H3V19LastVideoTokenLatent":H3V19LastVideoTokenLatent,
 "H3V18ForceFreshLatent":H3V18ForceFreshLatent,
 "H3V18ProgressivePreviewPause":H3V18ProgressivePreviewPause,
}
NODE_DISPLAY_NAME_MAPPINGS={
 "H3RefineResizeConditioning":"H3 V6 — Resize Conditioning for Refine",
 "H3RefineResizeConditioningDropRefVideo":"H3 V16.1 — Resize Conditioning + Strip Ref Video on Refine",
 "H3RawCacheHold":"H3 V6 — Hold RAW Cache",
 "H3RawCacheRestore":"H3 V6 — Restore RAW Cache",
 "H3VisibleJoinMatch":"H3 V8 — H3Studio Visible Join Fix",
 "H3V8LockPreviousHDPrefix":"H3 V10 — Persistent HD Context Lock",
 "H3V8StoreHDTail":"H3 V10 — Persist Refined HD Tail",
 "H3RawReviewPause":"H3 V11 — PAUSE APRES RAW — Continuer / Refaire",
 "H3V12PreviewReviewPause":"H3 V12 — FAST PREVIEW — Continuer / Refaire",
 "H3V12TaperPreviousHDPrefix":"H3 V12 — Tapered Persistent HD Context",
 "H3ConcatVideosNoOOM":"H3 V13 — Assemble FINAL without OOM",
 "H3V15Project":"H3 V15 — PROJECT",
 "H3V15ProjectSaveVideo":"H3 V15 — Save Video in Project",
 "H3V15PreviewDownscaleLatent":"H3 V15 — UltraFast Preview Downscale",
 "H3V15ProjectHardLock":"H3 V15 — Project HD HardLock",
 "H3V15ProjectStoreHDTail":"H3 V15 — Store Project HD Tail",
 "H3V15ConcatVideosNoOOM":"H3 V15 — Project FINAL No-OOM",
 "H3V16QuickControls":"H3 V16 — Quick Prompt + Seed Controls",
 "H3V18MicroRawPreviewLatent":"H3 V18 — Micro-RAW Temporal Preview",
 "H3V19MicroRawPreviewLatent":"H3 V19 — RAW-like Preview (tokens + resolution)",
 "H3V19LastVideoTokenLatent":"H3 V19 — Preview One Frame Latent",
 "H3V18ForceFreshLatent":"H3 V18.2 — Force Fresh Progressive Preview",
 "H3V18ProgressivePreviewPause":"H3 V18.2 — TRUE RAW Preview Pause",
}


WEB_DIRECTORY = "./web"
