import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";

const post = (url) => fetch(url, { method: "POST" });

function setPreviewPaused(node, paused) {
    if (!node) return;
    if (paused) {
        node.__v12OldColor ??= node.color;
        node.__v12OldBg ??= node.bgcolor;
        node.color = "#5a4212";
        node.bgcolor = "#2d220b";
        node.title = "⏸ PAUSE 1 — PREVIEW PRÊTE — CONTINUER ou REFAIRE";
    } else {
        if (node.__v12OldColor !== undefined) node.color = node.__v12OldColor;
        if (node.__v12OldBg !== undefined) node.bgcolor = node.__v12OldBg;
        node.title = "⏸ PAUSE 1 — PREVIEW — CONTINUER VERS RAW / REFAIRE";
    }
    node.setDirtyCanvas(true, true);
}

app.registerExtension({
    name: "H3RefineBridge.V12FastPreview",

    nodeCreated(node) {
        if (node.comfyClass !== "H3V12PreviewReviewPause") return;

        node.title = "⏸ PAUSE 1 — PREVIEW — CONTINUER VERS RAW / REFAIRE";
        node.size = [570, 150];

        let busy = false;

        node.addWidget("button", "▶ CONTINUER — lancer le RAW", null, async () => {
            if (busy) return;
            busy = true;
            try {
                await post(`/h3_v12_preview/continue/${node.id}`);
                setPreviewPaused(node, false);
            } finally {
                setTimeout(() => { busy = false; }, 500);
            }
        });

        node.addWidget("button", "🔁 REFAIRE — nouvelle preview depuis le début", null, async () => {
            if (busy) return;
            busy = true;
            try {
                try { window.__h3v16SyncQuickControls?.(); } catch (e) { console.warn(e); }
                await post(`/h3_v12_preview/retry/${node.id}`);
                await new Promise(r => setTimeout(r, 250));
                await app.queuePrompt(0);
                setPreviewPaused(node, false);
            } catch (e) {
                console.error("H3 V12 preview retry failed:", e);
            } finally {
                setTimeout(() => { busy = false; }, 900);
            }
        });
    },

    setup() {
        api.addEventListener("h3_v12_preview_paused", (event) => {
            const nodeId = Number(event?.detail?.node_id);
            const node = app.graph?.getNodeById?.(nodeId);
            setPreviewPaused(node, true);
        });
    },
});
