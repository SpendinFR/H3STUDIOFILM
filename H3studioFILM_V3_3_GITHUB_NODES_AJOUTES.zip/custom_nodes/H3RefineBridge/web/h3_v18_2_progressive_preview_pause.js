import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";

const post = (url) => fetch(url, { method: "POST" });
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

async function waitExecutionStops(maxMs = 5000) {
    const start = Date.now();
    while (Date.now() - start < maxMs) {
        // runningNodeId is null/undefined once the interrupted prompt has left the executor.
        if (app.runningNodeId == null) return;
        await sleep(100);
    }
}

function setPausedLook(node, paused) {
    if (!node) return;
    if (paused) {
        node.__v182OldColor ??= node.color;
        node.__v182OldBg ??= node.bgcolor;
        node.color = "#5a4212";
        node.bgcolor = "#2d220b";
        node.title = "⏸ PAUSE 1 — VRAIE PREVIEW RAW PRÊTE — CONTINUER / REFAIRE";
    } else {
        if (node.__v182OldColor !== undefined) node.color = node.__v182OldColor;
        if (node.__v182OldBg !== undefined) node.bgcolor = node.__v182OldBg;
        node.title = "⏸ PAUSE 1 — VRAIE PREVIEW RAW — CONTINUER / REFAIRE";
    }
    node.setDirtyCanvas(true, true);
}

app.registerExtension({
    name: "H3RefineBridge.V18_2ProgressivePreviewPause",

    nodeCreated(node) {
        if (node.comfyClass !== "H3V18ProgressivePreviewPause") return;

        node.title = "⏸ PAUSE 1 — VRAIE PREVIEW RAW — CONTINUER / REFAIRE";
        node.size = [610, 150];
        let busy = false;

        node.addWidget("button", "▶ CONTINUER — terminer CE MÊME RAW", null, async () => {
            if (busy) return;
            busy = true;
            try {
                await post(`/h3_v18_progressive_preview/continue/${node.id}`);
                setPausedLook(node, false);
            } finally {
                setTimeout(() => { busy = false; }, 500);
            }
        });

        node.addWidget("button", "🔁 REFAIRE — nouvelle PREVIEW depuis le début", null, async () => {
            if (busy) return;
            busy = true;
            try {
                // Push edits from the bottom quick-controls into the real H3Studio/RandomNoise widgets.
                try { window.__h3v16SyncQuickControls?.(); } catch (e) { console.warn(e); }

                // Abort the currently paused prompt.
                await post(`/h3_v18_progressive_preview/retry/${node.id}`);
                await waitExecutionStops();
                await sleep(100);

                // Queue the CURRENT graph. H3V18ForceFreshLatent guarantees the first RAW segment
                // is recomputed instead of being served from cache.
                await app.queuePrompt(0);
                setPausedLook(node, false);
            } catch (e) {
                console.error("H3 V18.2 progressive preview retry failed:", e);
            } finally {
                setTimeout(() => { busy = false; }, 900);
            }
        });
    },

    setup() {
        api.addEventListener("h3_v18_progressive_preview_paused", (event) => {
            const nodeId = Number(event?.detail?.node_id);
            const node = app.graph?.getNodeById?.(nodeId);
            setPausedLook(node, true);
        });
    },
});
