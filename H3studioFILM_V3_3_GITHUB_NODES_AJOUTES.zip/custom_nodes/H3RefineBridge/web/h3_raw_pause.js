import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";

const post = (url) => fetch(url, { method: "POST" });
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
async function waitExecutionStops(maxMs = 5000) {
    const start = Date.now();
    while (Date.now() - start < maxMs) {
        if (app.runningNodeId == null) return;
        await sleep(100);
    }
}

function setPausedLook(node, paused) {
    if (!node) return;
    if (paused) {
        node.__v11OldColor ??= node.color;
        node.__v11OldBg ??= node.bgcolor;
        node.color = "#5a4212";
        node.bgcolor = "#2d220b";
        node.title = "⏸ PAUSE 2 — RAW PRÊT — CONTINUER ou REFAIRE TOUT";
    } else {
        if (node.__v11OldColor !== undefined) node.color = node.__v11OldColor;
        if (node.__v11OldBg !== undefined) node.bgcolor = node.__v11OldBg;
        node.title = "⏸ PAUSE 2 — RAW — CONTINUER / REFAIRE TOUT";
    }
    node.setDirtyCanvas(true, true);
}

app.registerExtension({
    name: "H3RefineBridge.V11RawReview",

    nodeCreated(node) {
        if (node.comfyClass !== "H3RawReviewPause") return;

        node.title = "⏸ PAUSE 2 — RAW — CONTINUER / REFAIRE TOUT";
        node.size = [520, 150];

        let busy = false;

        node.addWidget("button", "▶ CONTINUER — faire le 1920 + FINAL", null, async () => {
            if (busy) return;
            busy = true;
            try {
                await post(`/h3_raw_review/continue/${node.id}`);
                setPausedLook(node, false);
            } finally {
                setTimeout(() => { busy = false; }, 500);
            }
        });

        node.addWidget("button", "🔁 REFAIRE TOUT — reprendre depuis la PREVIEW", null, async () => {
            if (busy) return;
            busy = true;
            try {
                // Copy the bottom prompt/seed controls into the real H3Studio + RandomNoise widgets.
                try { window.__h3v16SyncQuickControls?.(); } catch (e) { console.warn(e); }

                // Stop this run at the pause node.
                await post(`/h3_raw_review/retry/${node.id}`);

                // Give the backend a moment to leave the current prompt,
                // then queue the CURRENT graph. So if the user edited the
                // prompt/seed while inspecting the RAW, those edits are used.
                await waitExecutionStops();
                await sleep(100);
                await app.queuePrompt(0);
                setPausedLook(node, false);
            } catch (e) {
                console.error("H3 V11 retry failed:", e);
                // Safe fallback: user can press Execute manually.
            } finally {
                setTimeout(() => { busy = false; }, 900);
            }
        });
    },

    setup() {
        api.addEventListener("h3_raw_review_paused", (event) => {
            const nodeId = Number(event?.detail?.node_id);
            const node = app.graph?.getNodeById?.(nodeId);
            setPausedLook(node, true);
        });
    },
});
