import { app } from "../../scripts/app.js";

function findNodeByClass(cls) {
    return app.graph?._nodes?.find?.(n => n.comfyClass === cls || n.type === cls) ?? null;
}

function findWidget(node, name, fallbackIndex = null) {
    if (!node?.widgets) return null;
    const exact = node.widgets.find(w => w?.name === name);
    if (exact) return exact;
    if (fallbackIndex !== null) return node.widgets[fallbackIndex] ?? null;
    return null;
}

function syncOneQuickNode(node) {
    if (!node) return false;

    const h3 = findNodeByClass("H3StudioImageToVideo");
    const noise = findNodeByClass("RandomNoise");
    if (!h3 || !noise) return false;

    const qp = findWidget(node, "prompt", 0);
    const qs = findWidget(node, "noise_seed", 1);
    const hp = findWidget(h3, "prompt", 0);
    const ns = findWidget(noise, "noise_seed", 0);

    if (qp && hp) hp.value = qp.value ?? "";
    if (qs && ns) ns.value = Number(qs.value ?? 0);

    h3.setDirtyCanvas?.(true, true);
    noise.setDirtyCanvas?.(true, true);
    return true;
}

function syncAllQuickControls() {
    const quick = findNodeByClass("H3V16QuickControls");
    return syncOneQuickNode(quick);
}

// Exposed so the RAW/preview Retry buttons can force a last-second sync
// immediately before queuing the current graph.
window.__h3v16SyncQuickControls = syncAllQuickControls;

app.registerExtension({
    name: "H3RefineBridge.V16QuickControls",

    nodeCreated(node) {
        if (node.comfyClass !== "H3V16QuickControls") return;

        node.title = "🎛 V16 — CONTRÔLES RAPIDES — PROMPT + BRUIT / SEED";
        node.size = [760, 360];

        const promptW = findWidget(node, "prompt", 0);
        const seedW = findWidget(node, "noise_seed", 1);

        for (const w of [promptW, seedW]) {
            if (!w) continue;
            const old = w.callback;
            w.callback = function(value, ...args) {
                if (old) old.call(this, value, ...args);
                syncOneQuickNode(node);
            };
        }

        // Once the whole graph exists, make the bottom control panel the
        // source-of-truth for the duplicated prompt/seed values.
        setTimeout(() => syncOneQuickNode(node), 350);
    },

    loadedGraphNode(node) {
        if (node.comfyClass === "H3V16QuickControls") {
            setTimeout(() => syncOneQuickNode(node), 150);
        }
    },
});
