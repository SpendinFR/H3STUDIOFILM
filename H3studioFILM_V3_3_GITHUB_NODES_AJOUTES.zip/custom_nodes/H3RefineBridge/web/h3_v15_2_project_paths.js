import { app } from "../../scripts/app.js";

function slugProject(value) {
    let s = String(value ?? "").trim() || "Projet_01";
    s = s.replace(/[<>:"/\\|?*]/g, "_");
    s = s.replace(/\s+/g, "_");
    s = s.replace(/^[ ._]+|[ ._]+$/g, "");
    return (s || "Projet_01").slice(0, 80);
}

const SAVE_TARGETS = {
    210: ["preview", "H3_FAST_PREVIEW"],
    191: ["raw", "H3_RAW_CLIP"],
    92:  ["visible", "H3_VISIBLE_CLIP_1920"],
    171: ["final", "H3_VISIBLE_FINAL_1920"],
};

function projectValue() {
    const node = app.graph?._nodes?.find(n => n.comfyClass === "H3V15Project");
    if (!node) return "Anna";
    const w = node.widgets?.find(w => w.name === "project_name") ?? node.widgets?.[0];
    return slugProject(w?.value);
}

function syncNativeSavePaths() {
    if (!app.graph) return;
    const project = projectValue();

    for (const [idText, spec] of Object.entries(SAVE_TARGETS)) {
        const id = Number(idText);
        const node = app.graph.getNodeById?.(id);
        if (!node || node.comfyClass !== "SaveVideo") continue;

        const [folder, stem] = spec;
        const prefix = `video/H3studio/${project}/${folder}/${stem}`;
        const w = node.widgets?.find(w => w.name === "filename_prefix") ?? node.widgets?.[0];
        if (w && w.value !== prefix) {
            w.value = prefix;
            node.setDirtyCanvas?.(true, true);
        }
    }
}

function hookProjectWidget(node) {
    if (node.comfyClass !== "H3V15Project") return;
    const w = node.widgets?.find(w => w.name === "project_name") ?? node.widgets?.[0];
    if (!w || w.__h3v152Hooked) return;
    w.__h3v152Hooked = true;

    const old = w.callback;
    w.callback = function(...args) {
        const result = old?.apply(this, args);
        setTimeout(syncNativeSavePaths, 0);
        return result;
    };
}

app.registerExtension({
    name: "H3RefineBridge.V15_2NativeProjectPaths",

    nodeCreated(node) {
        hookProjectWidget(node);
        if (node.comfyClass === "SaveVideo" || node.comfyClass === "H3V15Project") {
            setTimeout(syncNativeSavePaths, 50);
        }
    },

    loadedGraphNode(node) {
        hookProjectWidget(node);
        setTimeout(syncNativeSavePaths, 50);
    },

    setup() {
        setTimeout(syncNativeSavePaths, 500);
    },
});
