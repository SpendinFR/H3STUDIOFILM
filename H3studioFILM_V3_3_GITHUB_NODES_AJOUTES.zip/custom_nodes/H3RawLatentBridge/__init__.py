from __future__ import annotations

import logging
import os
import re
import time
from pathlib import Path
from typing import Any

import torch
import comfy.nested_tensor
import comfy.model_management
import folder_paths

_VERSION = 1


def _slug(value: str, fallback: str) -> str:
    s = str(value or "").strip() or fallback
    s = re.sub(r'[<>:"/\\|?*]+', "_", s)
    s = "_".join(s.split()).strip(" ._") or fallback
    return s[:120]


def _state_path(project_name: str, latent_name: str) -> Path:
    project = _slug(project_name, "Projet_01")
    name = _slug(latent_name, "RAW_LATENT")
    root = Path(folder_paths.get_output_directory()) / "H3FilmSimple" / project / "_state"
    root.mkdir(parents=True, exist_ok=True)
    return root / f"{name}.pt"


def _is_nested(obj: Any) -> bool:
    return isinstance(obj, comfy.nested_tensor.NestedTensor) or bool(getattr(obj, "is_nested", False))


def _pack(obj: Any) -> Any:
    """Convert a Comfy LATENT payload to torch.save-safe CPU tensors/primitives."""
    if _is_nested(obj):
        members = list(obj.unbind())
        return {
            "__h3_kind__": "nested_tensor",
            "members": [x.detach().to("cpu", copy=True) for x in members],
        }
    if isinstance(obj, torch.Tensor):
        return {
            "__h3_kind__": "tensor",
            "tensor": obj.detach().to("cpu", copy=True),
        }
    if isinstance(obj, dict):
        return {str(k): _pack(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return {"__h3_kind__": "list", "items": [_pack(x) for x in obj]}
    if isinstance(obj, tuple):
        return {"__h3_kind__": "tuple", "items": [_pack(x) for x in obj]}
    if obj is None or isinstance(obj, (str, int, float, bool)):
        return obj
    raise TypeError(f"H3RawLatentBridge: unsupported LATENT member type: {type(obj)!r}")


def _move_tensor(x: torch.Tensor, device: torch.device) -> torch.Tensor:
    # CPU persistence is bit-exact for the stored dtype; loading back to the working
    # torch device does not decode/re-encode the latent or alter its numeric dtype.
    return x.to(device=device, non_blocking=False)


def _unpack(obj: Any, device: torch.device) -> Any:
    if isinstance(obj, dict):
        kind = obj.get("__h3_kind__")
        if kind == "tensor":
            t = obj.get("tensor")
            if not isinstance(t, torch.Tensor):
                raise ValueError("H3RawLatentBridge: invalid tensor payload")
            return _move_tensor(t, device)
        if kind == "nested_tensor":
            members = obj.get("members")
            if not isinstance(members, list) or not members or not all(isinstance(x, torch.Tensor) for x in members):
                raise ValueError("H3RawLatentBridge: invalid NestedTensor payload")
            return comfy.nested_tensor.NestedTensor([_move_tensor(x, device) for x in members])
        if kind == "list":
            return [_unpack(x, device) for x in obj.get("items", [])]
        if kind == "tuple":
            return tuple(_unpack(x, device) for x in obj.get("items", []))
        return {k: _unpack(v, device) for k, v in obj.items()}
    return obj


class H3StoreRawLatent:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "latent": ("LATENT",),
                "project_name": ("STRING", {"default": "Projet_01", "multiline": False}),
                "latent_name": ("STRING", {"default": "clip_0001_RAW_LATENT", "multiline": False}),
            }
        }

    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("latent",)
    FUNCTION = "run"
    CATEGORY = "H3Studio/RAW Latent"

    def run(self, latent, project_name, latent_name):
        path = _state_path(project_name, latent_name)
        tmp = path.with_suffix(path.suffix + ".tmp")
        payload = {
            "version": _VERSION,
            "created_unix": float(time.time()),
            "latent": _pack(latent),
        }
        torch.save(payload, tmp)
        os.replace(tmp, path)
        logging.info("H3RawLatentBridge: STORED exact RAW LATENT -> %s", path)
        return (latent,)


class H3LoadRawLatent:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "project_name": ("STRING", {"default": "Projet_01", "multiline": False}),
                "latent_name": ("STRING", {"default": "clip_0001_RAW_LATENT", "multiline": False}),
            }
        }

    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("latent",)
    FUNCTION = "run"
    CATEGORY = "H3Studio/RAW Latent"

    @classmethod
    def IS_CHANGED(cls, project_name, latent_name):
        path = _state_path(project_name, latent_name)
        try:
            st = path.stat()
            return f"{path}:{st.st_mtime_ns}:{st.st_size}"
        except OSError:
            return f"{path}:missing"

    def run(self, project_name, latent_name):
        path = _state_path(project_name, latent_name)
        if not path.is_file():
            raise FileNotFoundError(f"H3RawLatentBridge: RAW LATENT introuvable: {path}")
        try:
            payload = torch.load(path, map_location="cpu", weights_only=True)
        except TypeError:
            payload = torch.load(path, map_location="cpu")
        if not isinstance(payload, dict) or int(payload.get("version", -1)) != _VERSION or "latent" not in payload:
            raise ValueError(f"H3RawLatentBridge: fichier RAW LATENT invalide/incompatible: {path}")
        device = comfy.model_management.get_torch_device()
        latent = _unpack(payload["latent"], device)
        if not isinstance(latent, dict) or "samples" not in latent:
            raise ValueError(f"H3RawLatentBridge: payload LATENT sans 'samples': {path}")
        logging.info("H3RawLatentBridge: LOADED exact RAW LATENT <- %s", path)
        return (latent,)


NODE_CLASS_MAPPINGS = {
    "H3StoreRawLatent": H3StoreRawLatent,
    "H3LoadRawLatent": H3LoadRawLatent,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "H3StoreRawLatent": "H3 — Store Exact RAW Latent",
    "H3LoadRawLatent": "H3 — Load Exact RAW Latent",
}
