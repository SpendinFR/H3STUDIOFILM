from __future__ import annotations

import logging
import os
import re
import time
from pathlib import Path
from typing import Any

import torch
import torch.nn.functional as F
import comfy.nested_tensor
import comfy.model_management
import folder_paths

_VERSION = 2


def _slug(value: str, fallback: str) -> str:
    s = str(value or "").strip() or fallback
    s = re.sub(r'[<>:"/\\|?*]+', "_", s)
    s = "_".join(s.split()).strip(" ._") or fallback
    return s[:120]


def _state_path(project_name: str, latent_name: str) -> Path:
    project = _slug(project_name, "Projet_01")
    name = _slug(latent_name, "RAW_LATENT")
    root = Path(folder_paths.get_output_directory()) / "H3FilmSimple" / project / "_state"
    root.mkdir(parents=True, exist_ok=True)
    return root / f"{name}.pt"


def _is_nested(obj: Any) -> bool:
    return isinstance(obj, comfy.nested_tensor.NestedTensor) or bool(getattr(obj, "is_nested", False))


def _tensor_record(t: torch.Tensor) -> dict[str, Any]:
    return {
        "tensor": t.detach().to("cpu", copy=True),
        "dtype": str(t.dtype),
        "device": str(t.device),
        "shape": tuple(int(x) for x in t.shape),
    }


def _pack_tensorish(value: Any) -> dict[str, Any] | None:
    if value is None:
        return None
    if _is_nested(value):
        members = list(value.unbind())
        if not members or not all(isinstance(x, torch.Tensor) for x in members):
            raise TypeError("H3RawLatentPersist: NestedTensor invalide")
        return {"nested": True, "members": [_tensor_record(x) for x in members]}
    if isinstance(value, torch.Tensor):
        return {"nested": False, "members": [_tensor_record(value)]}
    raise TypeError(f"H3RawLatentPersist: valeur tensorielle non supportee: {type(value)!r}")


def _safe_extra(value: Any) -> Any:
    # LATENT normally only needs samples/noise_mask. Preserve simple metadata without
    # ever pickling arbitrary Comfy/Python objects into the persistence file.
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, torch.Tensor):
        return {"__tensor__": _tensor_record(value)}
    if isinstance(value, list):
        return {"__list__": [_safe_extra(x) for x in value]}
    if isinstance(value, tuple):
        return {"__tuple__": [_safe_extra(x) for x in value]}
    if isinstance(value, dict):
        return {"__dict__": {str(k): _safe_extra(v) for k, v in value.items()}}
    raise TypeError(f"H3RawLatentPersist: metadata LATENT non supportee: {type(value)!r}")


def _target_device(saved_device: str) -> torch.device:
    # Recreate the latent on the same *kind* of device when possible. Do not trust a
    # literal saved cuda index across restarts; let ComfyUI select its active torch GPU.
    if str(saved_device).startswith("cuda") and torch.cuda.is_available():
        return comfy.model_management.get_torch_device()
    if str(saved_device).startswith("mps") and getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def _restore_record(rec: dict[str, Any]) -> torch.Tensor:
    t = rec.get("tensor")
    if not isinstance(t, torch.Tensor):
        raise ValueError("H3RawLatentPersist: tensor absent du payload")
    expected_shape = tuple(rec.get("shape") or ())
    if expected_shape and tuple(t.shape) != expected_shape:
        raise ValueError(f"H3RawLatentPersist: shape corrompue {tuple(t.shape)} != {expected_shape}")
    return t.to(device=_target_device(str(rec.get("device") or "cpu")), non_blocking=False)


def _unpack_tensorish(payload: dict[str, Any] | None) -> Any:
    if payload is None:
        return None
    members_raw = payload.get("members")
    if not isinstance(members_raw, list) or not members_raw:
        raise ValueError("H3RawLatentPersist: membres absents")
    members = [_restore_record(x) for x in members_raw]
    if bool(payload.get("nested")):
        return comfy.nested_tensor.NestedTensor(tuple(members))
    if len(members) != 1:
        raise ValueError("H3RawLatentPersist: latent simple avec plusieurs membres")
    return members[0]


def _restore_extra(value: Any) -> Any:
    if not isinstance(value, dict):
        return value
    if "__tensor__" in value:
        return _restore_record(value["__tensor__"])
    if "__list__" in value:
        return [_restore_extra(x) for x in value["__list__"]]
    if "__tuple__" in value:
        return tuple(_restore_extra(x) for x in value["__tuple__"])
    if "__dict__" in value:
        return {k: _restore_extra(v) for k, v in value["__dict__"].items()}
    return value


def _describe_samples(samples: Any) -> str:
    if not _is_nested(samples):
        return f"NON-NESTED type={type(samples).__name__} shape={getattr(samples, 'shape', None)}"
    members = list(samples.unbind())
    desc=[]
    for i,t in enumerate(members):
        desc.append(f"m{i}:shape={tuple(t.shape)},dtype={t.dtype},device={t.device}")
    return "NestedTensor[" + "; ".join(desc) + "]"


def _validate_h3_av(latent: dict[str, Any], where: str) -> None:
    if not isinstance(latent, dict) or "samples" not in latent:
        raise ValueError(f"{where}: LATENT dict/samples absent")
    samples = latent["samples"]
    if not _is_nested(samples):
        raise TypeError(f"{where}: samples doit etre comfy.nested_tensor.NestedTensor, recu {_describe_samples(samples)}")
    members = list(samples.unbind())
    if len(members) < 2:
        raise ValueError(f"{where}: NestedTensor H3 doit contenir video+audio, membres={len(members)}")
    video, audio = members[0], members[1]
    if not isinstance(video, torch.Tensor) or video.ndim != 5:
        raise ValueError(f"{where}: video latent attendu BxCxTxHxW, recu {getattr(video, 'shape', None)}")
    if not isinstance(audio, torch.Tensor) or audio.ndim != 4:
        raise ValueError(f"{where}: audio latent attendu BxCx2xT, recu {getattr(audio, 'shape', None)}")


class H3StoreRawLatentExact:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "latent": ("LATENT",),
            "project_name": ("STRING", {"default": "Projet_01", "multiline": False}),
            "latent_name": ("STRING", {"default": "clip_0001_RAW_LATENT", "multiline": False}),
        }}

    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("latent",)
    FUNCTION = "run"
    CATEGORY = "H3Studio/RAW Latent Exact"

    def run(self, latent, project_name, latent_name):
        _validate_h3_av(latent, "H3StoreRawLatentExact")
        path = _state_path(project_name, latent_name)
        tmp = path.with_suffix(path.suffix + ".tmp")
        extras = {k: _safe_extra(v) for k,v in latent.items() if k not in {"samples", "noise_mask"}}
        payload = {
            "version": _VERSION,
            "created_unix": float(time.time()),
            "samples": _pack_tensorish(latent["samples"]),
            "noise_mask": _pack_tensorish(latent.get("noise_mask")) if latent.get("noise_mask") is not None else None,
            "extras": extras,
        }
        torch.save(payload, tmp)
        os.replace(tmp, path)
        logging.info("H3RawLatentPersist: STORED exact H3 AV RAW -> %s | %s", path, _describe_samples(latent["samples"]))
        return (latent,)


class H3LoadRawLatentExact:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "project_name": ("STRING", {"default": "Projet_01", "multiline": False}),
            "latent_name": ("STRING", {"default": "clip_0001_RAW_LATENT", "multiline": False}),
        }}

    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("latent",)
    FUNCTION = "run"
    CATEGORY = "H3Studio/RAW Latent Exact"

    @classmethod
    def IS_CHANGED(cls, project_name, latent_name):
        path = _state_path(project_name, latent_name)
        try:
            st = path.stat()
            return f"{path}:{st.st_mtime_ns}:{st.st_size}"
        except OSError:
            return f"{path}:missing"

    def run(self, project_name, latent_name):
        path = _state_path(project_name, latent_name)
        if not path.is_file():
            raise FileNotFoundError(f"H3LoadRawLatentExact: fichier absent: {path}")
        try:
            payload = torch.load(path, map_location="cpu", weights_only=True)
        except TypeError:
            payload = torch.load(path, map_location="cpu")
        if not isinstance(payload, dict) or int(payload.get("version", -1)) != _VERSION:
            raise ValueError(f"H3LoadRawLatentExact: payload incompatible: {path}")
        latent = {k: _restore_extra(v) for k,v in (payload.get("extras") or {}).items()}
        latent["samples"] = _unpack_tensorish(payload.get("samples"))
        if payload.get("noise_mask") is not None:
            latent["noise_mask"] = _unpack_tensorish(payload.get("noise_mask"))
        _validate_h3_av(latent, "H3LoadRawLatentExact")
        logging.info("H3RawLatentPersist: LOADED exact H3 AV RAW <- %s | %s", path, _describe_samples(latent["samples"]))
        return (latent,)


class H3RawSavedAutoGate:
    """Automatic no-pause barrier between RAW SaveVideo and HD refine.

    This mirrors the dependency role of H3RawReviewPause from H3RefineBridge, but
    never waits for human input. The exact in-memory H3 AV latent is returned
    untouched only after RAW SaveVideo has completed, forcing RAW -> HD ordering
    inside ONE ComfyUI prompt.
    """
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "latent": ("LATENT",),
            "raw_video_saved": ("VIDEO",),
        }}

    RETURN_TYPES = ("LATENT",)
    RETURN_NAMES = ("latent",)
    FUNCTION = "run"
    CATEGORY = "H3Studio/RAW Latent Exact"

    def run(self, latent, raw_video_saved):
        _validate_h3_av(latent, "H3RawSavedAutoGate")
        logging.info(
            "H3RawLatentPersist: RAW SaveVideo complete -> releasing SAME in-memory H3 AV latent to HD refine | %s",
            _describe_samples(latent["samples"]),
        )
        return (latent,)


# ---------------------------------------------------------------------------
# FilmMaker V9: RAW refs stay authoritative, HD refine drops VISUAL refs.
#
# H3Studio sees the full image-reference set while generating the 1152x640 RAW.
# The 1920 refine receives the exact RAW latent, text conditioning, Motion
# Context/keyframes and hard-video continuity, but not image/video refs again.
# Audio refs are intentionally kept for dialogue/voice conditioning.
# This node lives in H3RawLatentPersist so the user's H3RefineBridge remains
# completely untouched.
# ---------------------------------------------------------------------------

def _target_video_from_latent(latent: dict[str, Any]) -> torch.Tensor:
    if not isinstance(latent, dict) or "samples" not in latent:
        raise ValueError("H3RefineDropVisualRefs: LATENT dict/samples absent")
    samples = latent["samples"]
    members = list(samples.unbind()) if hasattr(samples, "unbind") else [samples]
    if not members or not isinstance(members[0], torch.Tensor) or members[0].ndim != 5:
        raise ValueError(
            "H3RefineDropVisualRefs: video latent BxCxTxHxW attendu, recu "
            f"{getattr(members[0] if members else None, 'shape', None)}"
        )
    return members[0]


def _resize_cond_latent(z: torch.Tensor, h: int, w: int) -> torch.Tensor:
    if not isinstance(z, torch.Tensor) or tuple(z.shape[-2:]) == (h, w):
        return z
    dt, dev = z.dtype, z.device
    if z.ndim == 5:
        b, c, t, oh, ow = z.shape
        x = z.permute(0, 2, 1, 3, 4).reshape(b * t, c, oh, ow)
        if x.dtype in (torch.float16, torch.bfloat16):
            x = x.float()
        x = F.interpolate(x, size=(h, w), mode="nearest-exact")
        x = x.reshape(b, t, c, h, w).permute(0, 2, 1, 3, 4)
        return x.to(device=dev, dtype=dt)
    if z.ndim == 4:
        x = z.float() if z.dtype in (torch.float16, torch.bfloat16) else z
        return F.interpolate(x, size=(h, w), mode="nearest-exact").to(device=dev, dtype=dt)
    return z


class H3RefineResizeConditioningDropVisualRefs:
    """Prepare H3 conditioning for HD refine without re-feeding image/video refs.

    Keeps:
      - text embedding / all unrelated conditioning metadata
      - audio reference entries in minimax_refs
      - minimax_keyframes (Motion Context), resized to HD latent grid
      - minimax_hard_video, resized to HD latent grid

    Drops from minimax_refs:
      - image refs
      - video refs / video_audio refs
      - any unknown non-audio visual/reference kind (fail-safe for performance)
    """
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "conditioning": ("CONDITIONING",),
            "target_latent": ("LATENT",),
        }}

    RETURN_TYPES = ("CONDITIONING",)
    RETURN_NAMES = ("conditioning",)
    FUNCTION = "run"
    CATEGORY = "H3Studio/RAW Latent Exact"

    def run(self, conditioning, target_latent):
        video = _target_video_from_latent(target_latent)
        h, w = int(video.shape[-2]), int(video.shape[-1])
        out = []
        removed_total = 0
        kept_audio = 0
        removed_kinds: dict[str, int] = {}

        for entry in conditioning:
            if not isinstance(entry, (list, tuple)) or len(entry) < 2:
                out.append(entry)
                continue
            emb, meta = entry[0], entry[1]
            d = dict(meta)

            refs = meta.get("minimax_refs")
            if refs is not None:
                kept = []
                for ref in refs:
                    x = dict(ref)
                    kind = str(x.get("kind", "") or "").strip().lower()
                    if kind == "audio":
                        kept.append(x)
                        kept_audio += 1
                    else:
                        removed_total += 1
                        removed_kinds[kind or "<empty>"] = removed_kinds.get(kind or "<empty>", 0) + 1
                d["minimax_refs"] = kept

            # Motion Context/keyframes remain authoritative during HD refine.
            kfs = meta.get("minimax_keyframes")
            if kfs is not None:
                nk = []
                for k in kfs:
                    x = dict(k)
                    if isinstance(x.get("latent"), torch.Tensor):
                        x["latent"] = _resize_cond_latent(x["latent"], h, w)
                    nk.append(x)
                d["minimax_keyframes"] = nk

            # Preserve any hard-video continuity metadata used by H3 itself.
            hard = meta.get("minimax_hard_video")
            if hard is not None:
                nh = []
                for e in hard:
                    x = dict(e)
                    if isinstance(x.get("latent"), torch.Tensor):
                        x["latent"] = _resize_cond_latent(x["latent"], h, w)
                    nh.append(x)
                d["minimax_hard_video"] = nh

            out.append([emb, d])

        logging.info(
            "H3RawLatentPersist V9: HD refine visual refs DROPPED=%d kinds=%s; "
            "audio refs kept=%d; MC/keyframes + hard-video kept; target=%dx%d.",
            removed_total,
            removed_kinds,
            kept_audio,
            w,
            h,
        )
        return (out,)


NODE_CLASS_MAPPINGS = {
    "H3StoreRawLatentExact": H3StoreRawLatentExact,
    "H3LoadRawLatentExact": H3LoadRawLatentExact,
    "H3RawSavedAutoGate": H3RawSavedAutoGate,
    "H3RefineResizeConditioningDropVisualRefs": H3RefineResizeConditioningDropVisualRefs,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "H3StoreRawLatentExact": "H3 — Store RAW Latent EXACT",
    "H3LoadRawLatentExact": "H3 — Load RAW Latent EXACT",
    "H3RawSavedAutoGate": "H3 — RAW Saved Auto Gate (same latent)",
    "H3RefineResizeConditioningDropVisualRefs": "H3 — Refine HD (drop visual refs, keep MC/audio)",
}

# V10 gate is a separate node; no changes to H3RefineBridge or V9 auto gate.
from comfy.model_management import InterruptProcessingException

class H3RawSavedStudioGate:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{
            'latent':('LATENT',), 'raw_video_saved':('VIDEO',),
            'project_name':('STRING',{'default':'Projet_01'}),
            'clip_number':('INT',{'default':1,'min':1,'max':100000}),
        }}
    RETURN_TYPES=('LATENT',)
    FUNCTION='run'
    CATEGORY='H3Studio/RAW Latent Exact'
    def run(self,latent,raw_video_saved,project_name,clip_number):
        _validate_h3_av(latent,'H3RawSavedStudioGate')
        root=Path(folder_paths.get_output_directory())/'H3FilmSimple'/_slug(project_name,'Projet_01')/'_studio'/'gates'
        root.mkdir(parents=True,exist_ok=True)
        stem=f'clip_{int(clip_number):04d}'
        waiting=root/f'{stem}.waiting.json'; decision=root/f'{stem}.decision.json'
        timing=root/f'{stem}.timing.json'
        timing.unlink(missing_ok=True)
        decision.unlink(missing_ok=True)
        waiting.write_text(__import__('json').dumps({'clip':int(clip_number),'state':'waiting','time':time.time()}),encoding='utf-8')
        gate_started=time.time()
        logging.info('H3Studio V10: RAW ready clip %s — awaiting Studio UI validation', clip_number)
        try:
            while True:
                if (root/'stop.request').is_file():
                    # Never promote a cancelled RAW to the next clip's motion cache.
                    import sys
                    for _module in list(sys.modules.values()):
                        if getattr(_module,'__name__','').endswith('h3_latent_cache') and hasattr(_module,'_last'):
                            _module._last=None
                    logging.warning('H3Studio: cancelled RAW gate clip %s; no HD refine',clip_number)
                    raise InterruptProcessingException()
                if decision.is_file():
                    choice=__import__('json').loads(decision.read_text(encoding='utf-8'))
                    action=choice.get('action','approve')
                    decision.unlink(missing_ok=True)
                    if action=='approve':
                        timing.write_text(__import__('json').dumps({'review_seconds':time.time()-gate_started,'approved_at':time.time()}),encoding='utf-8')
                        logging.info('H3Studio V10: RAW approved clip %s — HD refine starts',clip_number)
                        return (latent,)
                    if action=='redo':
                        # A rejected RAW must not populate H3Studio's next-clip
                        # reuse cache. Match the manual H3RawReviewPause retry safety.
                        import sys
                        for _module in list(sys.modules.values()):
                            if getattr(_module,'__name__','').endswith('h3_latent_cache') and hasattr(_module,'_last'):
                                _module._last=None
                        (root/f'{stem}.redo.json').write_text(__import__('json').dumps({'feedback':choice.get('feedback','')},ensure_ascii=False),encoding='utf-8')
                        logging.info('H3Studio V10: RAW redo clip %s — HD refine cancelled',clip_number)
                        raise InterruptProcessingException()
                time.sleep(.20)
        finally:
            waiting.unlink(missing_ok=True)

NODE_CLASS_MAPPINGS['H3RawSavedStudioGate']=H3RawSavedStudioGate
NODE_DISPLAY_NAME_MAPPINGS['H3RawSavedStudioGate']='H3 — Studio RAW Validation Gate'
