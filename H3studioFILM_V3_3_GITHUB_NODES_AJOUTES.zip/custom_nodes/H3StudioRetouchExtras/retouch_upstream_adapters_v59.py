"""Independent ComfyUI adapters for v10.59 retouches.

Technique:
- DiffSynth-Studio MiniMax-H3 retake: widen video edits to 17-frame VAE clips,
  protect original image/audio latent outside that interval (RAW .pt only).
- ComfyUI MiniMax H3 Director: supply a retake_info record and a precise
  generated AV window to its upstream MiniMaxH3RetakeStitchCS node.
- Roycho v7.4: automatically prepare an inpaint-friendly visual keyframe for
  the native MiniMaxH3AddGuide conditioning, no manual picture inputs.

Neither original FilmStudio nodes nor upstream GitHub code are patched.
"""
from __future__ import annotations
import json, math
from pathlib import Path
import torch
import comfy.nested_tensor
import folder_paths
from PIL import Image
import numpy as np


def _members(latent):
    if not isinstance(latent,dict) or 'samples' not in latent:
        raise ValueError('Latent RAW exact H3 requis')
    nested=latent['samples']
    if not isinstance(nested,comfy.nested_tensor.NestedTensor):
        raise TypeError('Latent RAW AV H3 NestedTensor requis')
    members=list(nested.unbind())
    if len(members)!=2 or members[0].ndim!=5 or members[1].ndim!=4:
        raise ValueError('RAW doit contenir video (B,C,T,H,W) et audio (B,C,2,L)')
    return members


def diffsynth_clip_bounds(start_frame,end_frame,frame_count,latent_t):
    """Map half-open H3 frame ranges to the 17-frame VAE clip grid.

    Initial 5 frames use two latent tokens; every next clip adds five tokens.
    Same 17-frame outward alignment as DiffSynth-Studio Retake pipeline.
    """
    s,e=int(start_frame),int(end_frame)
    total=int(frame_count)
    if not (0<=s<e<=total):
        raise ValueError('Bornes Retake invalides')
    first=s//17
    after=math.ceil(e/17)
    pixel_a=first*17
    pixel_b=min(total,after*17)
    # H3 video VAE: token frame counts repeat [1,4,4,4,4] (17 frames/5 tokens).
    # The prior 2+5*n calculation shifted all retakes by several frames.
    token_a=min(int(latent_t),first*5)
    token_b=min(int(latent_t),after*5)
    if not (0<=token_a<token_b<=latent_t):
        raise ValueError('Retake: indices du latent incompatibles avec la grille 17')
    return pixel_a,pixel_b,token_a,token_b


class H3DiffSynthClipRetakeV59:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {
            'latent':('LATENT',),
            'start_frame':('INT',{'default':0,'min':0,'max':200000}),
            'end_frame':('INT',{'default':24,'min':1,'max':200000}),
            'total_frames':('INT',{'default':124,'min':5,'max':200000}),
            'track':(['video only','audio only','both'],),
            'x_pct':('FLOAT',{'default':0.,'min':0.,'max':99.9}),
            'y_pct':('FLOAT',{'default':0.,'min':0.,'max':99.9}),
            'w_pct':('FLOAT',{'default':100.,'min':.1,'max':100.}),
            'h_pct':('FLOAT',{'default':100.,'min':.1,'max':100.}),
        }}
    RETURN_TYPES=('LATENT','STRING')
    RETURN_NAMES=('latent','clip_report')
    FUNCTION='run'
    CATEGORY='H3Studio/Retouches - upstream adapters'

    def run(self,latent,start_frame,end_frame,total_frames,track,x_pct,y_pct,w_pct,h_pct):
        members=_members(latent)
        vi,au=members
        pa,pb,ta,tb=diffsynth_clip_bounds(start_frame,end_frame,total_frames,vi.shape[2])
        if not(0<=x_pct<100 and 0<=y_pct<100 and 0<w_pct<=100-x_pct and 0<h_pct<=100-y_pct):
            raise ValueError('Masque spatial du retake invalide')
        vm=torch.zeros_like(vi,dtype=torch.float32)
        if track!='audio only':
            h,w=vi.shape[-2:]
            x0=max(0,math.floor(x_pct*w/100)); x1=min(w,math.ceil((x_pct+w_pct)*w/100))
            y0=max(0,math.floor(y_pct*h/100)); y1=min(h,math.ceil((y_pct+h_pct)*h/100))
            vm[:,:,ta:tb,y0:y1,x0:x1]=1.
        am=torch.zeros_like(au,dtype=torch.float32)
        if track in ('audio only','both'):
            size=au.shape[-1]
            a=math.floor(size*start_frame/max(1,total_frames))
            b=math.ceil(size*end_frame/max(1,total_frames))
            am[...,a:b]=1.
        out=dict(latent)
        out['noise_mask']=comfy.nested_tensor.NestedTensor((vm,am))
        return out,f'frame {start_frame}:{end_frame} -> VAE clips {pa}:{pb}, latent {ta}:{tb}'

class H3RetouchWindowCutV59:
    """Cut decoded H3 VIDEO/AUDIO to user's exact timeline before Director Stitch."""
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {
            'images':('IMAGE',),'audio':('AUDIO',),
            'start_frame':('INT',{'default':0,'min':0,'max':200000}),
            'end_frame':('INT',{'default':24,'min':1,'max':200000}),
            'fps':('FLOAT',{'default':24.,'min':1.,'max':120.}),
        }}
    RETURN_TYPES=('IMAGE','AUDIO')
    RETURN_NAMES=('images','audio')
    FUNCTION='run'
    CATEGORY='H3Studio/Retouches - upstream adapters'
    def run(self,images,audio,start_frame,end_frame,fps):
        start,end=int(start_frame),int(end_frame)
        if not(0<=start<end<=len(images)):
            raise ValueError('Retake window outside rendered frames')
        if not isinstance(audio,dict) or 'waveform' not in audio:
            raise ValueError('Audio de sortie H3 manquant')
        signal=audio['waveform']
        rate=int(audio.get('sample_rate',32000))
        s=min(signal.shape[-1],int(round(start/fps*rate)))
        e=min(signal.shape[-1],int(round(end/fps*rate)))
        result_audio=dict(audio)
        result_audio['waveform']=signal[...,s:max(s+1,e)].contiguous()
        return images[start:end].contiguous(),result_audio

class H3RetouchDirectorInfoV59:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{
            'base_video':('STRING',{'default':''}),
            'start_frame':('INT',{'default':0,'min':0,'max':200000}),
            'end_frame':('INT',{'default':24,'min':1,'max':200000}),
            'base_frames':('INT',{'default':124,'min':1,'max':200000}),
            'width':('INT',{'default':1664,'min':32,'max':8192}),
            'height':('INT',{'default':928,'min':32,'max':8192}),
        }}
    RETURN_TYPES=('STRING',)
    RETURN_NAMES=('retake_info',)
    FUNCTION='run'
    CATEGORY='H3Studio/Retouches - upstream adapters'
    def run(self,base_video,start_frame,end_frame,base_frames,width,height):
        if Path(base_video).name!=base_video or '/' in base_video or '\\' in base_video:
            raise ValueError('Source Director must be a filename in ComfyUI/input')
        if not (0<=start_frame<end_frame<=base_frames):
            raise ValueError('Invalid Director temporal retake')
        return (json.dumps({'base_video':base_video,'timeline_fps':24.,
            'start_frame':int(start_frame),'length_frames':int(end_frame-start_frame),
            'base_frames':int(base_frames),'generated_frames':int(end_frame-start_frame),
            'generated_fps':24.,'width':int(width),'height':int(height)},sort_keys=True),)

class H3RetouchRoychoGuideV59:
    """Prepare the freshly generated insertion keyframe for H3 AddGuide.

    Krea2/LanPaint produced the NEW element within the chosen rectangle. We
    MUST retain that element in this guide; blurring it out was the old V10.59
    failure. H3 editable frames still come from the exact saved RAW .pt.
    """
    @classmethod
    def INPUT_TYPES(cls):
        return {'required': {
            'image_name':('STRING',{'default':''}),
            'x_pct':('FLOAT',{'default':10.,'min':0.,'max':100.}),
            'y_pct':('FLOAT',{'default':10.,'min':0.,'max':100.}),
            'w_pct':('FLOAT',{'default':30.,'min':0.1,'max':100.}),
            'h_pct':('FLOAT',{'default':30.,'min':0.1,'max':100.}),
        }}
    RETURN_TYPES=('IMAGE',)
    RETURN_NAMES=('image',)
    FUNCTION='run'
    CATEGORY='H3Studio/Retouches - upstream adapters'
    def run(self,image_name,x_pct,y_pct,w_pct,h_pct):
        if Path(image_name).name!=image_name or not image_name.startswith('h3new_'):
            raise ValueError('Image guide must be an isolated H3 retouch input')
        image_path=Path(folder_paths.get_input_directory())/image_name
        if not image_path.is_file():raise FileNotFoundError(str(image_path))
        im=Image.open(image_path).convert('RGB')
        w,h=im.size
        x0=max(0,math.floor(w*x_pct/100));y0=max(0,math.floor(h*y_pct/100))
        x1=min(w,math.ceil(w*(x_pct+w_pct)/100));y1=min(h,math.ceil(h*(y_pct+h_pct)/100))
        if not(x1>x0 and y1>y0):raise ValueError('Region guide vide')
        # Keep the Krea2-generated object intact. The H3 latent mask, not
        # this guide image, determines which parts of the original may change.
        arr=np.asarray(im,dtype=np.float32)/255.
        return (torch.from_numpy(arr).unsqueeze(0),)

NODE_CLASS_MAPPINGS={
    'H3DiffSynthClipRetakeV59':H3DiffSynthClipRetakeV59,
    'H3RetouchWindowCutV59':H3RetouchWindowCutV59,
    'H3RetouchDirectorInfoV59':H3RetouchDirectorInfoV59,
    'H3RetouchRoychoGuideV59':H3RetouchRoychoGuideV59,
}
NODE_DISPLAY_NAME_MAPPINGS={
    'H3DiffSynthClipRetakeV59':'H3 Retake — DiffSynth VAE 17-frame region (RAW)',
    'H3RetouchWindowCutV59':'H3 Retake — Cut precise generated AV window',
    'H3RetouchDirectorInfoV59':'H3 Retake — Director information',
    'H3RetouchRoychoGuideV59':'H3 Insert — Roycho masked auto visual guide',
}
