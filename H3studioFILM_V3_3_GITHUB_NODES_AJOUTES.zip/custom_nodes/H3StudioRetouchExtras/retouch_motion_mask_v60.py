"""Frame-tracked RAW H3 retouch masks. Independent of the FilmMaker production workflow.

Replicates the *mechanism*, not the UI, of Roycho's animated mask -> MVEx
mask-to-latent route. Uses CPU optical flow on the original H3 clip to move a
user-drawn/auto box through the shot and converts the sequence to H3 NestedTensor
video-latent noise masks. Never converts the video back into H3 latents.
"""
from __future__ import annotations
import math
from pathlib import Path
import torch
import comfy.nested_tensor
import folder_paths


def validate_source(path):
    root=Path(folder_paths.get_output_directory()).resolve()
    p=Path(path).resolve()
    if not p.is_file() or not p.is_relative_to(root) or p.suffix.lower() not in ('.mp4','.mov','.mkv'):
        raise ValueError('Suivi : fichier RAW vidéo hors du dossier ComfyUI/output')
    return p


def track_boxes(video_path, rect, samples, start_sec, end_sec, fps=24, max_width=480):
    """Return per-latent-frame boxes (normalized x,y,w,h).

    This is a visual placement tracker. It cannot synthesize a desired 3D pose;
    the new gesture itself must still be produced by MiniMax H3 sampling.
    """
    import cv2
    x,y,w,h=map(float,rect)
    if not all(math.isfinite(q) for q in (x,y,w,h)) or not(0<=x<=1 and 0<=y<=1 and 0<w<=1-x and 0<h<=1-y):
        raise ValueError('Rectangle suivi invalide')
    cap=cv2.VideoCapture(str(video_path))
    if not cap.isOpened(): raise RuntimeError('Impossible de suivre ce RAW : vidéo illisible')
    try:
        n=int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        video_fps=float(cap.get(cv2.CAP_PROP_FPS) or fps)
        n=max(n,1)
        # Four frame temporal strides balance accuracy and low CPU use.
        stride=4
        sampled=[]
        stride=4
        for k in range(0,n,stride):
            cap.set(cv2.CAP_PROP_POS_FRAMES,k)
            ok,frame=cap.read()
            if not ok:break
            ratio=min(1,max_width/max(1,frame.shape[1]))
            small=cv2.resize(frame,None,fx=ratio,fy=ratio,interpolation=cv2.INTER_AREA)
            sampled.append((k/video_fps,cv2.cvtColor(small,cv2.COLOR_BGR2GRAY)))
        if not sampled: raise RuntimeError('RAW illisible : aucun cadre pour suivre la zone')
        anchor=min(range(len(sampled)),key=lambda i:abs(sampled[i][0]-start_sec))
        positions={anchor:(x,y,w,h)}
        def advance(old,gray,rect):
            bx,by,bw,bh=rect
            height,width=old.shape
            ax=max(0,int((bx-.04)*width));ay=max(0,int((by-.04)*height))
            ex=min(width,int((bx+bw+.04)*width));ey=min(height,int((by+bh+.04)*height))
            mask=None
            if ex-ax>8 and ey-ay>8:
                import numpy as np
                mask=np.zeros_like(old,dtype='uint8');mask[ay:ey,ax:ex]=255
            pts=cv2.goodFeaturesToTrack(old,maxCorners=110,qualityLevel=.012,minDistance=6,mask=mask)
            if pts is None or len(pts)<4:
                pts=cv2.goodFeaturesToTrack(old,maxCorners=110,qualityLevel=.015,minDistance=8)
            if pts is not None and len(pts)>=4:
                dest,status,_=cv2.calcOpticalFlowPyrLK(old,gray,pts,None,winSize=(19,19),maxLevel=3)
                if dest is not None and status is not None:
                    motions=(dest-pts).reshape(-1,2)[status.reshape(-1)>0]
                    if len(motions)>=4:
                        import numpy as np
                        dx,dy=np.median(motions,axis=0)
                        bx=min(max(0.,bx+max(-.08,min(.08,float(dx)/width))),1-bw)
                        by=min(max(0.,by+max(-.08,min(.08,float(dy)/height))),1-bh)
            return (bx,by,bw,bh)
        # The box is drawn at the start of the selected interval, not always t=0.
        # Track both forward and backward so the same latent token aligns to its
        # corresponding original-world region even for a late retake.
        for k in range(anchor+1,len(sampled)):
            positions[k]=advance(sampled[k-1][1],sampled[k][1],positions[k-1])
        for k in range(anchor-1,-1,-1):
            positions[k]=advance(sampled[k+1][1],sampled[k][1],positions[k+1])
        shifts=[(sampled[k][0],positions[k]) for k in range(len(sampled))]
        if not shifts:raise RuntimeError('RAW illisible : aucun cadre pour suivre la zone')
        # For a saved H3 latent of T tokens, rendered frames = [1,4,4,4,4] repeated.
        # Sample the original tracked boxes at each token's temporal center.
        seconds=[];frame=0
        for i in range(samples):
            token_frames=(1 if i%5==0 else 4)
            seconds.append((frame+(token_frames-1)/2)/fps)
            frame+=token_frames
        import bisect
        times=[a for a,b in shifts]
        result=[]
        for t in seconds:
            idx=min(len(shifts)-1,max(0,bisect.bisect_right(times,t)-1))
            result.append(shifts[idx][1])
        return result
    finally:
        cap.release()


def mask_from_boxes(latent,boxes,start_pct,end_pct,track='video only',pad_pct=8.0,temporal_feather_pct=2.5):
    v,a=list(latent['samples'].unbind())
    if v.ndim!=5 or a.ndim!=4:raise ValueError('H3 latent RAW video/audio invalide')
    B,C,T,H,W=v.shape
    if len(boxes)!=T:raise ValueError('Suivi image et latent désynchronisés')
    if not(0<=start_pct<end_pct<=100):raise ValueError('Intervalle vidéo invalide')
    masks=torch.zeros((1,1,T,H,W),device=v.device,dtype=torch.float32)
    px=float(pad_pct)/100.
    for i,(x,y,w,h) in enumerate(boxes):
        u=(i+.5)*100/T
        feather=max(0.001,temporal_feather_pct)
        if u<start_pct-feather or u>end_pct+feather:continue
        weight=min(1.,(u-(start_pct-feather))/feather,(end_pct+feather-u)/feather)
        if weight<=0:continue
        xx0=max(0,int(math.floor((x-px)*W)));xx1=min(W,int(math.ceil((x+w+px)*W)))
        yy0=max(0,int(math.floor((y-px)*H)));yy1=min(H,int(math.ceil((y+h+px)*H)))
        if xx1>xx0 and yy1>yy0:masks[:,:,i,yy0:yy1,xx0:xx1]=weight
    # The audio remains pinned except for a dialogue rewrite.
    audio=torch.zeros_like(a,dtype=torch.float32)
    if track=='both':
        L=a.shape[-1]
        u=(torch.arange(L,device=a.device,dtype=torch.float32)+.5)*100/L
        f=max(.001,temporal_feather_pct)
        audible=torch.minimum(((u-(start_pct-f))/f).clamp(0,1),(((end_pct+f)-u)/f).clamp(0,1))
        audio=audible.reshape(1,1,1,L).expand_as(a).contiguous()
    out=dict(latent)
    out['noise_mask']=comfy.nested_tensor.NestedTensor((masks.expand_as(v).contiguous(),audio))
    return out


class H3RetouchTrackedMaskV60:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{
            'latent':('LATENT',),
            'source_video':('STRING',{'default':''}),
            'track':(['video only','both'],),
            'start_pct':('FLOAT',{'default':0.,'min':0.,'max':100.}),
            'end_pct':('FLOAT',{'default':100.,'min':0.,'max':100.}),
            'x_pct':('FLOAT',{'default':10.,'min':0.,'max':100.}),
            'y_pct':('FLOAT',{'default':10.,'min':0.,'max':100.}),
            'w_pct':('FLOAT',{'default':60.,'min':.1,'max':100.}),
            'h_pct':('FLOAT',{'default':60.,'min':.1,'max':100.}),
            'pad_pct':('FLOAT',{'default':8.,'min':0.,'max':40.}),
            'time_feather_pct':('FLOAT',{'default':2.5,'min':0.,'max':20.}),
        }}
    RETURN_TYPES=('LATENT','STRING')
    RETURN_NAMES=('latent','report')
    FUNCTION='run'
    CATEGORY='H3Studio/Retouches - isolated'

    def run(self,latent,source_video,track,start_pct,end_pct,x_pct,y_pct,w_pct,h_pct,pad_pct,time_feather_pct):
        path=validate_source(source_video)
        tensor=latent.get('samples') if isinstance(latent,dict) else None
        if not isinstance(tensor,comfy.nested_tensor.NestedTensor):raise ValueError('RAW NestedTensor requis')
        video,audio=list(tensor.unbind())
        if video.ndim!=5 or audio.ndim!=4:raise ValueError('H3 RAW incomplet')
        boxes=track_boxes(path,(x_pct/100,y_pct/100,w_pct/100,h_pct/100),int(video.shape[2]),start_pct,end_pct)
        out=mask_from_boxes(latent,boxes,start_pct,end_pct,track,pad_pct,time_feather_pct)
        return out,'Roycho/MVEx principle: animated tracked ROI, %d latent tokens, full original RAW outside mask'%len(boxes)

NODE_CLASS_MAPPINGS={'H3RetouchTrackedMaskV60':H3RetouchTrackedMaskV60}
NODE_DISPLAY_NAME_MAPPINGS={'H3RetouchTrackedMaskV60':'H3 — Tracked RAW insert/performance mask (optical flow)'}

class H3RetouchBoundaryFrameV60:
    """Sample an ORIGINAL RAW video frame to anchor a middle Retake on both sides.

    Image conditioning uses the native H3 AddGuide node; the source video
    never goes through a VAE and the target latent remains the saved .pt.
    """
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{
            'source_video':('STRING',{'default':''}),
            'frame_index':('INT',{'default':0,'min':0,'max':200000}),
        }}
    RETURN_TYPES=('IMAGE',)
    RETURN_NAMES=('image',)
    FUNCTION='run'
    CATEGORY='H3Studio/Retouches - isolated'
    def run(self,source_video,frame_index):
        import cv2
        import numpy as np
        path=validate_source(source_video)
        cap=cv2.VideoCapture(str(path))
        try:
            cap.set(cv2.CAP_PROP_POS_FRAMES,int(frame_index))
            okay,img=cap.read()
        finally:cap.release()
        if not okay:raise RuntimeError('Frame frontière Retake introuvable : '+str(frame_index))
        image=cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
        return (torch.from_numpy(np.ascontiguousarray(image,dtype=np.float32)/255.).unsqueeze(0),)

NODE_CLASS_MAPPINGS['H3RetouchBoundaryFrameV60']=H3RetouchBoundaryFrameV60
NODE_DISPLAY_NAME_MAPPINGS['H3RetouchBoundaryFrameV60']='H3 — Retake original before/after frame anchor'
