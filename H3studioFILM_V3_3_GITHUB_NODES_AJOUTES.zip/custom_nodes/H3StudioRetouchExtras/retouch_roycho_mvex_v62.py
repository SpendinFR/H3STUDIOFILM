"""Roycho/MVEx H3 insertion: automatically animate a drawn ROI across source frames,
then feed MVEx Mask To Latent Space's REAL output to the original H3 RAW AV latent.

No image paste, no Krea still, no synthetic replacement of MVEx. The pixel-mask
stream is converted by the installed upstream MVEx node before sampling.
"""
from __future__ import annotations
import math
from pathlib import Path
import torch
import comfy.nested_tensor
from .retouch_motion_mask_v60 import validate_source,track_boxes


def _token_frame_counts(t):
    """H3 saved video latent geometry: 2 + 5*n tokens for 5+17*n frames."""
    if t < 2 or (t-2)%5:
        raise ValueError(f'RAW H3 temporal grid mismatch: latent T={t} expected 2+5*n')
    return [1 if k%5==0 else 4 for k in range(t)]


def dynamic_pixel_mask(source, latent, rect, start_s,end_s, pad=0.08):
    source=validate_source(source)
    nested=latent.get('samples')
    if not isinstance(nested, comfy.nested_tensor.NestedTensor):
        raise ValueError('Saved H3 NestedTensor RAW is required')
    video,audio=list(nested.unbind())
    if video.ndim!=5 or audio.ndim!=4:
        raise ValueError('Expected joint H3 video/audio RAW latent')
    t=int(video.shape[2]);counts=_token_frame_counts(t)
    frames=sum(counts)
    height=int(video.shape[-2])*16; width=int(video.shape[-1])*16
    boxes=track_boxes(source,tuple(v/100 for v in rect),t,start_s,end_s)
    if len(boxes)!=t:raise ValueError('Tracked insertion ROI does not match video latent')
    # Full frame-resolution masks are necessary; MVEx knows H3's temporal groups.
    out=torch.zeros((frames,height,width),dtype=torch.float32,device='cpu')
    k=0
    for i,group_len in enumerate(counts):
        x,y,w,h=boxes[i]
        x0=max(0,math.floor((x-pad)*width));x1=min(width,math.ceil((x+w+pad)*width))
        y0=max(0,math.floor((y-pad)*height));y1=min(height,math.ceil((y+h+pad)*height))
        if x1>x0 and y1>y0:
            for q in range(k,k+group_len):
                if (start_s-.12)*24<=q<(end_s+.20)*24:
                    out[q,y0:y1,x0:x1]=1.
        k+=group_len
    if not bool((out>0).any()):
        raise ValueError('Insertion ROI/time selection generates an empty MVEx mask')
    return out

class H3RoychoAnimatedMaskV62:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{
            'latent':('LATENT',),
            'source_video':('STRING',{'default':''}),
            'start_seconds':('FLOAT',{'default':0.,'min':0.,'max':3600}),
            'end_seconds':('FLOAT',{'default':5.,'min':0.,'max':3600}),
            'x_pct':('FLOAT',{'default':20.,'min':0.,'max':100.}),
            'y_pct':('FLOAT',{'default':20.,'min':0.,'max':100.}),
            'w_pct':('FLOAT',{'default':40.,'min':0.1,'max':100.}),
            'h_pct':('FLOAT',{'default':40.,'min':0.1,'max':100.}),
        }}
    RETURN_TYPES=('MASK',)
    RETURN_NAMES=('animated_pixel_masks',)
    FUNCTION='run'
    CATEGORY='H3Studio/Retouches/Roycho + MVEx'
    def run(self,latent,source_video,start_seconds,end_seconds,x_pct,y_pct,w_pct,h_pct):
        if not 0<=start_seconds<end_seconds:raise ValueError('Insertion time range invalid')
        if not 0<=x_pct<100 or not 0<=y_pct<100 or not 0<w_pct<=100-x_pct or not 0<h_pct<=100-y_pct:
            raise ValueError('Insertion rectangle invalid')
        return (dynamic_pixel_mask(source_video,latent,(x_pct,y_pct,w_pct,h_pct),start_seconds,end_seconds),)

class H3RoychoApplyMVExMaskV62:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{'latent':('LATENT',),'mask':('MASK',)}}
    RETURN_TYPES=('LATENT',)
    RETURN_NAMES=('masked_exact_raw_latent',)
    FUNCTION='run'
    CATEGORY='H3Studio/Retouches/Roycho + MVEx'
    def run(self,latent,mask):
        nested=latent.get('samples')
        if not isinstance(nested,comfy.nested_tensor.NestedTensor):
            raise TypeError('Exact RAW H3 AV NestedTensor required')
        tracks=list(nested.unbind())
        if len(tracks)!=2 or tracks[0].ndim!=5 or tracks[1].ndim!=4:
            raise ValueError('H3 AV video/audio required')
        video,audio=tracks
        if mask.ndim==4 and mask.shape[1]==1:mask=mask[:,0]
        if mask.ndim!=3:
            raise ValueError(f'Unexpected MVEx latent mask shape {tuple(mask.shape)}')
        T,H,W=video.shape[-3:]
        if tuple(mask.shape)!=(T,H,W):
            raise ValueError(f'MVEx latent geometry {tuple(mask.shape)} != H3 RAW ({T},{H},{W}); no interpolated fallback')
        vm=mask.to(dtype=torch.float32,device=video.device).clamp(0,1)[None,None].expand_as(video).contiguous()
        am=torch.zeros_like(audio,dtype=torch.float32)
        output=dict(latent)
        output['noise_mask']=comfy.nested_tensor.NestedTensor((vm,am))
        return (output,)

NODE_CLASS_MAPPINGS={'H3RoychoAnimatedMaskV62':H3RoychoAnimatedMaskV62,
                     'H3RoychoApplyMVExMaskV62':H3RoychoApplyMVExMaskV62}
NODE_DISPLAY_NAME_MAPPINGS={'H3RoychoAnimatedMaskV62':'Roycho H3 automatic animated insertion mask',
                            'H3RoychoApplyMVExMaskV62':'Roycho H3 attach true MVEx latent mask to RAW AV'}
