"""MiniMax H3 RAW-only independent spatial/temporal mask for V10.58.

Implements the ramp logic described in panghea/minimax-h3-latent-core/masks.py
without modifying upstream sampler, payload, or original cached latents.
This file is an independently written implementation for our retouch node.
"""
import torch

def ramp(n, a, b, feather, device):
    if not 0 <= a < b <= n:
        raise ValueError('invalid ramp bounds')
    u=torch.arange(n,device=device,dtype=torch.float32)
    if feather <= 0:
        return ((u >= a)&(u < b)).float()
    # Keep the entire selected band at full strength; fade only OUTSIDE.
    before=((u-(a-feather))/feather).clamp(0,1)
    after=(((b+feather)-u)/feather).clamp(0,1)
    return torch.minimum(before,after)

def make_masks(members, track, start_pct, end_pct, x_pct,y_pct,w_pct,h_pct, temporal_feather_pct,spatial_feather_pct, strength):
    if len(members)<2 or members[0].ndim!=5 or members[1].ndim!=4:
        raise ValueError('H3 RAW must contain video (B,C,T,H,W) and audio (B,C,2,L)')
    if track not in ('video only','audio only','both'):
        raise ValueError('H3 track type invalid')
    if not (0 <= start_pct < end_pct <= 100):
        raise ValueError('H3 time range invalid')
    if not (0 <= x_pct<100 and 0 <= y_pct<100 and 0<w_pct<=100-x_pct and 0<h_pct<=100-y_pct):
        raise ValueError('H3 selected rectangle invalid')
    if not 0 < strength <= 1:
        raise ValueError('H3 mask strength invalid')
    masks=[]
    for i,t in enumerate(members):
        active=(track=='both' or (i==0 and track=='video only') or (i==1 and track=='audio only'))
        if not active:
            masks.append(torch.zeros_like(t,dtype=torch.float32));continue
        if i==0:
            T,H,W=t.shape[2:]
            mt=ramp(T,start_pct*T/100,end_pct*T/100,temporal_feather_pct*T/100,t.device).view(1,1,T,1,1)
            mx=ramp(W,x_pct*W/100,(x_pct+w_pct)*W/100,spatial_feather_pct*W/100,t.device).view(1,1,1,1,W)
            my=ramp(H,y_pct*H/100,(y_pct+h_pct)*H/100,spatial_feather_pct*H/100,t.device).view(1,1,1,H,1)
            m=mt*mx*my
        else:
            L=t.shape[-1]
            m=ramp(L,start_pct*L/100,end_pct*L/100,temporal_feather_pct*L/100,t.device).view(1,1,1,L)
        masks.append((m*strength).expand_as(t).contiguous())
    return masks
