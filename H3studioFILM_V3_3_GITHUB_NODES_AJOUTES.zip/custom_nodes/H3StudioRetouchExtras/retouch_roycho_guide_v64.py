"""Crop real Krea2 insertion image to the SAME pixel bbox as upstream MVEx.

Guide is NOT composited onto the final clip; it conditions MiniMaxH3AddGuide
on the cropped H3 latent. All edits outside mask remain controlled by MVEx
and ultimately MVEx SubjectUncrop.
"""
import torch
import torch.nn.functional as F

class H3RoychoCropGuideV64:
    @classmethod
    def INPUT_TYPES(cls):
        return {'required':{
            'full_image':('IMAGE',),
            'bboxes':('BOUNDING_BOX',),
            'cropped_images':('IMAGE',),
            'frame_index':('INT',{'default':0,'min':0,'max':200000}),
        }}
    RETURN_TYPES=('IMAGE',)
    RETURN_NAMES=('image',)
    FUNCTION='run'
    CATEGORY='H3Studio/Retouches - isolated'

    def run(self,full_image,bboxes,cropped_images,frame_index):
        if not isinstance(full_image,torch.Tensor) or full_image.ndim!=4 or full_image.shape[-1]<3:
            raise ValueError('Guide doit être IMAGE [N,H,W,C]')
        if not isinstance(cropped_images,torch.Tensor) or cropped_images.ndim!=4:
            raise ValueError('Crop MVEx original introuvable')
        if isinstance(bboxes,dict): box=bboxes
        elif isinstance(bboxes,list) and bboxes:
            frame=bboxes[min(max(0,int(frame_index)),len(bboxes)-1)]
            box=frame[0] if isinstance(frame,list) else frame
        else:raise ValueError('MVEx crop bbox absent')
        x,y,w,h=(int(round(box[k])) for k in ('x','y','width','height'))
        im=full_image[min(max(0,int(frame_index)),len(full_image)-1),:,:,:3]
        height,width=im.shape[:2]
        if not (w>0 and h>0 and 0<=x<width and 0<=y<height and x+w<=width and y+h<=height):
            raise ValueError(f'Guide crop bbox hors image {x,y,w,h} vs {width,height}')
        chunk=im[y:y+h,x:x+w,:].permute(2,0,1)[None]
        ch,cw=(int(cropped_images.shape[1]),int(cropped_images.shape[2]))
        if (h,w)!=(ch,cw):
            chunk=F.interpolate(chunk,(ch,cw),mode='bicubic',align_corners=False)
        guide=chunk.permute(0,2,3,1).clamp(0,1).contiguous()
        return (guide,)

NODE_CLASS_MAPPINGS={'H3RoychoCropGuideV64':H3RoychoCropGuideV64}
NODE_DISPLAY_NAME_MAPPINGS={'H3RoychoCropGuideV64':'H3 Roycho V64 - real insertion guide crop aligned to MVEx'}
