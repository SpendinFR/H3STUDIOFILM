"""Additional RAW-only masked H3 retake node; never patches existing FilmStudio nodes."""
import torch
import comfy.nested_tensor

class H3RetouchRawMask:
    @classmethod
    def INPUT_TYPES(cls):
        pct={"default":0.0,"min":0.0,"max":100.0,"step":0.05}
        return {"required":{
            "latent":("LATENT",),
            "track":(["video only","audio only","both"],),
            "start_pct":("FLOAT",dict(pct)),
            "end_pct":("FLOAT",dict(pct,default=100.0)),
            "x_pct":("FLOAT",dict(pct)),
            "y_pct":("FLOAT",dict(pct)),
            "w_pct":("FLOAT",dict(pct,default=100.0)),
            "h_pct":("FLOAT",dict(pct,default=100.0)),
            "time_feather_pct":("FLOAT",dict(pct,default=1.0)),
            "spatial_feather_pct":("FLOAT",dict(pct,default=2.0)),
        }}
    RETURN_TYPES=("LATENT",)
    RETURN_NAMES=("latent",)
    FUNCTION="run"
    CATEGORY="H3Studio/Retouches - isolated"

    @staticmethod
    def _band(length,start,end,feather,device):
        u=(torch.arange(length,device=device,dtype=torch.float32)+.5)/length*100
        if feather<=0:return ((u>=start)&(u<end)).float()
        # soft transition in original latent; zero away from selection
        return ((u-start)/max(feather,0.01)).clamp(0,1)*((end-u)/max(feather,0.01)).clamp(0,1)

    def run(self,latent,track,start_pct,end_pct,x_pct,y_pct,w_pct,h_pct,time_feather_pct,spatial_feather_pct):
        if not (0<=start_pct<end_pct<=100):raise ValueError('Intervalle temporel H3 invalide')
        if not (0<=x_pct<100 and 0<=y_pct<100 and 0<w_pct<=100-x_pct and 0<h_pct<=100-y_pct):
            raise ValueError('Rectangle H3 invalide')
        if not isinstance(latent,dict) or 'samples' not in latent:raise ValueError('Latent RAW H3 absent')
        nested=latent['samples']
        if not isinstance(nested,comfy.nested_tensor.NestedTensor):raise TypeError('RAW H3 AV NestedTensor requis')
        values=list(nested.unbind())
        if len(values)<2 or values[0].ndim!=5 or values[1].ndim!=4:
            raise ValueError('RAW H3 AV incompatible: video (B,C,T,H,W) et audio (B,C,2,T) attendus')
        video,audio=values[:2]
        masks=[]
        for i,tensor in enumerate(values):
            enabled = (track=='both' or (i==0 and track=='video only') or (i==1 and track=='audio only'))
            if not enabled:
                masks.append(torch.zeros_like(tensor));continue
            if i==0:
                _,_,T,H,W=tensor.shape
                time=self._band(T,start_pct,end_pct,time_feather_pct,tensor.device).view(1,1,T,1,1)
                xp=self._band(W,x_pct,x_pct+w_pct,spatial_feather_pct,tensor.device).view(1,1,1,1,W)
                yp=self._band(H,y_pct,y_pct+h_pct,spatial_feather_pct,tensor.device).view(1,1,1,H,1)
                mask=(time*xp*yp).to(tensor.dtype).expand_as(tensor)
            else:
                L=tensor.shape[-1]
                time=self._band(L,start_pct,end_pct,time_feather_pct,tensor.device)
                mask=time.view(1,1,1,L).to(tensor.dtype).expand_as(tensor)
            masks.append(mask)
        out=dict(latent)
        out['noise_mask']=comfy.nested_tensor.NestedTensor(tuple(masks))
        return (out,)

NODE_CLASS_MAPPINGS={'H3RetouchRawMask':H3RetouchRawMask}
NODE_DISPLAY_NAME_MAPPINGS={'H3RetouchRawMask':'H3 Retouches — RAW Spatial Temporal Mask'}

class H3RetouchQuickWindow:
    """Isolated 22-frame RAW preview (no MP4 VAE encode).

    Operates only on a *copy* of H3's saved video/audio NestedTensor. The 22-frame
    H3 cadence corresponds to 7 latent video frames. Temporal crops are coarsened
    to H3 latent coordinates; they may not reproduce all long-context behavior.
    """
    @classmethod
    def INPUT_TYPES(cls):
        return {"required":{
            "latent":("LATENT",),
            "start_latent":("INT",{"default":0,"min":0,"max":999999}),
        }}
    RETURN_TYPES=("LATENT",)
    RETURN_NAMES=("latent",)
    FUNCTION="run"
    CATEGORY="H3Studio/Retouches - isolated"

    def run(self,latent,start_latent):
        if not isinstance(latent,dict) or 'samples' not in latent:
            raise ValueError('RAW H3 exact requis pour le test court')
        nested=latent['samples']
        if not isinstance(nested,comfy.nested_tensor.NestedTensor):
            raise TypeError('Le test court attend un RAW vidéo + audio NestedTensor')
        tracks=list(nested.unbind())
        if len(tracks)!=2 or tracks[0].ndim!=5 or tracks[1].ndim!=4:
            raise ValueError('Structure RAW H3 inattendue')
        video,audio=tracks
        total_t=int(video.shape[2]);window_t=7  # length=22, H3 17k+5 temporal cadence
        if total_t<window_t:raise ValueError('RAW trop court pour essai 0,9 seconde')
        first=min(max(0,int(start_latent)),total_t-window_t)
        # Original H3 render duration is (5 + 17*(T-2)/5)/24 seconds.
        full_frames=5+17*(total_t-2)/5
        start_frame=first*17/5
        audio_len=int(audio.shape[-1]);audio_first=round(audio_len*start_frame/full_frames)
        audio_count=max(1,round(audio_len*22/full_frames))
        audio_first=min(audio_first,max(0,audio_len-audio_count))
        new_video=video[:,:,first:first+window_t,:,:].contiguous()
        new_audio=audio[...,audio_first:audio_first+audio_count].contiguous()
        result={k:v for k,v in latent.items() if k not in ('samples','noise_mask')}
        result['samples']=comfy.nested_tensor.NestedTensor((new_video,new_audio))
        return (result,)

NODE_CLASS_MAPPINGS['H3RetouchQuickWindow']=H3RetouchQuickWindow
NODE_DISPLAY_NAME_MAPPINGS['H3RetouchQuickWindow']='H3 Retouches — RAW 0.9s Quick Window'


# Dedicated inpaint masks: unlike the legacy triangle mask, this protects
# the original exactly outside the selection while keeping full denoise
# freedom throughout the user-selected interval.
try:
    from .retouch_mask_math_v58 import make_masks
except ImportError:
    # Unit tests can load this ComfyUI node directly without a package parent.
    import importlib.util as _ilu
    from pathlib import Path as _Path
    _spec=_ilu.spec_from_file_location('retouch_mask_math_v58',_Path(__file__).with_name('retouch_mask_math_v58.py'))
    _core=_ilu.module_from_spec(_spec)
    _spec.loader.exec_module(_core)
    make_masks=_core.make_masks

class H3RetouchMaskV58:
    @classmethod
    def INPUT_TYPES(cls):
        pct={"default":0.,"min":0.,"max":100.,"step":0.05}
        return {"required":{
            "latent":("LATENT",),
            "track":(["video only","audio only","both"],),
            "start_pct":("FLOAT",dict(pct)),
            "end_pct":("FLOAT",dict(pct,default=100.)),
            "x_pct":("FLOAT",dict(pct)),
            "y_pct":("FLOAT",dict(pct)),
            "w_pct":("FLOAT",dict(pct,default=100.)),
            "h_pct":("FLOAT",dict(pct,default=100.)),
            "time_feather_pct":("FLOAT",dict(pct,default=4.)),
            "spatial_feather_pct":("FLOAT",dict(pct,default=4.)),
            "strength":("FLOAT",{"default":0.95,"min":0.05,"max":1.,"step":0.05}),
        }}
    RETURN_TYPES=("LATENT",)
    RETURN_NAMES=("latent",)
    FUNCTION="run"
    CATEGORY="H3Studio/Retouches - isolated"
    def run(self,latent,track,start_pct,end_pct,x_pct,y_pct,w_pct,h_pct,time_feather_pct,spatial_feather_pct,strength):
        if not isinstance(latent,dict) or 'samples' not in latent:raise ValueError('Missing exact RAW latent')
        nested=latent['samples']
        if not isinstance(nested,comfy.nested_tensor.NestedTensor):raise TypeError('H3 AV NestedTensor required')
        values=list(nested.unbind())
        masks=make_masks(values,track,start_pct,end_pct,x_pct,y_pct,w_pct,h_pct,time_feather_pct,spatial_feather_pct,strength)
        out=dict(latent)
        out['noise_mask']=comfy.nested_tensor.NestedTensor(tuple(masks))
        return (out,)

NODE_CLASS_MAPPINGS['H3RetouchMaskV58']=H3RetouchMaskV58
NODE_DISPLAY_NAME_MAPPINGS['H3RetouchMaskV58']='H3 Retouches — RAW Mask V58 (full selected span)'

# V10.59 isolated upstream-derived mechanisms, no original FilmMaker node patches.
from .retouch_upstream_adapters_v59 import (
 NODE_CLASS_MAPPINGS as _UPSTREAM_V59, NODE_DISPLAY_NAME_MAPPINGS as _UPSTREAM_LABELS_V59)
NODE_CLASS_MAPPINGS.update(_UPSTREAM_V59)
NODE_DISPLAY_NAME_MAPPINGS.update(_UPSTREAM_LABELS_V59)

# V10.60 — actual per-frame tracked inpaint masks, independent of FilmMaker.
from .retouch_motion_mask_v60 import NODE_CLASS_MAPPINGS as _V60_CLASSES, NODE_DISPLAY_NAME_MAPPINGS as _V60_NAMES
NODE_CLASS_MAPPINGS.update(_V60_CLASSES)
NODE_DISPLAY_NAME_MAPPINGS.update(_V60_NAMES)

# V10.62 - actual Roycho -> MVEx mask nodes (upstream MVEx installed separately).
from .retouch_roycho_mvex_v62 import (
    NODE_CLASS_MAPPINGS as _ROYCHO_V62, NODE_DISPLAY_NAME_MAPPINGS as _ROYCHO_V62_NAMES)
NODE_CLASS_MAPPINGS.update(_ROYCHO_V62)
NODE_DISPLAY_NAME_MAPPINGS.update(_ROYCHO_V62_NAMES)

from .retouch_roycho_guide_v64 import NODE_CLASS_MAPPINGS as GUIDE64_CLASSES, NODE_DISPLAY_NAME_MAPPINGS as GUIDE64_NAMES
NODE_CLASS_MAPPINGS.update(GUIDE64_CLASSES)
NODE_DISPLAY_NAME_MAPPINGS.update(GUIDE64_NAMES)
