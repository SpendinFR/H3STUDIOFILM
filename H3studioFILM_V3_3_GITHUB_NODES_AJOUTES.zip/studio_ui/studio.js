const $=id=>document.getElementById(id);let state={},project={},selected='',kind='hd',projectName='',lastQuery='',lastReview='',lastGate='',followLive=true;
const escapeHTML=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function request(url,data){let r=await fetch(url,{method:data===undefined?'GET':'POST',headers:{'Content-Type':'application/json'},body:data===undefined?undefined:JSON.stringify(data)});let x=await r.json();if(!r.ok)throw Error(x.error||r.status);return x;}
function toast(x){$('toast').textContent=x;$('toast').classList.remove('hidden');setTimeout(()=>$('toast').classList.add('hidden'),4500)}
function showModal(id){$(id).classList.remove('hidden')}function hideModal(id){$(id).classList.add('hidden')}
function changeView(id){['workspace','story','library','activity','retouches'].forEach(x=>$(x).classList.toggle('hidden',x!==id));document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x.dataset.view===id));if(id==='library')loadRefs();if(id==='retouches'&&window.retouchOnOpen)window.retouchOnOpen();}
for(const b of document.querySelectorAll('.tab'))b.onclick=()=>changeView(b.dataset.view);
// V10.8: projects are a topbar popover, not a third grid cell or floating sidebar.
function setProjectsMenu(open){
 const menu=$('projectsMenu'),btn=$('projectsMenuBtn');
 menu.classList.toggle('hidden',!open);btn.setAttribute('aria-expanded',String(open));
}
$('projectsMenuBtn').onclick=()=>setProjectsMenu($('projectsMenu').classList.contains('hidden'));
document.addEventListener('click',e=>{if(!e.target.closest('.projectMenuWrapper'))setProjectsMenu(false)});
document.addEventListener('keydown',e=>{if(e.key==='Escape')setProjectsMenu(false)});
for(const b of document.querySelectorAll('[data-close]'))b.onclick=()=>hideModal(b.dataset.close);
$('newProject').onclick=()=>{showModal('createModal');loadModels();loadAvailableLoras()};$('refresh').onclick=refresh;$('openLogs').onclick=()=>changeView('activity');
// Optional H3 LoRA selections; no effect on H3 graphs unless explicitly enabled.
let availableLoras=[];
let loraNotice='';
async function loadAvailableLoras(){
 try{const result=await request('/api/loras');availableLoras=result.loras||[];loraNotice=result.ok?'':(result.error||'ComfyUI indisponible');}
 catch(e){availableLoras=[];loraNotice=e.message;}
 for(const id of ['filmLoraItems','clipLoraItems']){
  const box=$(id);if(box&&box.children.length)for(const sel of box.querySelectorAll('select')){
    const previous=sel.value;sel.innerHTML=loraOptions();if(availableLoras.includes(previous))sel.value=previous;
  }
 }
}
function loraOptions(){return '<option value="">Choisir une LoRA disponible…</option>'+availableLoras.map(n=>`<option value="${escapeHTML(n)}">${escapeHTML(n)}</option>`).join('')}
function addLoraRow(container, name='',strength=1){
 const root=$(container);if(!root)return;
 if(root.querySelectorAll('.loraRow').length>=12){toast('Maximum 12 LoRA');return}
 const row=document.createElement('div');row.className='loraRow';
 row.innerHTML=`<select aria-label="Modèle LoRA">${loraOptions()}</select><input class="loraStrength" aria-label="Force LoRA" type="number" min="0" max="2" step="0.05" value="${Number(strength)}"><button type="button" aria-label="Retirer la LoRA">×</button>`;
 const sel=row.querySelector('select');if(availableLoras.includes(name))sel.value=name;
 row.querySelector('button').onclick=()=>row.remove();root.appendChild(row);
}
function selectedLoras(enabledId,listId){
 if(!$(enabledId)?.checked)return [];
 const rows=[...$(listId).querySelectorAll('.loraRow')];
 if(!rows.length)throw Error('Active une LoRA puis choisis au moins un modèle, ou désactive le bouton.');
 const selected=rows.map(row=>({name:row.querySelector('select').value,strength:Number(row.querySelector('.loraStrength').value)}));
 for(const l of selected){if(!l.name)throw Error(loraNotice||'Choisis une LoRA disponible dans ComfyUI.');if(!Number.isFinite(l.strength)||l.strength<0||l.strength>2)throw Error('Force LoRA comprise entre 0 et 2.');}
 if(new Set(selected.map(x=>x.name)).size!==selected.length)throw Error('LoRA sélectionnée plusieurs fois.');
 return selected;
}
function initLoraPicker(toggleId,panelId,itemsId,addId,initial=[]){
 const checkbox=$(toggleId),panel=$(panelId),items=$(itemsId);if(!checkbox||!panel||!items)return;
 items.innerHTML='';checkbox.checked=Array.isArray(initial)&&initial.length>0;
 checkbox.onchange=()=>{panel.classList.toggle('hidden',!checkbox.checked);if(checkbox.checked&&!items.children.length)addLoraRow(itemsId);};
 $(addId).onclick=()=>addLoraRow(itemsId);
 for(const l of initial)addLoraRow(itemsId,l.name,l.strength);
 checkbox.onchange();
}
initLoraPicker('filmLoraEnabled','filmLoraPanel','filmLoraItems','filmAddLora');
void loadAvailableLoras();

$('startFilm').onclick=async()=>{try{const data={title:$('filmName').value,prompt:$('brief').value,details:$('details').value,style:$('style').value,duration:$('duration').value,director:$('director').value,mode:$('mode').value,content_type:$('contentType').value,orientation:$('orientation').value,loras:selectedLoras('filmLoraEnabled','filmLoraItems'),models:{content:$('modelContent').value,scene:$('modelScene').value,plan:$('modelPlan').value,clip:$('modelClip').value},reviews:{brief:false,scenes:$('reviewScenes').checked,plans:$('reviewPlans').checked,clips:$('reviewClips').checked,raw:$('reviewRaw').checked}};const x=await request('/api/start',data);hideModal('createModal');setProjectsMenu(false);followLive=true;awaitingNewProject=true;newProjectDraftTitle=data.title||'Nouveau film';projectName='';selected='';project={};timelineSignature='';storySignature='';historySource='';liveRefsSignature='';clearLatestFinal();$('projectTitle').textContent=data.title||'Nouveau film';$('projectDesc').textContent='Création en cours…';$('clipStat').textContent='0 clip';$('sceneStat').textContent='0 scène';$('currentClipLabel').textContent='En attente du premier clip';$('currentPrompt').textContent='Film en préparation…';$('currentRefs').innerHTML='<p class="muted">Les références apparaîtront pendant la production.</p>';$('timeline').innerHTML='<div class="timelineEmpty">Nouveau film en cours de création.</div>';$('questionArea').dataset.token='';changeView('workspace');window.scrollTo({top:0,behavior:'instant'});toast('Production créée : '+x.session);await refresh();}catch(e){toast(e.message)}};
$('pauseBtn').onclick=async()=>{try{toast((await request('/api/pause',{})).message)}catch(e){toast(e.message)}};
$('resumeBtn').onclick=async()=>{try{await request('/api/resume',{});toast('Pause levée — production reprise')}catch(e){toast(e.message)}};
$('suspendBtn').onclick=async()=>{try{toast((await request('/api/suspend',{})).message)}catch(e){toast(e.message)}};
async function stopCurrentFilm(){
 if(!confirm('ARRÊT GLOBAL : tous les processus llama-server et Ollama seront arrêtés, le rendu ComfyUI interrompu et toute sa file d’attente vidée. Les clips validés restent conservés. Continuer ?'))return;
 try{const x=await request('/api/status');if(!x.running && x.older_running?.length){await stopLegacySession(x.older_running[0].pid);return;}toast((await request('/api/stop',{})).message);await refresh()}catch(e){toast(e.message)}
}
async function stopLegacySession(pid){
 if(!confirm(`Arrêter l'ancien moteur FilmMaker (PID ${pid}), tous les llama-server/Ollama et vider intégralement la queue ComfyUI ?`))return;
 try{const x=await request('/api/stop-older',{pid});toast(x.message);await refresh();}catch(e){toast(e.message)}
}
$('stopRenderBtn').onclick=stopCurrentFilm;
$('resumeProjectBtn').onclick=async()=>{if(!projectName){toast('Sélectionne le projet à reprendre');return}try{const x=await request('/api/restart-project',{project:projectName});followLive=true;toast('Reprise du projet : '+x.project);refresh()}catch(e){toast(e.message)}};
$('followLiveBtn').onclick=()=>{followLive=true;toast('Retour au clip en cours');refresh()};
const openRetouchRaw=async()=>{
 if(!projectName||!selected)return toast('Choisis un clip RAW pour le retoucher.');
 if(!window.retouchOpenProjectRaw)return toast('Retouches indisponibles.');
 try{await window.retouchOpenProjectRaw(projectName,selected);}catch(e){toast(e.message)}
};
$('retouchSelectedRaw').onclick=openRetouchRaw;
window.retouchReturnToDirection=function(record){
 changeView('workspace');
 const box=$('retouchApprovedInDirection'),v=$('retouchApprovedPlayer'),msg=$('retouchApprovedMessage');
 if(box&&v&&record.saved_url){
  box.classList.remove('hidden');v.src=record.saved_url;v.load();
  msg.textContent=record.returned_to_film?'Retouche du clip '+record.clip+' transmise à Direction : refine HD en préparation.':'Version retouchée sauvegardée pour clip '+record.clip+'. Le RAW latent original reste intact.';
 }
 toast(record.returned_to_film?'Retouche validée : Direction reprend le HD et le film.':'Version retouchée validée et sauvegardée. Retour à Direction.');
};
$('showRaw').onclick=()=>{kind='raw';updateVideo()};$('showHD').onclick=()=>{kind='hd';updateVideo()};
$('reviseClip').onclick=()=>{if(!selected){toast('Sélectionnez un clip');return} $('revisionTitle').textContent='Modifier le clip '+selected;showModal('reviseModal')};
$('saveRevision').onclick=async()=>{try{let x=await request('/api/revision',{project:projectName,clip:Number(selected),feedback:$('revisionFeedback').value});hideModal('reviseModal');toast(x.message);$('revisionFeedback').value='';await getProject();}catch(e){toast(e.message)}};
function pathFromClip(item){return kind==='raw'?item.raw_url:item.url}
let videoRetry=null,videoAttempts=0;
function loadVideoSource(src,force=false){
 const v=$('video');if(!src)return;
 if(v.dataset.source!==src){v.dataset.source=src;videoAttempts=0;clearTimeout(videoRetry);force=true;}
 if(force){v.pause();v.src=src+(src.includes('?')?'&':'?')+'load='+Date.now();v.load()}
 $('emptyVideo').classList.add('hidden');
}
$('video').addEventListener('loadedmetadata',()=>{clearTimeout(videoRetry);videoAttempts=0;});
$('video').addEventListener('error',()=>{
 const v=$('video'),src=v.dataset.source;if(!src)return;
 if(videoAttempts>=8){$('viewerChip').textContent='RAW/HD illisible — codec ou fichier';toast('Vidéo indisponible : utilise le bouton Voir RAW/HD pour réessayer.');return;}
 const current=src;const delay=Math.min(8000,1300*(1+videoAttempts++));clearTimeout(videoRetry);
 videoRetry=setTimeout(()=>{if($('video').dataset.source===current)loadVideoSource(current,true)},delay);
});
function updateVideo(){const item=(project.clips||{})[selected];$('showRaw').classList.toggle('selected',kind==='raw');$('showHD').classList.toggle('selected',kind==='hd');let src=item?pathFromClip(item):'';let v=$('video');if(src){loadVideoSource(src,true)}else{clearTimeout(videoRetry);v.pause();v.dataset.source='';v.removeAttribute('src');v.load();$('emptyVideo').classList.remove('hidden')} $('viewerChip').textContent=kind==='raw'?(project.project_info?.orientation==='portrait'?'RAW • 640×1152':'RAW • 1152×640'):(project.project_info?.orientation==='portrait'?'HD • 1080×1920':'HD • 1920×1080');} 
function pickClip(id,auto=false){if(!auto)followLive=false;selected=id;const item=(project.clips||{})[id];if(!item)return;$('selectedTitle').textContent=`Clip ${id} · Scène ${item.scene||'—'}`;$('selectedInfo').textContent=`Plan ${item.plan||'—'} · ${item.mc?'Motion Context 22':'Premier clip'} · ${item.refs.length} refs · ${item.voices.length} audio`;$('clipNum').textContent=id;$('clipState').textContent='Rendu disponible';$('clipPrompt').textContent='Chargement du prompt…';$('checkpointLine').textContent=`RAW .pt ${item.raw_pt_present?'sauvegardé ✓':'absent'} · HD archive(s): ${(item.hd_pt_archives||[]).length}`;
  $('clipRefs').innerHTML=item.refs_url.map((u,i)=>u?`<img src="${escapeHTML(u)}" title="Picture ${i+1}" loading="lazy">`:'').join('')+item.voices_url.map((u,i)=>u?`<audio controls src="${escapeHTML(u)}"></audio>`:'').join('');if(!$('clipRefs').innerHTML)$('clipRefs').innerHTML='<p class="muted">Sans référence</p>';kind='hd';updateVideo();drawTimeline();const info=project.prompt_records?.[id];if(info)$('clipPrompt').textContent=info.h3_prompt_sent||'(vide)';else $('clipPrompt').textContent='Voir projet / prompts pour la description complète.';
 }
let timelineSignature='',storySignature='',projectListSignature='',liveRefsSignature='',awaitingNewProject=false,newProjectDraftTitle='';
function drawTimeline(){const clips=Object.entries(project.clips||{}).sort((a,b)=>+a[0]-+b[0]);let revisions=project.pending_revisions?.items||[];const stableSignature=JSON.stringify([projectName,selected,clips.map(([id,c])=>[id,c.thumb_url,c.scene,c.plan]),revisions.map(r=>r.invalidates_from)]);if(timelineSignature===stableSignature)return;timelineSignature=stableSignature;let dirtyFrom=revisions.length?Math.min(...revisions.map(r=>+r.invalidates_from).filter(n=>n>0)):Infinity;$('timelineCount').textContent=clips.length+' élément(s)';$('clipStat').textContent=clips.length+' clip'+(clips.length>1?'s':'');$('sceneStat').textContent=((project.scenes||{}).scenes||[]).length+' scène(s)';$('timeline').innerHTML=clips.length?clips.map(([id,clip])=>`<button class="clipCard ${id===selected?'active':''}" data-clip="${escapeHTML(id)}"><div class="clipThumb">${clip.thumb_url?`<img loading="lazy" src="${escapeHTML(clip.thumb_url)}" style="width:100%;height:100%;object-fit:cover">`:'▣'}</div><div class="clipMeta"><b>CLIP ${id}</b><small style="color:${+id>=dirtyFrom?'#f0bf7f':'#7fd8b0'}">${+id>=dirtyFrom?'À revérifier':'HD ✓'}</small></div></button>`).join(''):'<div class="timelineEmpty">Les clips apparaîtront ici une fois générés.</div>';for(let b of $('timeline').querySelectorAll('[data-clip]'))b.onclick=()=>pickClip(b.dataset.clip);}
function drawStory(){const scenes=((project.scenes||{}).scenes||[]);const key=JSON.stringify([projectName,scenes]);if(storySignature===key)return;storySignature=key;$('storyBody').innerHTML=scenes.length?scenes.map(sc=>`<details class="sceneCard"><summary>SCÈNE ${escapeHTML(sc.scene)} — ${escapeHTML(sc.title||sc.name||sc.location||'Sans titre')} · ${escapeHTML(sc.start)} → ${escapeHTML(sc.end)}</summary><p>${escapeHTML(sc.description||'')}</p><pre>${escapeHTML(sc.scene_logic||sc.final_state||'')}</pre></details>`).join(''):'Aucune scène encore créée.'}
// Latest cumulative FINAL only. Never replace the <video> element on a routine status refresh:
// doing so resets user playback and unnecessarily rerequests the growing MP4.
let latestFinalIdentity='';
function renderLatestFinal(){
 const items=Object.entries(project.clips||{}).filter(([number,item])=>item.final_url);
 items.sort((a,b)=>Number(a[0])-Number(b[0]));
 const last=items.length?items[items.length-1]:null;
 const identity=JSON.stringify([projectName,last?.[0]||'',last?.[1].final_url||'']);
 if(identity===latestFinalIdentity)return;
 latestFinalIdentity=identity;
 const player=$('latestFinalVideo');
 player.pause();
 if(!last){
   player.removeAttribute('src');player.load();
   $('latestFinalPlayerBox').classList.add('hidden');
   $('latestFinalEmpty').classList.remove('hidden');
   $('latestFinalInfo').textContent=project.name?'Ce film n’a pas encore de FINAL.':'En attente du premier clip FINAL validé.';
   return;
 }
 const [number, clip]=last;
 $('latestFinalPlayerBox').classList.remove('hidden');
 $('latestFinalEmpty').classList.add('hidden');
 $('latestFinalInfo').textContent=`Clip ${Number(number)} · montage cumulatif jusqu’à ce clip (un seul lecteur, toujours le plus récent)`;
 player.src=clip.final_url;player.load();
}
function clearLatestFinal(){
 latestFinalIdentity='';
 const player=$('latestFinalVideo');player.pause();player.removeAttribute('src');player.load();
 $('latestFinalPlayerBox').classList.add('hidden');$('latestFinalEmpty').classList.remove('hidden');
 $('latestFinalInfo').textContent='En attente du premier clip FINAL validé.';
}
function renderProject(){if(!project.name)return;const hasVisualContent=!!((state.active_clip?.clip && state.project?.name===projectName)||Object.keys(project.clips||{}).length);document.body.classList.toggle('preproduction', !hasVisualContent);$('projectTitle').textContent=project.project_info?.title||project.film?.title||project.name;$('projectDesc').textContent=project.film?.concept||project.name;drawTimeline();drawStory();renderProposalArchive();renderLatestFinal();if(selected && project.clips?.[selected]){const item=project.clips[selected];$('checkpointLine').textContent=`RAW .pt ${item.raw_pt_present?'sauvegardé ✓':'absent'} · HD archive(s): ${(item.hd_pt_archives||[]).length}`; }else{const keys=Object.keys(project.clips||{}).sort((a,b)=>+a-+b);if(keys.length)pickClip(keys[keys.length-1],true);}}
async function getProject(){const requested=projectName;if(!requested)return;try{const incoming=await request('/api/project?name='+encodeURIComponent(requested));if(requested!==projectName)return;const stamp=JSON.stringify(incoming);if(lastProjectName!==requested||lastProjectPayload!==stamp){lastProjectName=requested;lastProjectPayload=stamp;project=incoming;renderProject();}if(state && state.project)actionPanel(state);}catch(e){console.error(e)}}
async function loadRefs(){if(!projectName)return;try{const x=await request('/api/ref-images?name='+encodeURIComponent(projectName));$('gallery').innerHTML=x.length?x.map(f=>`<div class="refCard"><img loading="lazy" src="${escapeHTML(f.url)}"><p>${escapeHTML(f.name)}</p><small>${escapeHTML(f.group)}</small></div>`).join(''):'Aucune image de référence encore disponible.';}catch(e){toast(e.message)}}
function drawProjects(names){const key=JSON.stringify([projectName,names.map(p=>[p.name,p.title])]);if(projectListSignature===key)return;projectListSignature=key;$('projects').innerHTML=names.map(p=>`<button class="projectItem ${p.name===projectName?'active':''}" data-project="${escapeHTML(p.name)}" title="${escapeHTML(p.name)}">◈ ${escapeHTML(p.title||p.name)}</button>`).join('')||'<span class="muted">Aucun projet</span>';for(let b of $('projects').querySelectorAll('[data-project]'))b.onclick=()=>{followLive=false;projectName=b.dataset.project;selected='';project={};timelineSignature='';storySignature='';liveRefsSignature='';clearLatestFinal();setProjectsMenu(false);getProject();drawProjects(names);};}
function richInline(str){
 let safe=escapeHTML(String(str||''));
 safe=safe.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/__(.+?)__/g,'<strong>$1</strong>');
 return safe.replace(/(?<!\*)\*([^*]+?)\*(?!\*)/g,'<em>$1</em>');
}
function richText(source){
 const lines=String(source||'').replace(/<0xA0>/ig,' ').replace(/\r\n?/g,'\n').split('\n');
 let out=[],para=[],items=[];
 const flushP=()=>{if(para.length){out.push('<p>'+para.map(richInline).join('<br>')+'</p>');para=[]}};
 const flushList=()=>{if(items.length){out.push('<ul>'+items.map(s=>'<li>'+richInline(s)+'</li>').join('')+'</ul>');items=[]}};
 for(const line of lines){const s=line.trim();if(!s){flushP();flushList();continue}
  if(/^#{1,5}\s+/.test(s)){flushP();flushList();const level=Math.min(4,Math.max(2,(s.match(/^#+/)||['##'])[0].length-1));out.push(`<h${level}>`+richInline(s.replace(/^#+\s*/,''))+`</h${level}>`);continue}
  if(/^[-*•]\s+/.test(s)){flushP();items.push(s.replace(/^[-*•]\s+/,''));continue}
  if(/^\d+[.)]\s+/.test(s)){flushP();items.push(s.replace(/^\d+[.)]\s+/,''));continue}
  flushList();para.push(s);
 }
 flushP();flushList();return out.join('')||'<p class="muted">Aucun contenu fourni.</p>';
}
function structuredReview(kind,payload){
 const rows=kind==='scenes'?(payload?.scenes||[]):kind==='plans'?(payload?.plans||[]):[];
 if(!rows.length)return richText(payload?.text||'');
 const card=(x,i)=>{
  const isScene=kind==='scenes',head=isScene?`Scène ${x.scene||i+1}`:`Plan ${x.plan||i+1}`;
  const time=[x.start||'',x.end||''].filter(Boolean).join(' → ');
  const facts=isScene?[['Lieu',x.location],['Personnages',x.characters],['Situation initiale',x.initial_state],['Description',x.description],['Logique de scène',x.scene_logic],['Continuité',x.continuity_elements],['État final',x.final_state]]:[['État initial',x.start_state],['Vue / caméra',x.view],['Action',x.action],['Intention',x.purpose],['État final',x.end_state]];
  const detail=facts.filter(x=>x[1]).map(([label,value])=>`<div class="structuredFact"><strong>${escapeHTML(label)}</strong><p>${escapeHTML(typeof value==='string'?value:JSON.stringify(value))}</p></div>`).join('');
  let shots='';if(!isScene && Array.isArray(x.shots) && x.shots.length){shots=`<div class="structuredShots"><b>Découpage intérieur · ${x.shots.length} shot(s)</b>${x.shots.map((shot,j)=>`<p><strong>Shot ${j+1}</strong> ${escapeHTML(shot.view||shot.vue||'')} ${escapeHTML(shot.action||'')}</p>`).join('')}</div>`}
  return `<article class="structuredCard"><header><b>${escapeHTML(head)}</b><span>${escapeHTML(time)}</span></header>${detail}${shots}</article>`;
 };
 return `<div class="structuredReview"><div class="structuredCount">${rows.length} ${kind==='scenes'?'scène(s) proposées':'plan(s) proposés'}</div>${rows.map(card).join('')}<details class="originalOutput"><summary>Voir la proposition originale du Director</summary><div class="richReview">${richText(payload?.text||'')}</div></details></div>`;
}
function renderProposalArchive(){
 const rows=project.proposal_history||[],panel=$('pastProposals');
 panel.classList.toggle('hidden',!rows.length);
 $('proposalArchiveCount').textContent=rows.length?`(${rows.length})`:'';
 const key=JSON.stringify(rows.map(r=>r.name));
 if(panel.dataset.archiveKey===key)return;
 panel.dataset.archiveKey=key;
 $('proposalArchiveItems').innerHTML=rows.map((r,i)=>`<details class="proposalArchiveItem"><summary>Proposition ${i+1} · ${escapeHTML(r.name)}</summary><div class="richReview">${richText(r.text)}</div></details>`).join('');
}
// Stable live journal: preserve the event being read, not just its numeric scrollTop.
let historyLastSignature='',historySource='';
function historyPanel(data,source='active'){
 const stream=$('historyStream'),rows=(data.history||[]).slice(-35).reverse();
 if(historySource!==source){historySource=source;historyLastSignature='';stream.dataset.signature='';stream.replaceChildren();stream.scrollTop=0;}
 const signature=JSON.stringify(rows.map(r=>[r.at,r.title,r.detail,r.action]));
 if(historyLastSignature===signature)return;
 const oldEntries=[...stream.querySelectorAll('.historyEntry')];
 const oldAnchor=oldEntries.find(el=>el.getBoundingClientRect().bottom>stream.getBoundingClientRect().top+6);
 const anchorKey=oldAnchor?.dataset.eventKey;
 const anchorOffset=oldAnchor?oldAnchor.getBoundingClientRect().top-stream.getBoundingClientRect().top:0;
 const wasTop=stream.scrollTop<=12;
 // If the user is reading older events, do not force them to the latest event.
 historyLastSignature=signature;stream.dataset.signature=signature;
 stream.innerHTML=rows.length?rows.map((r,i)=>{
  const action=r.action;const status=action==='continue'?'Validé':action==='redo'?'Nouvelle proposition demandée':action==='revise'?'Modification demandée':action==='answered'?'Réponse envoyée':'';
  const icon=action==='continue'?'✓':action==='revise'?'✎':action==='redo'?'↻':'●';
  const stamp=r.at?new Date(r.at*1000).toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'}):'';
  const key=escapeHTML([r.at,r.title,r.action].join('|'));
  return `<div class="historyEntry" data-event-key="${key}"><div class="historyDot">${icon}</div><div><div class="historyTitle">${escapeHTML(r.title)}</div><div class="historyMeta">${escapeHTML(stamp)} ${status?'· '+escapeHTML(status):''}</div>${r.detail?`<p class="historyDetail">${escapeHTML(r.detail)}</p>`:''}</div></div>`;
 }).join(''):'<div class="emptyTimeline">Aucune étape enregistrée pour cette session.</div>';
 if(anchorKey && !wasTop){const match=[...stream.querySelectorAll('.historyEntry')].find(el=>el.dataset.eventKey===anchorKey);if(match)stream.scrollTop+=match.getBoundingClientRect().top-stream.getBoundingClientRect().top-anchorOffset;}
 // When at top the newest event remains visible, without scrolling the document.
 else if(wasTop)stream.scrollTop=0;
}

let clipDraft=null;
function visualType(ref){
 if(ref.media==='audio')return 'voice';
 if(ref.kind==='character')return 'person';
 if(ref.kind==='decor')return 'decor';
 if(ref.kind==='object')return 'object';
 return 'visual';
}
function buildClipDraft(r){
 const d=r.payload||{};
 // Old saved projects may carry an older generated prefix. They still take the
 // legacy preview route: never duplicate or silently replace their authority.
 const text=String(d.text||'');
 const matchedPrefix=typeof d.authority_prefix==='string' && (
   d.authority_prefix ? text.startsWith(d.authority_prefix) : !text.trimStart().startsWith('REFERENCE AUTHORITY —'));
 return {id:r.id,text,loras:Array.isArray(d.loras)?d.loras:[],originalPrefix:matchedPrefix?d.authority_prefix:null,previewPrefix:matchedPrefix?d.authority_prefix:null,previewNonce:0,authorityReady:matchedPrefix,initialized:matchedPrefix,bankDeletes:[],bankNames:[],refs:[...(d.refs||[]).map((x,i)=>({media:'image',index:i,name:x.subject_name||x.name||('Picture '+(i+1)),originalName:x.subject_name||x.name||('Picture '+(i+1)),kind:x.kind||'manual',role:x.role||'',subjectKey:x.subject_key||'',path:String(x.path||x.annotated||'').split(' [',1)[0],url:d.refs_url?.[i]||'',visualType:visualType({media:'image',kind:x.kind}),bankScope:'clip',bankTarget:'',editing:false})),...(d.audio_refs||[]).map((x,i)=>({media:'audio',index:i,name:x.subject_name||x.name||('Audio '+(i+1)),kind:'voice',role:'voice',audioUse:x.studio_audio_use||'voice',audioTarget:x.subject_name||'',url:d.voices_url?.[i]||'',editing:false}))]};
}
function nativeRoleLabel(r){
 if(r.media==='audio')return r.audioUse==='object_sound'?'Son d’objet':'Voix de personnage';
 if(r.kind==='character')return r.role==='film_appearance'?'Apparence de personnage':r.role==='canonical_identity'?'Identité canonique':'Personnage';
 if(r.kind==='decor'||r.kind==='global_environment')return 'Décor / environnement';
 if(r.kind==='object')return 'Objet récurrent';
 return 'Sujet visuel';
}
function refPayload(){
 return clipDraft.refs.map(r=>({media:r.media,...('index' in r?{index:r.index}:{path:r.path}),name:r.name,...(r.media==='image'?{visual_type:r.visualType,bank_scope:r.bankScope||'clip',bank_target:r.bankTarget||r.name}:{audio_use:r.audioUse||'voice',audio_target:r.audioTarget||r.name})}));
}
function creativeText(){
 if(!clipDraft?.authorityReady)throw Error('La protection REFERENCE AUTHORITY est encore en préparation. Attends la synchronisation.');
 return $('clipEditText')?.value||'';
}
function clipAuthorityControls(draft){
 if(!draft || clipDraft!==draft)return;
 const ready=!!draft.authorityReady;
 for(const id of ['approveReviewTop','approveReview']){
  const button=$(id);
  if(button){button.disabled=!ready;button.title=ready?'':(draft.authorityError||'Synchronisation des références en cours');}
 }
 const retry=$('retryClipAuthority');if(retry)retry.classList.toggle('hidden',!draft.authorityError);
 const authority=$('clipAuthorityText');
 if(authority && draft.authorityError)authority.textContent='Synchronisation indisponible : '+draft.authorityError;
 const hint=$('refAuthoritySync');
 if(hint && draft.authorityError){hint.textContent='⚠ '+draft.authorityError;hint.classList.add('refSyncError');}
}
function previewClipAuthority(){
 if(!clipDraft)return Promise.resolve();
 const draft=clipDraft,nonce=++draft.previewNonce;
 const body=$('clipEditText')?.value ?? String(draft.text||'');
 draft.authorityReady=false;draft.authorityError='';
 clipAuthorityControls(draft);
 const task=(async()=>{
  try{
   const result=await request('/api/reference-preview',{id:draft.id,body,refs:refPayload(),bank_deletes:draft.bankDeletes});
   if(clipDraft!==draft||nonce!==draft.previewNonce)return;
   if(draft.originalPrefix===null)draft.originalPrefix=result.original_prefix||'';
   draft.previewPrefix=result.prefix||'';
   draft.text=result.text;
   const originalBody = draft.originalPrefix && body.startsWith(draft.originalPrefix)
     ? body.slice(draft.originalPrefix.length).trimStart() : body;
   const editor=$('clipEditText');
   const liveText=editor?.value ?? body;
   // A slow authority preview must NEVER erase edits typed while it was pending.
   const liveBody = draft.originalPrefix && liveText.startsWith(draft.originalPrefix)
     ? liveText.slice(draft.originalPrefix.length).trimStart() : liveText;
   const nextBody=draft.initialized?liveText:(liveText!==body?liveBody:originalBody);
   draft.initialized=true;draft.authorityReady=true;
   if(Array.isArray(result.subjects)){let i=0;for(const ref of draft.refs){if(ref.media==='image'){ref.resolvedSubject=Number(result.subjects[i])||null;ref.resolvedName=result.resolved_names?.[i]||ref.name;i++;}}}
   renderClipRefEditor();
   if(editor)editor.value=nextBody;
   const authority=$('clipAuthorityText');if(authority)authority.textContent=draft.previewPrefix||'Aucune référence attachée à ce clip.';
   const hint=$('refAuthoritySync');if(hint){hint.textContent='✓ Bloc Picture / Subject / Audio synchronisé avec les références';hint.classList.remove('refSyncError');}
   clipAuthorityControls(draft);
  }catch(err){
   if(clipDraft===draft && nonce===draft.previewNonce){
    draft.authorityReady=false;draft.authorityError=String(err?.message||err);
    clipAuthorityControls(draft);
   }
   throw err;
  }
 })();
 draft.pendingPreview=task;
 return task;
}
async function ensureClipAuthorityReady(){
 // Last reference edit wins. Validation must not race the current async preview.
 for(let attempts=0;attempts<4;attempts++){
  const draft=clipDraft;
  if(!draft)throw Error('Clip Director : éditeur de références absent');
  if(draft.authorityReady)return;
  if(draft.pendingPreview){
   try{await draft.pendingPreview}catch(err){throw Error('Synchronisation des références échouée : '+err.message+'. Clique sur Réessayer.');}
  }else{
   await previewClipAuthority();
  }
  if(clipDraft===draft && draft.authorityReady)return;
 }
 throw Error('Les références ont changé pendant la validation : réessaie une fois la synchronisation terminée.');
}
async function updateReferences(){
 renderClipRefEditor();
 try{await previewClipAuthority()}catch(err){toast('Références : '+err.message);}
}
function renderClipRefEditor(){
 const list=$('clipEditRefs');if(!list||!clipDraft)return;
 const images=clipDraft.refs.filter(r=>r.media==='image'),audios=clipDraft.refs.filter(r=>r.media==='audio');
 const subjectKeys=new Map();let subject=0;
 for(const ref of images){
  const normalized=ref.name.normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,'');
  const key=ref.kind==='manual'||ref.name!==ref.originalName?'studio_'+normalized:(ref.subjectKey||'ref_'+images.indexOf(ref));
  if(!subjectKeys.has(key))subjectKeys.set(key,++subject);
  ref.displaySubject=Number.isInteger(ref.resolvedSubject)?ref.resolvedSubject:subjectKeys.get(key);
 }
 list.innerHTML=clipDraft.refs.map((r,i)=>{
  const no=r.media==='image'?images.indexOf(r)+1:audios.indexOf(r)+1;
  const label=r.media==='image'?`PICTURE ${no} · SUBJECT ${r.displaySubject}`:`AUDIO ${no}`;
  const canChangeType=r.media==='image'&&r.kind==='manual';
  const option=(value,text)=>`<option value="${value}" ${r.visualType===value?'selected':''}>${text}</option>`;
  const bankOption=r.media==='image'&&r.role!=='canonical_identity'?`<label>Portée de la correction<select class="refBankScope" data-ri="${i}"><option value="clip" ${r.bankScope!=='bank'?'selected':''}>Ce clip uniquement</option><option value="bank" ${r.bankScope==='bank'?'selected':''}>Ce clip + corriger RefBank pour les futurs clips</option></select></label><small class="refProtectedRole">Une correction RefBank ne supprime pas les images des anciens clips.</small>`:'';
  const charNames=[...new Set([...(clipDraft.bankNames||[]),...images.filter(x=>x.kind==='character'||x.visualType==='person').map(x=>x.name)].filter(Boolean))];
  const objectNames=[...new Set(images.filter(x=>x.kind==='object'||(x.kind==='manual'&&x.visualType==='object')).map(x=>x.name).filter(Boolean))];
  const targets=r.media==='image' && (r.kind==='manual'||(r.kind==='character'&&r.role!=='canonical_identity'))?`<label>Rattacher à un personnage existant (nécessaire pour « Apparence »)<select class="refBankTarget" data-ri="${i}"><option value="">Choisir un personnage existant…</option>${charNames.map(n=>`<option value="${escapeHTML(n)}" ${r.bankTarget===n?'selected':''}>${escapeHTML(n)}</option>`).join('')}</select></label>`:'';
  const audioTargets=r.media==='audio'?`<label>Référence audio pour<select class="refAudioUse" data-ri="${i}"><option value="voice" ${r.audioUse!=='object_sound'?'selected':''}>Voix d’un personnage</option><option value="object_sound" ${r.audioUse==='object_sound'?'selected':''}>Son d’un objet</option></select></label><label>Rattacher à un personnage / objet existant (facultatif)<select class="refAudioTarget" data-ri="${i}"><option value="">Utiliser le nom saisi</option>${[...new Set([...charNames,...objectNames])].map(n=>`<option value="${escapeHTML(n)}" ${r.audioTarget===n?'selected':''}>${escapeHTML(n)}</option>`).join('')}</select></label>`:'';
  const fields=r.editing?`<div class="refEditForm"><label>Nom du sujet<input class="refNameInput" data-ri="${i}" value="${escapeHTML(r.name)}" maxlength="90"></label>${canChangeType?`<label>Rôle de la référence<select class="refTypeInput" data-ri="${i}">${option('person','Personnage / identité')}${option('appearance','Apparence d’un personnage existant')}${option('decor','Décor / lieu')}${option('object','Objet récurrent')}${option('visual','Sujet visuel')}</select></label>`:`<small class="refProtectedRole">${escapeHTML(nativeRoleLabel(r))} · identité/autorité préservée</small>`}${targets}${audioTargets}${bankOption}<div class="refEditFormActions"><button type="button" class="refSave" data-ri="${i}">✓ Enregistrer</button><button type="button" class="refCancel" data-ri="${i}">Annuler</button></div></div>`:
  `<div class="refNameLabel">${escapeHTML(r.name)}</div><div class="refRoleLabel">${escapeHTML(canChangeType?{person:'Personnage',appearance:'Apparence de personnage',decor:'Décor / lieu',object:'Objet récurrent',visual:'Sujet visuel'}[r.visualType]||'Sujet visuel':nativeRoleLabel(r))}${canChangeType?'':' · protégé'}</div>`;
  return `<article class="clipEditRef ${r.editing?'refIsEditing':''}" data-ri="${i}"><div class="clipEditPreview">${r.media==='image'?(r.url?`<img loading="lazy" src="${escapeHTML(r.url)}" alt="Picture ${no}">`:'▣'):(r.url?`<audio controls preload="none" src="${escapeHTML(r.url)}"></audio>`:'♫')}</div><div class="refEditFields"><small>${label}</small>${fields}</div><div class="refEditControls"><button type="button" class="refPencil" data-ri="${i}" aria-label="Modifier ${label}" title="Modifier le nom et le rôle">✎</button><button type="button" class="refRemove" data-ri="${i}" aria-label="Retirer ${label}" title="Retirer du clip">×</button></div></article>`;
 }).join('')||'<div class="muted">Aucune référence pour ce clip.</div>';
 list.querySelectorAll('.refPencil').forEach(el=>el.onclick=()=>{clipDraft.refs[+el.dataset.ri].editing=!clipDraft.refs[+el.dataset.ri].editing;renderClipRefEditor();});
 list.querySelectorAll('.refCancel').forEach(el=>el.onclick=()=>{clipDraft.refs[+el.dataset.ri].editing=false;renderClipRefEditor();});
 list.querySelectorAll('.refSave').forEach(el=>el.onclick=async()=>{
  const i=+el.dataset.ri,r=clipDraft.refs[i],card=el.closest('.clipEditRef');
  const name=card.querySelector('.refNameInput')?.value.trim();if(!name){toast('Indique le nom de la référence');return;}
  const proposedType=r.kind==='manual'?card.querySelector('.refTypeInput')?.value||'visual':r.visualType;
  const selectedPerson=card.querySelector('.refBankTarget')?.value||'';
  if(r.media==='image'&&r.kind==='manual'&&proposedType==='appearance'&&!selectedPerson){toast('Pour une apparence, choisis un personnage existant.');return;}
  r.name=name;
  if(r.kind==='manual')r.visualType=proposedType;
  r.bankScope=card.querySelector('.refBankScope')?.value||'clip';
  r.bankTarget=selectedPerson||name;
  if(selectedPerson&&(r.kind==='character'||r.visualType==='appearance'))r.name=selectedPerson;
  if(r.media==='audio'){
    r.audioUse=card.querySelector('.refAudioUse')?.value||'voice';
    r.audioTarget=card.querySelector('.refAudioTarget')?.value||name;
    if(r.audioTarget!==name)r.name=r.audioTarget;
  }
  r.editing=false;
  await updateReferences();
 });
 list.querySelectorAll('.refRemove').forEach(el=>el.onclick=async()=>{
  const r=clipDraft.refs[+el.dataset.ri];
  if(r.bankScope==='bank'&&r.media==='image'){
   if(r.role==='canonical_identity'){toast('Identité canonique protégée : suppression RefBank impossible');return}
   if(!confirm('Supprimer cette référence de la RefBank pour les futurs clips ? Les anciens fichiers vidéo et images ne seront pas effacés.'))return;
   if(Number.isInteger(r.index))clipDraft.bankDeletes.push(r.index);
  }
  clipDraft.refs.splice(+el.dataset.ri,1);await updateReferences();
 });
 $('clipRefCount').textContent=images.length+'/8 images · '+audios.length+' audio';
}
async function chooseBankImage(){
 if(!projectName){toast('Choisis un projet');return}
 const box=$('clipBankPicker');if(!box)return;
 if(!box.classList.contains('hidden')){box.classList.add('hidden');return}
 const rows=await request('/api/ref-images?name='+encodeURIComponent(projectName));
 const valid=(rows||[]).filter(r=>r.url?.startsWith('/media/input/')&&r.path);
 box.innerHTML=valid.length?valid.map((r,i)=>`<button class="bankPick" data-bank="${i}" title="${escapeHTML(r.name)}"><img loading="lazy" src="${escapeHTML(r.url)}"><small>${escapeHTML(r.name)}</small></button>`).join(''):'<p class="muted">Pas de référence prête dans la RefBank du projet.</p>';
 valid.forEach((r,i)=>{const b=box.querySelector(`[data-bank="${i}"]`);if(b)b.onclick=async()=>{
  if(clipDraft.refs.filter(x=>x.media==='image').length>=8){toast('8 images maximum');return}
  clipDraft.refs.push({media:'image',path:r.path,url:r.url,name:r.name.replace(/\.[^.]+$/,''),kind:'manual',visualType:'visual',bankScope:'clip',editing:true});box.classList.add('hidden');await updateReferences();
 }});
 box.classList.remove('hidden');
}
async function importClipRef(file,media){
 if(!file||!clipDraft)return;
 if(media==='image'&&clipDraft.refs.filter(x=>x.media==='image').length>=8)throw Error('H3 accepte 8 images maximum');
 const result=await fetch('/api/upload',{method:'POST',headers:{'X-Filename':file.name,'Content-Type':'application/octet-stream'},body:file});
 const info=await result.json();if(!result.ok)throw Error(info.error||'Import impossible');
 clipDraft.refs.push({media,path:info.path,url:info.url,name:file.name.replace(/\.[^.]+$/,''),kind:media==='audio'?'voice':'manual',visualType:'visual',bankScope:'clip',editing:true});await updateReferences();
}
function wireClipEditor(r){
 if(!r||r.kind!=='clips')return;
  clipDraft=buildClipDraft(r);
  request('/api/bank-characters',{project:projectName}).then(x=>{
    if(clipDraft?.id!==r.id)return;
    clipDraft.bankNames=x.names||[];
    // Update choices in place while a form is open: never wipe typed values.
    const open=$('clipEditRefs')?.querySelectorAll('.refBankTarget, .refAudioTarget')||[];
    if(!open.length){renderClipRefEditor();return;}
    for(const select of open){
     const previous=select.value,choices=[...new Set([...(clipDraft.bankNames||[]),...clipDraft.refs.filter(y=>y.media==='image'&&(y.kind==='character'||y.visualType==='person')).map(y=>y.name)].filter(Boolean))];
     const audio=select.classList.contains('refAudioTarget');
     const options=audio?[...new Set([...choices,...clipDraft.refs.filter(y=>y.visualType==='object'||y.kind==='object').map(y=>y.name)])]:choices;
     select.innerHTML=`<option value="">${audio?'Utiliser le nom saisi':'Choisir un personnage existant…'}</option>`+options.map(n=>`<option value="${escapeHTML(n)}">${escapeHTML(n)}</option>`).join('');
     if(options.includes(previous))select.value=previous;
    }
  }).catch(()=>{});
 initLoraPicker('clipLoraEnabled','clipLoraPanel','clipLoraItems','clipAddLora',clipDraft.loras);
 void loadAvailableLoras();
 $('clipEditText').oninput=()=>{clipDraft.text=$('clipEditText').value};
 $('chooseBankRef').onclick=()=>chooseBankImage().catch(e=>toast(e.message));
 $('openKreaClip').onclick=()=>openKreaClip();
 renderClipRefEditor();
 if($('retryClipAuthority'))$('retryClipAuthority').onclick=()=>previewClipAuthority().catch(e=>toast('Références : '+e.message));
 // V10.29: native runtime authority already accompanies the checkpoint.
 // DO NOT make an asynchronous browser round-trip when references are untouched.
 // Preserve the old API preview ONLY for a ref edit or an older checkpoint.
 if(clipDraft.authorityReady){
  const authority=$('clipAuthorityText');
  if(authority)authority.textContent=clipDraft.previewPrefix||'Aucune référence attachée à ce clip.';
  const editor=$('clipEditText');
  if(editor && clipDraft.originalPrefix && editor.value.startsWith(clipDraft.originalPrefix)){
   editor.value=editor.value.slice(clipDraft.originalPrefix.length).trimStart();
  }
  const hint=$('refAuthoritySync');
  if(hint){hint.textContent='✓ Bloc Picture / Subject / Audio initialisé par le moteur';hint.classList.remove('refSyncError');}
  clipAuthorityControls(clipDraft);
 }else{
  previewClipAuthority().catch(e=>toast('Prévisualisation refs : '+e.message));
 }
 for(const [id,media] of [['addClipImage','image'],['addClipAudio','audio']]){
  const input=$(id);input.onchange=async()=>{try{await importClipRef(input.files?.[0],media);toast('Référence ajoutée au clip')}catch(e){toast(e.message)}finally{input.value=''}};
 }
}
function setKreaSourceOptions(entries, preferred=''){
 const selector=$('kreaClipSource');if(!selector)return;
 const seen=new Set(),valid=[];
 for(const r of entries){
  if(!r.path||seen.has(r.path))continue;
  seen.add(r.path);valid.push(r);
 }
 selector.innerHTML=valid.length?valid.map(r=>`<option value="${escapeHTML(r.path)}">${escapeHTML(r.name||'Image de référence')}${r.group?' · '+escapeHTML(r.group):''}</option>`).join(''):
   '<option value="">Aucune image disponible — sélectionne RefBank ou importe une image</option>';
 if(valid.some(r=>r.path===preferred))selector.value=preferred;
 const chosen=valid.find(r=>r.path===selector.value);
 const preview=$('kreaSourcePreview');
 if(preview){preview.src=chosen?.url||'';preview.classList.toggle('hidden',!chosen?.url)}
 return valid;
}
function kreaClipSources(){
 return (clipDraft?.refs||[]).filter(r=>r.media==='image'&&r.path).map((r,i)=>({
  path:r.path,url:r.url,name:`${r.name||'Picture'} (clip ${i+1})`,group:'clip'
 }));
}
async function loadKreaBankSources(){
 if(!projectName)return;
 const draft=clipDraft,selector=$('kreaClipSource');
 try{
  const rows=await request('/api/ref-images?name='+encodeURIComponent(projectName));
  if(clipDraft!==draft||$('kreaClipModal').classList.contains('hidden'))return;
  const existing=kreaClipSources();
  const bank=(Array.isArray(rows)?rows:[]).filter(r=>r.path&&r.url?.startsWith('/media/'));
  const previous=selector.value;
  kreaSourceItems=[...kreaSourceItems.filter(r=>r.group==='import'),...bank];
  const all=setKreaSourceOptions([...existing,...kreaSourceItems],previous);
  $('kreaSourceHint').textContent=all.length?`${all.length} image(s) disponibles : clip et RefBank.`:'Aucune image existante. Importe une source ci-dessous.';
 }catch(e){$('kreaSourceHint').textContent='RefBank inaccessible : '+e.message}
}
function openKreaClip(){
 if(!clipDraft)return;
 kreaSourceItems=[];
 // Source Krea is not an H3 Picture input: it must remain selectable even
 // when 8 H3 Pictures are already attached to the clip.
 const refs=kreaClipSources();
 setKreaSourceOptions(refs,refs[0]?.path||'');
 $('kreaClipMode').value='style';
 $('kreaClipMode').onchange=()=>{$('kreaSourceRow').classList.toggle('hidden',$('kreaClipMode').value==='text')};
 $('kreaClipMode').onchange();
 $('kreaClipName').value=clipDraft.refs.find(r=>r.media==='image')?.name||'';
 resetKreaPreview();
 $('kreaClipStatus').textContent='';
 $('kreaSourceHint').textContent='Recherche des références du projet…';
 resetKreaPreview();
 showModal('kreaClipModal');
 void loadKreaBankSources();
}
$('kreaClipSource').onchange=()=>{
 const choice=$('kreaClipSource').selectedOptions[0];
 const preview=$('kreaSourcePreview');
 const bank=[...kreaClipSources(),...kreaSourceItems];
 const selected=bank.find(x=>x.path===$('kreaClipSource').value);
 if(preview){preview.src=selected?.url||'';preview.classList.toggle('hidden',!selected?.url)}
};
let kreaSourceItems=[];
$('kreaImportSource').onchange=async e=>{
 const file=e.target.files?.[0];if(!file)return;
 try{
  if(!file.type.startsWith('image/'))throw Error('Choisis une image PNG, JPEG ou WebP');
  $('kreaSourceHint').textContent='Importation de la source…';
  const response=await fetch('/api/upload',{method:'POST',headers:{'X-Filename':file.name,'Content-Type':'application/octet-stream'},body:file});
  const item=await response.json();if(!response.ok)throw Error(item.error||'Import impossible');
  // Independent of clip Pictures: the source is ONLY for the Krea img2img pass.
  kreaSourceItems.push({name:file.name,path:item.path,url:item.url,group:'import'});
  const selected=item.path;
  setKreaSourceOptions([...kreaClipSources(),...kreaSourceItems],selected);
  await loadKreaBankSources();
  $('kreaSourceHint').textContent='Image importée pour Krea. Elle ne remplace aucune référence H3.';
 }catch(err){$('kreaSourceHint').textContent='Import : '+err.message}
 finally{e.target.value=''}
};
let kreaPreview=null;
let kreaLastRequest=null;
function resetKreaPreview(){
 kreaPreview=null;$('kreaStage').classList.add('hidden');$('kreaResultImage').classList.add('hidden');$('kreaBusyVisual').classList.remove('hidden');
 $('kreaClipModal').querySelector('.dialog').classList.remove('kreaWorking');
 for(const id of ['approveKreaClip','redoKreaClip','modifyKreaClip'])$(id).classList.add('hidden');
 $('generateKreaClip').classList.remove('hidden');
}
async function generateKreaPreview(override={}){
 const button=$('generateKreaClip');
 if(!clipDraft){toast('Clip non disponible');return}
 const id=clipDraft.id;
 const data={project:projectName,review_id:id,
  mode:$('kreaClipMode').value,source_path:$('kreaClipSource').value,
  name:$('kreaClipName').value,category:$('kreaClipCategory').value,
  prompt:$('kreaClipPrompt').value,...override};
 if(data.mode!=='text'&&!data.source_path)throw Error('Choisis une image de référence avant de créer');
 button.disabled=true;resetKreaPreview();kreaLastRequest=data;
 $('kreaStage').classList.remove('hidden');
 $('kreaClipModal').querySelector('.dialog').classList.add('kreaWorking');
 const started=Date.now();
 $('kreaClipStatus').textContent='';
 $('kreaBusyVisual').classList.remove('hidden');
 $('kreaBusyVisual').querySelector('strong').textContent='Le Director prépare le prompt Krea…';
 $('kreaElapsed').textContent='Préparation du rendu…';
 try{
  const job=await request('/api/krea-clip',data);
  $('kreaBusyVisual').querySelector('strong').textContent='Image Krea en cours de génération';
  $('kreaElapsed').textContent='0 s écoulées · Seed '+job.seed;
  for(let i=0;i<240;i++){
   await new Promise(resolve=>setTimeout(resolve,2000));
   $('kreaElapsed').textContent='Temps écoulé : '+Math.floor((Date.now()-started)/1000)+' s · Seed '+job.seed;
   const result=await request('/api/krea-job?id='+encodeURIComponent(job.job_id));
   if(result.status==='failed')throw Error(result.error||'Échec Krea');
   if(result.status==='complete'){
    if(!clipDraft||clipDraft.id!==id)throw Error('Ce clip a changé ; la référence ne sera pas attachée');
    kreaPreview=result;
    const img=$('kreaResultImage');img.src=result.url;img.classList.remove('hidden');
    $('kreaBusyVisual').classList.add('hidden');
    $('kreaClipStatus').textContent='Image générée. Vérifie-la AVANT de l’ajouter au clip.';
    $('generateKreaClip').classList.add('hidden');
    for(const id of ['approveKreaClip','redoKreaClip','modifyKreaClip'])$(id).classList.remove('hidden');
    return;
   }
  }
  throw Error('Krea dépasse le délai. Regarde les résultats avant de relancer.');
 }catch(e){$('kreaClipModal').querySelector('.dialog').classList.remove('kreaWorking');$('kreaClipStatus').textContent='Krea : '+e.message;toast(e.message)}
 finally{button.disabled=false}
}
$('generateKreaClip').onclick=()=>generateKreaPreview().catch(e=>toast(e.message));
$('approveKreaClip').onclick=async()=>{
 if(!kreaPreview||!clipDraft)return;
 try{
  clipDraft.refs.push({media:'image',path:kreaPreview.path,url:kreaPreview.url,
   name:kreaPreview.name||'Krea',kind:'manual',visualType:'visual',bankScope:'clip',editing:true});
  await updateReferences();resetKreaPreview();hideModal('kreaClipModal');
  toast('Image validée et ajoutée au brouillon. Choisis son rôle avant validation du clip.');
 }catch(e){toast(e.message)}
};
$('redoKreaClip').onclick=()=>generateKreaPreview().catch(e=>toast(e.message));
$('modifyKreaClip').onclick=()=>{
 if(!kreaPreview)return;
 const current=kreaPreview;
 // Retake the generated result in transform mode; the original S-Ref source is untouched.
 $('kreaClipMode').value='transform';$('kreaClipMode').onchange();
 kreaSourceItems.push({path:current.path,url:current.url,name:'Dernier rendu Krea à modifier',group:'retake'});
 setKreaSourceOptions([...kreaClipSources(),...kreaSourceItems],current.path);
 $('kreaClipPrompt').focus();resetKreaPreview();
 $('kreaClipStatus').textContent='Décris la modification, puis clique sur « Créer avec Krea ».';
};

function collectClipEdits(){
 if(!clipDraft)return null;
 const body=creativeText();
 const text=clipDraft.previewPrefix?clipDraft.previewPrefix+'\n\n'+body:body;
 return {text,creative_text:body,refs:refPayload(),bank_deletes:clipDraft.bankDeletes,loras:selectedLoras('clipLoraEnabled','clipLoraItems')};
}
function focusDirector(){
 // Navigation is exclusively triggered by the director's click; NEVER on polling.
 const el=$('directorDesk');if(el)el.scrollIntoView({behavior:'smooth',block:'start'});
}
function optionButton(opt,id){return `<button class="decisionOption" data-value="${escapeHTML(opt.value??'')}">${escapeHTML(opt.label||opt.value||'Continuer')} <span>→</span></button>`}
function actionPanel(data){
 if(!data.running && data.older_running?.length && !project?.resume_state?.completed){const old=data.older_running[0];$('deskTitle').textContent='Ancienne production encore active';$('deskSubtitle').textContent='Le studio a retrouvé une session de la version précédente. Tu peux arrêter uniquement son moteur FilmMaker pour reprendre ton projet.';$('decisionStatus').textContent='SESSION BLOQUANTE';$('deskStep').textContent='Arrêt requis';const area=$('questionArea');const token='legacy-'+old.pid;if(area.dataset.token!==token){area.dataset.token=token;area.innerHTML=`<div class="legacyPanel"><div><b>FilmMaker précédent · PID ${Number(old.pid)}</b><p>${escapeHTML(old.project||old.session)}</p><small>ComfyUI reste ouvert. Les clips validés et checkpoints ne sont pas supprimés.</small></div><button id="stopLegacy" class="stopRenderBtn">■ Arrêter cette ancienne production</button></div>`;$('stopLegacy').onclick=()=>stopLegacySession(old.pid);}return;}
 if(!data.running && data.error && data.project?.name===projectName){
  $('deskTitle').textContent='Moteur interrompu';
  $('deskSubtitle').textContent=data.error;
  $('decisionStatus').textContent='ERREUR MOTEUR';
  $('deskStep').textContent='Journal technique';
  const area=$('questionArea');const token='worker-error:'+data.return_code;
  if(area.dataset.token!==token){area.dataset.token=token;area.innerHTML='<div class="standby"><div><b>La production ne tourne plus.</b><p>Ouvre le Journal technique et consulte les dernières lignes de console.log. Les fichiers déjà créés restent sur disque.</p></div></div>';}
  return;
 }
 if(data.stop_requested && data.project?.name===projectName && !project?.resume_state?.completed){
  $('deskTitle').textContent='Arrêt du rendu demandé';
  $('deskSubtitle').textContent='ComfyUI est en cours d’interruption. Le dernier clip validé reste sauvegardé.';
  $('decisionStatus').textContent='ARRÊT EN COURS';
  const area=$('questionArea');if(area.dataset.token!=='stopping'){area.dataset.token='stopping';area.innerHTML='<div class="standby">Attente de confirmation de l’arrêt…</div>';}
  return;
 }
 const activeHere=data.project?.name===projectName;
 let gate=activeHere?data.raw_gates?.[0]:null,review=activeHere&&data.review?.id?data.review:null,question=activeHere&&data.question?.id?data.question:null;
 let html='',title='',subtitle='',phase='',status='EN COURS';
 if(gate){
  phase='CONTRÔLE VISUEL · H3STUDIO';title=`RAW du clip ${gate.clip}`;subtitle='Visionne le RAW complet avant le refine 1920. La modification renvoie tes consignes au Clip Director.';status='VALIDATION REQUISE';
  html=`<div class="decisionRich"><div class="decisionKicker">APERÇU RAW GÉNÉRÉ</div>${gate.raw_url?`<video class="decisionVideo" src="${escapeHTML(gate.raw_url)}" controls preload="metadata"></video>`:'<p>Prévisualisation en préparation…</p>'}</div><div class="decisionActions"><button id="approveRaw" class="primary decisionPrimary">✓ Accepter le RAW · Lancer le refine HD</button><button id="retouchPendingRaw" class="decisionSecondary">✎ Retoucher dans le Studio (9 moteurs)</button><button id="showRawEdit" class="decisionSecondary">✎ Modifier le RAW</button></div><div id="rawEditArea" class="editArea hidden"><label for="rawFeedback">Corrections à renvoyer au Clip Director</label><textarea id="rawFeedback" rows="4" placeholder="Décris ce qui ne va pas, et ce que le nouveau RAW doit montrer…"></textarea><button id="redoRaw" class="primary">↻ Renvoyer au Clip Director et refaire</button></div>`;
 } else if(activeHere && data.stage?.stage==='raw_retouch'){
  const stage=data.stage||{};
  phase='RETOUCHES · RAW EN ATTENTE';title=`Clip ${stage.payload?.clip||'?'} — retouche en cours`;
  subtitle='Le RAW est terminé et ComfyUI est libre. Le film attend ton MP4 validé.';
  status='ATTENTE RETOUCHES';
  html=`<div class="standby"><b>Film mis en attente volontairement</b><p>Utilise Retouches puis Valider pour relancer le refine 4σ et poursuivre le film. Le RAW et son latent .pt original sont conservés.</p><button id="returnToPendingRetouches" class="primary">Ouvrir Retouches pour ce RAW</button></div>`;
 } else if(review){
  const r=review;phase=r.kind==='content'?'PRÉPRODUCTION · CONTENT DIRECTOR':r.kind==='brief'?'DÉMARRAGE · BRIEF':r.kind==='plans'?'RÉALISATION · PLAN DIRECTOR':r.kind==='scenes'?'ÉCRITURE · SCENE DIRECTOR':'VALIDATION · '+r.kind.toUpperCase();
  title=r.kind==='content'?'Proposition du film':r.title;subtitle=r.kind==='content'?'Lis le synopsis, les personnages, les actes et les décors. C’est ici que tu diriges ton film avant de créer les scènes.':r.kind==='brief'?'Ton brief est-il prêt pour le Content Director ?':'Valide cette proposition avant que le moteur passe à la suite.';status='DÉCISION REQUISE';
  const readable=r.payload?.text||'',structured=r.payload?.content||{};
  const smallHead=structured.title?`<div class="proposalMeta"><span>${escapeHTML(structured.title)}</span><span>${escapeHTML(structured.content_type||'')}</span><span>${escapeHTML(structured.duration_text||'')}</span></div>`:'';
  const mode=r.kind==='content'?'content':'other';
  const dialogueInfo=r.payload?.dialogue_issue?`<div class="refProgress" role="alert">Avertissement de débit (modifiable) : ${escapeHTML(r.payload.dialogue_issue)} — Tu peux aussi cliquer « Valider » pour continuer avec ton dialogue tel quel.</div>`:'';
  const dialogueAutoInfo=r.kind==='clips' && r.payload?.dialogue_auto_changed ? (()=>{
    const lines=t=>[...String(t||'').matchAll(/<d\s*>([\s\S]*?)<\/d\s*>/gi)].map(x=>x[1].trim());
    const before=lines(r.payload.dialogue_previous),after=lines(r.payload.text);
    const modifications=after.map((line,i)=>({old:before[i]||'',new:line})).filter(x=>x.old!==x.new);
    return `<div class="refProgress" role="status"><b>Dialogues ajustés automatiquement par le Clip Director — validation obligatoire avant H3.</b><p>Tu peux valider la nouvelle rédaction, l'éditer ou demander une autre correction. Le rendu attend ton choix.</p>${modifications.length?`<div class="dialogueChanges">${modifications.map(x=>`<div><small>Avant : ${escapeHTML(x.old)}</small><strong>Après : ${escapeHTML(x.new)}</strong></div>`).join('')}</div>`:''}</div>`;
  })():'';

  const revisionInfo=r.payload?.raw_retake?`<div class="refProgress">NOUVELLE VERSION APRÈS REFUS DU RAW · Plan ${escapeHTML(r.payload?.plan?.plan||'?')} · Vérifie le nouveau prompt avant de relancer le GPU.</div><div class="structuredFact"><strong>Ta correction</strong><p>${escapeHTML(r.payload?.feedback||'')}</p></div>`:'';
  const isClip=r.kind==='clips';
  const reviewCorrectionEditor=r.allow_revise?`<div id="reviewEditArea" class="editArea hidden"><label for="reviewFeedback">Tes instructions pour le Director</label><textarea id="reviewFeedback" rows="5" placeholder="Indique ce que tu veux modifier dans ce clip…"></textarea><div class="editActions"><button id="cancelReviewEdit">Annuler</button><button class="primary" id="redoReview">Envoyer les modifications au Director →</button></div></div>`:'';
  const proposal=dialogueInfo+dialogueAutoInfo+revisionInfo+(isClip?`<div class="clipReviewActions"><div><b>Clip Director · Édition du prompt</b><small>Modifie directement le texte et les références ci-dessous, puis valide sans nouvel appel LLM.</small></div><div class="clipReviewButtons"><button id="approveReviewTop" class="primary decisionPrimary">✓ Valider le prompt modifié</button><button id="showReviewEditTop" class="decisionSecondary">✎ Demander au Clip Director</button></div></div>${reviewCorrectionEditor}<div class="editableClip"><section class="clipEditMain"><div class="directorEditHead"><b>Prompt H3 directement éditable</b><span>Bloc technique verrouillé + texte créatif transmis au moteur H3</span></div><div class="directorAuthorityHead">AUTORITÉ DES RÉFÉRENCES · lecture seule (✎ pour modifier les liaisons)</div><pre id="clipAuthorityText" class="clipAuthorityText" aria-label="Autorité des références verrouillée">Synchronisation des références…</pre><label class="clipCreativeLabel" for="clipEditText">Texte créatif H3 · modifiable</label><textarea id="clipEditText" class="clipEditText" spellcheck="false" rows="18" aria-label="Modifier uniquement le contenu créatif du prompt H3">${escapeHTML(readable)}</textarea><details class="clipInitialPreview"><summary>Afficher l’ancienne proposition mise en forme</summary><div class="richReview">${richText(readable)}</div></details></section><section class="clipEditSide"><div class="directorEditHead"><b>Références du clip</b><span id="clipRefCount"></span></div><p class="refSectionExplainer">Références figées dans leur ordre actuel. ✎ pour modifier le sujet, sa liaison et la RefBank si tu le souhaites ; le bloc Picture / Subject verrouillé est automatiquement mis à jour au-dessus du texte créatif.</p><p id="refAuthoritySync" class="refAuthoritySync">Synchronisation des références…</p><button id="retryClipAuthority" type="button" class="decisionSecondary hidden">↻ Réessayer la synchronisation</button><div id="clipEditRefs" class="clipEditRefs"></div><div class="clipUploadRow"><button type="button" id="chooseBankRef" class="uploadRef">▣ RefBank</button><button type="button" id="openKreaClip" class="uploadRef">✦ Krea</button><label class="uploadRef">＋ Image<input type="file" id="addClipImage" accept="image/png,image/jpeg,image/webp"></label><label class="uploadRef">＋ Audio<input type="file" id="addClipAudio" accept="audio/*"></label></div><section class="loraBox"><label class="loraToggle"><input type="checkbox" id="clipLoraEnabled"> Appliquer des LoRA à ce clip uniquement</label><div id="clipLoraPanel" class="hidden"><div id="clipLoraItems"></div><button type="button" id="clipAddLora">＋ Ajouter une LoRA</button><small>La sélection du clip remplace celle du film ; désactivée = aucune LoRA pour ce clip.</small></div></section><div id="clipBankPicker" class="clipBankPicker hidden"></div><p class="refEditHint">Les numéros suivent automatiquement l’ordre fixe des références. Une image ajoutée peut être une apparence liée à un personnage canonique. Un audio peut décrire une voix ou le son d’un objet ; aucune modification de la Voice Bank automatique.</p></section></div>`:(r.kind==='scenes'||r.kind==='plans')?structuredReview(r.kind,r.payload):`<div class="richReview">${richText(readable)}</div>`);
  const isEditableDirector=['content','scenes','plans'].includes(r.kind);
  const editableSource=readable;
  const directorName={content:'Content',scenes:'Scene',plans:'Plan'}[r.kind]||'';
  const editHint=r.kind==='content'?'Retouche la proposition en français : actes, personnages, événements, rythme. Le Content Director reformatera ta version sans toucher au moteur H3.':r.kind==='scenes'?'Retouche la description des scènes. Le Scene Director proposera un découpage cohérent avec la partie validée.':'Retouche les plans, les actions et les raccords. Le Plan Director respectera la durée validée de la scène.';
  const editablePanel=isEditableDirector?`<div class="directorManualEdit"><div class="clipReviewActions"><div><b>${directorName} Director · Modifier la proposition</b><small>${escapeHTML(editHint)}</small></div><div class="clipReviewButtons"><button type="button" id="applyDirectorDraft" class="primary decisionPrimary">↻ Appliquer mes retouches avec le Director</button><button type="button" id="directorLLMEdit" class="decisionSecondary">✎ Demander une autre modification</button></div></div><div id="directReviewArea"><label for="directorDirectText">Proposition lisible — tu peux la modifier directement</label><textarea id="directorDirectText" class="clipEditText" rows="15" spellcheck="false">${escapeHTML(editableSource)}</textarea><p id="directorDraftState" class="editorHelp">Pas de JSON à écrire. Si tu modifies le texte, le Director produira une nouvelle proposition à vérifier avant validation.</p><div id="directorEditError" class="directorEditError hidden" role="alert"></div><div class="directorRecovery"><button type="button" id="restoreDirectorSource" class="decisionSecondary">↩ Rétablir le texte proposé</button><button type="button" id="undoDirectorRestore" class="decisionSecondary hidden">Annuler la restauration</button></div></div></div>`:'';
  html=`<article class="proposalPaper">${smallHead}${editablePanel}${proposal}</article><div class="decisionBar"><button id="approveReview" class="primary decisionPrimary">✓ Valider · Continuer</button>${r.allow_revise?'<button id="showReviewEdit" class="decisionSecondary">✎ Modifier</button>':''}${r.allow_redo?'<button id="redoProposal" class="decisionSecondary">↻ Refaire une proposition</button>':''}</div>${!isClip?reviewCorrectionEditor:''}`;
 } else if(question){
  const q=question,ctx=q.context||{},opts=Array.isArray(ctx.options)?ctx.options:[];
  phase='PRÉPRODUCTION · RÉFÉRENCES';title=ctx.title||'Décision de préproduction';subtitle=ctx.description||'Choisis la prochaine action pour poursuivre la production.';status='ACTION REQUISE';
  const progress=ctx.progress||{},refStatus=progress.total?`<div class="refProgress">Références : <b>${progress.index} / ${progress.total}</b> · <b>${progress.remaining}</b> après celle-ci · <b>${progress.accepted}</b> déjà retenue(s)</div>`:'';
  const imageSrc=ctx.image_url||((ctx.image && data.krea_preview)?data.krea_preview:'');
  // Reuse the outer `title` assigned above. A block-local `const title` here
  // shadows it and triggers a TDZ ReferenceError on EVERY preproduction question.
  const kreaBackButtons=(function(){
    let out='';
    if(/Précisions Krea/i.test(title))out+='<button type="button" class="decisionSecondary" id="backKreaPrecisions">← Retour au choix Krea</button>';
    if(/Importer une source Krea/i.test(title))out+='<button type="button" class="decisionSecondary" id="backKreaFileImport">← Retour aux sources</button>';
    if(/Image source pour /i.test(title) || /Mode Krea \+ image source/i.test(title))out+='<button type="button" class="decisionSecondary" id="backKreaSourceChoice">← Retour au choix Krea</button>';
    return out;
  })();
  html=`<div class="questionSheet">${refStatus}${imageSrc?`<div class="kreaPreview"><img src="${escapeHTML(imageSrc)}" alt="Image Krea actuelle"></div>`:''}${opts.length?`<div class="decisionChoices">${opts.map(optionButton).join('')}</div>`:''}${ctx.input_type==='text'?'<textarea id="answerInput" rows="4" placeholder="Écris tes précisions ici…"></textarea><button class="primary" id="sendAnswer">Envoyer →</button>'+kreaBackButtons:ctx.input_type==='file'?'<label class="importCard">Importer une image ou un audio<input id="fileUpload" type="file" accept="image/*,audio/*"></label><input id="answerInput" placeholder="Ou colle le chemin d’un fichier local"><button class="primary" id="sendAnswer">Utiliser ce fichier →</button>'+kreaBackButtons:opts.length?`${kreaBackButtons}`:'<input id="answerInput" placeholder="Ta réponse"><button class="primary" id="sendAnswer">Continuer →</button>'+kreaBackButtons}</div>`;
 } else {
  const currentSessionProject=data.project?.name===projectName;
  const finished=!!(projectName&&project?.resume_state?.completed);
  const stage=currentSessionProject?data.stage||{}:{};
  phase=finished?'PRODUCTION TERMINÉE':stage.stage==='complete'?'PRODUCTION TERMINÉE':'SUIVI DE PRODUCTION';
  title=finished?'Film terminé — projet terminé':stage.title||'À ton poste de réalisateur';
  subtitle=finished?'Le montage est exporté. Consulte le scénario, les clips et le dernier FINAL plus bas.':data.running&&currentSessionProject?'FilmMaker travaille. La prochaine proposition apparaîtra ici.':projectName?'Projet sélectionné. Consulte le scénario et les clips enregistrés.':'Crée un film ou sélectionne un projet pour consulter sa progression.';
  status=finished?'TERMINÉ':data.running&&currentSessionProject?'TRAVAIL EN COURS':'PRÊT';
  const krea=stage.payload||{},kreaSrc=krea.image_url||currentSessionProject&&data.krea_preview;
  const refProgress=krea.total?`<div class="refProgress">Référence <b>${krea.index}/${krea.total}</b> · ${krea.remaining} après celle-ci · ${krea.accepted} retenue(s)</div>`:'';
  html=finished?'<div class="standby completedFilm"><div class="standbyIcon">✓</div><div><b>Film terminé — montage exporté</b><p>Projet terminé. Les clips et le dernier montage FINAL restent disponibles ci-dessous.</p></div></div>':`${refProgress}${(stage.stage==='krea'&&kreaSrc)?`<div class="kreaPreview"><img src="${escapeHTML(kreaSrc)}" alt="Dernière image Krea"></div>`:''}<div class="standby"><div class="standbyIcon">◷</div><div><b>${escapeHTML(stage.title||'Aucune décision en attente')}</b><p>${data.running&&currentSessionProject?'Les Directors travaillent. Tu peux suivre le déroulement ci-dessous.':'Aucune décision en attente. Choisis « Nouveau film » pour lancer une production.'}</p></div></div>`;
 }
 $('deskTitle').textContent=title;$('deskSubtitle').textContent=subtitle;$('deskPhase').textContent=phase;$('decisionStatus').textContent=status;
 $('decisionStatus').classList.toggle('waiting',!!(review||question||gate));
 $('deskStep').textContent=review?'À valider':gate?'RAW à valider':question?'Références':(project?.resume_state?.completed?'Terminé':(data.stage?.stage||'Production'));
 const area=$('questionArea');const token=gate?'gate'+gate.clip:review?.id||question?.id||(project?.resume_state?.completed?'finished:'+projectName:'idle:'+projectName+':'+(data.stage?.stage||''));
 if(area.dataset.token!==token || (question?.context?.image_url && area.dataset.preview!==question.context.image_url)){area.dataset.token=token;area.dataset.preview=question?.context?.image_url||'';area.innerHTML=html;
  if(gate){
   const preview=area.querySelector('video.decisionVideo');
   if(preview){let retries=0;preview.addEventListener('error',()=>{if(retries++>=6)return;const original=gate.raw_url;setTimeout(()=>{if(preview.isConnected){preview.src=original+(original.includes('?')?'&':'?')+'load='+Date.now();preview.load()}},1200+retries*1200)});}
   $('approveRaw').onclick=()=>decideRaw(gate.clip,'approve');$('retouchPendingRaw').onclick=async()=>{try{const clip=gate.clip;await request('/api/raw-decision',{clip,action:'retouch'});toast('Libération du graphe H3 : attends quelques secondes…');for(let i=0;i<45;i++){await new Promise(r=>setTimeout(r,1000));const d=await request('/api/status');if(d.stage?.stage==='raw_retouch' && d.project?.name===projectName){await window.retouchOpenProjectRaw(projectName,clip);return;}if(!d.running)throw Error('FilmMaker arrêté pendant la préparation de Retouches');}throw Error('Libération ComfyUI non confirmée; consulte le Journal technique');}catch(e){toast(e.message)}};$('showRawEdit').onclick=()=>$('rawEditArea').classList.toggle('hidden');$('redoRaw').onclick=()=>decideRaw(gate.clip,'redo',$('rawFeedback').value);}
  if($('returnToPendingRetouches'))$('returnToPendingRetouches').onclick=()=>window.retouchOpenProjectRaw(projectName,data.stage.payload.clip);
  if(review){if(review.kind==='clips'){wireClipEditor(review);if($('approveReviewTop'))$('approveReviewTop').onclick=()=>decideReview(review.id,'continue');if($('showReviewEditTop'))$('showReviewEditTop').onclick=()=>{const edit=$('reviewEditArea');edit.classList.remove('hidden');edit.scrollIntoView({behavior:'smooth',block:'nearest'});};}$('approveReview').onclick=()=>decideReview(review.id,'continue');if($('showReviewEdit'))$('showReviewEdit').onclick=()=>$('reviewEditArea').classList.toggle('hidden');if($('cancelReviewEdit'))$('cancelReviewEdit').onclick=()=>$('reviewEditArea').classList.add('hidden');if($('redoReview'))$('redoReview').onclick=()=>decideReview(review.id,'revise',$('reviewFeedback').value);if($('applyDirectorDraft'))$('applyDirectorDraft').onclick=()=>decideReview(review.id,'continue');if($('restoreDirectorSource')){let previousDraft=null;const editor=$('directorDirectText');const error=$('directorEditError');editor.oninput=()=>{if(error){error.classList.add('hidden');error.textContent=''}const changed=editor.value!==editor.defaultValue;$('directorDraftState').textContent=changed?'Texte modifié : la validation demandera une révision au Director, sans poursuivre directement le rendu.':'Proposition initiale : valider continuera sans nouvel appel LLM.';};$('restoreDirectorSource').onclick=()=>{if(editor.value===editor.defaultValue)return;if(!confirm('Revenir à la proposition du Director ? Tu pourras annuler cette restauration.'))return;previousDraft=editor.value;editor.value=editor.defaultValue;editor.oninput();if(error){error.classList.add('hidden');error.textContent=''}$('undoDirectorRestore').classList.remove('hidden');};$('undoDirectorRestore').onclick=()=>{if(previousDraft===null)return;editor.value=previousDraft;editor.oninput();previousDraft=null;$('undoDirectorRestore').classList.add('hidden');};}if($('directorLLMEdit'))$('directorLLMEdit').onclick=()=>{$('reviewEditArea').classList.remove('hidden');$('reviewEditArea').scrollIntoView({behavior:'smooth',block:'nearest'});};if($('redoProposal'))$('redoProposal').onclick=()=>{if(confirm('Demander une nouvelle proposition ? La proposition actuelle restera enregistrée.'))decideReview(review.id,'redo');};}
  if(question){if($('backKreaPrecisions'))$('backKreaPrecisions').onclick=()=>answer(question.id,'__BACK_TO_KREA_CHOICES__');if($('backKreaFileImport'))$('backKreaFileImport').onclick=()=>answer(question.id,'__BACK_TO_SOURCES__');if($('backKreaSourceChoice'))$('backKreaSourceChoice').onclick=()=>answer(question.id,'__BACK_TO_KREA_CHOICES__');for(const b of area.querySelectorAll('.decisionOption'))b.onclick=()=>answer(question.id,b.dataset.value);if($('sendAnswer'))$('sendAnswer').onclick=()=>answer(question.id,$('answerInput').value);if($('fileUpload'))$('fileUpload').onchange=async e=>{try{let file=e.target.files[0];if(!file)return;const result=await fetch('/api/upload',{method:'POST',headers:{'X-Filename':file.name,'Content-Type':'application/octet-stream'},body:file});const info=await result.json();if(!result.ok)throw Error(info.error||'Import impossible');$('answerInput').value=info.path;toast('Référence importée, clique pour continuer.')}catch(ex){toast(ex.message)}};}
 }
}
async function decideRaw(clip,action,feedback=''){try{if(action==='redo'&&!feedback.trim()){toast('Décrivez les modifications attendues');return}await request('/api/raw-decision',{clip,action,feedback});$('questionArea').dataset.token='';focusDirector();toast(action==='approve'?'RAW accepté : le refine HD va démarrer':'RAW refusé : correction enregistrée. Attente du Clip Director…')}catch(e){toast(e.message)}}
async function decideReview(id,action,feedback=''){
 try{
  if(state.review?.id===id && ['content','scenes','plans'].includes(state.review.kind)){
   const editor=$('directorDirectText');
   if(action==='continue'&&editor&&editor.value!==editor.defaultValue){
    if(!editor.value.trim()){const error=$('directorEditError');error.textContent='La proposition est vide. Rétablis le texte proposé ou décris tes corrections.';error.classList.remove('hidden');return;}
    action='revise';
    feedback='MODIFICATION MANUELLE DU RÉALISATEUR — utilise la dernière proposition structurée comme base. Le texte suivant est la nouvelle rédaction souhaitée : applique les changements explicites, conserve tout le reste, puis restitue une sortie complète dans ton format habituel. Ne traite pas ce texte comme un nouveau scénario libre. Respecte la durée totale et les contraintes validées.\n\nTEXTE SOUHAITÉ :\n'+editor.value;
   }
  }
  if(action==='revise'&&!feedback.trim()){toast('Ajoute une correction');return}
  let edits=null;
  if(action==='continue'&&state.review?.id===id && state.review.kind==='clips'){
   await ensureClipAuthorityReady();
   // A freshly saved preview is authoritative. Do not accept an old prefix.
   edits=collectClipEdits();
  }
  await request('/api/review',{id,action,feedback,edits});
  $('questionArea').dataset.token='';focusDirector();toast(action==='redo'?'Nouvelle proposition demandée':action==='revise'?'Retouches envoyées au Director — proposition à revalider':'Étape validée');
 }catch(e){const error=$('directorEditError');if(error){error.textContent='Envoi impossible : '+e.message+'\nTon texte est conservé. Rien n’a été enregistré.';error.classList.remove('hidden');}else toast(e.message)}
}
async function answer(id,value){try{await request('/api/answer',{id,value});$('questionArea').dataset.token='';focusDirector();toast('Réponse transmise')}catch(e){toast(e.message)}}
function livePanel(x){
 const c=x.active_clip||{},stage=x.stage||{};
 $('currentClipLabel').textContent=c.clip?`Clip ${c.clip} · Scène ${c.scene||'—'} · Plan ${c.plan||'—'} · ${stage.title||'Production'}`:(stage.title||'Aucun clip en cours');
 const prompt=c.text||'';
 $('currentPrompt').textContent=prompt||'Le prompt complet apparaîtra ici avant le rendu RAW.';
 const imgs=(c.refs||[]).map((r,i)=>{const url=c.refs_url?.[i]||'';return `<div class="liveRefCard">${url?`<img loading="lazy" src="${escapeHTML(url)}" alt="Picture ${i+1}">`:'<div class="missingRef">Image non trouvée</div>'}<small>PICTURE ${i+1} · ${escapeHTML(r.subject_name||r.name||r.kind||'Référence')}</small></div>`}).join('');
 const voices=(c.audio_refs||[]).map((r,i)=>`<div class="liveRefCard"><small>AUDIO ${i+1} · ${escapeHTML(r.subject_name||r.name||'Voix')}</small>${c.voices_url?.[i]?`<audio controls preload="none" src="${escapeHTML(c.voices_url[i])}"></audio>`:''}</div>`).join('');
 const refsKey=JSON.stringify([c.clip,c.refs_url,c.voices_url,c.refs,c.audio_refs]);if(liveRefsSignature!==refsKey){liveRefsSignature=refsKey;$('currentRefs').innerHTML=(imgs+voices)||'<p class="muted">Références en attente du Clip Director.</p>';} 
 $('followLiveBtn').classList.toggle('selected',!followLive);$('followLiveBtn').classList.toggle('hidden',followLive);
 if(followLive && c.clip){
  const key=String(c.clip).padStart(4,'0');
  if(projectName===x.project?.name && project.clips?.[key]){
   if(selected!==key){pickClip(key,true)}
  }else if(c.raw_url){
   loadVideoSource(c.raw_url);kind='raw';$('showRaw').classList.add('selected');$('showHD').classList.remove('selected');
   $('emptyVideo').classList.add('hidden');$('viewerChip').textContent='RAW EN ATTENTE DE VALIDATION';
  }
 }
}
function durationClock(s){if(!Number.isFinite(s)||s<0)return '00:00';return String(Math.floor(s/60)).padStart(2,'0')+':'+String(Math.floor(s%60)).padStart(2,'0')}
function runningPulse(){const active=state.running && !state.raw_gates?.length && !state.review?.id && !state.question?.id; $('runningSignal').classList.toggle('hidden',!active); if(active){$('runningText').textContent=state.stage?.title||'FilmMaker travaille';$('runningTime').textContent=durationClock(Date.now()/1000-(state.stage?.updated||state.started||Date.now()/1000));}}
let refreshBusy=false, lastProjectPayload='', lastProjectName='';async function refresh(){if(refreshBusy)return;refreshBusy=true;let apiReachable=false;try{let x=await request('/api/status');apiReachable=true;state=x;let projects=x.projects||[];if(awaitingNewProject && x.project?.name)awaitingNewProject=false;if(awaitingNewProject && !x.project?.name){$('projectTitle').textContent=newProjectDraftTitle;$('projectDesc').textContent='Préparation de ce nouveau film…';}if(x.project?.name && (!projectName || followLive && x.running && x.project.name!==projectName)){projectName=x.project.name;selected='';project={};timelineSignature='';storySignature='';liveRefsSignature='';clearLatestFinal();}
// The viewed project alone owns layout mode; renderProject() updates it after data arrives.
$('conn').textContent=x.running?(x.paused_at_boundary?'● PAUSE':'● EN COURS'):'● LOCAL';
$('pauseBtn').disabled=!x.running||!!x.paused;
$('resumeBtn').disabled=!x.running||!x.paused;
$('suspendBtn').disabled=!x.running;
$('stopRenderBtn').disabled=!(x.running||(x.older_running||[]).length);
$('stopRenderBtn').title=x.running?'Stop = arrêt du rendu courant; ne sauvegarde pas le travail en cours':x.older_running?.length?'Arrêter un ancien moteur FilmMaker identifié':'Aucun rendu actif';
drawProjects(projects);$('extendFilmBtn').classList.toggle('hidden',!(projectName && ((x.running && x.project?.name===projectName)||project?.resume_state?.completed)));actionPanel(x);runningPulse();
if(projectName)await getProject();
if(projectName && projectName!==x.project?.name){
 if(Array.isArray(project.history))historyPanel({history:project.history},'project:'+projectName);
}else historyPanel(x,'active:'+String(x.project?.name||''));
livePanel(x);if(!$('library').classList.contains('hidden'))await loadRefs();if(!$('activity').classList.contains('hidden')){let logs=await request('/api/log');setLogText(logs.log||'');}
}catch(e){$('conn').textContent=apiReachable?'● ERREUR INTERFACE':'● HORS LIGNE';console.error(e)}finally{refreshBusy=false}}
function setLogText(text){const log=$('fullLog');if(log.textContent===text)return;const prevTop=log.scrollTop;const nearBottom=log.scrollTop+log.clientHeight>=log.scrollHeight-32;log.textContent=text;log.scrollTop=nearBottom?log.scrollHeight:prevTop;}
$('goLogEnd').onclick=()=>{$('fullLog').scrollTop=$('fullLog').scrollHeight};
refresh();setInterval(refresh,2100);setInterval(runningPulse,1000);

// Prolong only unrendered future scenes; no modifications to prior clip checkpoints.
$('extendFilmBtn').onclick=()=>{
 if(!(state?.running&&state?.project?.name===projectName) && !project?.resume_state?.completed){toast('Sélectionne un film en cours ou terminé');return}
 $('extendNotice').textContent='';showModal('extendModal');
};
function parseExtendDuration(raw){
 const text=String(raw||'').trim().toLowerCase();
 const match=text.match(/^(\d+)\s*(s|sec|m|min|h)?$/);
 if(!match)throw Error('Durée : saisis 0s, 30s, 1m ou 1h');
 const total=Number(match[1])*({h:3600,m:60,min:60,s:1,sec:1}[match[2]||'s']);
 if(!Number.isInteger(total)||total<0||total>3600||total%5)throw Error('Durée entre 0 et 60 minutes, multiple de 5 secondes');
 return total;
}
$('sendExtend').onclick=async()=>{
 const button=$('sendExtend');
 try{
  const extra_seconds=parseExtendDuration($('extendDuration').value);
  const instructions=$('extendInstructions').value.trim();
  if(!extra_seconds&&!instructions)throw Error('Indique une durée ou les changements demandés');
  if(project?.resume_state?.completed&&!extra_seconds)throw Error('Film terminé : ajoute au moins 5 secondes pour continuer');
  button.disabled=true;
  const result=await request('/api/extend-timeline',{project:projectName,extra_seconds,instructions});
  $('extendNotice').textContent=result.message||'Demande enregistrée';
  toast(result.message||'Prolongation en attente de la prochaine frontière de scène');
  setTimeout(()=>hideModal('extendModal'),800);
 }catch(e){$('extendNotice').textContent=e.message;toast(e.message)}
 finally{button.disabled=false}
};
const studioCheckIds=['reviewScenes','reviewPlans','reviewClips','reviewRaw'];
let studioCheckMemory=Object.fromEntries(studioCheckIds.map(id=>[id,$(id).checked]));
$('mode').onchange=()=>{let off=$('mode').value==='auto';for(const id of studioCheckIds){const el=$(id);if(off){studioCheckMemory[id]=el.checked;el.checked=false;}else{el.checked=studioCheckMemory[id];}el.disabled=off;}document.querySelector('.reviewOptions').classList.toggle('autoChecks',off);};$('mode').onchange();
$('independentModels').onchange=()=>{$('individualModels').classList.toggle('hidden',!$('independentModels').checked);if(!$('independentModels').checked)$('modelAll').onchange();};$('modelAll').onchange=()=>{for(const role of ['Content','Scene','Plan','Clip'])$('model'+role).value=$('modelAll').value;};
$('independentModels').onchange();

async function loadModels(){
 let opts=[{value:'',label:'Gemma 12B si disponible (défaut moteur)'}];
 const status=$('modelStatus');
 if(status)status.textContent='Recherche des modèles Ollama installés…';
 try {
  const d=await request('/api/models');const installed=d.ollama||[];
  const known26=installed.find(x=>x.toLowerCase().startsWith('gemma4:26b'));
  opts.push({value:known26||'gemma4:26b-a4b-it-q4_K_M',
             label:known26?'Gemma 26B · '+known26+' (installé)':'Gemma 26B · vérifier sa présence dans Ollama'});
  const already=new Set(opts.map(x=>x.value.toLowerCase()));
  for(const x of installed){if(!already.has(x.toLowerCase())){opts.push({value:x,label:x+' · Ollama'});already.add(x.toLowerCase())}}
  opts.push(...(d.special||[]));
  if(status)status.textContent=d.ollama_error?('⚠ '+d.ollama_error+' — modèle choisi vérifié au lancement.'):installed.length+' modèle(s) Ollama détecté(s). Gemma 26B disponible : '+(!!known26?'oui':'non (vérifie ollama list)')+'.';
 } catch(e){
  opts.push({value:'gemma4:26b-a4b-it-q4_K_M',label:'Gemma 26B · Ollama (détection indisponible)'},
            {value:'27',label:'Qwen3.8 27B · llama.cpp'},{value:'jp',label:'Jpetrina · llama.cpp'});
  if(status)status.textContent='⚠ Impossible de consulter Ollama : '+e.message;
 }
 {const el=$('modelAll'),old=el.value;el.innerHTML=opts.map(o=>`<option value="${escapeHTML(o.value)}">${escapeHTML(o.label)}</option>`).join('');if(opts.some(o=>o.value===old))el.value=old;}
 for(const k of ['Content','Scene','Plan','Clip']){
  const el=$('model'+k),old=el.value;
  el.innerHTML=opts.map(o=>`<option value="${escapeHTML(o.value)}">${escapeHTML(o.label)}</option>`).join('');
  if(opts.some(o=>o.value===old))el.value=old;
 }
 if(!$('independentModels').checked){for(const role of ['Content','Scene','Plan','Clip'])$('model'+role).value=$('modelAll').value;}
}
$('refreshDirectorModels').onclick=()=>loadModels();
loadModels();
