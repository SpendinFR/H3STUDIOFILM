/* V10.55 additive RAW engines: existing player, shot boundaries and mask canvas. */
(()=>{'use strict';
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const titles={extend:'Prolongation',performance:'Performance',precise:'Retake précis',insert:'Ajouter élément'};
const descriptions={
 extend:'Ajoute une suite au clip. Le studio reformule ta consigne pour H3 en gardant la continuité du plan.',
 performance:'Réécrit le plan entier à partir du prompt source du clip et de ta modification en langage naturel. Action, dialogue ou émotion : une seule entrée simple.',
 precise:'Refais une portion ratée de la timeline avec les images d’avant et d’après préservées dans le latent.',
 insert:'Ajoute un objet, une personne ou un élément dans le plan, à l’endroit demandé.'
};
const performanceExamples={
 generic:["Elle lève la main droite en regardant la caméra.","Au lieu de sourire, elle répond d'un ton sec : C'est bon, j'ai compris.","Elle devient soudain très inquiète en gardant la même situation."]
};
const examples={
 extend:['Prolonge de 5 secondes, elle lève les yeux puis se met à parler.'],
 performance:performanceExamples.generic,
 precise:['Corrige sa main entre 2,0 et 2,8 secondes.','Corrige le visage ici sans changer le reste.'],
 insert:['Ajoute un téléphone sur le bureau à droite.',"Ajoute un homme flou à l'arrière-plan près de la porte."]
};
let engine='',activeJob='',lastJobs='',performanceType='action',insertReference='',insertReferenceURL='';
function notify(t,err=false){const el=$('newRetStatus');el.textContent=t;el.classList.toggle('newRetError',err)}
async function api(route,body){const r=await fetch(route,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)});const j=await r.json();if(!r.ok)throw Error(j.error||'HTTP '+r.status);return j}
function selectedSource(){
 if(window.retouchChainSource){
   const kind=window.retouchChainSource.kind,id=window.retouchChainSource.id;
   const path=(kind==='new'?'/api/retouches/new/output/':'/api/retouches/output/')+encodeURIComponent(id);
   if($('retVideo').currentSrc.includes(path))return {...window.retouchChainSource};
 }
 const player=$('retVideo'),project=$('retProject').value,clip=$('retClip').value;
 if($('retSourceProject').classList.contains('isActive') && project && clip && $('retVariant').value==='raw' && player.currentSrc)
   return {type:'project',project,clip,variant:'raw'};
 return null;
}
function sourceRegion(){
 const player=$('retVideo'),overlay=$('retMaskOverlay'),box=$('retMaskBox');
 if(!player.videoWidth||overlay.classList.contains('hidden')||box.classList.contains('hidden'))return null;
 const container=overlay.getBoundingClientRect(),selected=box.getBoundingClientRect();
 if(!container.width||!container.height||!selected.width||!selected.height)return null;
 const scale=Math.min(container.width/player.videoWidth,container.height/player.videoHeight);
 const width=player.videoWidth*scale,height=player.videoHeight*scale;
 const left=container.left+(container.width-width)/2,top=container.top+(container.height-height)/2;
 const x=Math.max(0,Math.min(1,(selected.left-left)/width));
 const y=Math.max(0,Math.min(1,(selected.top-top)/height));
 const w=Math.max(0,Math.min(1-x,selected.width/width));
 const h=Math.max(0,Math.min(1-y,selected.height/height));
 if(w<0.025||h<0.025)return null;
 return [x,y,w,h].map(v=>Math.round(v*10000)/10000);
}
function renderExamples(mode){ const chosen=mode==='performance'?performanceExamples.generic:examples[mode]; const items=(chosen||[]).map(x=>`<li><button type="button" class="newRetExampleBtn">${esc(x)}</button></li>`).join(''); $('newRetExamples').innerHTML=items||''; document.querySelectorAll('.newRetExampleBtn').forEach(btn=>btn.addEventListener('click',()=>{$('newRetInstruction').value=btn.textContent.trim();$('newRetInstruction').focus();notify('Exemple copié. Tu peux le modifier avant de lancer.');})); }
function repaintInsertReference(){const box=$('newRetInsertRefResult'); if(!box) return; box.classList.toggle('hidden',!insertReference); $('newRetInsertRefPreview').src=insertReferenceURL||''; $('newRetInsertRefName').textContent=insertReference?insertReference.split(/[\/]/).pop():'';}

function timeRange(){
 const video=$('retVideo'),duration=Number(video.duration),selected=engine!=='extend'&&$('newRetUseRange').checked;
 if(!Number.isFinite(duration)||duration<=0)throw Error('Attends que la vidéo RAW soit chargée.');
 const start=selected?Number($('retShotStart').value||0):0;
 const end=selected?(Number($('retShotEnd').value||0)||duration):duration;
 if(!(start>=0 && start<end && end<=duration+0.05))throw Error('Plage invalide. Utilise Début/Fin sous le lecteur.');
 return {selected,start,end};
}
function select(mode){
 if(!titles[mode])return;
 engine=mode;
 $('retLegacySetup').classList.add('hidden');$('newRetRoot').classList.remove('hidden');
 document.querySelectorAll('.retouchMode').forEach(el=>el.classList.toggle('isActive',el.dataset.newEngine===engine));
 $('newRetTitle').textContent=titles[mode];$('newRetHelp').textContent=descriptions[mode];$('newRetPerformanceTypes').classList.add('hidden');$('newRetInsertReference').classList.toggle('hidden',mode!=='insert');renderExamples(mode);
 $('newRetUseRange').disabled=mode==='extend';
 $('newRetTimelineHint').classList.toggle('hidden',mode==='extend'||!$('newRetUseRange').checked);
 $('newRetDraw').disabled=mode==='extend';$('newRetClear').disabled=mode==='extend';
 $('retMaskBar').classList.remove('hidden'); // Same legacy drawn region, no duplicate canvas.
 $('retDrawMask').textContent='◎ Encadrer sur la vidéo';
 $('retouches').classList.add('retouchesNewActive');
 notify('');
}
function backToLegacy(){
 engine='';$('newRetRoot').classList.add('hidden');$('retLegacySetup').classList.remove('hidden');
 $('retouches').classList.remove('retouchesNewActive');
 // Legacy click has already restored mode-specific controls and the mask toolbar.
}
async function refresh(){
 if($('retouches').classList.contains('hidden'))return;
 try{
   const data=await api('/api/retouches/new/jobs');const list=data.jobs||[];
   window.__retouchExtraJobs=list; const signature=list.map(j=>j.id+':'+j.status+':'+(j.finished_at||'')+':'+(j.error||'')+':'+(j.stage||'')+':'+(j.part||'')).join('|');
   if(signature!==lastJobs){lastJobs=signature; if(window.retouchLegacyRefresh)await window.retouchLegacyRefresh()}
   if(activeJob){const row=list.find(x=>x.id===activeJob);if(row?.status==='complete'){notify(row.review_warning||'RAW généré. Résultat visuel à vérifier ; clip original conservé.',Boolean(row.review_warning));activeJob=''}else if(row?.status==='error'){notify(row.error,true);activeJob=''}else if(row?.status==='cancelled'){notify('Rendu annulé.');activeJob=''}else if(row)notify('H3 RAW : '+row.status)}
 }catch(e){notify(e.message,true)}
}
async function run(test_clip=false){
 try{
   const src=selectedSource();if(!src)throw Error('Sélectionne un clip RAW du projet dans le lecteur à gauche.');
   const instruction=$('newRetInstruction').value.trim();if(!instruction)throw Error('Écris ta consigne en français.');
   const range=timeRange(),rect=engine==='extend'?null:sourceRegion();
   const answer=await api('/api/retouches/new/start',{mode:engine,performance_type:'action',source:src,instruction,test_clip,
     selected:range.selected,start:range.start,end:range.end,region:rect,playhead:Number($('retVideo').currentTime||0),reference_path:(engine==='insert'?insertReference:'')});
   activeJob=answer.id;notify(test_clip?'Essai H3 RAW début 1,6 s envoyé. Aucun fichier original modifié.':'Retouche H3 RAW lancée. Aucun fichier original modifié.');
   await refresh();
 }catch(e){notify(e.message,true)}
}
window.addEventListener('DOMContentLoaded',()=>{
 if(!$('newRetRoot'))return;
 $('retJobs').addEventListener('click',async e=>{
   const trigger=e.target.closest('[data-prompt-id]');if(!trigger)return;
   e.preventDefault();const id=trigger.getAttribute('data-prompt-id');
   let panel=trigger.parentElement.querySelector('.newRetPromptPreview');
   if(panel){panel.remove();return}
   try{
     const record=await api('/api/retouches/new/prompt/'+encodeURIComponent(id));
     panel=document.createElement('div');panel.className='newRetPromptPreview';
     const info=document.createElement('strong');info.textContent='Prompt envoyé à H3 · '+(record.method||'méthode inconnue');
     const pre=document.createElement('pre');pre.textContent=record.text||'';
     panel.append(info,pre);trigger.parentElement.append(panel);
   }catch(err){notify(err.message,true)}
 });
 $('newRetImportRef').addEventListener('change',async e=>{const file=e.target.files?.[0]; if(!file)return; notify('Import de la référence…'); try{const r=await fetch('/api/upload',{method:'POST',headers:{'Content-Type':'application/octet-stream','X-Filename':encodeURIComponent(file.name)},body:file}); const x=await r.json(); if(!r.ok) throw Error(x.error||'Import refusé'); insertReference=x.path||''; insertReferenceURL=x.url||''; repaintInsertReference(); notify('Référence d’élément prête.');}catch(err){notify(err.message,true)}finally{e.target.value=''}});
 $('newRetClearRef').addEventListener('click',()=>{insertReference='';insertReferenceURL='';repaintInsertReference();notify('Référence d’élément effacée.');});
 document.querySelectorAll('[data-new-engine]').forEach(btn=>btn.addEventListener('click',()=>select(btn.dataset.newEngine)));
 document.querySelectorAll('[data-mode]').forEach(btn=>btn.addEventListener('click',backToLegacy));
 $('newRetUseRange').addEventListener('change',()=>{$('newRetTimelineHint').classList.toggle('hidden',!$('newRetUseRange').checked)}); $('newRetInstruction').placeholder='Décris librement la modification souhaitée…'; repaintInsertReference();
 $('newRetDraw').onclick=()=>{$('retDrawMask').click();if(!$('retMaskOverlay').classList.contains('isDrawing'))notify('Zone sélectionnée sur le lecteur.');else notify('Dessine directement le rectangle sur la vidéo RAW à gauche.')};
 $('newRetClear').onclick=()=>{$('retClearMask').click();notify('Zone effacée.')};
 $('newRetQuick').onclick=()=>run(true);$('newRetGenerate').onclick=()=>run(false);
 window.refreshNewRetouchJobs=refresh; setInterval(()=>{if(!$('retouches').classList.contains('hidden'))refresh()},5000);
});
})();
