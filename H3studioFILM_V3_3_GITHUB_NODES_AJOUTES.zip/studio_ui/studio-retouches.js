/* Isolated Retouches UI. No Director, RefBank or FINAL state is mutated. */
(()=>{'use strict';
const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,x=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[x]));
const modeInfo={
 remove_person:{title:'Supprimer un personnage',desc:'Méthode Akatz : SAM3 suit la personne, une vidéo masquée en vert est préparée, puis H3 reconstruit le fond. La première frame propre est générée automatiquement par Krea2/LanPaint.',needs:'Personnage ciblé + suivi SAM3 (première image propre créée automatiquement par Krea2/LanPaint)',example:'Remove the green-masked woman and reconstruct the background. Preserve the rest of the video, including its camera motion and frame timing.',targetPlaceholder:'woman, man, person, girl, boy…',promptHelp:"Conseil : décris la cible en anglais simple pour SAM3 et laisse Krea2/LanPaint reconstruire automatiquement la première image. Le prompt reste libre."},
 swap_person:{title:'Remplacer un personnage',desc:'Choisis l’acteur présent et sa nouvelle apparence depuis la RefBank.',needs:'Personnage ciblé + référence d’apparence',example:'Replace the selected actor, preserve the original motion and scene.',targetPlaceholder:'woman, man, person…',promptHelp:'Décris le personnage à suivre en anglais simple. La photo de référence définit la nouvelle apparence.'},
 remove_element:{title:'Supprimer un élément',desc:'Même pipeline de suppression 5 s V10.73 (Krea + masque vert + H3/LoRA + fenêtres 22/17). Encadre un objet inconnu pour le suivre par pixels, sans reconnaissance SAM3.',needs:'Nom de l’objet OU encadrement manuel. Le suivi par pixels se prévisualise avant H3.',example:'Remove the selected object completely and reconstruct the original background from the first frame.',targetPlaceholder:'chair, microphone, mug… (ou encadre)',promptHelp:'Le masque suit l’objet. Pour un objet inconnu, encadre-le : le suivi par pixels n’utilise pas le vocabulaire de SAM3.'},
 replace_element:{title:'Remplacer un élément',desc:'Même suivi et fenêtres temporelles V10.73. Une photo du nouvel objet est FACULTATIVE : sans photo, Krea crée automatiquement une image-guide à partir de ta description.',needs:'Description du NOUVEL objet + nom OU encadrement de l’ancien. Photo facultative.',example:'',targetPlaceholder:'chair, microphone, bag… (ou encadre)',promptHelp:'Décris le nouvel objet dans Résultat voulu ou directement dans Instruction de modification. La photo, si ajoutée, aide à conserver son apparence.'},
 move_camera:{title:'Changer la caméra',desc:'Recompose le plan existant depuis un nouvel angle avec CrossView-Warp et la profondeur MoGe.',needs:'Angle horizontal et vertical, même vidéo d’origine',example:'Keep the same actors, movement and timing from another cinematic angle.',targetPlaceholder:'',promptHelp:'Pas besoin de texte compliqué : règle surtout les deux curseurs de caméra, puis teste la reprojection MoGe.'},
 replace_background:{title:'Remplacer le décor',desc:'Décris le personnage à garder. SAM3 le suit sur toutes les images, inverse son masque et H3 transforme uniquement le décor.',needs:'Personnage à conserver + description du nouveau décor (encadrement initial facultatif)',example:'Keep the actor intact and place them in the new environment.',targetPlaceholder:'woman, man, person…',promptHelp:'Dans « Nouveau décor », décris directement le nouvel environnement souhaité. Ex. : a neon cyberpunk bedroom.'},
 local_edit:{title:'Retoucher une zone',desc:'Décris l’objet ou le vêtement, ou encadre-le sur la première image du plan. SAM3 suit son masque même s’il bouge.',needs:'Sujet à suivre (description ou sélection initiale) + instruction de retouche',example:'Replace the selected microphone with a banana. Preserve the rest of the clip exactly.',targetPlaceholder:'microphone, shirt, mug, laptop…',promptHelp:'Écris la demande complète en anglais simple. Ex. : Replace the selected microphone with a banana. Preserve the rest of the clip exactly.'}
};


function syncPrompt(){
 const target=($('retTarget').value||'').trim()||'subject';
 const extra=($('retActionText')?.value||'').trim();
 if(mode==='remove_person'){
   $('retPrompt').readOnly=false;
   $('retPrompt').value=`Remove the green-masked ${target} and reconstruct the background. Preserve the rest of the video, including its camera motion and frame timing.`+(extra?` ${extra}`:'');
 }else if(mode==='remove_element'){
   $('retPrompt').value=`Remove the selected ${target} completely from the first frame and reconstruct the background without modifying the rest.`+(extra?' '+extra:'');
 }else if(mode==='replace_element'){
   // The description is the authority. Photo is optional. Never make the prompt
   // refer to <Picture 1> unless there really is a user-supplied image.
   if(extra){
     const low=extra.toLowerCase();
     if(extra.split(/\s+/).length<=12 && !/(replace|change|swap|turn|make|keep|preserve|remove)/.test(low)){
       $('retPrompt').value=`Replace only the selected ${target} with ${extra}. Preserve the camera motion, scene and timing from frame zero.`;
     }else $('retPrompt').value=extra;
   }
   // With an empty "Résultat voulu" field, leave the user-authored prompt alone.
 }else if(mode==='local_edit'){
   $('retPrompt').readOnly=false;
   if(!extra){
     $('retPrompt').value=`Replace the selected ${target}. Preserve the rest of the clip exactly.`;
   }else{
     const low=extra.toLowerCase();
     if(extra.split(/\s+/).length<=5 && !/(replace|change|swap|turn|make|keep|preserve|remove)/.test(low)) $('retPrompt').value=`Replace the selected ${target} with ${extra}. Preserve the rest of the clip exactly.`;
     else $('retPrompt').value=extra;
   }
 }else{
   $('retPrompt').readOnly=false;
 }
}

let jobFingerprint='',mode='swap_person',sourceMode='project',source=null,retProjectName='',clipList={},uploads=[],loadedRefs=[],reference='',referenceURL='',region=null,maskDrawing=false,coords0=null,readiness=null,jobID='',uploading=false,jobTicker=0;
async function api(path,data){const r=await fetch(path,{method:data===undefined?'GET':'POST',headers:{'Content-Type':'application/json'},body:data===undefined?undefined:JSON.stringify(data)});const j=await r.json();if(!r.ok)throw Error(j.error||'HTTP '+r.status);return j;}
function msg(text,type=''){const el=$('retStatus');el.textContent=text;el.className='retouchStatus '+type;}
function error(e){msg(e?.message||String(e),'error')}
function option(value,label){return `<option value="${esc(value)}">${esc(label)}</option>`}
function repaintRef(){const field=$('retImageResult');field.classList.toggle('hidden',!reference);$('retImagePreview').src=referenceURL||'';$('retImageName').textContent=reference?reference.split(/[\\/]/).pop():'';}
function setMode(newMode){if(!modeInfo[newMode])return;if(mode!==newMode){region=null;paintRegion();$('retTarget').value='';if($('retActionText'))$('retActionText').value='';}
 if(!['swap_person','replace_element'].includes(newMode) && reference){reference='';referenceURL=''; if($('retRefBank')) $('retRefBank').value=''; repaintRef();}
 mode=newMode;
 for(const b of document.querySelectorAll('.retouchMode'))b.classList.toggle('isActive',b.dataset.mode===mode);
 const info=modeInfo[mode];$('retModeTitle').textContent=info.title;$('retModeDesc').textContent=info.desc;$('retRequirementsText').textContent=info.needs;$('retPrompt').value=info.example;$('retTarget').placeholder=info.targetPlaceholder||'';if($('retPromptHelp'))$('retPromptHelp').textContent=info.promptHelp||'';
 $('retTargetFields').classList.toggle('hidden',mode==='move_camera');
 $('retReferenceFields').classList.toggle('hidden',!['swap_person','replace_element'].includes(mode));
 $('retCameraFields').classList.toggle('hidden',mode!=='move_camera');
 if(mode==='move_camera'&&Number($('retAzimuth').value)===0&&Number($('retElevation').value)===0){$('retAzimuth').value='-30';$('retElevation').value='15';$('retAzValue').textContent='-30°';$('retElValue').textContent='15°';}
 if($('retMaskCheck'))$('retMaskCheck').textContent=mode==='move_camera'?'◎ Tester la reprojection MoGe · sans H3':(['remove_element','replace_element'].includes(mode)&&region?'◎ Tester suivi pixels · sans H3':'◎ Tester suivi SAM3 · sans H3');
 $('retBackgroundFields').classList.toggle('hidden',mode!=='replace_background');
 $('retModelFields').classList.toggle('hidden',!['local_edit','replace_background'].includes(mode));$('retQualityFields').classList.toggle('hidden',['remove_person','swap_person','remove_element','replace_element'].includes(mode));
 if(!['local_edit','replace_background'].includes(mode) && $('retBaseModel').value==='fl2va') $('retBaseModel').value='singularity';
 $('retActionFields').classList.toggle('hidden',!['remove_person','local_edit','remove_element','replace_element'].includes(mode));
 if(mode==='remove_person' || mode==='remove_element'){ $('retActionLabel').firstChild.textContent='Détails supplémentaires (optionnel)'; $('retActionText').placeholder='Preserve lighting and camera motion.'; $('retActionHelp').textContent='Le prompt reste libre, mais la suppression suit le workflow Akatz avec clean first frame.'; }
 else if(mode==='local_edit' || mode==='replace_element'){ $('retActionLabel').firstChild.textContent='Résultat voulu'; $('retActionText').placeholder='banana, red tie, silver laptop…'; $('retActionHelp').textContent='Décris seulement le résultat souhaité ; la phrase H3 finale est générée automatiquement.'; }
 $('retMaskBar').classList.toggle('hidden',mode==='move_camera');
 $('retRegionText').classList.toggle('hidden',mode==='move_camera');
 $('retTargetLabel').firstChild.textContent=({remove_person:'Personnage à effacer',swap_person:'Personnage à remplacer',replace_background:'Personnage à conserver (suivi SAM3)',local_edit:'Objet / vêtement / élément à suivre (SAM3)',remove_element:'Objet à supprimer (ou encadrer)',replace_element:'Objet à remplacer (ou encadrer)'})[mode]||'Sujet du plan';$('retRefLabel').textContent='RÉFÉRENCE VISUELLE';$('retRefHelp').textContent=mode==='swap_person'?'Image du nouvel acteur / apparence depuis la RefBank.':mode==='replace_element'?'Photo facultative ; sans photo Krea crée une première image selon ta description.':'';
 $('retDrawMask').textContent=mode==='replace_background'?'◎ Encadrer la personne à garder':'◎ Encadrer l’élément à suivre';
 if(!['remove_element','replace_element'].includes(mode)) $('retRegionText').textContent='Décris le sujet à suivre, ou encadre-le sur la première image du plan. SAM3 calcule le masque de chaque image pendant le mouvement.';
 if(['remove_element','replace_element'].includes(mode)) $('retRegionText').textContent='Encadre le sujet sur la première image : suivi DIRECT par pixels et mouvement (sans reconnaissance de catégorie SAM3). Teste le masque vidéo avant de lancer H3. Sans cadre, détection SAM3 par texte.';
 syncPrompt();
 endMask();msg('');repaintReady();}
function setSourceMode(value){window.retouchChainSource=null;sourceMode=value;source=null;document.querySelector('#retSourceProject').classList.toggle('isActive',value==='project');document.querySelector('#retSourceImport').classList.toggle('isActive',value==='upload');$('retProjectControls').classList.toggle('hidden',value!=='project');$('retImportControls').classList.toggle('hidden',value!=='upload');pickSource();}
function pickSource(){window.retouchChainSource=null;let uri='',name='',where='';
 if(sourceMode==='project'){
  const id=$('retClip').value;const entry=clipList[id];const variant=$('retVariant').value;
  if(entry){uri=entry.raw_url;if(uri){source={type:'project',project:retProjectName,clip:id,variant};name='Clip '+id;where=variant.toUpperCase()+' · '+retProjectName;}}
 }else if(uploads.length){const entry=uploads[0];source={type:'upload',id:entry.id};uri=entry.url;name=entry.name;where='Vidéo importée'}
 const player=$('retVideo');player.pause();if(uri){player.src=uri;player.load()}else{player.removeAttribute('src');player.load()}$('retShotStart').value='0';$('retShotEnd').value='0';
 $('retVideoBlank').classList.toggle('hidden',!!uri);$('retPlayingLabel').textContent=name||'Aucun clip';$('retPlayingMeta').textContent=where||'Choisis ton clip ou importe ton MP4';$('retSourceChip').textContent=uri?'Clip prêt':'Aucune vidéo';endMask();region=null;paintRegion();}
async function loadProject(){retProjectName=$('retProject').value;clipList={};loadedRefs=[];reference='';referenceURL='';repaintRef();
 if(!retProjectName){$('retClip').innerHTML=option('','Aucun projet');$('retRefBank').innerHTML=option('','Aucune référence');pickSource();return;}
 try{const [data,refs]=await Promise.all([api('/api/project?name='+encodeURIComponent(retProjectName)),api('/api/ref-images?name='+encodeURIComponent(retProjectName))]);
  clipList=data.clips||{};let clips=Object.keys(clipList).filter(k=>clipList[k].raw_url).sort((a,b)=>Number(a)-Number(b));
  $('retClip').innerHTML=clips.length?clips.map(k=>option(k,'Clip '+k+' · Scène '+(clipList[k].scene||'?')+' / Plan '+(clipList[k].plan||'?'))).join(''):option('','Aucun clip terminé');
  $('retVariant').value='raw';
  loadedRefs=refs||[];$('retRefBank').innerHTML=option('','Choisir une image du projet…')+loadedRefs.map((r,i)=>option(i,r.name+' · '+(r.group||'RefBank'))).join('');
  pickSource();
 }catch(e){error(e)}}
async function loadWorkspace(){try{const j=await api('/api/retouches');uploads=j.videos||[];const present=$('retProject').value;const projects=j.projects||[];$('retProject').innerHTML=projects.length?projects.map(x=>option(x.name,x.title||x.name)).join(''):option('','Aucun projet');
 if(projects.some(x=>x.name===present))$('retProject').value=present;
 if(sourceMode==='project')await loadProject();else if(sourceMode!=='review')pickSource();renderJobs(j.jobs||[]);
 }catch(e){error(e)}}
async function checkReady(){try{readiness=await api('/api/retouches/readiness');repaintReady()}catch(e){error(e)}}
function repaintReady(){const el=$('retReadiness');if(!el)return;if(!readiness){el.textContent='Vérification…';return}
 if(!readiness.comfy_connected){el.innerHTML='<span style="color:#f3b49c">ComfyUI inaccessible (port 8188). Démarre ComfyUI, puis clique Vérifier.</span>';return}
 el.innerHTML=Object.entries(readiness.modes||{}).map(([key,row])=>`<div class="retouchDependencyItem"><b>${esc(modeInfo[key]?.title||key)}</b><small class="${row.ready?'ready':''}">${row.ready?'✓ Dépendances présentes'+(row.warning?' · '+esc(row.warning):''):esc((row.missing||[]).join(' · '))}</small></div>`).join('');
}
function fmtElapsed(seconds){seconds=Math.max(0,Math.floor(seconds||0));const h=Math.floor(seconds/3600),m=Math.floor((seconds%3600)/60),s=seconds%60;return (h?String(h).padStart(2,'0')+':':'')+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');}
let reviewDecisions={},reviewActiveSignature='',reviewSelectedKey='',reviewDismissed='';
function reviewKey(row){return (row.__extra?'new':'legacy')+':'+row.id}
function reviewVideoURL(row){return (row.__extra?'/api/retouches/new/output/':'/api/retouches/output/')+encodeURIComponent(row.id)}
function reviewActionURL(row){return reviewDecisions[reviewKey(row)]||{}}
function renderActiveJob(row){
 const el=$('retActiveJob');if(!el)return;
 if(!row){if(reviewActiveSignature!=='empty'){el.innerHTML='<div class="retouchHistoryEmpty">Aucun rendu en cours.</div>';reviewActiveSignature='empty';}return}
 const decision=reviewActionURL(row),done=row.status==='complete',isNative=!!row.__extra;
 const signature=[reviewKey(row),row.status,decision.state||'',row.stage||'',row.part||'',row.error||''].join(':');
 if(reviewActiveSignature===signature)return;reviewActiveSignature=signature;
 const label=isNative?(row.name||row.mode):(modeInfo[row.mode]?.title||row.mode);
 const state=row.status==='error'?(row.error||'Erreur'):done?'Rendu terminé · contrôle du résultat':(row.stage||'Génération en cours');
 const original=(row.source?.type==='project'||isNative)?'RAW du projet':'vidéo importée';
 const video=done?`<div class="retReviewPlayer"><video controls playsinline preload="metadata" src="${reviewVideoURL(row)}"></video><small>Résultat de ${esc(label)} · source : ${esc(original)}</small></div>`:'';
 const follow='';
 const actions=done?`<div class="retReviewActions">
  <button type="button" data-ret-review="redo" data-kind="${isNative?'new':'legacy'}" data-id="${esc(row.id)}">↻ Refaire modifications</button>
  <button type="button" data-ret-review="continue" data-kind="${isNative?'new':'legacy'}" data-id="${esc(row.id)}" ${follow}>➜ Continuer modifications</button>
  <button class="primary" type="button" data-ret-review="approve" data-kind="${isNative?'new':'legacy'}" data-id="${esc(row.id)}">✓ Valider · sauvegarder</button>
 </div>`:'';
 const download=decision.state==='approved' && decision.saved_url ? `<a class="retReviewSavedLink" href="${esc(decision.saved_url)}" download="retouche_${esc(row.id)}.mp4">↓ Télécharger le MP4 validé</a>` : '';
 const message=decision.state==='approved'?'✓ Version finale validée et sauvegardée. Le RAW original est intact.':decision.state==='continued'?'✓ Étape validée. Le MP4 devient la source de la prochaine retouche (tous moteurs).':decision.state==='redo'?'Nouvelle consigne attendue sur la source précédente.':'';
 el.innerHTML=`<div class="retouchRunningBox"><div><b>${esc(label)}</b><small>${esc(row.status)} · ${esc(state)}</small></div><div class="retouchRunningState ${esc(row.status)}">${done?'✓':row.status==='error'?'!':'⏳'}</div></div>${video}${actions}${message?`<p class="retReviewMessage">${esc(message)}</p>`:''}${download}`;
}
function renderJobs(rows){
 const extra=(window.__retouchExtraJobs||[]).map(j=>Object.assign({__extra:true},j));
 const all=[...extra,...rows].sort((a,b)=>(b.created_at||0)-(a.created_at||0));
 const active=all.find(j=>['queued','preparing','preparing_clean_plate','checking_mask','submitting','rendering','compositing','cancelling'].includes(j.status));
 const finished=all.find(j=>j.status==='complete' && !j.mask_only && reviewActionURL(j).state!=='cancelled' && reviewKey(j)!==reviewDismissed);
 const selected=active||finished||null;
 renderActiveJob(selected);
 const stopBtn=$('retStop');if(stopBtn){stopBtn.classList.toggle('hidden',!selected||selected.status==='cancelling'||['approved','continued'].includes(reviewActionURL(selected).state));stopBtn.dataset.job=selected?(selected.__extra?'new:'+selected.id:selected.id):'';stopBtn.dataset.review=selected&&selected.status==='complete'?'cancel':'';stopBtn.textContent=selected&&selected.status==='complete'?'✕ Annuler cette version':'■ Stop génération (sans fermer ComfyUI)';}
 const signature=all.map(j=>j.id+':'+j.status+':'+(j.finished_at||'')+':'+(j.error||'')+':'+(j.stage||'')+':'+(j.part||'')+':'+(reviewActionURL(j).state||'')).join('|');
 if(signature===jobFingerprint)return;jobFingerprint=signature;
 $('retJobs').innerHTML=all.length?all.map(j=>{
  const when=new Date((j.created_at||0)*1000).toLocaleString('fr-FR');
  const video=j.status==='complete'?`<div class="retouchResultActions"><a href="${reviewVideoURL(j)}" target="_blank" rel="noopener">Ouvrir le MP4 ↗</a></div>`:'';
  const errorText=j.status==='error'?`<div class="retouchJobError">${esc(j.error||'Erreur inconnue')}</div>`:'';
  const title=j.__extra?((j.name||j.mode)+' — RAW'):(modeInfo[j.mode]?.title||j.mode);
  const current=reviewActionURL(j),reviewed=current.state==='approved'?' · ✓ Validé':current.state==='continued'?' · ✓ Étape conservée':current.state==='cancelled'?' · Annulé':'';
  return `<div class="retouchJob"><div><b>${esc(title)}</b><small>${when} · ${esc(j.status)}${reviewed}</small></div>${j.__extra&&j.prompt_method?`<div class="retouchResultActions"><a href="#" data-prompt-id="${esc(j.id)}">Voir le prompt H3 envoyé (${esc(j.prompt_method)})</a></div>`:''}${video}${errorText}</div>`;
 }).join(''):'<div class="retouchHistoryEmpty">Aucune retouche lancée.</div>';
}
async function jobs(){try{
 const [d,states]=await Promise.all([api('/api/retouches'),api('/api/retouches/review/choices')]);
 reviewDecisions=states.choices||{};renderJobs(d.jobs||[]);
 if(jobID){const row=(d.jobs||[]).find(j=>j.id===jobID);if(row?.status==='complete'){msg('✓ Retouche terminée : résultat visible dans le bloc 03.','success');jobID='';}else if(row?.status==='error'){msg(row.error,'error');jobID='';}else if(row){const elapsed=fmtElapsed((Date.now()/1000)-(row.created_at||Date.now()/1000));msg('Moteur : '+row.status+' · '+elapsed);}}
 }catch(e){error(e)}}
function closestClipKey(clip){return Object.keys(clipList).find(k=>Number(k)===Number(clip))||String(clip)}
function selectReviewSource(kind,id){
 sourceMode='review';source={type:'review',kind,id};
 window.retouchChainSource={...source};
 $('retSourceProject').classList.remove('isActive');$('retSourceImport').classList.remove('isActive');
 $('retProjectControls').classList.add('hidden');$('retImportControls').classList.add('hidden');
 const video=$('retVideo');video.pause();
 video.src=(kind==='new'?'/api/retouches/new/output/':'/api/retouches/output/')+encodeURIComponent(id);video.load();
 $('retVideoBlank').classList.add('hidden');$('retPlayingLabel').textContent='Dernier MP4 validé · nouvelle source';
 $('retPlayingMeta').textContent='Continuation depuis le dernier résultat, pour les 9 moteurs';
 $('retSourceChip').textContent='Suite de retouche';$('retShotStart').value='0';$('retShotEnd').value='0';
 region=null;endMask();paintRegion();
}
async function actionReview(action,kind,id){
 try{
  const response=await api('/api/retouches/review/decision',{action,kind,id});
  if(action==='approve'){
   msg(response.returned_to_film?'✓ MP4 validé, retour au refine HD du film.':'✓ Copie MP4 validée et sauvegardée, sans remplacer le RAW original.','success');
   if(window.retouchReturnToDirection && (response.returned_to_film ||
      (response.project && window.retouchFilmContext?.project===response.project && Number(window.retouchFilmContext.clip)===Number(response.clip)))){
    window.retouchReturnToDirection(response);
   }
  }else if(action==='cancel'){
   reviewDismissed=kind+':'+id;
   msg('Version annulée. Le RAW et les anciennes versions restent intacts.','success');
  }else if(action==='redo'){
   const row=(kind==='new'?(window.__retouchExtraJobs||[]):(await api('/api/retouches')).jobs||[]).find(j=>j.id===id);
   if(!row)throw Error('Retouche introuvable');
   if(kind==='new'){
    const button=document.querySelector(`[data-new-engine="${row.mode}"]`);if(button)button.click();
   }else {
    const button=document.querySelector(`[data-mode="${row.mode}"]`);if(button)button.click();
   }
   const original=kind==='new'?(row.source||{type:'project',project:row.project,clip:String(row.clip)}):(row.source||{});
   if(original.type==='project'){
    setSourceMode('project');$('retProject').value=original.project;await loadProject();$('retClip').value=closestClipKey(original.clip);pickSource();
   }else if(original.type==='review')selectReviewSource(original.kind,original.id);
   else if(original.type==='upload') {const ix=uploads.findIndex(x=>x.id===original.id);if(ix>0)uploads.unshift(uploads.splice(ix,1)[0]);setSourceMode('upload');}
   else {throw Error('Source précédente indisponible, sélectionne-la de nouveau.');}
   msg('Refaire : modifie ton instruction et lance un nouvel essai. Aucun rendu automatique.','success');
  }else if(action==='continue'){
   selectReviewSource(kind,id);msg('✓ Étape validée. Le dernier MP4 est prêt pour une nouvelle retouche, avec n’importe quel moteur. Rien n’a encore été envoyé à Direction.','success');
  }
  await jobs();
 }catch(e){error(e)}
}
$('retActiveJob').addEventListener('click',e=>{const button=e.target.closest('[data-ret-review]');if(!button)return;button.disabled=true;actionReview(button.dataset.retReview,button.dataset.kind,button.dataset.id).finally(()=>button.disabled=false)});
async function importVideo(input){const file=input.files?.[0];if(!file)return;if(file.size>700*1024*1024){msg('Vidéo trop volumineuse (700 Mo maximum).','error');return}
 uploading=true;msg('Import du MP4…');try{const r=await fetch('/api/retouches/import',{method:'POST',headers:{'Content-Type':'application/octet-stream','X-Filename':encodeURIComponent(file.name)},body:file});const x=await r.json();if(!r.ok)throw Error(x.error||'Import refusé');uploads.unshift(x);$('retImportedName').textContent='✓ '+x.name;pickSource();msg('Vidéo importée : '+x.name,'success')}catch(e){error(e)}finally{uploading=false;input.value=''}}
async function importRef(input){const file=input.files?.[0];if(!file)return;msg('Import de la référence…');try{const r=await fetch('/api/upload',{method:'POST',headers:{'Content-Type':'application/octet-stream','X-Filename':encodeURIComponent(file.name)},body:file});const x=await r.json();if(!r.ok)throw Error(x.error||'Import de référence refusé');reference=x.path;referenceURL=x.url;repaintRef();msg('Image de référence prête.','success')}catch(e){error(e)}finally{input.value=''}}
function maskBounds(){const video=$('retVideo'),full=$('retMaskOverlay').getBoundingClientRect(),vw=video.videoWidth||16,vh=video.videoHeight||9;
 const ratio=Math.min(full.width/vw,full.height/vh),dw=vw*ratio,dh=vh*ratio;
 return {left:full.left+(full.width-dw)/2,top:full.top+(full.height-dh)/2,width:dw,height:dh};}
function normalized(evt){const b=maskBounds();return {x:Math.max(0,Math.min(1,(evt.clientX-b.left)/b.width)),y:Math.max(0,Math.min(1,(evt.clientY-b.top)/b.height))}}
function paintRegion(){const box=$('retMaskBox');if(!region){box.classList.add('hidden');return}const b=maskBounds(),parent=$('retMaskOverlay').getBoundingClientRect();box.classList.remove('hidden');Object.assign(box.style,{left:(b.left-parent.left+region[0]*b.width)+'px',top:(b.top-parent.top+region[1]*b.height)+'px',width:(region[2]*b.width)+'px',height:(region[3]*b.height)+'px'});}
function endMask(){if($('retMaskCheck')&&['remove_element','replace_element'].includes(mode))$('retMaskCheck').textContent=region?'◎ Tester suivi PIXELS · sans H3':'◎ Tester suivi SAM3 · sans H3';maskDrawing=false;$('retMaskOverlay').classList.remove('isDrawing');$('retMaskOverlay').classList.toggle('hidden',!region);$('retDrawMask').classList.remove('isActive');}
async function startJob(maskOnly=false,testClip=false){try{if(uploading)throw Error('Import vidéo en cours');if(!source)throw Error('Choisis un clip ou importe une vidéo');
 if(mode==='swap_person'&&(!reference||!$('retTarget').value.trim()))throw Error("Décris l’acteur à remplacer (de préférence en anglais simple : woman, man, person) et ajoute une image du nouvel acteur");if(mode==='remove_person'&&!$('retTarget').value.trim())throw Error('Décris clairement le personnage à supprimer ; le fond initial sera généré automatiquement.');
 if(['remove_element','replace_element'].includes(mode)&&!region&&!$('retTarget').value.trim())throw Error('Décris ou encadre l’objet à suivre');if(mode==='replace_element'&&!$('retPrompt').value.trim())throw Error('Décris le nouvel objet dans Résultat voulu ou dans Instruction de modification. La photo est facultative.');
 if(mode==='local_edit'&&!region&&!$('retTarget').value.trim())throw Error('Décris le sujet à suivre ou encadre-le sur la première image du plan');
 
 const payload={mask_only:maskOnly,test_clip:testClip,quality:$('retQuality').value,shot_start:Number($('retShotStart').value||0),shot_end:Number($('retShotEnd').value||0),mode,source,model_choice:$('retBaseModel').value,reference_path:((mode==='swap_person'||mode==='replace_element')?reference:''),target:$('retTarget').value.trim(),instructions:$('retPrompt').value.trim(),background_prompt:$('retBackground').value.trim(),azimuth:Number($('retAzimuth').value),elevation:Number($('retElevation').value),region};
 const response=await api('/api/retouches/start',payload);jobID=response.id;msg(maskOnly?(mode==='move_camera'?'Calcul du warp MoGe en cours : aucun rendu H3.':(['remove_element','replace_element'].includes(mode)&&region?'Suivi PIXELS en cours : aucune génération H3.':'Suivi SAM3 en cours : aucune génération H3.')):'Retouche H3 lancée après pré-validation · la vidéo d’origine reste intacte.','success');setTimeout(jobs,400);
 }catch(e){error(e)}}
async function saveDraft(){try{if(!source)throw Error('Choisis une vidéo');const response=await api('/api/retouches/draft',{mode,source,target:$('retTarget').value,instructions:$('retPrompt').value,background_prompt:$('retBackground').value,reference_name:reference.split(/[\\/]/).pop(),reference_url:referenceURL,azimuth:Number($('retAzimuth').value),elevation:Number($('retElevation').value),region,shot_start:Number($('retShotStart').value||0),shot_end:Number($('retShotEnd').value||0)});msg(response.message,'success')}catch(e){error(e)}}
function openFromFilm(){setSourceMode('project');if(typeof projectName!=='undefined'&&projectName){$('retProject').value=projectName;}return loadProject()}
window.retouchOnOpen=async()=>{await loadWorkspace();if(window.retouchFilmContext){const ctx=window.retouchFilmContext;setSourceMode('project');$('retProject').value=ctx.project;await loadProject();$('retClip').value=closestClipKey(ctx.clip);pickSource();}await checkReady()};
document.querySelectorAll('.retouchMode').forEach(b=>b.addEventListener('click',()=>setMode(b.dataset.mode)));
$('retSourceProject').onclick=()=>setSourceMode('project');$('retSourceImport').onclick=()=>setSourceMode('upload');
$('retProject').onchange=loadProject;$('retClip').onchange=pickSource;$('retVariant').onchange=pickSource;$('retImportVideo').onchange=e=>importVideo(e.target);
$('retImportImage').onchange=e=>importRef(e.target);$('retRefBank').onchange=()=>{const ix=$('retRefBank').value;const r=ix===''?null:loadedRefs[Number(ix)];reference=r?.path||'';referenceURL=r?.url||'';repaintRef()};
$('retAzimuth').oninput=()=>{$('retAzValue').textContent=$('retAzimuth').value+'°'};$('retElevation').oninput=()=>{$('retElValue').textContent=$('retElevation').value+'°'};
$('retTarget').addEventListener('input',syncPrompt); if($('retActionText')) $('retActionText').addEventListener('input',syncPrompt);
$('retBaseModel').addEventListener('change',()=>{ if(!['local_edit','replace_background'].includes(mode) && $('retBaseModel').value==='fl2va'){ $('retBaseModel').value='singularity'; msg('FL2VA n’est utilisé ici que pour décor / zone ; retour automatique sur Singularity.'); }});
$('retDrawMask').onclick=()=>{if(!source)return msg('Choisis une vidéo avant de sélectionner le sujet.','error');maskDrawing=!maskDrawing;if(maskDrawing){const v=$('retVideo');v.pause();v.currentTime=Number($('retShotStart').value||0);msg('Encadre le sujet sur le PREMIER cadre du plan. SAM3 le suivra ensuite.')} $('retMaskOverlay').classList.toggle('isDrawing',maskDrawing);$('retMaskOverlay').classList.toggle('hidden',!maskDrawing&&!region);$('retDrawMask').classList.toggle('isActive',maskDrawing)};
$('retClearMask').onclick=()=>{region=null;paintRegion();endMask()};$('retMarkStart').onclick=()=>{$('retShotStart').value=Math.max(0,$('retVideo').currentTime||0).toFixed(3);region=null;paintRegion();endMask()};$('retMarkEnd').onclick=()=>{$('retShotEnd').value=Math.max(0,$('retVideo').currentTime||0).toFixed(3)};$('retShotReset').onclick=()=>{$('retShotStart').value='0';$('retShotEnd').value='0';region=null;paintRegion();endMask()};const overlay=$('retMaskOverlay');
overlay.addEventListener('pointerdown',e=>{if(!maskDrawing)return;coords0=normalized(e);overlay.setPointerCapture(e.pointerId);e.preventDefault()});
overlay.addEventListener('pointermove',e=>{if(!coords0)return;const at=normalized(e);region=[Math.min(coords0.x,at.x),Math.min(coords0.y,at.y),Math.abs(coords0.x-at.x),Math.abs(coords0.y-at.y)];paintRegion()});
overlay.addEventListener('pointerup',e=>{if(!coords0)return;const at=normalized(e);region=[Math.min(coords0.x,at.x),Math.min(coords0.y,at.y),Math.abs(coords0.x-at.x),Math.abs(coords0.y-at.y)];coords0=null;if(region[2]<0.025||region[3]<0.025){region=null;msg('Zone trop petite : maintiens et glisse pour encadrer.','error')}paintRegion();endMask()});
window.addEventListener('resize',paintRegion);$('retGenerate').onclick=()=>startJob(false,false);if($('retMaskCheck'))$('retMaskCheck').onclick=()=>startJob(true,false);if($('retQuickEdit'))$('retQuickEdit').onclick=()=>startJob(false,true);$('retSaveDraft').onclick=saveDraft;if($('retCheck'))$('retCheck').onclick=checkReady;$('retRefreshJobs').onclick=jobs;$('retStop').onclick=async()=>{const id=$('retStop').dataset.job;if(!id)return;try{if($('retStop').dataset.review==='cancel'){const kind=String(id).startsWith('new:')?'new':'legacy';await actionReview('cancel',kind,kind==='new'?String(id).slice(4):id);return;} if(String(id).startsWith('new:')){ await fetch('/api/retouches/new/stop',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:String(id).slice(4)})}).then(async r=>{const x=await r.json(); if(!r.ok) throw Error(x.error||'Arrêt refusé'); return x;}); msg('Demande d’arrêt envoyée uniquement à cette retouche RAW. ComfyUI reste ouvert.','success'); if(window.refreshNewRetouchJobs) await window.refreshNewRetouchJobs(); } else { await api('/api/retouches/stop',{id}); msg('Demande d’arrêt envoyée uniquement à cette retouche. ComfyUI reste ouvert.','success'); await jobs(); } }catch(e){error(e)}};
if($('retInstallWorkflows'))$('retInstallWorkflows').onclick=async()=>{const button=$('retInstallWorkflows');button.disabled=true;msg('Téléchargement des fichiers JSON de référence…');try{const x=await api('/api/retouches/install-workflows',{});const errs=(x.workflows||[]).filter(x=>x.status==='erreur');msg(errs.length?'Workflows : '+errs.map(x=>x.mode+' : '+x.message).join(' | '):'Workflows des auteurs installés. Vérifie les nodes et les LoRA.',errs.length?'error':'success');await checkReady()}catch(e){error(e)}finally{button.disabled=false}};
const direct=$('retouchCurrentClip');if(direct)direct.onclick=async()=>{if(!projectName||!selected)return msg('Choisis un clip sur la timeline.','error');changeView('retouches');setSourceMode('project');$('retProject').value=projectName;await loadProject();$('retClip').value=String(selected);pickSource()};
window.retouchOpenProjectRaw=async function(project,clip){
 window.retouchFilmContext={project:String(project),clip:String(clip)};
 changeView('retouches');await loadWorkspace();setSourceMode('project');$('retProject').value=String(project);
 await loadProject();$('retClip').value=closestClipKey(clip);pickSource();
 msg('RAW du film sélectionné. Valider une retouche renverra le MP4 au refine HD du film si Direction attend ce clip.','success');
};
window.retouchLegacyRefresh=jobs;setMode('swap_person');jobTicker=setInterval(()=>{if(!document.getElementById('retouches').classList.contains('hidden'))jobs()},4000);
})();
