@echo off
setlocal
set "H3_RETOUCH_ONLY=1"
set "COMFYUI_DIR=C:\AI\ComfyUI_windows_portable\ComfyUI"
set "PY=C:\AI\ComfyUI_windows_portable\python_embeded\python.exe"
if not exist "%PY%" (
 echo ERREUR : Python embarque ComfyUI introuvable.
 pause
 exit /b 1
)
cd /d "%~dp0"
echo V10.105 - Insert: Gemma H3 + guide Krea neutre + 17 frames techniques.
echo Retake V10.94 et FilmMaker inchanges. Aucun masque Retake requis pour Performance ou Ajouter element.
echo Aucun pip, DiffSynth, CUDA ou modele installe.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALLER-NOUVEAUX-MOTEURS-V10_66.ps1"
if errorlevel 1 (
 echo Verification des nodes ComfyUI en echec.
 pause
 exit /b 1
)
echo Studio Retouches V10.105 : http://127.0.0.1:7861/
"%PY%" -u "%~dp0studio_web.py" --port 7861
if errorlevel 1 pause
endlocal
