"""Generate a real visual insertion keyframe automatically using existing Studio Krea2.

This is ONLY used by the additive H3 insertion engine. It never changes the
legacy Retouches Krea2 removal graph or the FilmMaker production workflow.
"""
from __future__ import annotations
import shutil
from pathlib import Path
from PIL import Image, ImageDraw, ImageChops, ImageStat
import retouches_clean_plate as prior


def make_mask(original:Path, destination:Path, rect):
    x,y,w,h=rect
    with Image.open(original) as image:
        iw,ih=image.size
        a=int(round(x/100*iw));b=int(round(y/100*ih))
        c=int(round((x+w)/100*iw));d=int(round((y+h)/100*ih))
        a=max(0,min(iw-2,a));b=max(0,min(ih-2,b))
        c=max(a+2,min(iw,c));d=max(b+2,min(ih,d))
        mask=Image.new('RGB',(iw,ih),(0,0,0))
        ImageDraw.Draw(mask).rectangle((a,b,c-1,d-1),fill=(255,255,255))
        mask.save(destination)
    return destination


def build_graph(info, frame_name, mask_name, instruction, job_id, reference_path='', guide_prompt=None):
    prior.validate(info)
    graph=prior.graph(info,frame_name,mask_name,'neutral spatial placeholder',job_id)
    if guide_prompt is None or not str(guide_prompt).strip():
        raise ValueError('Insertion : prompt neutre Krea obligatoire')
    if reference_path:
        raise ValueError('Insertion : la référence <Picture 1> ne doit jamais être envoyée à Krea')
    graph['6']['inputs']['text']=str(guide_prompt).strip()
    graph['9']['inputs']['LanPaint_Info']='Krea2/LanPaint local insert guide for H3 — ADDITIVE'
    graph['9']['inputs']['seed']=int(job_id[:8],16)
    graph['11']['inputs']['filename_prefix']='H3FilmSimple/retouches/new_insert/'+job_id+'_guide'
    return graph


def verify_visual_change(original:Path,generated:Path,mask_path:Path,threshold:float=4.0):
    with Image.open(original) as old,Image.open(generated) as new,Image.open(mask_path) as mask:
        if old.size!=new.size:raise RuntimeError('Krea2 : taille du guide différente de la source')
        m=mask.convert('L')
        change=ImageStat.Stat(ImageChops.difference(old.convert('RGB'),new.convert('RGB')),mask=m).mean
        avg=sum(change)/max(1,len(change))
        if avg<threshold:
            raise RuntimeError(f'Krea2 n’a pas créé de nouvel élément visible dans la zone ({avg:.1f}/255). Génération H3 évitée.')
        return avg


def stage_generated_guide(comfy:Path,job_id:str,generated:Path):
    destination=(comfy/'input'/f'h3new_{job_id}_inserted_keyframe.png').resolve()
    input_dir=(comfy/'input').resolve()
    if not destination.is_relative_to(input_dir):raise ValueError('Destination du guide hors ComfyUI')
    shutil.copy2(generated,destination)
    return destination
