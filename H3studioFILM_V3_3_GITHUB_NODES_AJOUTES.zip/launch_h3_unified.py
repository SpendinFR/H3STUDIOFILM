"""Safe unified launcher for H3 Film Studio and H3 Retouches.

ComfyUI stays on :8188; the single web front-end stays on :7861.
No ComfyUI start/stop/restart or render queue clearing.
The legacy V10.108 H3 retouch node files are hash-synchronized safely; a changed
file requires a manual ComfyUI restart before any generation.
This launcher intentionally does not alter any generation logic.
"""
from __future__ import annotations
import json
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import socket
import sys
import threading
import time
import webbrowser
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parent
COMFY_URL = 'http://127.0.0.1:8188'
OLLAMA_URL = 'http://127.0.0.1:11434'
WEB_HOST = '127.0.0.1'
WEB_PORT = 7861
REQUIRED_FILM_NODES = (
    'H3StoreRawLatentExact', 'H3LoadRawLatentExact',
    'H3RawSavedAutoGate', 'H3RawSavedStudioGate',
    'H3RefineResizeConditioningDropVisualRefs',
)
REQUIRED_RETOUCH_NODES = (
    'H3RoychoAnimatedMaskV62', 'H3RoychoCropGuideV64',
    'MVEx_SubjectCrop', 'MiniMaxH3ReferenceToVideo',
)


V108_NODE_FILES = (
    '__init__.py',
    'retouch_mask_math_v58.py',
    'retouch_upstream_adapters_v59.py',
    'retouch_motion_mask_v60.py',
    'retouch_roycho_mvex_v62.py',
    'retouch_roycho_guide_v64.py',
)


def _sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):
            h.update(chunk)
    return h.hexdigest()


def verify_and_sync_v108_nodes():
    """Restore V10.108 node installation semantics without hot-reloading ComfyUI.

    Identical installed files are left untouched (no timestamp change). If
    differences exist, synchronize only when ComfyUI has no queued/running
    prompts, then STOP the launch to require a manual ComfyUI restart. A
    running ComfyUI still holds its previous Python classes in memory.
    """
    comfy=Path(os.environ.get('COMFYUI_DIR',r'C:\AI\ComfyUI_windows_portable\ComfyUI')).resolve()
    src=ROOT/'custom_nodes'/'H3StudioRetouchExtras'
    dst=comfy/'custom_nodes'/'H3StudioRetouchExtras'
    changed=[]
    for name in V108_NODE_FILES:
        a=src/name
        b=dst/name
        if not a.is_file():
            raise RuntimeError(f'Node V10.108 absent du ZIP : {a}')
        if not b.is_file() or _sha256_file(a)!=_sha256_file(b):
            changed.append((a,b))
    if not changed:
        print('[OK] Les 6 nodes Retake/Roycho installes sont identiques octet par octet a V10.108.',flush=True)
        print('[NOTE] Une ancienne version de ces nodes peut rester EN MEMOIRE : redemarre ComfyUI manuellement une fois si necessaire.',flush=True)
        return

    # Never edit Python nodes under an active GPU computation: a partial hot-
    # swap is not a valid reload of classes that ComfyUI already imported.
    try:
        queue=get_json(COMFY_URL+'/queue',timeout=8)
        active=(queue.get('queue_running') or [])+(queue.get('queue_pending') or [])
    except Exception as exc:
        raise RuntimeError('Impossible de verifier la file ComfyUI : aucun node n a ete copie. '+str(exc)) from exc
    if active:
        raise RuntimeError(f'{len(active)} rendu(s) ComfyUI actif(s) ou en attente : nodes V10.108 differents detectes mais copie suspendue. Termine les rendus avant mise a jour.')

    dst.mkdir(parents=True,exist_ok=True)
    for a,b in changed:
        shutil.copy2(a,b)
        if _sha256_file(a)!=_sha256_file(b):
            raise RuntimeError('Echec de verification apres copie : '+str(b))
        print('[SYNCHRO V10.108] '+a.name,flush=True)
    raise RuntimeError(
        f'{len(changed)} node(s) V10.108 synchronise(s) sur disque. '
        'STOP de securite : ferme puis redemarre MANUELLEMENT ComfyUI sur 8188 '
        'pour qu il recharge les classes Python, puis relance le Studio. '
        'Aucun rendu ou service n a ete interrompu automatiquement.'
    )


def port_open(port: int, timeout: float = 0.9) -> bool:
    try:
        with socket.create_connection((WEB_HOST, port), timeout=timeout):
            return True
    except OSError:
        return False


def get_json(url: str, timeout: float = 20.0):
    with urllib.request.urlopen(urllib.request.Request(url, headers={'Accept':'application/json'}), timeout=timeout) as resp:
        return json.loads(resp.read().decode('utf-8'))


def preflight():
    print('[1/4] ComfyUI deja ouvert sur :8188 ? Verification sans relancer...', flush=True)
    try:
        info = get_json(COMFY_URL + '/object_info', timeout=35)
        if not isinstance(info, dict) or not info:
            raise RuntimeError('object_info vide')
    except Exception as exc:
        raise RuntimeError(
            'ComfyUI ne repond pas correctement sur http://127.0.0.1:8188/object_info. '
            'Ouvre une seule instance de ComfyUI avec ses nodes et attends la fin du chargement. '
            'Ce lanceur NE ferme ni NE redemarre ComfyUI. Detail : ' + str(exc)
        ) from exc
    print('[OK] ComfyUI repond; aucun second ComfyUI ne sera lance.', flush=True)
    missing_film = [n for n in REQUIRED_FILM_NODES if n not in info]
    missing_retouch = [n for n in REQUIRED_RETOUCH_NODES if n not in info]
    if missing_film or missing_retouch:
        parts=[]
        if missing_film:parts.append('Film Studio: ' + ', '.join(missing_film))
        if missing_retouch:parts.append('Retouches: ' + ', '.join(missing_retouch))
        raise RuntimeError(
            'Nodes absents de ComfyUI EN MEMOIRE : ' + ' | '.join(parts) + '. '
            'Ne lance pas la generation avec des nodes obsoletes. '
            'Verifie les nodes installes avec les scripts fournis puis redemarre '
            'MANUELLEMENT ComfyUI, sans rendu actif. '
            'Ce lanceur ne modifie pas custom_nodes.'
        )
    print('[OK] Nodes Film Studio et Retouches presents dans ComfyUI.', flush=True)

    print('[2/4] Port web unique :7861...', flush=True)
    if port_open(WEB_PORT):
        raise RuntimeError(
            'Le port 7861 est deja occupe (probablement ancien serveur Retouches). '
            'Ferme UNIQUEMENT la fenetre qui lance ce serveur (Ctrl+C dans son terminal), '
            'sans arreter ComfyUI, puis relance ce Studio unifie. '
            'Le nouveau Studio ne remplace jamais silencieusement un autre serveur.'
        )
    if port_open(7860):
        raise RuntimeError(
            'Ancien serveur Film Studio detecte sur 7860. '
            'Avant de le fermer, termine ou suspends proprement sa production. '
            'ATTENTION : Ctrl+C dans cet ANCIEN lanceur peut arreter ComfyUI. '
            'Evite toute interruption d un rendu GPU en cours.'
        )
    print('[OK] Ports disponibles; Direction et Retouches partageront :7861.', flush=True)


def ollama_ready(timeout: float = 2.0) -> bool:
    """Only a healthy /api/tags counts; a TCP listener alone is insufficient."""
    try:
        result = get_json(OLLAMA_URL + '/api/tags', timeout=timeout)
        return isinstance(result, dict) and isinstance(result.get('models'), list)
    except (OSError, ValueError, TimeoutError):
        return False


def find_ollama_exe() -> Path:
    """Resolve Ollama without depending solely on the embedded Python's PATH."""
    names = [shutil.which('ollama.exe'), shutil.which('ollama')]
    local = os.environ.get('LOCALAPPDATA', '')
    programs = os.environ.get('PROGRAMFILES', '')
    if local:
        names.append(str(Path(local) / 'Programs' / 'Ollama' / 'ollama.exe'))
    if programs:
        names.append(str(Path(programs) / 'Ollama' / 'ollama.exe'))
    for name in names:
        if name and Path(name).is_file():
            return Path(name).resolve()
    raise RuntimeError(
        'Ollama ne repond pas sur http://127.0.0.1:11434 et ollama.exe est introuvable. '
        'Verifie que Ollama est installe (commande "ollama serve"), puis relance le Studio.'
    )


def ensure_ollama():
    """Reuse existing Ollama, otherwise launch a separate persistent local server."""
    print('[3/4] Ollama local :11434 — verification puis demarrage automatique si besoin...', flush=True)
    if ollama_ready():
        print('[OK] Ollama deja en service sur :11434; aucune seconde instance.', flush=True)
        return
    if port_open(11434, timeout=0.5):
        # Ollama may still be scanning its models: wait, but never start a second
        # server on the same port and risk confusing Director requests.
        for _ in range(15):
            if ollama_ready():
                print('[OK] Ollama deja present et maintenant pret.', flush=True)
                return
            time.sleep(1)
        raise RuntimeError(
            'Le port 11434 est deja occupe, mais Ollama /api/tags ne repond pas. '
            'Aucune seconde instance Ollama n a ete lancee. '
            'Verifie la fenetre Ollama ou le processus qui utilise le port 11434.'
        )

    exe = find_ollama_exe()
    logs = ROOT / '_logs'
    logs.mkdir(parents=True, exist_ok=True)
    logfile = logs / 'ollama-auto-start.log'
    print('[OLLAMA] Demarrage de "ollama serve" via ' + str(exe), flush=True)
    print('[OLLAMA] Journal : ' + str(logfile), flush=True)
    flags = 0
    if os.name == 'nt':
        flags = subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_NO_WINDOW
    with logfile.open('ab') as handle:
        child = subprocess.Popen(
            [str(exe), 'serve'],
            cwd=str(exe.parent),
            stdin=subprocess.DEVNULL,
            stdout=handle,
            stderr=subprocess.STDOUT,
            close_fds=True,
            creationflags=flags,
        )
    # The server is independent: stopping the Studio does not kill Ollama.
    for i in range(75):
        if ollama_ready():
            print('[OK] Ollama disponible sur http://127.0.0.1:11434/api/tags.', flush=True)
            return
        code = child.poll()
        if code is not None:
            raise RuntimeError(
                f'Ollama s est arrete au demarrage (code {code}). '
                f'Consulte : {logfile}'
            )
        if i in (9, 29, 49):
            print('[OLLAMA] Initialisation des modeles locaux en cours...', flush=True)
        time.sleep(1)
    raise RuntimeError(
        'Ollama a ete lance, mais /api/tags reste inaccessible apres environ 75 secondes. '
        f'Consulte {logfile}. ComfyUI n a pas ete modifie.'
    )


def open_browser_when_ready():
    """On Windows, open the UI only after our own listener has started."""
    for _ in range(60):
        if port_open(WEB_PORT):
            try:webbrowser.open(f'http://{WEB_HOST}:{WEB_PORT}/')
            except OSError:pass
            return
        time.sleep(0.25)


def main():
    try:
        verify_and_sync_v108_nodes()
        preflight()
        ensure_ollama()
    except Exception as exc:
        print('\n[ERREUR DE DEMARRAGE] ' + str(exc), file=sys.stderr, flush=True)
        return 2
    print('[4/4] Demarrage du serveur commun. Pas de nouveau ComfyUI.', flush=True)
    # The Studio owns no ComfyUI process: closing the web page must never kill GPU jobs.
    os.environ['H3_RETOUCH_ONLY'] = '1'
    os.environ.setdefault('COMFYUI_DIR', r'C:\AI\ComfyUI_windows_portable\ComfyUI')
    # ComfyUI's embedded Python often uses an isolated ._pth configuration:
    # it ignores PYTHONPATH and may omit the script directory from sys.path.
    # Import the *sibling* server explicitly; never depend on a global install.
    if str(ROOT) not in sys.path:
        sys.path.insert(0, str(ROOT))
    import studio_web
    sys.argv=[str(ROOT / 'studio_web.py'),'--port',str(WEB_PORT)]
    print('Studio unifie : http://127.0.0.1:7861/ | Direction + Retouches', flush=True)
    if os.name=='nt':
        threading.Thread(target=open_browser_when_ready,daemon=True).start()
    studio_web.main()
    return 0


if __name__=='__main__':
    raise SystemExit(main())
