"""V10.104 — Gemma-written H3 insert prompt + neutral Krea placeholder guide.

Goal: keep the successful Roycho/MVEx insertion path and 17-frame pre-roll from V10.101,
while preventing Krea from generating portraits/cards/people that leak into H3 as visible guide imagery.
Krea now creates only a neutral local placeholder / occupancy patch; H3 + Gemma remain responsible
for the real inserted element.
"""
from __future__ import annotations
import re
from retouches_llm_prompt_v74 import choose_backend, _strip_fences

SYSTEM = """Tu es réalisateur VFX pour l'INSERTION D'UN ÉLÉMENT dans une vidéo H3 existante.
Tu reçois le PROMPT ORIGINAL complet du clip et une demande de modification.
Le prompt original décrit l'intention historique : tu ne prétends pas avoir vu la vidéo.
La véritable vidéo est fournie séparément à MiniMax H3 comme <Video 1>.

Écris UNIQUEMENT les TROIS champs suivants, en français, sans markdown, JSON ni [Shot] :
SCENE_CONTEXT: une phrase concrète sur la scène d'origine (décor, lumière, angle, protagonistes), 260 caractères max.
ELEMENT: 1-2 phrases concrètes sur le SEUL élément demandé, son aspect pertinent, son mouvement ou son état. 380 caractères max.
INTEGRATION: 1-2 phrases sur sa place et sa présence PHYSIQUE dans la scène existante : profondeur,
contact, ombres, occlusion, perspective et continuité. 350 caractères max.

RÈGLES IMPÉRATIVES :
- L'élément demandé n'est PAS une photographie, un portrait, un écran, un cadre, une vignette, un collage,
  une surimpression, ni une image dans l'image, sauf si l'utilisateur demande explicitement un de ces objets.
- Le plan ORIGINAL, la personne originale, le décor et la caméra doivent rester tels quels, hors de la zone ajoutée.
- Ne crée aucun personnage, visage, silhouette humaine ni nouvel objet NON demandé. Si la demande vise un humain,
  décris une personne physiquement intégrée à la scène, pas un portrait ni un cliché du personnage.
- Si l'utilisateur fournit une image d'apparence, MiniMax la reçoit comme <Picture 1> : tu ne peux PAS voir
  cette image et tu ne dois PAS inventer son contenu ; décris simplement l'élément demandé.
- L'élément doit être présent/intégré dès la PREMIÈRE image du RENDU FINAL si c'est un ajout statique.
  S'il s'agit d'une entrée ou d'une descente, conserve le mouvement voulu dès le début sans effet photo incrustée.
- Les plages horaires données sont les secondes ORIGINALES du clip ; ne gère jamais les images techniques
  de préparation H3, ne déplace pas le geste et ne change pas la durée.
- Ne remplace jamais le sujet de la demande par un autre, ni ne crée un sujet supplémentaire.
- Écris des actions visibles précises, pas des formules génériques ni des instructions à copier.
"""

FIELDS = re.compile(r'(?im)^\s*(?:\*\*)?\s*(SCENE_CONTEXT|ELEMENT|INTEGRATION)\s*:\s*(?:\*\*)?\s*')
_FORBIDDEN_PLACEHOLDER = re.compile(r'(?i)\b(?:TRANSITION AVANT|TRANSITION APRÈS|A REMPLIR|TODO|PLACEHOLDER)\b')


def build_request(*, request: str, source_prompt: str, start: float, end: float,
                  duration: float, has_picture: bool, rect: tuple[float,float,float,float]):
    if not 0 <= start < end <= duration + 0.03:
        raise ValueError('Insertion : fenêtre réelle invalide')
    if not request.strip():
        raise ValueError('Insertion : élément non décrit')
    x,y,w,h = rect
    return (
        f'DEMANDE UTILISATEUR EXACTE : {request.strip()}\n'
        f'SECONDES RÉELLES DE LA DEMANDE : {start:.3f}–{end:.3f}s / {duration:.3f}s.\n'
        f'ZONE D\'INSERTION IMAGE (x,y,largeur,hauteur en %) : {x:.1f},{y:.1f},{w:.1f},{h:.1f}.\n'
        f'RÉFÉRENCE D\'APPARENCE : {"<Picture 1> fournie à H3 (ne pas prétendre la voir)" if has_picture else "Aucune image optionnelle"}.\n'
        'PROMPT ORIGINAL COMPLET — contexte historique uniquement :\n'
        + (source_prompt.strip() or '(Prompt original indisponible : ne rien inventer sur le décor au-delà de la demande.)')
        + '\n\nRENVOIE UNIQUEMENT SCENE_CONTEXT, ELEMENT, INTEGRATION avec des phrases physiques rédigées.'
    )


def parse_output(response: str):
    raw = _strip_fences(str(response or '')).strip()
    matches = list(FIELDS.finditer(raw))
    if len(matches) != 3 or [x.group(1).upper() for x in matches] != ['SCENE_CONTEXT','ELEMENT','INTEGRATION']:
        raise ValueError('Gemma insertion : attendu SCENE_CONTEXT, ELEMENT, INTEGRATION dans cet ordre')
    entries=[]
    caps=(260,380,350)
    for index,match in enumerate(matches):
        content=raw[match.end():matches[index+1].start() if index+1<len(matches) else len(raw)]
        content=re.sub(r'\s+',' ',content).strip(' \t\r\n*-')
        if not 15 <= len(content) <= caps[index]:
            raise ValueError(f'Gemma insertion : {match.group(1)} vide, trop court ou trop long')
        if _FORBIDDEN_PLACEHOLDER.search(content) or '[Shot' in content or '<Picture' in content or '<Video' in content:
            raise ValueError(f'Gemma insertion : {match.group(1)} contient un marqueur non rédigé')
        entries.append(content)
    return tuple(entries)


def _picture_subject_label(request: str) -> str:
    text=re.sub(r"\s+", " ", str(request or '').strip())
    if not text:
        return 'requested element'
    text=text.strip(' ' + chr(34) + chr(39) + chr(96))
    words=text.split()
    label=' '.join(words[:8]).strip(' ,.;:')
    return label or 'requested element'


def make_h3_prompt(parts, *, has_picture: bool, request: str):
    scene, element, integration=parts
    if has_picture:
        subject=_picture_subject_label(request)
        shot_prefix=(
            f'<Picture 1> is the reference appearance for the requested element: {subject}. '
            f'Preserve the identity, silhouette and appearance of that same {subject}. '
        )
        picture_tail=(
           ' Match the inserted element to Picture 1 in appearance and identity while keeping it fully integrated into the real scene. '
           'Never display Picture 1 itself as a photo, portrait, poster, panel, floating card, screen, collage or picture-in-picture. '
           'When any neutral Krea placement guide differs in appearance, Picture 1 defines the final inserted element appearance.'
        )
    else:
        shot_prefix=''
        picture_tail=''
    return (
        '<Video 1> is the EXISTING moving scene: preserve the original actors, room, camera, '
        'light, depth and continuous motion. Alter only the requested insertion region.\n'
        'SCENE CONTEXT: ' + scene + '\n'
        'NEW TAKE — physically insert ONLY the user-requested element.\n'
        '[Shot 1] ' + shot_prefix + element + ' ' + integration + '\n'
        'The new element is part of the scene from the first visible frame of the final edited clip; '
        'no visible Krea picture, portrait, inset or delayed picture-to-subject morph. '
        'Respect the requested motion if the element enters the shot. Preserve original background '
        'and actors outside the editable region.' + picture_tail
    )


def make_krea_prompt(parts):
    _scene, _element, _integration=parts
    # Deliberately never provide the requested human/object's description to
    # Krea. It only prepares a nonfigurative placement cue *inside the scene*.
    # The actual new element is solely authored by Gemma + generated by H3.
    return (
        'THIS IS A NON-FIGURATIVE SPATIAL GUIDE, NOT THE FINAL VFX OBJECT. '
        'Inpaint ONLY the white masked zone of the ORIGINAL VIDEO FRAME. '
        'Keep all pixels outside the mask, original room, actor, camera, '
        'perspective and light unchanged. The SOURCE FRAME itself is the scene authority. '
        'Within the WHITE MASK, create ONLY a subtle, smooth, neutral, '
        'unrecognizable diffuse 3D occupancy/shading cue integrated into '
        'the existing scene, showing a plausible approximate occupied region. '
        'Do NOT create the requested subject, any person, face, hands, body, '
        'animal, object, product, portrait, photograph, screenshot, framed '
        'picture, inset, card, square panel, poster, silhouette, collage or '
        'text. Do NOT generate a separate composition or miniature scene. '
        'Respect the actual original background texture and illumination. '
        'Only a quiet neutral spatial cue for subsequent 3D creation by H3.'
    )


def write_prompt(*, request:str, source_prompt:str, start:float, end:float, duration:float,
                 has_picture:bool, rect:tuple, gpu_prepare):
    import h3film_studio_v3 as film
    gpu_prepare()
    backend=choose_backend(film)
    try:
        user=build_request(request=request,source_prompt=source_prompt,start=start,end=end,
                           duration=duration,has_picture=has_picture,rect=rect)
        for attempt in range(2):
            response=film.director_text(backend,SYSTEM,user,
                                       label='AJOUT ELEMENT GEMMA 4 26B / OLLAMA',
                                       num_ctx=12288,num_predict=900)
            try:
                parts=parse_output(response)
                break
            except ValueError as exc:
                if attempt:
                    raise RuntimeError('Gemma insertion : deux réponses invalides, aucun rendu H3 lancé : '+str(exc)) from exc
                user+='\nCORRIGE TA REPONSE : '+str(exc)+'. Renvoie les trois champs, sans phrases placeholder.'
    finally:
        try:
            film.unload_text_backend(backend,label='Avant Krea2/H3 insertion')
        finally:
            film.release_all_text_models_for_h3(label='Insertion : libération Gemma avant Krea2/H3')
    return (make_h3_prompt(parts,has_picture=has_picture,request=request),
            make_krea_prompt(parts),
            'Gemma 26B · ajout intégré + guide Krea neutre · '+str(backend.get('display') or backend.get('model')))
