"""Content Director team selection. No prompt text is rewritten here.

Installed prompt archives are located under director_teams/<type>/ and must
provide exactly one usable file for each of the four existing Director roles.
The film type uses the historical bundled /prompts directory, unchanged.
"""
from __future__ import annotations
import json
import re
from pathlib import Path

TYPES = {
    'film': 'Cinéma / Fiction',
    'divertissement': 'Divertissement',
    'publicite': 'Publicité',
    'createur_facecam': 'Créateur / Streamer / Facecam',
    'reportage': 'Reportage / Documentaire',
    'sport': 'Sport',
    'musique': 'Musique',
    'actualites': 'Actualités',
    'podcast': 'Podcast / Interview',
    'education': 'Éducation / Tutoriel',
    'reseaux_sociaux': 'Réseaux sociaux',
}
ROLES = ('CONTENT','SCENE','PLAN','CLIP')


def normalize_type(value: str) -> str:
    key = str(value or 'film').strip()
    if key not in TYPES:
        raise ValueError('Type de contenu inconnu : '+key)
    return key


def prompt_files(root: Path, kind: str) -> dict[str, Path]:
    kind=normalize_type(kind)
    base=root/'prompts' if kind=='film' else root/'director_teams'/kind
    if not base.is_dir():
        raise FileNotFoundError(
            f"Équipe '{TYPES[kind]}' non installée : {base}. "
            "Utilise INSTALLER-EQUIPES-DIRECTORS.ps1 depuis le dossier Studio.")
    files=[p for p in base.rglob('*') if p.is_file() and p.suffix.lower() in ('.txt','.md','.prompt')]
    result={}
    for role in ROLES:
        exact=[p for p in files if p.stem.upper()==role+'_DIRECTOR']
        if len(exact)!=1:
            # Support versioned names, e.g. CONTENT_DIRECTOR_V1.txt. Never guess
            # between multiple candidates: the wrong team would contaminate a film.
            pat=re.compile(r'(?i)(?:^|[_ .-])'+role+r'[_ .-]*DIRECTOR(?:$|[_ .-])')
            exact=[p for p in files if pat.search(p.stem)]
        if len(exact)!=1:
            raise RuntimeError(
                f"Équipe '{TYPES[kind]}': attendu un seul {role}_DIRECTOR.txt "
                f"(trouvés {len(exact)}). Dossier : {base}")
        if exact[0].stat().st_size < 200:
            raise RuntimeError(f'Prompt {role} trop court : {exact[0]}')
        result[role]=exact[0]
    return result


def read_team(root: Path, kind: str) -> dict[str,str]:
    return {role:file.read_text(encoding='utf-8-sig') for role,file in prompt_files(root,kind).items()}


def freeze_team(project_dir:Path, kind:str, prompts:dict[str,str]) -> None:
    """Snapshot the chosen team once, so resuming can't silently switch versions."""
    frozen=project_dir/'_studio'/'director_team'
    frozen.mkdir(parents=True,exist_ok=True)
    (frozen/'team.json').write_text(json.dumps({'content_type':kind},ensure_ascii=False,indent=2),encoding='utf-8')
    for role in ROLES:
        (frozen/(role+'_DIRECTOR.txt')).write_text(prompts[role],encoding='utf-8')


def project_team(root:Path, project_dir:Path, kind:str, resume:bool) -> dict[str,str]:
    frozen=project_dir/'_studio'/'director_team'
    if resume and (frozen/'team.json').is_file():
        info=json.loads((frozen/'team.json').read_text(encoding='utf-8'))
        if normalize_type(info.get('content_type')) != kind:
            raise RuntimeError('Le type des Directors ne correspond pas au projet enregistré.')
        prompts={role:(frozen/(role+'_DIRECTOR.txt')).read_text(encoding='utf-8') for role in ROLES}
        if any(len(p)<200 for p in prompts.values()):
            raise RuntimeError('Snapshot des Directors du projet incomplet.')
        return prompts
    if resume and kind!='film':
        raise RuntimeError('Projet ancien sans snapshot de Directors : refus de changer silencieusement d’équipe.')
    prompts=read_team(root,kind)
    if not resume:freeze_team(project_dir,kind,prompts)
    return prompts
