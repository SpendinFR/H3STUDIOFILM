"""Keep validated 63-frame Gemma choreography unchanged when H3 renders 10 extra lead frames.

Gemma always writes the exact original HALF-CLIP (2.625 s) beat script.
Only a deterministic 10-frame technical lead-in is inserted for H3, and each
Gemma beat moves by exactly that many frames.  No LLM rewrites the choreography.
"""
from __future__ import annotations
import re

from retouches_llm_prompt_v74 import SHOT_HEADER, SHOT_RE, _seconds
from retouches_llm_prompt_half_v82 import _grid


def prepare_for_h3(gemma_prompt: str, half_window: dict, render_window: dict) -> str:
    lead = int(render_window.get('preroll_frames', 0))
    if lead == 0:
        return gemma_prompt
    half_frames = int(half_window['frames'])
    render_frames = int(render_window['frames'])
    if lead <= 0 or render_frames != lead + half_frames:
        raise ValueError('Retake H3 : préroll incompatible avec les 63 images Gemma')
    if int(render_window['origin_frame']) + lead != int(half_window['origin_frame']):
        raise ValueError('Retake H3 : décalage RAW/préroll impossible')
    if abs((half_window['start'] + lead / 24) - render_window['start']) > 1/24:
        raise ValueError('Retake H3 : l’action dériverait dans le temps')

    # Parse the actual H3 text, never let an LLM regenerate the good choreography.
    prefix, marker, metadata = gemma_prompt.partition('\nLOCAL TAKE:')
    if not marker:
        raise ValueError('Retake H3 : description locale de Gemma manquante')
    shots = list(SHOT_HEADER.finditer(prefix))
    occurrences = list(SHOT_RE.finditer(prefix))
    if not shots or len(shots) != len(occurrences):
        raise ValueError('Retake H3 : plan Gemma incompatible avec décalage temporel')
    lead_start = shots[0].start()
    header_text = prefix[:lead_start]
    shifted = []
    last_frame = 0
    grid = _grid(half_window)
    if len(shots) != len(grid):
        raise ValueError('Retake H3 : le nombre de shots Gemma a changé')
    for i, shot in enumerate(shots, 1):
        if int(shot.group(1)) != i:
            raise ValueError('Retake H3 : numérotation de Gemma incorrecte')
        start_frame = round(_seconds(shot.group(2))*24)
        end_frame = round(_seconds(shot.group(3))*24)
        expected_start = round(grid[i-1][1]*24)
        expected_end = round(grid[i-1][2]*24)
        if (start_frame != last_frame or start_frame != expected_start or
                end_frame != expected_end or end_frame <= start_frame or end_frame > half_frames):
            raise ValueError('Retake H3 : les temps Gemma ne correspondent pas au demi-clip')
        description = prefix[shot.end():shots[i].start() if i < len(shots) else len(prefix)].strip()
        if len(description) < 14 or re.fullmatch(r'(?:TRANSITION\s+(?:AVANT|APR[ÈE]S)|ACTION)[.!?…]*', description, flags=re.I):
            raise ValueError('Retake H3 : mouvement Gemma non décrit')
        shifted.append(f'[Shot {i+1}] {(start_frame+lead)/24:.3f}–{(end_frame+lead)/24:.3f}s {description}')
        last_frame = end_frame
    if last_frame != half_frames:
        raise ValueError('Retake H3 : la dernière image Gemma ne correspond pas à la fin')

    first = ('[Shot 1] 0.000–' + f'{lead/24:.3f}' + 's '
             'Continuité du mouvement original visible dans <Video 1>, sans nouvelle action, '
             'avec la même lumière et le même cadrage.')
    dur = render_frames / 24
    off = int(render_window['origin_frame']) / 24
    action_start = (int(half_window['local_first']) + lead) / 24
    action_end = (int(half_window['local_last']) + lead) / 24
    tail = (f'LOCAL TAKE: exactly {dur:.3f}s, from original {off:.3f}–{off+dur:.3f}s. '
            f'Action assigned within the local take at {action_start:.3f}–{action_end:.3f}s. '
            'Distinct [Shot]s are continuous motion beats, never camera cuts. '
            'Do not generate beyond the local take duration. Preserve visual identity and physical continuity.')
    # Preserve Gemma's scene context, every action description and their order.
    return header_text + first + '\n' + '\n'.join(shifted) + '\n' + tail
