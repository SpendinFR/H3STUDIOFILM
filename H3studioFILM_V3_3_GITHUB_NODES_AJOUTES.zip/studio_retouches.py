"""Independent, non-destructive Retouches workspace storage.

Rendering is handled by a separate retouches_engine module, not by FilmMaker.
This module owns only imported source videos and editable retouch preparations.
"""
from __future__ import annotations
import json
import os
from pathlib import Path
import re
import threading
import time
import uuid

ROOT = Path(__file__).resolve().parent / 'studio_sessions' / 'retouches'
UPLOADS = ROOT / 'uploads'
INDEX = ROOT / 'index.json'
LOCK = threading.RLock()
MAX_VIDEO_BYTES = 700 * 1024 * 1024
ALLOWED_MODES = {'remove_person','swap_person','move_camera','replace_background','local_edit','remove_element','replace_element'}


def _load():
    try:
        value=json.loads(INDEX.read_text(encoding='utf-8'))
        return value if isinstance(value,dict) else {}
    except (OSError, ValueError, TypeError):
        return {}


def _write(data):
    ROOT.mkdir(parents=True,exist_ok=True)
    temp=ROOT / ('index.' + uuid.uuid4().hex + '.tmp')
    try:
        temp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
        os.replace(temp,INDEX)
    finally:
        temp.unlink(missing_ok=True)


def source_file(video_id):
    if not re.fullmatch('[0-9a-f]{32}',str(video_id or '')):
        return None
    with LOCK:
        rows=_load().get('videos',[])
        found=next((r for r in rows if r.get('id')==video_id),None)
    if found is None:return None
    path=(UPLOADS/(video_id+'.mp4')).resolve()
    if path.parent!=UPLOADS.resolve() or not path.is_file():return None
    return path


def list_items():
    with LOCK:
        db=_load()
    videos=[]
    for row in db.get('videos',[]):
        file=source_file(row.get('id'))
        if file:
            videos.append({'id':row['id'],'name':row.get('name','Vidéo'),
                           'size':file.stat().st_size,'url':'/api/retouches/video/'+row['id'],
                           'added_at':row.get('added_at',0)})
    return {'videos':videos,'drafts':db.get('drafts',[])[:100], 'render_enabled':True}


def import_video(input_stream, length, filename):
    if not 0<length<=MAX_VIDEO_BYTES:
        raise ValueError('Vidéo MP4 limitée à 700 Mo')
    if Path(str(filename or '')).suffix.lower()!='.mp4':
        raise ValueError('Importe une vidéo au format MP4')
    video_id=uuid.uuid4().hex
    UPLOADS.mkdir(parents=True,exist_ok=True)
    path=UPLOADS/(video_id+'.mp4')
    try:
        with path.open('xb') as writer:
            remaining=length
            while remaining:
                chunk=input_stream.read(min(1024*1024,remaining))
                if not chunk:raise ValueError('Transfert vidéo incomplet')
                writer.write(chunk)
                remaining-=len(chunk)
        with path.open('rb') as file: header=file.read(32)
        if len(header)<12 or header[4:8]!=b'ftyp':
            raise ValueError('Le fichier n’est pas une vidéo MP4 valide')
        row={'id':video_id,'name':Path(str(filename)).name[:150], 'size':length,'added_at':time.time()}
        with LOCK:
            db=_load();db.setdefault('videos',[]).insert(0,row)
            _write(db)
        return {'id':video_id,'name':row['name'],'url':'/api/retouches/video/'+video_id,'size':length}
    except BaseException:
        path.unlink(missing_ok=True)
        raise


def store_draft(body, *, project_clip_valid=None):
    if not isinstance(body,dict):raise ValueError('Préparation invalide')
    mode=str(body.get('mode') or '')
    if mode not in ALLOWED_MODES:raise ValueError('Mode de retouche inconnu')
    source=body.get('source')
    if not isinstance(source,dict):raise ValueError('Sélectionne une vidéo')
    if source.get('type')=='upload':
        vid=str(source.get('id') or '')
        if not source_file(vid):raise ValueError('Vidéo importée introuvable')
        recorded={'type':'upload','id':vid}
    elif source.get('type')=='project':
        project=str(source.get('project') or '')
        clip=str(source.get('clip') or '')
        variant=str(source.get('variant') or 'hd')
        if not callable(project_clip_valid) or not project_clip_valid(project,clip,variant):
            raise ValueError('Clip de projet introuvable ou non rendu')
        recorded={'type':'project','project':project,'clip':clip,'variant':variant}
    else:raise ValueError('Source vidéo inconnue')
    details={}
    for field in ('target','instructions','reference_url','reference_name','camera_preset','background_prompt'):
        value=str(body.get(field) or '').strip()
        if len(value)>4500:raise ValueError('Texte de retouche trop long')
        details[field]=value
    try:
        azimuth=float(body.get('azimuth') or 0)
        elevation=float(body.get('elevation') or 0)
    except (TypeError,ValueError):raise ValueError('Angles de caméra invalides')
    if not -90<=azimuth<=90 or not -45<=elevation<=45:
        raise ValueError('Angle hors plage')
    details['azimuth']=azimuth;details['elevation']=elevation
    try:
        shot_start=float(body.get('shot_start') or 0)
        shot_end=float(body.get('shot_end') or 0)
    except (TypeError,ValueError):raise ValueError('Début/fin du plan invalides')
    if shot_start<0 or (shot_end and shot_end<=shot_start):raise ValueError('Le début du plan doit précéder la fin')
    details['shot_start']=shot_start;details['shot_end']=shot_end
    box=body.get('region')
    if box is not None:
        if not isinstance(box,list) or len(box)!=4 or any(not isinstance(v,(int,float)) or not 0<=v<=1 for v in box):
            raise ValueError('Zone sélectionnée invalide')
        details['region']=[round(float(v),5) for v in box]
    else:details['region']=None
    draft_id=str(body.get('draft_id') or '')
    if draft_id and not re.fullmatch('[0-9a-f]{32}',draft_id):raise ValueError('ID de préparation invalide')
    with LOCK:
        db=_load();drafts=db.setdefault('drafts',[])
        if draft_id and not any(row.get('id')==draft_id for row in drafts):
            raise ValueError('Préparation introuvable')
        if not draft_id:draft_id=uuid.uuid4().hex
        entry={'id':draft_id,'mode':mode,'source':recorded,'settings':details,
               'status':'prepared_only','updated_at':time.time()}
        drafts[:]=[entry]+[r for r in drafts if r.get('id')!=draft_id]
        db['drafts']=drafts[:100]
        _write(db)
    return {'ok':True,'draft':entry,'message':'Préparation enregistrée. Aucun rendu H3 lancé.'}
