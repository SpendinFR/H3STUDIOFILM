"""FilmMaker V10 lightweight local browser control, Python standard library only.
Use http://127.0.0.1:7860. No CUDA, no hidden worker models.
"""
from __future__ import annotations
import argparse, json, mimetypes, os, re, subprocess, sys, threading, time, uuid, ctypes
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote
# Windows ComfyUI python_embeded/python313._pth often uses isolated sys.path.
# Explicitly load our sibling modules without changing global ComfyUI settings.
_STUDIO_ROOT = Path(__file__).resolve().parent
if str(_STUDIO_ROOT) not in sys.path:
    sys.path.insert(0, str(_STUDIO_ROOT))
import studio_retouches
import retouches_engine
import retouches_next
import studio_retouch_review

ROOT=Path(__file__).resolve().parent
SESSIONS=ROOT/'studio_sessions'
SESSIONS.mkdir(exist_ok=True)
PORT=7860
STATE={'session':None,'proc':None,'log':[],'last_error':'','started':None}
LOCK=threading.RLock()
_REFERENCE_PREVIEW_MODULE=None
_KREA_JOBS = {}
_KREA_LOCK = threading.Lock()

def reference_preview_engine():
    """Load the existing native authority generator by absolute path.

    Embedded ComfyUI Python runs in isolated mode; importing by bare module
    name is unreliable. This does NOT start FilmMaker, H3, Ollama or any GPU model.
    """
    global _REFERENCE_PREVIEW_MODULE
    if _REFERENCE_PREVIEW_MODULE is None:
        import importlib.util
        with LOCK:
            if _REFERENCE_PREVIEW_MODULE is None:
                path=ROOT/'h3film_studio_v3.py'
                spec=importlib.util.spec_from_file_location('h3film_reference_preview',path)
                if spec is None or spec.loader is None:
                    raise RuntimeError('Moteur d’autorité des références introuvable')
                module=importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                _REFERENCE_PREVIEW_MODULE=module
    return _REFERENCE_PREVIEW_MODULE

def start_krea_clip_reference(request: dict, session: Path) -> dict:
    """Prompt-writer -> Krea (text/transform/SRef) -> pending preview only.

    Never write a canonical ref nor mutate the reviewed Clip Director proposal
    until the creator explicitly accepts the result in the UI.
    """
    with LOCK:
        worker=STATE.get('proc')
    if not worker or worker.poll() is not None:
        raise ValueError('Krea disponible uniquement pendant la validation d’un clip en cours')
    q=json_get(session/'review.json',{})
    if not q or q.get('kind')!='clips' or q.get('id')!=request.get('review_id'):
        raise ValueError('Clip Director : la validation a expiré, Krea annulé')
    project_name=json_get(session/'active_project.json',{}).get('name','')
    if project_name!=request.get('project'):
        raise ValueError('La référence doit appartenir au projet actif')
    instruction=str(request.get('prompt') or '').strip()
    if not 8<=len(instruction)<=3500:
        raise ValueError('Décris la nouvelle référence Krea (8 à 3500 caractères)')
    name=str(request.get('name') or 'Référence du clip').strip()[:90]
    category=str(request.get('category') or 'element')
    if category not in ('main_character','secondary_character','decor','element'):
        raise ValueError('Catégorie de référence invalide')
    mode=str(request.get('mode') or 'text')
    if mode=='image':mode='transform'  # compatibility with V10.19 requests
    if mode not in ('text','transform','style'):
        raise ValueError('Mode Krea invalide')
    source=None
    if mode!='text':
        source=Path(str(request.get('source_path') or '')).resolve()
        comfy=comfy_path()
        valid=any(source.is_relative_to((comfy/dir).resolve()) for dir in ('input','output'))
        if not valid or not source.is_file() or source.suffix.lower() not in ('.png','.jpg','.jpeg','.webp'):
            raise ValueError('Source image Krea : choisis une image déjà importée dans le Studio')
    with _KREA_LOCK:
        if any(j.get('status') in ('queued','rendering') for j in _KREA_JOBS.values()):
            raise ValueError('Une génération Krea est déjà en cours')
        job_id=uuid.uuid4().hex
        seed=int(uuid.uuid4().int % (2**63-1))
        _KREA_JOBS[job_id]={'status':'queued','project':project_name,'review_id':q['id'],
                            'seed':seed,'started':time.time()}

    def run():
        with _KREA_LOCK:_KREA_JOBS[job_id]['status']='rendering'
        try:
            engine=reference_preview_engine()
            comfy=comfy_path()
            tags=engine.rt.http_json(engine.rt.OLLAMA_URL+'/api/tags',timeout=10)
            original_cfg=json_get(session/'config.json',{})
            configured=str((original_cfg.get('models') or {}).get('clip') or '').strip()
            if configured in ('27','qwen38'):backend=engine._llama_backend('qwen38')
            elif configured in ('jp','jpetrina'):backend=engine._llama_backend('jpetrina')
            elif configured:backend=engine._ollama_backend(configured)
            else:
                installed=engine.installed_model_names(tags)
                model=next((v for v in installed if v.lower().startswith('gemma4:12b')),None)
                if not model:raise RuntimeError('Krea : aucun Clip Director configuré et gemma4:12b absent')
                backend=engine._ollama_backend(model)
            project=load_project(project_name)
            bible=json_get(project/'scenes.json',{}) if project else {}
            prompt=engine.studio_clip_krea_prompt(backend,user_description=instruction,
                  name=name,category=category,mode=mode,
                  content_bible=(bible.get('content') or {}))
            # Director can be CPU/GPU; release LLM before ComfyUI Krea, same H3 contract.
            engine.release_all_text_models_for_h3(label='Avant Krea référence Clip Director')
            with _KREA_LOCK:_KREA_JOBS[job_id]['prompt']=prompt
            objinfo=engine.rt.http_json(engine.rt.COMFY_URL+'/object_info',timeout=60)
            path=engine.render_krea_reference(comfy,objinfo,project_name,name,category,prompt,1,
                                               source_image=source,mode=mode,seed=seed)
            base=comfy/'input'/'H3FilmSimple'/project_name/'studio_krea_clip'
            base.mkdir(parents=True,exist_ok=True)
            staged=base/(job_id+path.suffix.lower())
            import shutil
            shutil.copy2(path,staged)
            with _KREA_LOCK:_KREA_JOBS[job_id].update(status='complete',path=str(staged),
                      url=media_uri(str(staged)),name=name,completed=time.time())
        except Exception as exc:
            with _KREA_LOCK:_KREA_JOBS[job_id].update(status='failed',error=str(exc)[:1800])
    threading.Thread(target=run,name='KreaClip-'+job_id[:8],daemon=True).start()
    return {'ok':True,'job_id':job_id,'seed':seed}


def krea_job_status(job_id: str) -> dict:
    with _KREA_LOCK:
        job=dict(_KREA_JOBS.get(job_id) or {})
    return job if job else {'status':'unknown','error':'Génération Krea non trouvée'}


def json_get(p,default=None):
    try:return json.loads(p.read_text(encoding='utf-8'))
    except (OSError,ValueError):return default

def write_json(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_name(p.name+'.tmp')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(tmp,p)

def comfy_path():
    c=os.environ.get('COMFYUI_DIR') or r'C:\AI\ComfyUI_windows_portable\ComfyUI'
    return Path(c).resolve()

def output_dir():return comfy_path()/'output'/'H3FilmSimple'

def sessions():
    return sorted((x for x in SESSIONS.iterdir() if x.is_dir()),key=lambda x:x.stat().st_mtime,reverse=True)[:20]

def sessions_for_resume():
    """Look for older sessions without taking over a still-running legacy process."""
    all_sessions=list(sessions())
    base=ROOT.parent
    for folder in base.glob('H3Film_STUDIO_V10*/studio_sessions'):
        if folder.resolve()==SESSIONS.resolve(): continue
        if folder.is_dir():
            all_sessions.extend(d for d in folder.iterdir() if d.is_dir() and (d/'config.json').is_file())
    return sorted(all_sessions,key=lambda f:f.stat().st_mtime,reverse=True)


def older_running_productions():
    """Find detached FilmMaker workers left alive by a prior Studio version."""
    with LOCK: selected=STATE.get('session')
    rows=[]
    for folder in sessions_for_resume():
        if selected is not None and folder.resolve()==selected.resolve():continue
        data=json_get(folder/'run.json',{})
        pid=int(data.get('pid') or 0)
        if data.get('running') and process_alive(pid):
            rows.append({'pid':pid,'session':str(folder),'project':json_get(folder/'active_project.json',{}).get('name','')})
    return rows




def verified_film_worker(pid, session):
    """Fail closed: PID must still belong to the known old FilmMaker script.

    A PID stored in JSON can be reused by Windows. Never kill that PID blindly.
    """
    if os.name != 'nt' or not process_alive(pid):
        return False
    expected=str((session.parent.parent/'h3film_studio_v3.py').resolve()).replace('\\','/').lower()
    ps=("$p=Get-CimInstance Win32_Process -Filter 'ProcessId=%d'; "
        "if($p){$p.CommandLine}" % pid)
    try:
        result=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',ps],
            capture_output=True,text=True,timeout=9,
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        line=result.stdout.replace('\\','/').lower()
        return result.returncode==0 and expected in line and 'python' in line
    except (OSError,subprocess.TimeoutExpired):
        return False


def interrupt_owned_prompt(session):
    """Only cancel the exact ComfyUI prompt recorded for this FilmMaker worker."""
    info=json_get(session/'active_prompt.json',{}) or {}
    prompt_id=str(info.get('id') or '')
    if not prompt_id or prompt_id=='None':
        return 'Aucun identifiant de prompt ComfyUI associé : aucun arrêt GPU global envoyé.'
    import urllib.request
    base='http://127.0.0.1:8188'
    try:
        with urllib.request.urlopen(base+'/queue',timeout=4) as response:
            queue=json.load(response)
        running=[str(row[1]) for row in queue.get('queue_running',[]) if len(row)>1]
        pending=[str(row[1]) for row in queue.get('queue_pending',[]) if len(row)>1]
        if prompt_id in running:
            if len(running)!=1:
                return 'Plusieurs prompts actifs : interruption globale ignorée par sécurité.'
            req=urllib.request.Request(base+'/interrupt',data=b'{}',
                headers={'Content-Type':'application/json'},method='POST')
            with urllib.request.urlopen(req,timeout=4): pass
            return 'Interruption du prompt ComfyUI associé demandée.'
        if prompt_id in pending:
            payload=json.dumps({'delete':[prompt_id]}).encode('utf-8')
            req=urllib.request.Request(base+'/queue',data=payload,
                headers={'Content-Type':'application/json'},method='POST')
            with urllib.request.urlopen(req,timeout=4): pass
            return 'Prompt en attente retiré de ComfyUI.'
        return 'Aucun prompt correspondant dans la file ComfyUI.'
    except Exception as exc:
        return 'ComfyUI indisponible : interruption GPU non confirmée ('+str(exc)+').' 


def request_worker_stop(session):
    """Durable stop request for detached worker; shared by web Stop and Ctrl+C."""
    if not session:
        return
    session=Path(session)
    (session/'stop.request').write_text('1',encoding='utf-8')
    active=json_get(session/'active_project.json',{}) or {}
    proj=load_project(active.get('name','')) if active else None
    if proj:
        gates=proj/'_studio'/'gates'
        gates.mkdir(parents=True,exist_ok=True)
        (gates/'stop.request').write_text('1',encoding='utf-8')


def _cleanup_project_raw_gate_files(project):
    """Remove abandoned RAW review gate files once a worker has actually stopped.

    Never call this while the renderer is still alive. It is safe for stale projects
    that should no longer block a new film session.
    """
    if not project:
        return 0
    p=load_project(str(project)) if not isinstance(project,Path) else project
    if not p or not (p/'_studio'/'gates').is_dir():
        return 0
    removed=0
    gates=p/'_studio'/'gates'
    for pattern in ('clip_*.waiting.json','clip_*.decision.json','clip_*.redo.json','clip_*.retouch.requested.json','clip_*.retouch.approved.json','stop.request'):
        for f in gates.glob(pattern):
            try:
                f.unlink(missing_ok=True)
                removed += 1
            except OSError:
                pass
    return removed


def cleanup_abandoned_raw_gates(*, keep_projects=None):
    """Purge stale RAW validation gates from projects with no live FilmMaker worker.

    A stopped/abandoned project must never keep a waiting RAW gate that can confuse
    a later project or make the UI look blocked on the wrong film.
    """
    keep=set(str(x) for x in (keep_projects or []) if x)
    live_projects=set()
    for folder in sessions_for_resume():
        row=json_get(folder/'run.json',{})
        pid=int(row.get('pid') or 0)
        if row.get('running') and process_alive(pid):
            name=str((json_get(folder/'active_project.json',{}) or {}).get('name') or '')
            if name:
                live_projects.add(name)
    for proj in output_dir().iterdir() if output_dir().is_dir() else []:
        if not proj.is_dir():
            continue
        if proj.name in keep or proj.name in live_projects:
            continue
        _cleanup_project_raw_gate_files(proj)


def studio_local_helper(name: str):
    """Load a bundled helper by absolute path even under ComfyUI's Python -I.

    Do not mutate sys.path and do not load the heavy FilmMaker engine just
    to stop processes or queue a timeline change.
    """
    if name not in ('studio_emergency_stop', 'studio_timeline_extension', 'studio_lora', 'studio_content_types'):
        raise ValueError(f'Composant Studio inconnu : {name}')
    module = sys.modules.get(name)
    if module is not None:
        return module
    import importlib.util
    path = ROOT / (name + '.py')
    if not path.is_file():
        raise RuntimeError(f'Composant Studio absent : {path}. Extrais le ZIP entier.')
    spec = importlib.util.spec_from_file_location(name, path)
    if not spec or not spec.loader:
        raise RuntimeError(f'Impossible de charger le composant Studio : {path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
    except BaseException:
        sys.modules.pop(name, None)
        raise
    return module


def emergency_stop_all():
    """User-requested global stop; NOT used by Pause or Suspend."""
    return studio_local_helper('studio_emergency_stop').emergency_stop()


def stop_older_session(pid):
    """Explicitly authorized stop of an older detached FilmMaker worker only."""
    try: pid=int(pid)
    except (ValueError,TypeError): raise ValueError('PID invalide')
    matches=[r for r in older_running_productions() if r['pid']==pid]
    if len(matches)!=1: raise ValueError('Cette ancienne session n’est plus active ou est ambiguë. Actualise.')
    old=Path(matches[0]['session']).resolve()
    if not verified_film_worker(pid,old):
        raise ValueError('Identité du processus non vérifiable. Aucun PID arrêté : utilise le diagnostic manuel pour cette ancienne session.')
    request_worker_stop(old)
    # The user explicitly chose GLOBAL emergency stop. Attempt GPU/LLM cleanup
    # even if the legacy worker later refuses to terminate.
    problems=emergency_stop_all()
    # Kill only the verified FilmMaker PID; never taskkill a process tree.
    result=subprocess.run(['taskkill.exe','/PID',str(pid),'/F'],capture_output=True,
        text=True,timeout=12,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    time.sleep(.25)
    if process_alive(pid):
        raise ValueError('Arrêt du processus non confirmé : '+(result.stderr or result.stdout).strip())
    row=json_get(old/'run.json',{}) or {}
    row.update(running=False,stopped_at=time.time(),stop_reason='manual_from_v10_5')
    write_json(old/'run.json',row)
    note=(' Nettoyage incomplet : '+' ; '.join(problems)) if problems else ''
    return {'ok':True,'pid':pid,
        'message':f'Ancien FilmMaker PID {pid} arrêté. Arrêt global LLM/ComfyUI demandé.'+note}

def recent_projects():
    p=output_dir()
    if not p.is_dir():return []
    return [{'name':d.name,'title':json_get(d/'_studio'/'project_info.json',{}).get('title') or d.name,'mtime':d.stat().st_mtime, 'resume':json_get(d/'_studio'/'resume_state.json',{})} for d in sorted((x for x in p.iterdir() if x.is_dir()),key=lambda x:x.stat().st_mtime,reverse=True)[:40]]

def process_alive(pid):
    if not isinstance(pid,int) or pid<=0:return False
    if os.name=='nt':
        # Query status without sending a signal to the detached GPU process.
        k=ctypes.windll.kernel32
        k.OpenProcess.argtypes=[ctypes.c_uint32,ctypes.c_int,ctypes.c_uint32]
        k.OpenProcess.restype=ctypes.c_void_p
        k.WaitForSingleObject.argtypes=[ctypes.c_void_p,ctypes.c_uint32]
        k.WaitForSingleObject.restype=ctypes.c_uint32
        k.CloseHandle.argtypes=[ctypes.c_void_p]
        k.CloseHandle.restype=ctypes.c_int
        h=k.OpenProcess(0x00100000 | 0x1000,False,pid)
        if not h:return False
        try:return k.WaitForSingleObject(h,0)==258
        finally:k.CloseHandle(h)
    try:os.kill(pid,0);return True
    except OSError:return False

class ExternalProc:
    def __init__(self,pid):self.pid=int(pid)
    def poll(self):return None if process_alive(self.pid) else 1


def tail_process(proc,session):
    """Read from a durable log, never pipe stdout to the parent web process."""
    pos=0
    log=session/'console.log'
    try:
        while True:
            if log.is_file():
                with log.open('rb') as f:
                    f.seek(pos)
                    new=f.read(1024*256)
                    pos=f.tell()
                if new:
                    lines=new.decode('utf-8',errors='replace').splitlines()
                    with LOCK:
                        STATE['log'].extend(lines)
                        STATE['log']=STATE['log'][-300:]
            if proc.poll() is not None:
                with LOCK:
                    still=STATE.get('session')==session
                if still:
                    row=json_get(session/'run.json',{})
                    row['running']=False;row['finished_at']=time.time()
                    write_json(session/'run.json',row)
                if (session/'stop.request').exists():
                    active=json_get(session/'active_project.json',{}) or {}
                    _cleanup_project_raw_gate_files(active.get('name',''))
                return
            time.sleep(0.7)
    except Exception as exc:
        with LOCK:STATE['last_error']=repr(exc)


def restore_running_session():
    # The web server may have restarted; GPU tasks are detached and persisted.
    for folder in sessions():
        row=json_get(folder/'run.json',{})
        pid=int(row.get('pid') or 0)
        if row.get('running') and process_alive(pid):
            proc=ExternalProc(pid)
            with LOCK:STATE.update(session=folder,proc=proc,started=row.get('started'))
            threading.Thread(target=tail_process,args=(proc,folder),daemon=True).start()
            return

def _launch_session(folder, prompt, *, resume_project=''):
    env=os.environ.copy()
    env['H3FILM_STUDIO_SESSION']=str(folder)
    env['PYTHONUNBUFFERED']='1'
    env['PYTHONIOENCODING']='utf-8'
    env['PYTHONUTF8']='1'
    config=json_get(folder/'config.json',{})
    env['H3FILM_CONTENT_TYPE']=str(config.get('content_type') or 'film')
    env['H3FILM_ORIENTATION']=str(config.get('orientation') or 'landscape')
    models=config.get('models') or {}
    for role in ('content','scene','plan','clip'):
        name=str(models.get(role) or '').strip()
        if name:env['H3FILM_'+role.upper()+'_MODEL']=name
    # Explicitly remove a possibly stale global model override.
    env.pop('H3FILM_TEXT_MODEL',None)
    if resume_project:
        env['H3FILM_RESUME_PROJECT']=resume_project
        old=load_project(resume_project)
        if old: (old/'_studio'/'gates'/'stop.request').unlink(missing_ok=True)
    args=[sys.executable,'-u',str(ROOT/'h3film_studio_v3.py'),prompt]
    flags=0
    if os.name=='nt':
        flags=subprocess.CREATE_NEW_PROCESS_GROUP | getattr(subprocess,'DETACHED_PROCESS',0)
    logfile=folder/'console.log'
    logfile.parent.mkdir(parents=True,exist_ok=True)
    with logfile.open('ab') as handle:
        proc=subprocess.Popen(args,cwd=str(ROOT),env=env,stdin=subprocess.DEVNULL,
                              stdout=handle,stderr=subprocess.STDOUT,creationflags=flags)
    write_json(folder/'run.json',{'pid':proc.pid,'running':True,'started':time.time(),
                                  'resume_project':resume_project})
    with LOCK:STATE.update(session=folder,proc=proc,log=[],last_error='',started=time.time())
    threading.Thread(target=tail_process,args=(proc,folder),daemon=True).start()
    return {'session':folder.name,'pid':proc.pid,'project':resume_project}


def validate_director_text_edit(review, text):
    """Check semantic validity BEFORE acknowledging a Studio checkpoint.

    Invalid edits must leave the user at the same review, not crash the worker
    after the web response has already said 'accepted'.
    """
    kind = review.get('kind')
    payload = review.get('payload') or {}
    film = reference_preview_engine()
    if kind == 'content':
        content = payload.get('content') or {}
        parts = content.get('parts') or []
        duration = sum(int(part.get('duration_seconds') or 0) for part in parts)
        if not duration or duration % 5:
            raise ValueError('Durée de la proposition Content invalide')
        # Strict JSON, no inferred edits to the presentation-only review summary.
        try:
            edited = json.loads(text)
        except (json.JSONDecodeError, TypeError) as exc:
            raise ValueError(f'Content Director : syntaxe JSON incorrecte ({exc}). Vérifie les virgules entre champs, les guillemets et les accolades. Le texte n’a pas été modifié.') from exc
        if not isinstance(edited,dict):
            raise ValueError('Content Director : la bible doit être un objet JSON')
        if 'parts' not in edited:
            raise ValueError('Il manque le champ parts : conserve la liste des actes/parties de la bible. Les autres champs peuvent être omis ; ils garderont leur valeur précédente.')
        try:
            parsed = film._parse_studio_content_json_revision(text,content,duration,'','','')
        except Exception as exc:
            raise ValueError(f'{exc} Pour modifier les actes, ajuste start/end de chaque partie : les intervalles doivent se suivre sans trou, couvrir exactement la durée du film, avec des frontières multiples de 5 secondes. Pour imposer un nombre de scènes, utilise scene_count sur la partie concernée (facultatif).') from exc
        if len(parsed['parts']) == 0:
            raise ValueError('Content Director : au moins une partie est nécessaire')
        return {'parts':len(parsed['parts'])}
    if kind == 'scenes':
        part=payload.get('part') or {}
        existing=payload.get('scenes') or []
        if not existing: raise ValueError('Aucune scène existante à éditer. Reviens à la proposition valide ou demande une nouvelle proposition au Scene Director.')
        try:
            parsed=film.parse_scene_output(text,part,int(existing[0]['scene']))
        except Exception as exc:
            raise ValueError(f'{exc} Conserve au moins un en-tête SCÈNE numéroté suivi de son contenu (Lieu, Description, etc.). Pour changer le nombre de scènes, ajoute ou enlève leurs blocs complets.') from exc
        exact=part.get('scene_count')
        if exact is not None and len(parsed)!=int(exact):
            raise ValueError(f'Le Content Director a fixé scene_count={exact} pour cette partie ; ton texte contient {len(parsed)} scènes. Ajuste les blocs SCÈNE ou corrige scene_count en amont.')
        return {'scenes':len(parsed)}
    if kind == 'plans':
        scene=payload.get('scene') or {}
        expected=int(scene['duration_seconds']//5)
        # parse_plan_output may truncate extra blocks: an explicit manual edit
        # must never silently discard plans the human authored.
        headings=re.findall(r'(?im)^\s*PLAN\s*(?:#|N(?:[°ºo.]\s*)?)?\d+\b',text)
        if headings and len(headings)!=expected:
            raise ValueError(f'{expected} plans de 5s nécessaires pour une scène de {scene["duration_seconds"]}s ; reçu {len(headings)}. Pour 3 plans, ajuste d’abord la durée de scène à 15s.')
        try:
            parsed=film.parse_plan_output(text,scene,fill_missing=False)
        except Exception as exc:
            raise ValueError(f'{exc} Chaque plan comporte un en-tête PLAN 1, PLAN 2, etc., suivi de Vue/Action ou de SHOT. Tu peux aussi restaurer la proposition.') from exc
        if len(parsed)!=expected:
            raise ValueError(f'{expected} plans de 5s nécessaires pour une scène de {scene["duration_seconds"]}s ; reçu {len(parsed)}. Ajoute ou enlève des blocs PLAN, ou modifie la durée de la scène en amont.')
        return {'plans':len(parsed)}
    raise ValueError('Cette étape ne peut pas être éditée directement')


def available_studio_loras():
    """ComfyUI is the authority for available model-only LoRAs."""
    import urllib.request
    url='http://127.0.0.1:8188/object_info/LoraLoaderModelOnly'
    try:
        with urllib.request.urlopen(url, timeout=6) as response:
            info=json.load(response)
        spec=((info.get('LoraLoaderModelOnly') or {}).get('input') or {}).get('required',{}).get('lora_name',[])
        choices=spec[0] if spec and isinstance(spec[0],list) else []
        return {'loras':[str(n) for n in choices if isinstance(n,str)],'ok':True}
    except Exception as exc:
        return {'loras':[],'ok':False,'error':'ComfyUI / LoRA indisponible : '+str(exc)}


def start_film(data):
    legacy=older_running_productions()
    if legacy:
        example=legacy[0]
        raise ValueError(f'Ancienne production FilmMaker encore active (PID {example["pid"]}, projet {example["project"] or "sans nom"}). Stoppe-la avant de lancer un autre film : {example["session"]}')
    with LOCK:
        proc=STATE.get('proc')
        if proc and proc.poll() is None:raise ValueError('Une production tourne déjà. Suspends-la sur un checkpoint sûr avant de démarrer un autre projet.')
    cleanup_abandoned_raw_gates()
    prompt=str(data.get('prompt') or '').strip()
    if not prompt:raise ValueError('Le prompt principal est vide.')
    content_type=studio_local_helper('studio_content_types').normalize_type(data.get('content_type') or 'film')
    orientation=str(data.get('orientation') or 'landscape')
    if orientation not in ('landscape','portrait'):
        raise ValueError('Orientation inconnue : '+orientation)
    # Fail BEFORE creating a session if the selected team's archives have not
    # been imported. Never silently use Film prompts for another content type.
    studio_local_helper('studio_content_types').prompt_files(ROOT,content_type)
    duration=str(data.get('duration') or '1m')
    if not re.fullmatch(r'(?:\d+(?:\.\d+)?\s*(?:h|hr|m|min|s|sec|heure|heures|minute|minutes|seconde|secondes)|\d{1,2}:\d{2}(?::\d{2})?)',duration,re.I):
        raise ValueError('Durée attendue : 1m, 30s, 5m, 01:00, etc.')
    # No LoRA request means the exact historical H3 graph remains untouched.
    selection=data.get('loras') or []
    loras=studio_local_helper('studio_lora').normalize(selection)
    if loras:
        offered=available_studio_loras()
        if not offered.get('ok'):
            raise ValueError(offered.get('error') or 'LoRA indisponibles')
        missing=[v['name'] for v in loras if v['name'] not in offered['loras']]
        if missing:raise ValueError('LoRA introuvables : '+', '.join(missing))
    models={k:str((data.get('models') or {}).get(k) or '').strip() for k in ('content','scene','plan','clip')}
    sid=time.strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:5]
    folder=SESSIONS/sid;folder.mkdir(parents=True)
    (folder/'answers').mkdir()
    title=str(data.get('title') or '').strip()[:90]
    mode=str(data.get('mode') or 'studio')
    reviews={k:bool(data.get('reviews',{}).get(k,False)) for k in ('brief','content','scenes','plans','clips','raw')}
    if mode=='studio': reviews['content']=True  # Studio reviews Content before preproduction.
    if mode=='auto':reviews={k:False for k in reviews}
    write_json(folder/'config.json',{
        'initial_answers':[str(data.get('details') or ''),duration,str(data.get('style') or ''),str(data.get('director') or '')],
        'auto_answers':mode=='auto','reviews':reviews,'mode':mode,'brief':prompt,
        'models':models,'title':title,'loras':loras,'content_type':content_type,'orientation':orientation,
    })
    return _launch_session(folder,prompt)


def recover_abandoned_raw_decision(project, next_clip):
    """Transfer an in-flight V10.3/5 RAW rejection to a durable retake on resume.

    Only call after checking that no previous FilmMaker worker is running.
    Stale .waiting/.decision files from a stopped worker must not mislead the UI.
    """
    gate=project/'_studio'/'gates'/f'clip_{next_clip:04d}'
    retake=gate.with_suffix('.retake.json')
    decision=json_get(gate.with_suffix('.decision.json'),{}) or {}
    redo=json_get(gate.with_suffix('.redo.json'),{}) or {}
    if not retake.is_file() and (decision.get('action')=='redo' or redo.get('feedback')):
        feedback=str(redo.get('feedback') or decision.get('feedback') or '').strip()
        if feedback:
            previous=project/'prompts'/f'clip_{next_clip:04d}.txt'
            old=previous.read_text(encoding='utf-8') if previous.is_file() else ''
            write_json(retake,{'clip':next_clip,'status':'requested','feedback':feedback,
                               'previous_prompt':old,'recovered_at':time.time()})
    # These are from the old renderer; new worker will create its own RAW gate.
    for suffix in ('.waiting.json','.decision.json','.redo.json'):
        gate.with_suffix(suffix).unlink(missing_ok=True)
    return json_get(retake,{}) or {}


def restart_project(name, *, allow_finished_extension=False):
    legacy=older_running_productions()
    if legacy:
        example=legacy[0]
        raise ValueError(f'Une ancienne production FilmMaker tourne toujours (PID {example["pid"]}). Arrête-la avant de reprendre ce projet : {example["session"]}')
    with LOCK:
        proc=STATE.get('proc')
        if proc and proc.poll() is None:raise ValueError('Une production tourne encore. Clique « Suspendre et sauvegarder » puis attends son arrêt.')
    cleanup_abandoned_raw_gates(keep_projects=[name])
    project=load_project(name)
    if not project:raise ValueError('Projet inconnu')
    checkpoint=json_get(project/'_studio'/'resume_state.json')
    if not checkpoint:raise ValueError('Projet sans checkpoint sûr : impossible de reprendre sans régénération.')
    if checkpoint.get('completed') and not (allow_finished_extension and (project/'_studio'/'timeline_extension_pending.json').is_file()):
        raise ValueError('Ce projet est déjà terminé : utilise « Prolonger » pour créer une suite.')
    recover_abandoned_raw_decision(project,int(checkpoint.get('completed_clip') or 0)+1)
    # Reuse the exact original Director settings, brief and answers.
    matches=[folder for folder in sessions_for_resume() if json_get(folder/'active_project.json',{}).get('name')==name]
    if not matches:raise ValueError('Session initiale introuvable : les paramètres de production ne peuvent pas être restaurés.')
    orig=json_get(matches[0]/'config.json',{})
    if not orig.get('brief'):raise ValueError('Brief initial absent')
    folder=SESSIONS/(time.strftime('%Y%m%d_%H%M%S')+'_resume_'+uuid.uuid4().hex[:5])
    folder.mkdir(parents=True)
    (folder/'answers').mkdir()
    write_json(folder/'config.json',orig)
    (folder/'resume_of.txt').write_text(name,encoding='utf-8')
    return _launch_session(folder,orig['brief'],resume_project=name)

def active_folder():
    with LOCK:return STATE.get('session')

def load_project(name):
    if not re.fullmatch(r'[A-Za-z0-9_\-]+',name or ''):return None
    root=output_dir().resolve();p=(root/name).resolve()
    if p.parent!=root or not p.is_dir():return None
    return p

def media_uri(file):
    if not file:return ''
    try:
        path=Path(str(file).split(' [',1)[0]); c=comfy_path()
        if not path.is_absolute():
            path=c/('input' if '[input]' in str(file) else 'output')/path
        path=path.resolve()
        if not path.is_file():return ''
        for base in (c/'output',c/'input'):
            base=base.resolve()
            if path.is_relative_to(base):
                from urllib.parse import quote
                return '/media/'+('output' if base.name=='output' else 'input')+'/'+quote(path.relative_to(base).as_posix(),safe='/')
    except Exception:return ''
    return ''

def review_with_media(review):
    if not isinstance(review,dict):return {}
    payload=review.get('payload')
    if not isinstance(payload,dict):return review
    review['payload']=dict(payload)
    for key,output in (('refs','refs_url'),('audio_refs','voices_url')):
        review['payload'][output]=[media_uri(r.get('annotated') or r.get('path')) if isinstance(r,dict) else '' for r in payload.get(key,[])]
    return review


def pending_film_retouch(project_name='', clip=''):
    """Only a live FilmMaker session explicitly parked for this exact RAW clip."""
    session=active_folder()
    with LOCK:proc=STATE.get('proc')
    if not session or not proc or proc.poll() is not None:return None
    active=json_get(session/'active_project.json',{}) or {}
    if project_name and active.get('name')!=str(project_name):return None
    p=load_project(active.get('name',''))
    if not p:return None
    gates=p/'_studio'/'gates'
    for path in gates.glob('clip_*.retouch.requested.json'):
        marker=json_get(path,{}) or {}
        num=int(marker.get('clip') or 0)
        if not num or (clip and num!=int(clip)):continue
        if (gates/f'clip_{num:04d}.retouch.approved.json').exists():continue
        if marker.get('session')!=session.name:continue
        # Never give a new retouch access while the original graph is still on GPU.
        phase=json_get(session/'stage.json',{}) or {}
        if phase.get('stage')!='raw_retouch':continue
        return {'project':p.name,'clip':str(num),'session':session,'project_path':p}
    return None


def publish_film_retouch_approval(kind, ident, record):
    """Commit ONLY a validated approved MP4 for the original pending film clip."""
    if record.get('state')!='approved':return False
    project,clip=record.get('project'),str(record.get('clip') or '')
    pending=pending_film_retouch(project,clip) if clip.isdigit() else None
    if not pending:return False
    approved=studio_retouch_review.approved_file(kind,ident)
    if approved is None or not approved.is_file():return False
    gates=pending['project_path']/'_studio'/'gates'
    mark=json_get(gates/f'clip_{int(clip):04d}.retouch.requested.json',{}) or {}
    row=retouches_engine.job(ident) if kind=='legacy' else retouches_next.job(ident)
    if float(row.get('created_at') or 0)<float(mark.get('requested_at') or float('inf')):
        return False
    dest=gates/f'clip_{int(clip):04d}.retouch.approved.json'
    if dest.exists():raise ValueError('Ce RAW a déjà reçu une retouche validée')
    write_json(dest,{'clip':int(clip),'project':project,'session':pending['session'].name,
                     'kind':kind,'id':ident,'approved_path':str(approved.resolve()),
                     'approved_at':time.time()})
    return True


def film_raw_gate_allows_retouch(selection):
    """Allow an H3 retouch only while FilmMaker is blocked at THIS clip's RAW gate.

    Does not allow simultaneous refine, and does not authorize a gate for a
    different project/clip. The RAW latent and FilmMaker state stay untouched.
    """
    if not isinstance(selection,dict):return False
    if selection.get('type')=='review':
        project,clip=studio_retouch_review.source_project_clip(str(selection.get('kind') or ''),str(selection.get('id') or ''))
        if not project or not clip:return False
        selection={'type':'project','project':project,'clip':clip,'variant':'raw'}
    if selection.get('type')!='project' or selection.get('variant')!='raw':
        return False
    session=active_folder()
    if not session:return False
    active=json_get(session/'active_project.json',{})
    name=str(selection.get('project') or '')
    clip=str(selection.get('clip') or '')
    if active.get('name')!=name or not clip.isdigit():return False
    project=load_project(name)
    if not project:return False
    gate=project/'_studio'/'gates'/f'clip_{int(clip):04d}.waiting.json'
    return gate.is_file() and not gate.with_name(f'clip_{int(clip):04d}.decision.json').is_file()


def ensure_film_and_retouch_not_racing():
    if retouches_next.ACTIVE or retouches_engine.RUNNING:
        raise ValueError('Une retouche H3 est en cours. Attends sa fin avant de reprendre le film.')


def ensure_retouch_can_start(source):
    with LOCK:proc=STATE.get('proc')
    if not proc or proc.poll() is not None:return
    if not isinstance(source,dict):
        raise ValueError('Source de retouche invalide')
    if source.get('type')=='review':
        kind=str(source.get('kind') or '')
        ident=str(source.get('id') or '')
        # No browser-supplied path. The review must have been explicitly kept
        # for continuation, and must belong to the pending FilmMaker clip.
        decision=studio_retouch_review.decision(kind,ident)
        if decision.get('state')!='continued':
            raise ValueError('Clique « Continuer modifications » sur le rendu terminé avant de le modifier')
        project,clip=studio_retouch_review.source_project_clip(kind,ident)
        if not pending_film_retouch(project,clip):
            raise ValueError('Ce MP4 ne provient pas du RAW du film actuellement en attente')
    elif source.get('type')=='project' and source.get('variant')=='raw':
        if not pending_film_retouch(source.get('project'),source.get('clip')):
            raise ValueError('FilmMaker est actif : sélectionne le RAW de CE film')
    else:
        raise ValueError('Film en attente : seuls son RAW et ses retouches successives sont autorisés')
    if retouches_next.ACTIVE or retouches_engine.RUNNING:
        raise ValueError('Une autre retouche H3 est déjà en cours')


def retouch_video_source(selection):
    """Resolve by server-side project registry, never a client-supplied file path."""
    if not isinstance(selection,dict):return None
    if selection.get('type')=='upload':
        return studio_retouches.source_file(selection.get('id'))
    if selection.get('type')=='review':
        return studio_retouch_review.result_path(str(selection.get('kind') or ''),str(selection.get('id') or ''))
    if selection.get('type')=='project':
        name=str(selection.get('project') or '')
        clip=str(selection.get('clip') or '')
        variant=str(selection.get('variant') or 'hd')
        folder=load_project(name)
        if not folder or variant not in ('raw','hd'):return None
        data=json_get(folder/'_studio'/'clips.json',{})
        entry=(data.get('clips') or {}).get(clip) or {}
        if variant=='raw' and pending_film_retouch(name,clip):
            # Film is explicitly parked at THIS current RAW: never resolve an
            # older clips.json entry that might refer to another take/attempt.
            matches=sorted((folder/'raw').glob(f'clip_{int(clip):04d}_RAW_MC*.mp4'))
            if matches:return matches[-1]
            raise ValueError('RAW courant du film absent')
        filename=entry.get('raw' if variant=='raw' else 'video')
        if not filename:return None
        path=Path(str(filename).split(' [',1)[0])
        if not path.is_absolute():
            path=comfy_path()/('input' if '[input]' in str(filename) else 'output')/path
        path=path.resolve()
        for root in (comfy_path()/'input',comfy_path()/'output'):
            if path.is_relative_to(root.resolve()) and path.is_file() and path.suffix.lower()=='.mp4':return path
    return None

def retouch_image_reference(pathtext):
    """Allow only reference files already exposed by our ComfyUI input/output media.

    RefBank values can be absolute or ComfyUI annotated relative paths.
    """
    raw=str(pathtext or '')
    if not raw:return None
    path=Path(raw.split(' [',1)[0]);comfy=comfy_path()
    if not path.is_absolute():
        path=comfy/('input' if '[input]' in raw else 'output')/path
    path=path.resolve()
    if path.suffix.lower() not in ('.jpg','.jpeg','.png','.webp') or not path.is_file():return None
    for root in (comfy/'input',comfy/'output'):
        if path.is_relative_to(root.resolve()):return path
    return None

def project_data(name):
    p=load_project(name)
    if not p:return {}
    data=json_get(p/'_studio'/'clips.json',{'clips':{}})
    pending=pending_film_retouch(name)
    if pending:
        number=int(pending['clip']);key=str(number)
        raw_files=sorted((p/'raw').glob(f'clip_{number:04d}_RAW_MC*.mp4'))
        if raw_files and (p/'_state'/f'clip_{number:04d}_RAW_LATENT.pt').is_file():
            raw=raw_files[-1]
            entry=data.setdefault('clips',{}).setdefault(key,{'clip':number,'scene':'En cours',
                'plan':'RAW en attente','raw':str(raw),'video':'','final':'',
                'refs':[],'voices':[],'mc':number>1})
            # This is a transient API response, not a change to clips.json.
            # The UI and both generators must agree on the current RAW video.
            entry.update(raw=str(raw),raw_pt=str(p/'_state'/f'clip_{number:04d}_RAW_LATENT.pt'),
                         pending_retouch=True)
    for key,clip in data.get('clips',{}).items():
        clip['url']=media_uri(clip.get('video'))
        clip['final_url']=media_uri(clip.get('final'))
        clip['raw_url']=media_uri(clip.get('raw'))
        clip['retouched_raw_url']=media_uri(clip.get('retouched_raw'))
        clip['raw_pt_present']=Path(clip.get('raw_pt') or '').is_file()
        clip['refs_url']=[media_uri(f) for f in clip.get('refs',[])]
        clip['voices_url']=[media_uri(f) for f in clip.get('voices',[])]
        frames=sorted((p/'ref_quality_frames'/f'clip_{key}').glob('*.jpg'))+sorted((p/'ref_quality_frames'/f'clip_{key}').glob('*.png'))
        clip['thumb_url']=media_uri(str(frames[0])) if frames else (clip['refs_url'][0] if clip['refs_url'] else '')
    for file,name2 in [('film.json','film'),('scenes.json','scenes'),('run_summary.json','summary'),('refs/static_refs.json','static_refs'),('refs/ref_bank.json','ref_bank')]:
        data[name2]=json_get(p/file,{})
    data['name']=name
    data['project_info']=json_get(p/'_studio'/'project_info.json',{})
    data['resume_state']=json_get(p/'_studio'/'resume_state.json',{})
    data['timeline_extension_status']=json_get(p/'_studio'/'timeline_extension_status.json',{})
    data['timeline_extension_pending']=bool((p/'_studio'/'timeline_extension_pending.json').is_file())
    # Creator-facing archive of previous Content proposals; do not rely on console logs.
    proposals=[]
    for file in sorted((p/'preproduction').glob('review_*.txt'))[:30] if (p/'preproduction').is_dir() else []:
        try:
            proposals.append({'name':file.stem,'text':file.read_text(encoding='utf-8')[:25000]})
        except OSError:pass
    data['proposal_history']=proposals
    data['history']=json_get(p/'_studio'/'history.json',[])
    data['pending_revisions']=json_get(p/'_studio'/'revisions.json',{})
    data['prompt_records']={key:json_get(p/'prompts'/f'clip_{key}.json',{}) for key in data.get('clips',{})}
    return data

class Handler(BaseHTTPRequestHandler):
    def log_message(self,fmt,*args):return
    def send_data(self,data,status=200):
        blob=json.dumps(data,ensure_ascii=False,default=str).encode('utf-8')
        self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(blob)));self.end_headers();self.wfile.write(blob)
    def body(self):
        size=int(self.headers.get('Content-Length','0'))
        if size>1_000_000:raise ValueError('Payload trop grand')
        return json.loads(self.rfile.read(size).decode('utf-8')) if size else {}
    def do_GET(self):
        u=urlparse(self.path); route=u.path
        if route=='/':return self.file(ROOT/'studio_ui'/'index.html','text/html; charset=utf-8')
        if route in ('/studio.css','/studio.js','/studio-v10-2.css','/studio-v10-3.css','/studio-v10-4.css','/studio-v10-5.css','/studio-v10-6.css','/studio-v10-7.css','/studio-v10-8.css','/studio-v10-9.css','/studio-v10-10.css','/studio-v10-14.css','/studio-v10-15.css','/studio-v10-17.css','/studio-v10-20.css','/studio-v10-22.css','/studio-v10-23.css','/studio-v10-32.css','/studio-retouches.css','/studio-retouches.js','/studio-new-retouches.css','/studio-new-retouches.js'):
            return self.file(ROOT/'studio_ui'/route.lstrip('/'), 'text/css' if route.endswith('.css') else 'text/javascript')
        if route=='/api/retouches':
            data=studio_retouches.list_items()
            data['jobs']=retouches_engine.jobs()[:20]
            data['projects']=[{'name':p['name'],'title':p['title']} for p in recent_projects()]
            return self.send_data(data)
        if route=='/api/retouches/review/choices':
            return self.send_data({'choices':studio_retouch_review.choices()})
        if route.startswith('/api/retouches/review/saved/'):
            pieces=route.split('/')
            if len(pieces)!=7:return self.send_data({'error':'Chemin invalide'},404)
            try:path=studio_retouch_review.approved_file(pieces[5],pieces[6])
            except ValueError:path=None
            return self.file(path,'video/mp4',ranges=True) if path else self.send_data({'error':'Rendu validé indisponible'},404)
        if route=='/api/retouches/new/jobs':return self.send_data({'jobs':retouches_next.jobs()})
        if route=='/api/retouches/new/readiness':return self.send_data(retouches_next.readiness())
        if route.startswith('/api/retouches/new/prompt/'):
            try:return self.send_data(retouches_next.prompt_preview(route.rsplit('/',1)[-1]))
            except ValueError as exc:return self.send_data({'error':str(exc)},404)
        if route.startswith('/api/retouches/new/output/'):
            ident=route.rsplit('/',1)[-1]
            try:result=retouches_next.output(ident)
            except ValueError:result=None
            return self.file(result,'video/mp4',ranges=True) if result else self.send_data({'error':'RAW nouveau moteur indisponible'},404)
        if route=='/api/retouches/readiness':return self.send_data(retouches_engine.readiness())
        if route=='/api/retouches/job':
            ident=(parse_qs(u.query).get('id') or [''])[0]
            return self.send_data(retouches_engine.job(ident))
        if route.startswith('/api/retouches/clean-plate/'):
            ident=route.rsplit('/',1)[-1]
            try:result=retouches_engine.clean_plate_result(ident,comfy_path())
            except ValueError:result=None
            return self.file(result,'image/png') if result else self.send_data({'error':'Première image propre indisponible'},404)
        if route.startswith('/api/retouches/output/'):
            ident=route.rsplit('/',1)[-1]
            try:result=retouches_engine.job_result(ident)
            except ValueError:result=None
            return self.file(result,'video/mp4',ranges=True) if result else self.send_data({'error':'Retouche non terminée'},404)
        if route.startswith('/api/retouches/video/'):
            vid=route.rsplit('/',1)[-1]
            file=studio_retouches.source_file(vid)
            return self.file(file,'video/mp4',ranges=True) if file else self.send_data({'error':'Vidéo introuvable'},404)
        if route.startswith('/media/'):
            parts=route.split('/',3)
            if len(parts)<4 or parts[2] not in ('input','output'):return self.send_data({'error':'Not Found'},404)
            from urllib.parse import unquote
            base=(comfy_path()/parts[2]).resolve();f=(base/unquote(parts[3])).resolve()
            if not f.is_relative_to(base) or not f.is_file() or f.suffix.lower() not in ('.jpg','.jpeg','.webp','.png','.mp4','.wav','.mp3','.m4a','.ogg'):
                return self.send_data({'error':'Not Found'},404)
            return self.file(f,mimetypes.guess_type(str(f))[0] or 'application/octet-stream',ranges=True)
        if route=='/api/loras':return self.send_data(available_studio_loras())
        if route=='/api/krea-job':
            job_id=(parse_qs(u.query).get('id') or [''])[0]
            return self.send_data(krea_job_status(job_id))
        if route=='/api/log':
            session=active_folder()
            p=session/'console.log' if session else None
            if p and p.is_file():
                with p.open('rb') as f:
                    f.seek(0,2);size=f.tell();f.seek(max(0,size-400000))
                    raw=f.read()
                return self.send_data({'log':raw.decode('utf-8',errors='replace')})
            return self.send_data({'log':''})
        if route=='/api/status':
            with LOCK:
                session=STATE.get('session'); proc=STATE.get('proc');logs=STATE['log'][-65:];err=STATE['last_error']
            proj=json_get(session/'active_project.json',{}) if session else {}
            gate=[]
            p=load_project(proj.get('name','')) if proj else None
            krea_preview=''
            question=json_get(session/'question.json',{}) if session else {}
            if question and isinstance(question.get('context'),dict):
                ctx=question['context']
                ctx['image_url']=media_uri(ctx.get('image_path')) if ctx.get('image_path') else ''
            if p and (p/'studio_krea').is_dir():
                previews=sorted((f for f in (p/'studio_krea').iterdir() if f.suffix.lower() in ('.png','.jpg','.jpeg','.webp')),key=lambda f:f.stat().st_mtime)
                if previews:krea_preview=media_uri(str(previews[-1]))
            stage=json_get(session/'stage.json',{}) if session else {}
            if isinstance(stage.get('payload'),dict) and stage['payload'].get('image_path'):
                stage['payload']['image_url']=media_uri(stage['payload']['image_path'])
            if p and (p/'_studio'/'gates').exists():
                for f in (p/'_studio'/'gates').glob('*.waiting.json'):
                    g=json_get(f,{}) or {};g['file']=f.name;g['raw_url']=''
                    n=int(g.get('clip',0))
                    retake=json_get(f.with_name(f'clip_{n:04d}.retake.json'),{}) or {}
                    if retake.get('status')=='requested':
                        # Decision was already submitted; never show approve/redo
                        # a second time while ComfyUI is cancelling that RAW.
                        stage={'stage':'retake_queued',
                               'title':f'Clip {n} — refus transmis, Clip Director attendu',
                               'payload':{'clip':n,'feedback':retake.get('feedback',''),
                                          'text':retake.get('previous_prompt',''),
                                          'phase':'retake_queued'},
                               'updated':retake.get('requested_at') or time.time()}
                        continue
                    vids=sorted((p/'raw').glob(f'clip_{n:04d}_RAW_MC*.mp4')) if (p/'raw').exists() else []
                    if vids:g['raw_url']=media_uri(str(vids[-1]))
                    gate.append(g)
            active_clip={}
            payload=stage.get('payload') or {}
            if p and payload.get('clip'):
                active_clip=dict(payload)
                active_clip['refs_url']=[media_uri(x.get('annotated') or x.get('path')) for x in payload.get('refs',[]) if isinstance(x,dict)]
                active_clip['voices_url']=[media_uri(x.get('annotated') or x.get('path')) for x in payload.get('audio_refs',[]) if isinstance(x,dict)]
                cnum=int(payload['clip'])
                raws=sorted((p/'raw').glob(f'clip_{cnum:04d}_RAW_MC*.mp4')) if (p/'raw').is_dir() else []
                active_clip['raw_url']=media_uri(str(raws[-1])) if raws else ''
            worker_code = proc.poll() if proc else None
            if worker_code not in (None, 0) and not err:
                err = (f'Le moteur FilmMaker a quitté avec le code {worker_code}. '
                       'Consulte le Journal technique ou le fichier console.log de la session.')
            return self.send_data({'running':bool(proc and worker_code is None),'return_code':worker_code,
                'session':session.name if session else None,'project':proj,'logs':logs,'error':err,
                'stage':stage,'active_clip':active_clip,'started':STATE.get('started'),
                'suspended':bool(session and (session/'suspended.json').exists()),
                'question':question,
                'review':review_with_media(json_get(session/'review.json',{}) if session else {}),
                'history':json_get(session/'history.json',[]) if session else [],
                'stop_requested':bool(session and (session/'stop.request').exists()),
                'older_running':older_running_productions(),
                'paused':bool(session and (session/'pause.request').exists()),
                'paused_at_boundary':bool(session and (session/'paused.json').exists()),
                'raw_gates':gate,'krea_preview':krea_preview,'projects':recent_projects()})
        if route=='/api/models':
            import urllib.request
            local=[]
            try:
                with urllib.request.urlopen('http://127.0.0.1:11434/api/tags',timeout=2) as res:
                    tags=json.loads(res.read().decode('utf-8'))
                local=sorted({str(x.get('name') or x.get('model') or '') for x in tags.get('models',[])
                              if x.get('name') or x.get('model')})
                local=[x for x in local if not any(v in x.lower() for v in ('vision','qwen3-vl','qwen3vl','llava'))]
            except Exception as exc:
                ollama_error=str(exc)
            else:
                ollama_error='' if local else 'Ollama répond, mais aucun modèle texte n’est visible dans /api/tags (vérifie ollama list).'
            return self.send_data({'ollama':local,'ollama_error':ollama_error,
                'special':[{'value':'27','label':'Qwen3.8 27B · llama.cpp'},
                           {'value':'jp','label':'Jpetrina · llama.cpp'}]})
        if route=='/api/project':
            name=parse_qs(u.query).get('name',[''])[0]
            if not name:return self.send_data({})
            return self.send_data(project_data(name))
        if route=='/api/ref-images':
            name=parse_qs(u.query).get('name',[''])[0]
            p=load_project(name);items=[]
            if p:
                # Only registered items belong in the RefBank picker. Scanning
                # the whole dynamic_refs directory would resurrect references
                # explicitly removed by the director (the file stays for old clips).
                static=json_get(p/'refs'/'static_refs.json',[]) or []
                bank=json_get(p/'refs'/'ref_bank.json',{}) or {}
                entries=list(static)
                for group in ('character_appearance','characters','decor','objects','subjects'):
                    entries.extend((bank.get(group) or {}).values())
                if isinstance(bank.get('global_environment'),dict):entries.append(bank['global_environment'])
                seen=set()
                for r in entries:
                    if not isinstance(r,dict):continue
                    source=r.get('path') or r.get('annotated')
                    if not source:continue
                    uri=media_uri(source)
                    if not uri or uri in seen:continue
                    seen.add(uri)
                    name=str(r.get('subject_name') or Path(str(source)).stem)
                    items.append({'name':name,'url':uri,'group':str(r.get('role') or r.get('kind') or ''),'path':str(source).split(' [',1)[0]})
            return self.send_data(items[:250])
        return self.send_data({'error':'Not Found'},404)
    def file(self,path,mime,ranges=False):
        try:size=path.stat().st_size
        except OSError:return self.send_data({'error':'not found'},404)
        start=0;end=size-1;partial=False
        if ranges:
            m=re.match(r'bytes=(\d*)-(\d*)',self.headers.get('Range',''))
            if m:
                if m.group(1): start=int(m.group(1));end=int(m.group(2)) if m.group(2) else size-1
                elif m.group(2):start=max(size-int(m.group(2)),0)
                start=max(0,min(start,size-1));end=max(start,min(end,size-1));partial=True
        self.send_response(206 if partial else 200)
        self.send_header('Content-Type',mime);self.send_header('Accept-Ranges','bytes');self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(end-start+1))
        if partial:self.send_header('Content-Range',f'bytes {start}-{end}/{size}')
        self.end_headers()
        with path.open('rb') as f:
            f.seek(start);remaining=end-start+1
            while remaining:
                chunk=f.read(min(65536,remaining))
                if not chunk:break
                try:self.wfile.write(chunk)
                except (BrokenPipeError,ConnectionResetError):break
                remaining-=len(chunk)
    def do_POST(self):
        try:
            route=urlparse(self.path).path
            if route=='/api/retouches/import':
                length=int(self.headers.get('Content-Length','0'))
                result=studio_retouches.import_video(self.rfile,length,unquote(self.headers.get('X-Filename','')))
                return self.send_data(result)
            if route=='/api/upload':
                from urllib.parse import parse_qs
                length=int(self.headers.get('Content-Length','0'))
                if not 0<length<=50_000_000:raise ValueError('Fichier limité à 50 Mo')
                name=unquote(self.headers.get('X-Filename','file'))
                suffix=Path(name).suffix.lower()
                if suffix not in ('.png','.jpg','.jpeg','.webp','.wav','.mp3','.m4a','.flac','.ogg'):
                    raise ValueError('Seuls les fichiers images/audio de référence sont acceptés')
                raw=self.rfile.read(length)
                base=comfy_path()/'input'/'H3FilmSimple'/'studio_uploads'
                base.mkdir(parents=True,exist_ok=True)
                dest=base/(uuid.uuid4().hex[:12]+suffix)
                dest.write_bytes(raw)
                return self.send_data({'path':str(dest),'url':media_uri(str(dest))})
            body=self.body()
            if route=='/api/retouches/review/decision':
                kind=str(body.get('kind') or '');ident=str(body.get('id') or '');action=str(body.get('action') or '')
                result=studio_retouch_review.decide(kind,ident,action)
                if action=='approve':
                    result['returned_to_film']=publish_film_retouch_approval(kind,ident,result)
                return self.send_data(result)
            if route=='/api/retouches/new/start':
                if str(body.get('mode') or '') in ('extend','performance'):
                    raise ValueError('Moteur désactivé dans ce Studio : Prolongation et Performance ne sont pas intégrés.')
                ensure_retouch_can_start(body.get('source'))
                return self.send_data(retouches_next.start(body,load_project,comfy_path))
            if route=='/api/retouches/new/stop':
                return self.send_data(retouches_next.stop(str(body.get('id') or '')))
            if route=='/api/retouches/install-workflows':
                return self.send_data(retouches_engine.install_workflows())
            if route=='/api/retouches/stop':
                return self.send_data(retouches_engine.stop(str(body.get('id') or '')))
            if route=='/api/retouches/start':
                source=body.get('source')
                ensure_retouch_can_start(source)
                resolved=retouch_video_source(source)
                if not resolved:raise ValueError('Source vidéo absente ou non validée')
                reference=retouch_image_reference(body.get('reference_path')) if body.get('reference_path') else None
                if body.get('reference_path') and not reference:raise ValueError('Image de référence introuvable ou hors répertoire ComfyUI autorisé')
                return self.send_data(retouches_engine.start(body,source,retouch_video_source,comfy_path,reference))
            if route=='/api/retouches/draft':
                def valid_project_clip(project,clip,variant):
                    data=project_data(project)
                    row=(data.get('clips') or {}).get(clip)
                    return bool(row and variant in ('hd','raw','final') and
                                row.get({'hd':'url','raw':'raw_url','final':'final_url'}[variant]))
                return self.send_data(studio_retouches.store_draft(body,project_clip_valid=valid_project_clip))
            if route=='/api/start':return self.send_data(start_film(body))
            if route=='/api/restart-project':return self.send_data(restart_project(str(body.get('project') or '')))
            if route=='/api/stop-older':return self.send_data(stop_older_session(body.get('pid')))
            if route=='/api/krea-clip':
                session=active_folder()
                if not session:raise ValueError('Pas de session Studio')
                return self.send_data(start_krea_clip_reference(body,session))
            if route=='/api/extend-timeline':
                ext = studio_local_helper('studio_timeline_extension')
                with LOCK:
                    proc=STATE.get('proc')
                    current_session=STATE.get('session')
                running=bool(proc and proc.poll() is None)
                name=str(body.get('project') or '')
                if not running and not name:
                    raise ValueError('Production inactive : sélectionne un film terminé à prolonger')
                active=json_get(Path(current_session)/'active_project.json',{}) if current_session else {}
                if running and (not name or active.get('name')!=name):
                    raise ValueError('La demande doit cibler le projet actuellement en cours')
                project=load_project(name)
                if not project:
                    raise ValueError('Projet introuvable')
                state=json_get(project/'_studio'/'resume_state.json',{})
                completed=bool(state.get('completed'))
                if not running and not completed:
                    raise ValueError('Projet non terminé et production inactive : utilise Reprendre.')
                try: extra=int(body.get('extra_seconds'))
                except (ValueError,TypeError): raise ValueError('Durée supplémentaire invalide')
                if not 0<=extra<=3600 or extra%5:
                    raise ValueError('Durée de 0 à 3600 secondes, multiple de 5 secondes')
                instructions=str(body.get('instructions') or '').strip()
                if len(instructions)>6000 or not (extra or instructions):
                    raise ValueError('Précise une durée ou une modification des scènes restantes (6000 caractères maximum)')
                if completed and extra==0:
                    raise ValueError('Un film terminé nécessite une durée supplémentaire (au moins 5 secondes).')
                if ext.pending_path(project).exists():
                    raise ValueError('Une prolongation est déjà programmée pour la prochaine frontière de scène')
                request_id=uuid.uuid4().hex
                ext.atomic_json(ext.pending_path(project),{'id':request_id,'extra_seconds':extra,
                               'instructions':instructions,'requested_at':time.time()})
                ext.atomic_json(project/'_studio'/'timeline_extension_status.json',
                                {'id':request_id,'status':'queued','extra_seconds':extra})
                if completed and not running:
                    try:
                        launched=restart_project(name,allow_finished_extension=True)
                    except Exception:
                        ext.pending_path(project).unlink(missing_ok=True)
                        raise
                    return self.send_data({'ok':True,'message':'Film terminé : reprise de la suite au Content Director. Les anciens clips sont intacts.','launched':launched})
                return self.send_data({'ok':True,'message':'Demande enregistrée. Content et Scene Director reprendront à la prochaine frontière de scène.'})
            session=active_folder()
            if route=='/api/answer':
                if not session:raise ValueError('Pas de session')
                q=json_get(session/'question.json',{})
                if q.get('id')!=body.get('id'):raise ValueError('Question expirée')
                write_json(session/'answers'/f"{q['id']}.json",{'value':body.get('value','')})
                return self.send_data({'ok':True})
            if route=='/api/bank-characters':
                name=str(body.get('project') or '')
                p=load_project(name)
                if not p:raise ValueError('Projet introuvable')
                names=reference_preview_engine().studio_refbank_module().existing_character_names(p)
                # A clip-local person is also an existing person for appearance links.
                # It may have been manually introduced and not yet committed to RefBank.
                q=json_get(session/'review.json',{}) if session else {}
                if q.get('kind')=='clips':
                    for ref in (q.get('payload') or {}).get('refs',[]):
                        if not isinstance(ref,dict):continue
                        if ref.get('kind')!='character' and ref.get('studio_visual_type')!='person':continue
                        candidate=str(ref.get('subject_name') or '').strip()
                        if candidate and candidate.casefold() not in {n.casefold() for n in names}:names.append(candidate)
                return self.send_data({'names':names})
            if route=='/api/reference-preview':
                if not session:raise ValueError('Pas de session')
                q=json_get(session/'review.json',{})
                if q.get('kind')!='clips' or q.get('id')!=body.get('id'):
                    raise ValueError('Validation clip expirée')
                data=q.get('payload') or {}
                original=str(data.get('text') or '')
                refs=data.get('refs') or []
                audio_refs=data.get('audio_refs') or []
                creative=str(body.get('body') or '')
                # Exactly the SAME native authority builder used by the renderer.
                film=reference_preview_engine()
                previous=film.reference_prompt_prefix(refs,audio_refs)
                if previous and creative.startswith(previous):
                    creative=creative[len(previous):].lstrip()
                if not creative.strip() or len(creative)>50000:
                    raise ValueError('Texte créatif vide ou trop long')
                reconstructed=(previous+'\n\n'+creative).strip() if previous else creative
                updated,images,voices=film.apply_clip_studio_edits(
                    {'edits':{'text':reconstructed,'creative_text':creative,'refs':body.get('refs'),'bank_deletes':body.get('bank_deletes') or []}},
                    original,refs,audio_refs,comfy_path(),
                    load_project((json_get(session/'active_project.json',{}) or {}).get('name','')),commit=False)
                new_prefix=film.reference_prompt_prefix(images,voices)
                return self.send_data({'text':updated,'prefix':new_prefix,'original_prefix':previous,
                                       'images':len(images),'audios':len(voices),
                                       'subjects':film.reference_subject_numbers(images),
                                       'resolved_names':[str(x.get('subject_name') or '') for x in images]})
            if route=='/api/review':
                if not session:raise ValueError('Pas de session')
                q=json_get(session/'review.json',{})
                if q.get('id')!=body.get('id'):raise ValueError('Validation expirée')
                action=body.get('action','continue')
                if action not in (('continue','revise','redo') if q.get('kind') in ('content','scenes') else ('continue','revise')):raise ValueError('Action invalide')
                edits=body.get('edits')
                if edits is not None:
                    if not isinstance(edits,dict) or action != 'continue':
                        raise ValueError('Édition directe possible uniquement avec Valider')
                    if not isinstance(edits.get('text'),str) or not 0<len(edits['text'].strip())<=100000:
                        raise ValueError('Texte vide ou trop long')
                    if q.get('kind') in ('content','scenes','plans'):
                        validate_director_text_edit(q, edits['text'])
                    elif q.get('kind') == 'clips':
                        refs=edits.get('refs')
                        deletes=edits.get('bank_deletes') or []
                        if not isinstance(deletes,list) or len(deletes)>8 or any(type(i)!=int or i<0 or i>7 for i in deletes):
                            raise ValueError('Suppression RefBank invalide')
                        if refs is not None and (not isinstance(refs,list) or len(refs)>16):
                            raise ValueError('Liste des références invalide')
                    else:
                        raise ValueError('Édition directe non disponible ici')
                write_json(session/'answers'/f"{q['id']}.json",{'action':action,'feedback':str(body.get('feedback') or ''),'edits':edits})
                return self.send_data({'ok':True})
            if route=='/api/stop':
                if not session: raise ValueError('Aucune production active')
                with LOCK: active_proc=STATE.get('proc')
                if not active_proc or active_proc.poll() is not None:
                    raise ValueError('La production est déjà arrêtée')
                request_worker_stop(session)
                problems=emergency_stop_all()
                note=(' Nettoyage partiel : '+' ; '.join(problems)) if problems else ''
                if problems:
                    with LOCK: STATE['last_error']=note
                return self.send_data({'ok':True,'message':
                   'Arrêt global demandé : arrêt llama-server/Ollama, interruption ComfyUI '
                   'et vidage de toute sa queue. Les clips validés sont conservés.'+note,
                   'issues':problems})
            if route=='/api/suspend':
                if not session:raise ValueError('Pas de session')
                with LOCK:active_proc=STATE.get('proc')
                if not active_proc or active_proc.poll() is not None:
                    raise ValueError('Aucun moteur actif à suspendre. Utilise « Reprendre le projet sélectionné » pour un ancien projet.')
                active=json_get(session/'active_project.json',{})
                project=load_project(active.get('name','')) if active else None
                if not project or not (project/'_studio'/'resume_state.json').is_file():
                    raise ValueError('Checkpoint non prêt : le scénario et les références doivent être initialisés avant suspension persistante.')
                (session/'suspend.request').write_text('1',encoding='utf-8')
                return self.send_data({'ok':True,'message':'Suspension demandée à la prochaine frontière sûre; le GPU ne sera pas interrompu.'})
            if route=='/api/pause':
                if not session:raise ValueError('Pas de session')
                (session/'pause.request').write_text('1',encoding='utf-8')
                return self.send_data({'ok':True,'message':'Pause à la prochaine frontière sûre'})
            if route=='/api/resume':
                if not session:raise ValueError('Pas de session')
                if (session/'suspend.request').exists():
                    raise ValueError('Suspension définitive demandée. Reprends ce projet après arrêt depuis la liste des projets.')
                (session/'pause.request').unlink(missing_ok=True)
                return self.send_data({'ok':True})
            if route=='/api/raw-decision':
                ensure_film_and_retouch_not_racing()
                if not session:raise ValueError('Pas de session')
                active=json_get(session/'active_project.json',{})
                project=load_project(active.get('name',''))
                if not project:raise ValueError('Projet introuvable')
                clip=int(body.get('clip') or 0)
                gate=project/'_studio'/'gates'/f'clip_{clip:04d}'
                if not gate.with_suffix('.waiting.json').is_file():raise ValueError('RAW non en attente')
                action=body.get('action')
                if action not in ('approve','redo','retouch'):raise ValueError('Action non autorisée')
                if gate.with_suffix('.decision.json').exists():raise ValueError('Décision déjà envoyée, attends le Director')
                feedback=str(body.get('feedback') or '').strip()
                if action=='retouch':
                    if pending_film_retouch(project.name,clip):raise ValueError('Retouche déjà demandée')
                    write_json(gate.with_suffix('.retouch.requested.json'),
                        {'clip':clip,'project':project.name,'session':session.name,'requested_at':time.time()})
                    # The unmodified V10.108 gate understands redo as a cancellation.
                    # Our Film worker intercepts this specific request BEFORE Clip Director.
                    write_json(gate.with_suffix('.decision.json'),{'action':'redo','feedback':'RAW transféré vers Retouches'})
                    return self.send_data({'ok':True,'message':'RAW libéré pour retouche; attente ComfyUI'})
                if action=='redo':
                    if not feedback:raise ValueError('Indique les corrections attendues avant de refuser le RAW')
                    # Durable retake request, independent from the temporary ComfyUI gate.
                    # A restarted FilmMaker can recover this even if the old renderer exits.
                    retake=gate.with_suffix('.retake.json')
                    previous=project/'prompts'/f'clip_{clip:04d}.txt'
                    old_prompt=previous.read_text(encoding='utf-8') if previous.is_file() else ''
                    clip_meta=json_get(project/'prompts'/f'clip_{clip:04d}.json',{}) or {}
                    write_json(retake,{'clip':clip,'status':'requested','feedback':feedback,
                                       'previous_prompt':old_prompt,
                                       'clip_prompt':clip_meta.get('clip_director_output') or '',
                                       'refs':clip_meta.get('active_references') or [],
                                       'audio_refs':clip_meta.get('active_audio_references') or [],
                                       'requested_at':time.time()})
                write_json(gate.with_suffix('.decision.json'),{'action':action,'feedback':feedback})
                return self.send_data({'ok':True,'message': 'Décision transmise au moteur'})
            if route=='/api/revision':
                # Non-destructive edit request: record and invalidate dependent downstream clips;
                # rerender of old clips is deliberately NOT simulated or falsely claimed complete.
                name=str(body.get('project') or '')
                p=load_project(name)
                if not p:raise ValueError('Projet introuvable')
                number=int(body.get('clip') or 0);feedback=str(body.get('feedback') or '').strip()
                if number<=0 or not feedback:raise ValueError('Choisis un clip et une modification')
                path=p/'_studio'/'revisions.json'
                db=json_get(path,{'items':[]})
                db.setdefault('items',[]).append({'clip':number,'feedback':feedback,'created':time.strftime('%Y-%m-%d %H:%M:%S'), 'status':'pending_manual_rerender','invalidates_from':number})
                write_json(path,db)
                return self.send_data({'ok':True,'message':f'Demande archivée. Clip {number} et suivants à revérifier ; aucun rendu existant supprimé.'})
            return self.send_data({'error':'Route inconnue'},404)
        except Exception as exc:return self.send_data({'error':str(exc)},400)

def main():
    # Check both bundled helpers before opening a port or starting production.
    studio_local_helper('studio_emergency_stop')
    studio_local_helper('studio_timeline_extension')
    restore_running_session()
    ap=argparse.ArgumentParser();ap.add_argument('--port',type=int,default=PORT);args=ap.parse_args()
    try:
        s=ThreadingHTTPServer(('127.0.0.1',args.port),Handler)
        print(f'STUDIO V10.32: http://127.0.0.1:{args.port} (local only)',flush=True)
        s.serve_forever()
    except KeyboardInterrupt:
        if os.environ.get('H3_RETOUCH_ONLY')=='1':
            # Retouches-only launch: never interrupt ComfyUI or FilmMaker when
            # shutting down just the lightweight local HTTP Studio server.
            print('Serveur Retouches arrêté. ComfyUI et ses rendus restent intacts.',flush=True)
        else:
            # The original Film Studio entrypoint retains its emergency stop.
            with LOCK:
                session=STATE.get('session')
                proc=STATE.get('proc')
            if session and proc and proc.poll() is None:
                request_worker_stop(session)
            problems=emergency_stop_all()
            print('Ctrl+C : arrêt général demandé (LLM, ComfyUI /interrupt + /queue clear).',flush=True)
            for issue in problems:
                print('  Attention :',issue,flush=True)
    finally:
        if 's' in locals(): s.server_close()
if __name__=='__main__':main()
