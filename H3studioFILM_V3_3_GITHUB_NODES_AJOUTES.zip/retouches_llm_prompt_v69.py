"""V10.66 H3 visual-retake prompt writer: reuses FilmMaker's established LLM
loading, chat and unloading functions. H3's original RAW video/latent (not this
text) is the visual reference. This module never runs pip or installs models.
"""
from __future__ import annotations
import os
import re
import shutil
import subprocess
import time
from pathlib import Path

SYSTEM = """You are the MiniMax H3 VIDEO DIRECTOR preparing a NEW TAKE from a filmed
original, not a vague edit command. The original VIDEO is connected to H3 as
<Video 1>; it was made using the attached ORIGINAL H3 SHOT PROMPT. Preserve
its scene, actor identities, clothing, set, physical geography, lighting,
cinematography, audio, and already filmed narrative events except for the
explicit requested change.

Produce a FRESH, COMPLETE H3 GENERATION PROMPT in the ORIGINAL clip's shot
format. If the original prompt has [Shot 1], [Shot 2], etc, write exactly
those SAME shots, in order, with matching time ranges if originally known.
If the original only has [Shot 1], write ONLY [Shot 1]. Do not split a camera
shot into new cuts. Never invent a new shot merely to fit the edit.
Preserve all supported <Subject N>, <Picture N>, <Audio N> reference markers,
but avoid inventing markers. <Video 1> is the actual original video reference.

Within the specified EDIT WINDOW, REPLACE conflicting original behavior with
the new action/emotion: first describe what the actor does at the start, then
the physical anticipation and onset, then an UNMISTAKABLE VISIBLE requested
motion/expression (body orientation, limbs, eyes, timing), its follow-through,
and a naturally motivated transition into the same original motion at the
exact edit-end boundary. Outside that window the shot must continue as in the
original VIDEO; do not restart, repeat or recreate the beginning or ending.
Make the core requested action salient, not buried under preservation clauses.
Adapt the beat to the available time without changing the user's request.
If the gesture is too long for the interval, use its clearest achievable
portion, not a fabricated instant jump.

OUTPUT ONLY: the shot text ready for MiniMax H3. Use [Shot N] headers,
concrete chronological cinematic prose and natural time indications. Do NOT
output an edit plan, a comparison table, headings called ORIGINAL/NEW, JSON,
meta-instructions, or an analysis. Never say you saw frames you did not see.
Do NOT repeat the old prompt verbatim where it contradicts the change.
"""


def ensure_ollama_running(film, *, timeout=28.0):
    """Use the same `ollama serve` startup method as FilmMaker's PowerShell.

    Does NOT install software, pull a model, change CUDA, or replace Python.
    Leaves the daemon running just like FilmMaker. The specific Gemma model is
    explicitly unloaded by FilmMaker after writing the prompt.
    """
    url = film.rt.OLLAMA_URL + '/api/tags'
    try:
        return film.rt.http_json(url, timeout=3)
    except Exception as exc:
        start_exc = exc
    exe=shutil.which('ollama.exe') or shutil.which('ollama')
    if not exe and os.name=='nt':
        candidates=[Path(os.environ.get('LOCALAPPDATA',''))/'Programs'/'Ollama'/'ollama.exe',
                    Path(os.environ.get('PROGRAMFILES','C:/Program Files'))/'Ollama'/'ollama.exe']
        exe=next((str(p) for p in candidates if p.is_file()),None)
    if not exe:
        raise RuntimeError('Retouches : Ollama est indisponible : ollama.exe introuvable. '
                           'Aucun modèle ni logiciel ne sera installé.') from start_exc
    kwargs={'stdin':subprocess.DEVNULL,'stdout':subprocess.DEVNULL,
            'stderr':subprocess.DEVNULL,'cwd':str(Path(exe).resolve().parent)}
    if os.name=='nt':
        kwargs['creationflags']=getattr(subprocess,'CREATE_NO_WINDOW',0)
    print('[RETOUCHES] Ollama arrêté : lancement automatique de ollama serve...',flush=True)
    try:
        proc=subprocess.Popen([exe,'serve'],**kwargs)
    except OSError as exc:
        raise RuntimeError('Impossible de lancer Ollama automatiquement : '+str(exc)) from exc
    end=time.monotonic()+float(timeout)
    last=None
    while time.monotonic()<end:
        try:
            tags=film.rt.http_json(url,timeout=3)
            print('[RETOUCHES] Ollama prêt, modèle non encore chargé.',flush=True)
            return tags
        except Exception as exc:
            last=exc
        if proc.poll() is not None:
            # It can exit because an existing Ollama instance took the port.
            # Try one more time; never terminate external processes.
            try:return film.rt.http_json(url,timeout=3)
            except Exception:break
        time.sleep(1)
    raise RuntimeError('Ollama ne répond pas après démarrage automatique : '
                       +str(last or 'processus terminé'))


def choose_backend(film):
    """Select ONLY the pre-installed Gemma 4 26B in Ollama (FilmMaker backend).

    Never fallback to Qwen3.8 27B / llama-server; no installation or download.
    Fail closed if Ollama or Gemma 26B is unavailable.
    """
    # The FilmMaker's actual model naming from select_text_backend():
    #   gemma4:26b-a4b-it-q4_K_M
    tags = ensure_ollama_running(film)
    names = film.installed_model_names(tags)
    # Prefer the exact GGUF/quant used by the existing Film Studio; accept
    # alternate 26B tags if a compatible variant is already installed.
    preferred = 'gemma4:26b-a4b-it-q4_k_m'
    model = next((n for n in names if n.casefold() == preferred), None)
    if model is None:
        model = next((n for n in names if n.casefold().startswith('gemma4:26b')), None)
    if not model:
        raise RuntimeError(
            'Retouches : Gemma 4 26B Ollama introuvable. '
            'Modele attendu : gemma4:26b-a4b-it-q4_K_M. '
            'Modeles Ollama presents : ' + (', '.join(names) or '(aucun)') + '. '
            'Qwen 27B interdit pour ce mode, rien ne sera telecharge.'
        )
    backend = film._ollama_backend(model)
    if backend.get('provider') != 'ollama':
        raise RuntimeError('Retouches : backend Ollama attendu, generation annulee.')
    print('[RETOUCHES] Modele de prompt : ' + model + ' | Ollama | PAS de Qwen 27B', flush=True)
    return backend


# ``[Shot N]`` is H3's real authoring format. Do not manufacture shot cuts.
SHOT_RE = re.compile(r"\[Shot\s+(\d+)\]", re.IGNORECASE)


def original_shots(source_prompt: str) -> list[int]:
    identifiers = [int(m.group(1)) for m in SHOT_RE.finditer(source_prompt or '')]
    # Some approved clips have no explicit markers; they are one continuous shot.
    return list(dict.fromkeys(identifiers)) or [1]


def build_request(mode,performance_type,request,source_prompt,start,end,duration):
    shots=original_shots(source_prompt)
    kind = 'Retake precise' if mode=='precise' else ('Performance Action' if performance_type=='action' else 'Performance Emotion')
    span=end-start
    onset=start+span*.20
    peak=start+span*.60
    rejoin=start+span*.86
    historical=str(source_prompt or '').strip()
    # Do not infer imaginary historical actions when FilmMaker has no prompt on disk.
    if not historical:
        historical='[Shot 1] (Original text missing: use <Video 1> as the sole visual truth. Do not invent unobserved actions.)'
    historical=historical[:11500]
    shot_format=', '.join(f'[Shot {i}]' for i in shots)
    return (
        'GENERATE A COMPLETE NEW TAKE OF THE ORIGINAL H3 CLIP.\n'
        f'MODE: {kind}\n'
        '<Video 1> IS THE REAL ORIGINAL VIDEO REFERENCE PROVIDED TO H3. '
        'It is the actual output of the ORIGINAL H3 PROMPT below; the old text '
        'describes the intended shot, but <Video 1> wins for the actual framing, appearance and motion.\n'
        f'EXACT NEW CHANGE TO SHOW ON SCREEN: {request.strip()}\n'
        f'CLIP DURATION: {duration:.3f} seconds. KEEP THIS DURATION.\n'
        f'ORIGINAL SHOT STRUCTURE (COPY THESE HEADERS, NO EXTRA SHOTS): {shot_format}\n'
        f'CHANGE IS ALLOWED ONLY FROM {start:.3f}s TO {end:.3f}s.\n'
        'Write the NEW COMPLETE CLIP, preserving the filmed start, all previous '
        'events and the filmed ending, with the requested change incorporated '
        'as if it had always been part of this take.\n'
        'CINEMATIC CONTINUITY AND PHYSICAL PERFORMANCE (NOT SEPARATE NEW CUTS):\n'
        f'0.000–{start:.3f}s: the genuine filmed opening, unchanged; preserve <Video 1>.\n'
        f'{start:.3f}–{onset:.3f}s: begin the actor\'s motivated, anatomically coherent anticipation.\n'
        f'{onset:.3f}–{peak:.3f}s: visibly PERFORM the requested change, not a facial substitute or unrelated motion.\n'
        f'{peak:.3f}–{rejoin:.3f}s: finish the physical action and enter a natural transitional motion.\n'
        f'{rejoin:.3f}–{end:.3f}s: join the ORIGINAL pose and momentum exactly by the cut-off.\n'
        f'{end:.3f}–{duration:.3f}s: preserve original filmed continuation/end as <Video 1>.\n'
        'Produce original-style camera/lighting, blocking, interactions, body mechanics, '
        'and scene sound in one cohesive H3-ready film prompt. Do not replace the action '
        'with merely a smile, a change of mood or another convenient gesture. '
        'No cuts/fades/new scene unless the ORIGINAL shot structure already had them. '
        'Preserve existing shot header count and the real source-video visual authority.\n'
        'ORIGINAL H3 PROMPT (HISTORICAL BLUEPRINT TO REWRITE):\n'+historical
    )


def assemble(original_request,result,start,end,duration,source_prompt=''):
    result=str(result or '').strip()
    result=re.sub(r'^```(?:[\w-]+)?\s*|\s*```$','',result).strip()
    if not result or len(result)<90:
        raise RuntimeError('Gemma Retake : nouveau prompt du clip absent ou trop court ; H3 non lancé')
    if len(result)>10500:
        raise RuntimeError('Gemma Retake : prompt trop long ; H3 non lancé')
    required=original_shots(source_prompt)
    found=original_shots(result) if SHOT_RE.search(result) else []
    if found!=required:
        raise RuntimeError('Gemma Retake : découpage de shots incohérent : attendu '
                           +str(required)+', reçu '+str(found)+' ; H3 non lancé')
    # Wrapper speaks H3's actual multimodal reference syntax. This is not a
    # deterministic inpaint solver: the RAW mask enforces the selected time/ROI.
    return (
        'NEW TAKE of <Video 1> — ORIGINAL VIDEO REFERENCE. '
        '<Video 1> is the filmed version of the original H3 shot prompt. '
        'Use its actual visuals, same actors, scene, camera and ambient sound.\n'
        f'VISIBLE NEW ACTION/EMOTION: {original_request.strip()}\n'
        +result+'\n'
        f'CONTINUITY: original filmed motion before {start:.3f}s and after '
        f'{end:.3f}s, through the original ending at {duration:.3f}s. '
        'The transition back to original pose and timing completes before the '
        'end of the editable interval. One same-size, same-duration clip.'
    )



def write_prompt(*,mode,performance_type,request,source_prompt,start,end,duration,gpu_prepare):
    if mode!='precise' and (mode!='performance' or performance_type not in ('action','emotion')):
        raise ValueError('Retake LLM réservé aux retouches visuelles, pas au dialogue')
    if not(0<=start<end<=duration+.03):raise ValueError('Intervalle retake invalide')
    import h3film_studio_v3 as film  # reuse *existing* FilmMaker LLM backend
    gpu_prepare()                     # release H3 memory before loading Gemma 4 26B
    backend=choose_backend(film)
    output=None
    try:
        output=film.director_text(backend,SYSTEM,build_request(mode,performance_type,request,source_prompt,start,end,duration),
                                 label='RETOUCH DIRECTOR GEMMA 4 26B / OLLAMA',num_ctx=12288,num_predict=1450)
    finally:
        # H3 must not coexist with Gemma 26B loaded on a 16GB card.
        # FilmMaker owns/knows its own process; never kill external PIDs.
        try:
            film.unload_text_backend(backend,label='Avant retouche H3')
        finally:
            film.release_all_text_models_for_h3(label='Retouches : H3 prend le GPU')
    return assemble(request,output,start,end,duration,source_prompt),'Gemma 26B · New Take même structure [Shot] · '+str(backend.get('display') or backend.get('model'))
