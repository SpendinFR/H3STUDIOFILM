from __future__ import annotations

import copy
import json
import os
import re
import shutil
import subprocess
import sys
import time
import threading
import uuid
import unicodedata
from datetime import datetime
from pathlib import Path
from typing import Any
import importlib.util

# Embedded ComfyUI Python can run in isolated mode and ignore PYTHONPATH.
# Load the local bridge by its exact file path, not through sys.path resolution.
ROOT = Path(__file__).resolve().parent
_bridge_file = ROOT / "studio_bridge.py"
if not _bridge_file.is_file():
    raise RuntimeError(f"FilmMaker Studio incomplet: {_bridge_file} manque. Extraire TOUT le ZIP.")
_bridge_spec = importlib.util.spec_from_file_location("studio_bridge", _bridge_file)
if not _bridge_spec or not _bridge_spec.loader:
    raise RuntimeError(f"Impossible de charger {_bridge_file}")
studio = importlib.util.module_from_spec(_bridge_spec)
sys.modules["studio_bridge"] = studio
_bridge_spec.loader.exec_module(studio)
if studio.enabled():
    import builtins
    builtins.input = studio.ask_input

ROOT = Path(__file__).resolve().parent
_RUNTIME_FILE = ROOT / "h3_runtime_simple.py"
if not _RUNTIME_FILE.is_file():
    raise RuntimeError(f"Runtime manquant: {_RUNTIME_FILE}")
_spec = importlib.util.spec_from_file_location("h3_runtime_simple", _RUNTIME_FILE)
if _spec is None or _spec.loader is None:
    raise RuntimeError(f"Impossible de charger le runtime: {_RUNTIME_FILE}")
rt = importlib.util.module_from_spec(_spec)
sys.modules["h3_runtime_simple"] = rt
_spec.loader.exec_module(rt)


def studio_refbank_module(name: str = 'studio_refbank_edits'):
    """Load a bundled Studio helper by exact path under isolated Python.

    Keep the existing RefBank loader and its caching; only permit known bundled
    helpers. The embedded ComfyUI interpreter ignores PYTHONPATH and script dir.
    """
    if name not in ('studio_refbank_edits', 'studio_timeline_extension', 'studio_emergency_stop', 'studio_lora', 'studio_dialogue_budget', 'studio_content_types'):
        raise ValueError(f'Composant Studio inconnu : {name}')
    cached = sys.modules.get(name)
    if cached is not None:
        return cached
    source = ROOT / (name + '.py')
    if not source.is_file():
        raise RuntimeError(f'Composant RefBank manquant : {source}. Extrais le ZIP entier.')
    spec = importlib.util.spec_from_file_location(name, source)
    if not spec or not spec.loader:
        raise RuntimeError(f'Impossible de charger le composant RefBank : {source}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    try:
        spec.loader.exec_module(module)
    except BaseException:
        sys.modules.pop(name, None)
        raise
    return module


def reference_subject_numbers(refs: list[dict[str, Any]]) -> list[int]:
    """Same Subject grouping as reference_prompt_prefix; Picture != Subject."""
    seen: dict[str, int] = {}
    numbers: list[int] = []
    for r in refs:
        key = str(r.get('subject_key') or f"ref_{r.get('picture_order')}")
        if key not in seen:
            seen[key] = len(seen) + 1
        numbers.append(seen[key])
    return numbers

PROMPTS_DIR = ROOT / "prompts"
CONTENT_DIRECTOR_PROMPT = (PROMPTS_DIR / "CONTENT_DIRECTOR.txt").read_text(encoding="utf-8")
SCENE_DIRECTOR_PROMPT = (PROMPTS_DIR / "SCENE_DIRECTOR.txt").read_text(encoding="utf-8")
PLAN_DIRECTOR_PROMPT = (PROMPTS_DIR / "PLAN_DIRECTOR.txt").read_text(encoding="utf-8")
CLIP_DIRECTOR_PROMPT = (PROMPTS_DIR / "CLIP_DIRECTOR.txt").read_text(encoding="utf-8")
KREA_REFERENCE_WORKFLOW = ROOT / "workflows" / "Krea_reference.json"
KREA_REFERENCE_IMG_WORKFLOW = ROOT / "workflows" / "Krea_reference_img2img.json"
KREA_REFERENCE_SREF_WORKFLOW = ROOT / "workflows" / "Krea_reference_sref.json"

OUTPUT_ROOT_NAME = "H3FilmSimple"
WIDTH = 960
HEIGHT = 544
QUALITY_DIMS = {"standard": (960, 544), "quality": (1152, 640)}  # legacy metadata only; no interactive choice
H3_CLEAN_WORKFLOW = ROOT / "workflows" / "H3Studio_1920_API_CLEAN.json"


def workflow_raw_dimensions() -> tuple[int, int]:
    """Use the RAW resolution authored in the supplied H3 workflow; never ask the user."""
    data = json.loads(H3_CLEAN_WORKFLOW.read_text(encoding="utf-8"))
    matches = [n for n in data.get("nodes", []) if n.get("type") == "H3StudioImageToVideo" and n.get("mode", 0) in (0, None)]
    if len(matches) != 1:
        raise RuntimeError(f"Workflow H3: attendu exactement 1 H3StudioImageToVideo actif, trouvé {len(matches)}")
    hv = dict((matches[0].get("properties") or {}).get("h3_widget_values") or {})
    w, h = int(hv.get("width") or 0), int(hv.get("height") or 0)
    if w <= 0 or h <= 0:
        raise RuntimeError("Workflow H3: width/height RAW introuvables dans h3_widget_values")
    return w, h


def clean_md(text: str) -> str:
    text = (text or "").replace("```yaml", "").replace("```json", "").replace("```", "")
    text = text.replace("**", "")
    # Some local-model decoders occasionally expose a stray UTF-8 byte marker
    # before a structural number, e.g. ``SCÈNE <0xC2>6``. Treat only the known
    # spacing markers as whitespace so the structure-first parser keeps the scene.
    text = re.sub(r"(?i)<0x(?:C2|A0)>", " ", text)
    # Some smaller/local models emit LaTeX arrows in otherwise perfectly valid
    # timeline headers, e.g. ``ACTE I — 00:00 $\\rightarrow$ 00:30``.
    # Normalize formatting only; timeline validation remains strict below.
    text = re.sub(r"\$\s*\\(?:long)?rightarrow\s*\$", "→", text, flags=re.IGNORECASE)
    text = re.sub(r"\$\s*\\to\s*\$", "→", text, flags=re.IGNORECASE)
    # Directors often add harmless Markdown headings/list markers even when the
    # requested structure is otherwise perfect. Do not spend a second LLM call
    # repairing formatting that we can parse safely ourselves.
    text = re.sub(r"(?m)^\s*#{1,6}\s*", "", text)
    text = re.sub(
        r"(?im)^\s*[-*]\s+(?=(?:ACTE|PARTIE|SECTION|CHAPITRE|SEGMENT|SC[ÈE]NE|PLAN)\b)",
        "", text,
    )
    return text.strip()


def parse_duration_seconds(raw: str) -> int:
    s = (raw or "").strip().lower().replace(",", ".")
    if not s:
        raise ValueError("durée vide")
    if re.fullmatch(r"\d+(?:\.\d+)?", s):
        # Simple numeric input = minutes, convenient for the interactive UI.
        return int(round(float(s) * 60))
    m = re.fullmatch(r"(\d+(?:\.\d+)?)\s*(h|hr|heure|heures)", s)
    if m:
        return int(round(float(m.group(1)) * 3600))
    m = re.fullmatch(r"(\d+(?:\.\d+)?)\s*(m|min|minute|minutes)", s)
    if m:
        return int(round(float(m.group(1)) * 60))
    m = re.fullmatch(r"(\d+(?:\.\d+)?)\s*(s|sec|seconde|secondes)", s)
    if m:
        return int(round(float(m.group(1))))
    if re.fullmatch(r"\d{1,2}:\d{2}(?::\d{2})?", s):
        parts = [int(x) for x in s.split(":")]
        if len(parts) == 2:
            return parts[0] * 60 + parts[1]
        return parts[0] * 3600 + parts[1] * 60 + parts[2]
    raise ValueError("format attendu: 1h, 60m, 5m, 300s ou 01:00:00")


def tc(seconds: int) -> str:
    seconds = max(0, int(seconds))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def parse_tc(value: str) -> int:
    s = str(value or "").strip().replace(" ", "")
    parts = s.split(":")
    if not all(x.isdigit() for x in parts):
        raise ValueError(s)
    nums = [int(x) for x in parts]
    if len(nums) == 2:
        return nums[0] * 60 + nums[1]
    if len(nums) == 3:
        return nums[0] * 3600 + nums[1] * 60 + nums[2]
    raise ValueError(s)


def ollama_text(model: str, system: str, user: str, *, label: str, num_ctx: int = 16384, num_predict: int = 8192) -> str:
    # Keep the Director model resident only between consecutive Director calls.
    # It is explicitly unloaded before every H3 render below. This avoids
    # repeatedly destroying/restarting Gemma 4 (especially 26B + MTP) between
    # Film -> Plan -> Clip while preserving the VRAM/RAM safety boundary at H3.
    payload = {
        "model": model,
        "stream": False,
        "think": False,
        "keep_alive": "10m",
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "options": {
            "temperature": 0.35,
            "num_ctx": int(num_ctx),
            "num_predict": int(num_predict),
        },
    }
    model_low = str(model or "").lower()
    qwen3vl_thinking_only = ("qwen3-vl" in model_low or "qwen3vl" in model_low) and "instruct" not in model_low
    if qwen3vl_thinking_only:
        # Text-only helper calls such as Appearance Intent can hit the same Qwen3-VL
        # thinking-only pathology as vision calls. Force the same no-think prefill from
        # the first request instead of burning the context and retrying identically.
        payload["raw"] = True
        payload["messages"] = [
            {"role": "system", "content": system},
            {"role": "user", "content": user + "\n/no_think\nReturn only the requested final answer now. No reasoning."},
            {"role": "assistant", "content": "<think>\n\n</think>\n\n"},
        ]
    last_exc: Exception | None = None
    for attempt in range(1, 3):
        try:
            out = rt.http_json(rt.OLLAMA_URL + "/api/chat", "POST", payload, timeout=600)
            msg = out.get("message") if isinstance(out, dict) else None
            text = str((msg or {}).get("content") or "").strip() if isinstance(msg, dict) else ""
            if text:
                return text
            reason = str(out.get("done_reason") or "") if isinstance(out, dict) else ""
            raise RuntimeError(f"réponse vide{(' (' + reason + ')') if reason else ''}")
        except Exception as exc:
            last_exc = exc
            if attempt < 2:
                msg = str(exc)
                if "Gemma4Assistant requires ctx_other" in msg or "llama-server process has terminated" in msg:
                    print(f"  {label}: Gemma 4/Ollama a raté le chargement, libération complète puis retry propre...")
                    try:
                        rt.unload_all_ollama_models()
                    except Exception:
                        pass
                    time.sleep(3.0)
                else:
                    print(f"  {label}: réponse indisponible, retry transport identique...")
                    time.sleep(0.8)
    raise RuntimeError(f"{label}: aucun texte reçu de {model}: {last_exc}")


def installed_model_names(tags: dict) -> list[str]:
    out = []
    for row in tags.get("models", []) if isinstance(tags, dict) else []:
        name = row.get("name") or row.get("model")
        if name:
            out.append(str(name))
    return out


def choose_text_model(tags: dict) -> str:
    override = os.environ.get("H3FILM_TEXT_MODEL", "").strip()
    names = installed_model_names(tags)
    if override:
        for n in names:
            if n.casefold() == override.casefold() or (":" not in override and n.split(":")[0].casefold() == override.casefold()):
                return n
        raise RuntimeError(f"H3FILM_TEXT_MODEL={override} n'est pas installé dans Ollama.")
    prefs = [
        "gemma4:12b", "gemma4:26b-a4b-it-q4_K_M", "qwen3.5:9b", "qwen3.5:latest", "qwen3:14b", "qwen3:8b",
        "qwen2.5:14b", "mistral-nemo:12b", "mistral-nemo:latest",
    ]
    low = {n.casefold(): n for n in names}
    for p in prefs:
        if p.casefold() in low:
            return low[p.casefold()]
    for n in names:
        ln = n.casefold()
        if not any(x in ln for x in ("vision", "qwen3-vl", "qwen3vl", "qwen2.5vl")):
            return n
    raise RuntimeError("Aucun LLM texte Ollama détecté.")


# llama.cpp / ik_llama.cpp models already used on this machine. Environment
# variables can override every path without changing the pipeline or prompts.
_KIWI_ROOT = Path(os.environ.get(
    "H3FILM_KIWI_ROOT",
    r"C:\Users\wabad\Downloads\kiwi_meta_compress_v3v4\kiwi_meta_compress_v3v4",
))
_QWEN38_SERVER_EXE = Path(os.environ.get(
    "H3FILM_QWEN38_SERVER_EXE",
    str(_KIWI_ROOT / "bld" / "ikninja-sm120" / "bin" / "llama-server.exe"),
))
_LLAMA_SETTINGS = Path(os.environ.get(
    "H3FILM_LLAMA_SETTINGS",
    r"C:\Users\wabad\Downloads\qwen_codex_FINALOPTI\qwen_codex_local_v3\settings.json",
))
_QWEN38_MODEL = Path(os.environ.get(
    "H3FILM_QWEN38_MODEL",
    str(_KIWI_ROOT / "models" / "Qwen3.8-27B-ik-IQ4_KS" / "Qwen3.8-27B-ik_llama-IQ4_KS.gguf"),
))
_JPETRINA_SERVER_EXE = Path(os.environ.get(
    "H3FILM_JPETRINA_SERVER_EXE",
    str(_KIWI_ROOT / "third_party" / "llama-b10514-bin" / "llama-server.exe"),
))
_JPETRINA_MODEL = Path(os.environ.get(
    "H3FILM_JPETRINA_MODEL",
    str(_KIWI_ROOT / "models" / "Qwen3.8-27B-IQ4_XS-pure-Jpetrina" / "qwen3.8-27b-IQ4_XS-pure.gguf"),
))
_LLAMA_HOST = "127.0.0.1"
_LLAMA_PORT = int(os.environ.get("H3FILM_LLAMA_PORT", "18080"))
_LLAMA_BASE = f"http://{_LLAMA_HOST}:{_LLAMA_PORT}"
# Qwen3.8 27B needs more than 16K once the persistent film bible, full scene
# context and previous H3 handoff are combined. 24K is a deliberate middle
# ground: enough headroom for the Directors without jumping straight to 32K
# and wasting scarce 16 GB VRAM. JPETRINA keeps its proven 16K default.
_QWEN38_CTX = int(os.environ.get("H3FILM_QWEN38_CTX", "24576"))
_JPETRINA_CTX = int(os.environ.get("H3FILM_JPETRINA_CTX", "16384"))
_LLAMA_PROC: subprocess.Popen | None = None
_LLAMA_ACTIVE_KEY = ""


def _ollama_backend(model: str) -> dict[str, Any]:
    return {"provider": "ollama", "model": model, "display": model}


def _llama_backend(key: str) -> dict[str, Any]:
    if key == "qwen38":
        return {
            "provider": "llamacpp", "key": key, "model": "qwen3.8-27b",
            "display": f"Qwen3.8 27B — ik_llama.cpp SM120 {_QWEN38_CTX // 1024}K no-think", "path": str(_QWEN38_MODEL),
        }
    if key == "jpetrina":
        return {
            "provider": "llamacpp", "key": key, "model": "qwen3.8-27b-jpetrina",
            "display": "JPETRINA — llama.cpp b10514 16K no-think", "path": str(_JPETRINA_MODEL),
        }
    raise RuntimeError(key)


def _backend_signature(backend: dict[str, Any]) -> tuple[str, str]:
    provider = str(backend.get("provider") or "")
    ident = str(backend.get("key") or backend.get("model") or "")
    return provider, ident.casefold()


def same_text_backend(a: dict[str, Any], b: dict[str, Any]) -> bool:
    return _backend_signature(a) == _backend_signature(b)


def select_text_backend(tags: dict, *, role: str = "DIRECTOR", env_var: str = "H3FILM_TEXT_MODEL") -> dict[str, Any]:
    """Choose one Director LLM for one role. Director prompts are never changed by this choice."""
    override = os.environ.get(env_var, "").strip() or os.environ.get("H3FILM_TEXT_MODEL", "").strip()
    if override:
        low = override.casefold()
        if low in {"27", "qwen38", "qwen3.8", "qwen3.8-27b"}:
            return _llama_backend("qwen38")
        if low in {"jp", "jpet", "jpetrina", "qwen38-jpetrina", "qwen3.8-jpetrina"}:
            return _llama_backend("jpetrina")
        names = installed_model_names(tags)
        for n in names:
            nl = n.casefold()
            if nl == low or (":" not in override and n.split(":")[0].casefold() == low):
                return _ollama_backend(n)
        raise RuntimeError(f"{env_var}={override} n'est pas installé dans Ollama.")

    names = installed_model_names(tags)
    by_low = {n.casefold(): n for n in names}
    g12 = by_low.get("gemma4:12b")
    g26 = by_low.get("gemma4:26b-a4b-it-q4_k_m")
    q9 = by_low.get("qwen3.5:9b") or by_low.get("qwen3.5:latest")

    print(f"\n{role} — CHOIX DU MODÈLE")
    if g12:
        print(f"[Entrée/12] {g12}")
    if g26:
        print(f"[26]        {g26}")
    if q9:
        print(f"[9]         {q9}")
    print(f"[27]        Qwen3.8 27B — ik_llama.cpp SM120 {_QWEN38_CTX // 1024}K no-think")
    print("[JP]        JPETRINA — llama.cpp b10514 16K no-think")
    # Web Studio has its own model setting; do not consume prefilled brief answers.
    choice = '' if studio.enabled() else input("> ").strip().lower()

    if choice in {"27", "q27", "qwen38", "qwen3.8"}:
        return _llama_backend("qwen38")
    if choice in {"jp", "j", "jpet", "jpetrina"}:
        return _llama_backend("jpetrina")
    if choice in {"9", "9b", "q9", "qwen9", "qwen3.5"} and q9:
        return _ollama_backend(q9)
    if choice in {"26", "26b", "2"} and g26:
        return _ollama_backend(g26)
    if choice in {"12", "12b", "1", ""} and g12:
        return _ollama_backend(g12)
    if g12:
        print(f"  Choix non reconnu -> défaut {g12}")
        return _ollama_backend(g12)
    return _ollama_backend(choose_text_model(tags))


def _load_llama_settings() -> dict[str, Any]:
    if not _LLAMA_SETTINGS.is_file():
        raise RuntimeError(
            f"settings.json introuvable: {_LLAMA_SETTINGS}\n"
            "Définis H3FILM_LLAMA_SETTINGS si son emplacement a changé."
        )
    try:
        data = json.loads(_LLAMA_SETTINGS.read_text(encoding="utf-8-sig"))
    except Exception as exc:
        raise RuntimeError(f"Impossible de lire {_LLAMA_SETTINGS}: {exc}") from exc
    for key in ("main_context", "main_fit_margin"):
        if key not in data:
            raise RuntimeError(f"Clé {key} absente de {_LLAMA_SETTINGS}")
    return data


def _llama_context_for_backend(backend: dict[str, Any]) -> int:
    key = str(backend.get("key") or "")
    if key == "qwen38":
        return max(8192, int(_QWEN38_CTX))
    if key == "jpetrina":
        return max(8192, int(_JPETRINA_CTX))
    return 16384


def _llama_launch_args(backend: dict[str, Any]) -> list[str]:
    key = str(backend.get("key") or "")
    if key == "qwen38":
        server_exe = _QWEN38_SERVER_EXE
        model_path = Path(str(backend["path"]))
        batch = 64
    elif key == "jpetrina":
        server_exe = _JPETRINA_SERVER_EXE
        model_path = Path(str(backend["path"]))
        batch = 512
    else:
        raise RuntimeError(f"Backend llama.cpp non supporté: {key}")

    if not server_exe.is_file():
        raise RuntimeError(
            f"llama-server.exe {key} introuvable: {server_exe}"
        )
    if not model_path.is_file():
        raise RuntimeError(
            f"Modèle {key} introuvable: {model_path}"
        )

    # Qwen3.8 uses a 24K context by default: the full film/scene context plus
    # the previous H3 prompt can legitimately exceed 16K from clip 2 onward.
    # JPETRINA keeps its separately configurable proven default.
    ctx = _llama_context_for_backend(backend)
    return [
        str(server_exe), "-m", str(model_path),
        "-c", str(ctx),
        "-b", str(batch), "-ub", str(batch),
        "-t", "6", "-tb", "6",
        "-ctk", "q4_0", "-ctv", "q4_0",
        "--host", _LLAMA_HOST, "--port", str(_LLAMA_PORT),
    ]


def _llama_health_ok() -> bool:
    try:
        out = rt.http_json(_LLAMA_BASE + "/health", timeout=2)
        return isinstance(out, dict) and str(out.get("status", "")).casefold() in {"ok", "ready"}
    except Exception:
        return False


def _prepare_llama_vram(backend: dict[str, Any]) -> None:
    """Force ComfyUI to release GPU memory before loading either near-full-VRAM 27B profile."""
    key = str(backend.get("key") or "")
    if key not in {"qwen38", "jpetrina"}:
        return
    min_free_mb = 14000 if key == "jpetrina" else 14500
    display = str(backend.get("display") or key)
    rt.comfy_hard_free(f"Avant {display}")

    deadline = time.time() + 75
    stable = 0
    while time.time() < deadline:
        v = rt.query_gpu_vram()
        if v is None:
            print(f"  Avant {display}: VRAM non mesurable, lancement après nettoyage ComfyUI")
            return
        if v["free"] >= min_free_mb:
            stable += 1
            if stable >= 3:
                rt.print_gpu_vram(f"Avant {display} — VRAM prête")
                return
        else:
            stable = 0
        time.sleep(1.5)

    v = rt.query_gpu_vram()
    state = f"{v['free']} MiB libres" if v else "VRAM inconnue"
    raise RuntimeError(
        f"{display}: ComfyUI a été déchargé mais la VRAM n'est pas assez libre ({state}). "
        f"Il faut au moins {min_free_mb} MiB libres pour éviter un offload lent."
    )


def ensure_llama_server(backend: dict[str, Any]) -> None:
    global _LLAMA_PROC, _LLAMA_ACTIVE_KEY
    key = str(backend.get("key") or "")
    if _LLAMA_PROC is not None and _LLAMA_PROC.poll() is None and _LLAMA_ACTIVE_KEY == key and _llama_health_ok():
        return
    if _LLAMA_PROC is not None and _LLAMA_PROC.poll() is None:
        try:
            _LLAMA_PROC.terminate(); _LLAMA_PROC.wait(timeout=8)
        except Exception:
            try: _LLAMA_PROC.kill()
            except Exception: pass
        _LLAMA_PROC = None
    if _llama_health_ok():
        raise RuntimeError(
            f"Le port {_LLAMA_PORT} est déjà occupé par un llama-server externe. "
            "Ferme-le pour que H3Film puisse gérer automatiquement chargement/déchargement VRAM."
        )

    # Both 27B profiles nearly fill the 16 GB RTX 5080. Release ComfyUI
    # only when a fresh llama.cpp server actually has to be started.
    if key in {"qwen38", "jpetrina"}:
        _prepare_llama_vram(backend)

    args = _llama_launch_args(backend)
    log_path = ROOT / "llama_server_last.log"
    log = open(log_path, "w", encoding="utf-8", errors="replace")
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    _LLAMA_PROC = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT, creationflags=flags)
    _LLAMA_ACTIVE_KEY = key
    deadline = time.time() + 180
    while time.time() < deadline:
        if _LLAMA_PROC.poll() is not None:
            raise RuntimeError(f"llama-server s'est arrêté au démarrage. Voir {log_path}")
        if _llama_health_ok():
            return
        time.sleep(1.0)
    raise RuntimeError(f"llama-server non prêt après 180 s. Voir {log_path}")


def stop_llama_server(label: str = "") -> None:
    global _LLAMA_PROC, _LLAMA_ACTIVE_KEY
    if _LLAMA_PROC is None:
        return
    if _LLAMA_PROC.poll() is None:
        try:
            _LLAMA_PROC.terminate()
            _LLAMA_PROC.wait(timeout=15)
        except Exception:
            try:
                _LLAMA_PROC.kill()
                _LLAMA_PROC.wait(timeout=8)
            except Exception as exc:
                raise RuntimeError(
                    f"{label}: llama-server FilmMaker ne s'arrête pas : {exc}. "
                    "RAW H3 non lancé pour éviter la concurrence GPU."
                ) from exc
        if _LLAMA_PROC.poll() is None:
            raise RuntimeError(f"{label}: llama-server toujours actif après arrêt. H3 non lancé.")
    _LLAMA_PROC = None
    _LLAMA_ACTIVE_KEY = ""
    if label:
        print(f"  {label}: llama.cpp arrêté et processus terminé avant H3")



def _llama_final_answer(text: str, label: str) -> str:
    """Return only the final answer; never forward llama.cpp <think> scratch reasoning."""
    raw = str(text or "").strip()
    if not raw:
        return ""
    low = raw.lower()
    if "<think>" not in low and "</think>" not in low:
        return raw
    end = low.rfind("</think>")
    if end < 0:
        raise RuntimeError(
            f"{label}: Qwen3.8 a commencé un bloc <think> sans </think>; "
            "sortie finale absente ou tronquée."
        )
    final = raw[end + len("</think>"):].strip()
    if not final:
        raise RuntimeError(
            f"{label}: Qwen3.8 a terminé son <think> mais aucune réponse finale n'a suivi."
        )
    return final

def llamacpp_text(backend: dict[str, Any], system: str, user: str, *, label: str, num_ctx: int = 16384, num_predict: int = 8192) -> str:
    ensure_llama_server(backend)
    payload = {
        "model": str(backend.get("model") or "local-model"),
        "stream": False,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "temperature": 0.35,
        "max_tokens": int(num_predict),
    }
    if backend.get("key") in {"qwen38", "jpetrina"}:
        # Both 27B profiles: keep the Director in NO-THINK mode.
        payload["chat_template_kwargs"] = {"enable_thinking": False}
    last_exc: Exception | None = None
    for attempt in range(1, 3):
        try:
            out = rt.http_json(_LLAMA_BASE + "/v1/chat/completions", "POST", payload, timeout=900)
            choices = out.get("choices") if isinstance(out, dict) else None
            msg = choices[0].get("message") if isinstance(choices, list) and choices else None
            text = str((msg or {}).get("content") or "").strip() if isinstance(msg, dict) else ""
            if text:
                if backend.get("key") in {"qwen38", "jpetrina"}:
                    text = _llama_final_answer(text, label)
                return text
            raise RuntimeError("réponse llama.cpp vide")
        except Exception as exc:
            last_exc = exc
            msg = str(exc).casefold()
            if "context_length_exceeded" in msg or "exceeds the available context size" in msg:
                # A context overflow is not a crashed server. Restarting it and
                # resending the identical request only wastes time. First keep
                # the full input context and reduce the requested completion.
                current_max = int(payload.get("max_tokens") or num_predict)
                reduced = max(2200, min(current_max - 512, int(current_max * 0.68)))
                if attempt < 2 and reduced < current_max:
                    payload["max_tokens"] = reduced
                    print(
                        f"  {label}: contexte chargé mais budget de sortie trop grand; "
                        f"retry sans redémarrage avec max_tokens={reduced}."
                    )
                    continue
                break
            if attempt < 2:
                print(f"  {label}: llama.cpp indisponible, redémarrage puis retry...")
                stop_llama_server()
                time.sleep(1.0)
                ensure_llama_server(backend)
    stop_llama_server(label=f"{label} — échec")
    raise RuntimeError(f"{label}: aucun texte reçu de {backend.get('display')}: {last_exc}")


def director_text(backend: dict[str, Any], system: str, user: str, *, label: str, num_ctx: int, num_predict: int) -> str:
    if backend.get("provider") == "llamacpp":
        return llamacpp_text(backend, system, user, label=label, num_ctx=num_ctx, num_predict=num_predict)
    return ollama_text(str(backend["model"]), system, user, label=label, num_ctx=num_ctx, num_predict=num_predict)


def unload_text_backend(backend: dict[str, Any], *, label: str) -> None:
    if backend.get("provider") == "llamacpp":
        stop_llama_server(label)
        return
    model = str(backend["model"])
    rt.unload_ollama_model(model)
    rt.wait_ollama_released(model, max_wait=75, label=label)


def release_all_text_models_for_h3(*, label: str) -> None:
    """H3 owns the GPU. Release EVERY resident Director, not only Clip Director.

    The launcher-owned llama.cpp subprocess is stopped; external llama servers are
    intentionally NEVER killed. Ollama's running models are all unloaded; fail
    closed if they are still resident, rather than silently rendering with low VRAM.
    """
    stop_llama_server(label)
    # A separate, externally launched llama-server can hold most of the RTX 5080.
    # Never terminate an unknown PID; refuse the GPU render while its port is live.
    import socket
    try:
        with socket.create_connection((_LLAMA_HOST, _LLAMA_PORT), timeout=1):
            raise RuntimeError(f'{label}: llama-server est encore actif sur {_LLAMA_HOST}:{_LLAMA_PORT}. Ferme ce serveur avant H3 ; aucun processus externe n’a été tué.')
    except (ConnectionRefusedError, TimeoutError, OSError):
        pass
    # Extra safety for long unified Studio sessions: force-release every Ollama
    # resident model before H3 takes over the GPU, then verify with /api/ps.
    rt.unload_all_ollama_models()
    time.sleep(0.8)
    rt.unload_all_ollama_models()
    deadline = time.monotonic() + 90
    still = []
    while time.monotonic() < deadline:
        try:
            ps = rt.http_json(rt.OLLAMA_URL + '/api/ps', timeout=4)
            still = [str(m.get('name') or m.get('model') or '') for m in ps.get('models', []) if isinstance(m, dict)]
        except Exception as exc:
            # Ollama may not even be running on a llama.cpp-only project.
            if 'ollama' not in str(exc).lower():
                print(f'  {label}: Ollama ps inaccessible ({exc}); vérifier les modèles chargés.')
            still = []
        if not still:
            rt.print_gpu_vram(f'{label} — Director models released')
            if studio.enabled():
                studio.publish('memory', f'{label} — mémoire LLM libérée', {'phase':'gpu_ready'})
            return
        for model in still:
            rt.unload_ollama_model(model)
        time.sleep(1.5)
    raise RuntimeError(f'{label}: Ollama conserve des modèles en RAM/VRAM: {still}. H3 non lancé.')


def apply_clip_studio_edits(verdict: dict, h3_prompt: str, refs: list[dict],
                            audio_refs: list[dict], comfy: Path, project_dir: Path | None = None, *, commit: bool = True) -> tuple[str, list[dict], list[dict]]:
    """Apply an explicit Studio review edit, preserving the user's exact prompt.

    Existing references are selected ONLY by index. New media paths must resolve
    inside ComfyUI/input, exist and match the expected media type.
    """
    edits = verdict.get('edits') if isinstance(verdict, dict) else None
    if not isinstance(edits, dict):
        return h3_prompt, refs, audio_refs
    edited = str(edits.get('text') if edits.get('text') is not None else h3_prompt).strip()
    # The Web Studio submits the CREATIVE body separately from its protected
    # read-only Picture/Audio prefix. Never decide whether it edited authority
    # by comparing complete strings from different project versions.
    studio_creative = edits.get('creative_text')
    if studio_creative is not None:
        if not isinstance(studio_creative, str) or not studio_creative.strip():
            raise ValueError('Texte créatif du clip vide')
        if len(studio_creative) > 50000:
            raise ValueError('Texte créatif du clip trop long')
    if not edited or len(edited) > 50000:
        raise ValueError('Prompt H3 modifié vide ou trop long')
    spec = edits.get('refs')
    if spec is None:
        return edited, refs, audio_refs
    if not isinstance(spec, list) or len(spec) > rt.MAX_REF_IMAGES + 8:
        raise ValueError('Nombre de références invalide')
    input_root = (comfy/'input').resolve()
    result_images, result_audio = [], []
    old_prefix = reference_prompt_prefix(refs, audio_refs)
    for item in spec:
        if not isinstance(item,dict):
            raise ValueError('Référence mal formée')
        media = str(item.get('media') or 'image')
        if media not in ('image','audio'):
            raise ValueError('Type de référence invalide')
        old = refs if media=='image' else audio_refs
        if 'index' in item:
            idx = item['index']
            if type(idx) is not int or idx < 0 or idx >= len(old):
                raise ValueError('Indice de référence non reconnu')
            row = copy.deepcopy(old[idx])
        else:
            file_path = Path(str(item.get('path') or '')).resolve()
            if not file_path.is_file() or not file_path.is_relative_to(input_root):
                raise ValueError('Nouvelle référence absente du dossier ComfyUI/input')
            suffix = file_path.suffix.lower()
            extensions = {'.jpg','.jpeg','.png','.webp'} if media=='image' else {'.wav','.mp3','.m4a','.flac','.ogg'}
            if suffix not in extensions:
                raise ValueError('Format de référence incompatible')
            rel = file_path.relative_to(input_root).as_posix()
            row = {'kind':'manual' if media=='image' else 'voice', 'role':'manual', 'static':True,
                   'path':str(file_path),'annotated':f'{rel} [input]', 'strength':1.0}
        name = str(item.get('name') or row.get('subject_name') or row.get('name') or 'Référence').strip()[:90]
        if not name:
            raise ValueError('Nom de référence vide')
        # Preserve original group for canonical/dynamic pairs unless user renamed it.
        if name != str(row.get('subject_name') or row.get('name') or ''):
            row['subject_key'] = 'studio_'+norm(name)
        row['subject_name'] = name
        # Studio-only semantic type for MANUAL pictures. Never rewrite canonical
        # identity / film appearance / decor / object authority in the RefBank.
        if media == 'image' and str(row.get('kind') or '') == 'manual':
            visual_type = str(item.get('visual_type') or 'visual')
            if visual_type not in ('person', 'appearance', 'decor', 'object', 'visual'):
                raise ValueError('Rôle de référence manuelle invalide')
            if visual_type == 'appearance' and not str(item.get('bank_target') or '').strip():
                raise ValueError('Choisis le personnage canonique auquel rattacher cette apparence.')
            row['kind'], row['role'] = {
                'person': ('character', 'canonical_identity'),
                'appearance': ('character', 'film_appearance'),
                'decor': ('decor', 'strongly_referenced'),
                'object': ('object', 'continuing_object'),
                'visual': ('manual', 'manual'),
            }[visual_type]
        if media == 'image':
            row['strength'] = float(row.get('strength') or 1.0)
            row['picture_order'] = len(result_images) + 1
            result_images.append(row)
        else:
            usage = str(item.get('audio_use') or row.get('studio_audio_use') or 'voice')
            if usage not in ('voice', 'object_sound'):
                raise ValueError('Rôle audio inconnu : voix ou son d’objet')
            if usage == 'object_sound':
                target = str(item.get('audio_target') or name).strip()[:90]
                if not target:
                    raise ValueError('Indique l’objet correspondant à ce son')
                row['subject_name'] = target
            elif str(item.get('audio_target') or '').strip():
                row['subject_name'] = str(item['audio_target']).strip()[:90]
            row['studio_audio_use'] = usage
            row['audio_order'] = len(result_audio) + 1
            result_audio.append(row)
    if len(result_images) > rt.MAX_REF_IMAGES:
        raise ValueError('Trop de références image pour H3')
    if len(result_audio) > 8:
        raise ValueError('Trop de références audio')
    if len({x['annotated'] for x in result_images}) != len(result_images):
        raise ValueError('Image insérée plusieurs fois')
    if len({x['annotated'] for x in result_audio}) != len(result_audio):
        raise ValueError('Audio inséré plusieurs fois')
    # V10.11: user-controlled RefBank corrections, deliberately outside the
    # fragile H3 runtime. Preview is read-only; only accepted edits persist.
    if project_dir is not None or edits.get('bank_deletes'):
        apply_bank_edits = studio_refbank_module().apply
        result_images = apply_bank_edits(project_dir, refs, result_images, spec,
                                         edits.get('bank_deletes') or [], commit=False)
    if result_images == refs and result_audio == audio_refs:
        if studio_creative is not None:
            edited = (old_prefix + '\n\n' + studio_creative.strip()).strip() if old_prefix else studio_creative.strip()
        if commit and project_dir is not None:
            persist_bank_edits = studio_refbank_module().apply
            persist_bank_edits(project_dir, refs, result_images, spec, edits.get('bank_deletes') or [], commit=True)
        return edited, refs, audio_refs
    new_prefix = reference_prompt_prefix(result_images,result_audio)
    # The system prefix may differ between review creation and approval (for
    # example an older project's persisted prefix or a changed ref order).
    # The direct editor cannot edit that prefix: use its separate creative body.
    if studio_creative is not None:
        edited = studio_creative.strip()
        # A malicious/accidental manually pasted technical mapping is not allowed
        # in the creative editor, even though old project state is tolerated.
        if edited.lstrip().startswith('REFERENCE AUTHORITY —'):
            raise ValueError('Le texte créatif ne doit pas recopier REFERENCE AUTHORITY.')
    elif new_prefix and edited.startswith(new_prefix):
        edited = edited[len(new_prefix):].lstrip()
    elif old_prefix and edited.startswith(old_prefix):
        edited = edited[len(old_prefix):].lstrip()
    elif old_prefix and edited.lstrip().startswith('REFERENCE AUTHORITY —'):
        # Legacy approvals with an older generated prefix: strip only the
        # technical authority and preserve World ambience + creator text.
        edited = creative_clip_body(edited)
        if not edited:
            raise ValueError('Aucun contenu créatif à conserver après le préfixe technique.')
    if new_prefix:
        edited = new_prefix + '\n\n' + edited
    if commit and project_dir is not None:
        persist_bank_edits = studio_refbank_module().apply
        persist_bank_edits(project_dir, refs, result_images, spec, edits.get('bank_deletes') or [], commit=True)
    return edited, result_images, result_audio


def _extract_field(block: str, label: str, stop_labels: tuple[str, ...] = ("Lieu", "Personnages", "Description", "Fonction")) -> str:
    # Capture one labelled field, allowing multi-line content until the next known label.
    stops = "|".join(re.escape(x) for x in stop_labels)
    pat = re.compile(
        rf"(?ims)^\s*{re.escape(label)}\s*:\s*(.*?)\s*(?=^\s*(?:{stops})\s*:|\Z)"
    )
    m = pat.search(block)
    return re.sub(r"\s+", " ", m.group(1)).strip() if m else ""


def _extract_first_field(block: str, labels: tuple[str, ...], stop_labels: tuple[str, ...]) -> str:
    """Return the first non-empty labelled field among compatible aliases."""
    for label in labels:
        value = _extract_field(block, label, stop_labels)
        if value:
            return value
    return ""


def part_context_payload(part: dict[str, Any]) -> dict[str, Any]:
    """Macro context without source_block duplication."""
    keys = (
        "part", "kind", "label", "name", "start_seconds", "end_seconds",
        "duration_seconds", "start", "end", "function", "development",
    )
    return {k: part.get(k, "") for k in keys}


def plan_context_payload(plan: dict[str, Any]) -> dict[str, Any]:
    """Current 5-second H3 block, including its internal edit/shot sequence."""
    keys = (
        "plan", "start_seconds_in_scene", "end_seconds_in_scene", "duration_seconds",
        "start", "end", "start_state", "shots", "view", "action", "end_state", "purpose",
    )
    return {k: plan.get(k, "") for k in keys}


def clip_static_context_payload(content: dict[str, Any], scene: dict[str, Any]) -> dict[str, Any]:
    """Minimal non-future context for Clip Director.

    Deliberately excludes scene description/logic/final_state and future plan material so the
    local model cannot anticipate story beats it should not execute yet.
    """
    return {
        "film": {
            "title": content.get("title", ""),
            "content_type": content.get("content_type", ""),
            "genre_tone": content.get("genre_tone", ""),
            "art_direction": content.get("art_direction", ""),
        },
        "scene_static": {
            "location": scene.get("location", ""),
            "characters": scene.get("characters", ""),
            "continuity_elements": scene.get("continuity_elements", ""),
        },
    }


def scene_context_payload(scene: dict[str, Any]) -> dict[str, Any]:
    """Compact authoritative scene reality passed to Plan/Clip Directors and saved in clip JSON."""
    keys = (
        "scene", "start_seconds", "end_seconds", "duration_seconds",
        "location", "characters", "initial_state", "description",
        "scene_logic", "continuity_elements", "final_state", "function",
    )
    return {k: scene.get(k, "") for k in keys}


def scene_semantic_text(scene: dict[str, Any]) -> str:
    """All semantic scene text useful for references/identity recovery, without timing boilerplate."""
    return " ".join(
        str(scene.get(k) or "")
        for k in ("description", "initial_state", "scene_logic", "continuity_elements", "final_state")
    ).strip()


def _extract_multiline_section(text: str, label: str, stop_labels: tuple[str, ...]) -> str:
    """Extract a Content Director section whether it is written as a label or Markdown heading.

    clean_md() intentionally removes # markers and ** emphasis, so a model output such as
    ``## DIRECTION ARTISTIQUE GLOBALE`` becomes a bare heading without a colon.
    The parser must therefore accept both ``LABEL:`` and ``LABEL`` while stopping only
    at other top-level Content labels or temporal part headings.
    """
    stops = "|".join(re.escape(x) for x in stop_labels if x != label)
    section_header = rf"^\s*{re.escape(label)}\s*:?[ \t]*$"
    stop_bits = []
    if stops:
        stop_bits.append(rf"^\s*(?:{stops})\s*:?[ \t]*$")
    stop_bits.append(r"^\s*(?:ACTES|PARTIES|SECTIONS|CHAPITRES|SEGMENTS)\s*:?[ \t]*$")
    stop_bits.append(r"^\s*(?:ACTE|PARTIE|SECTION|CHAPITRE|SEGMENT)\b[^\n]*$")
    stop = "|".join(stop_bits)
    pat = re.compile(rf"(?ims){section_header}\s*(.*?)\s*(?={stop}|\Z)")
    m = pat.search(text)
    return m.group(1).strip() if m else ""



def _content_part_blocks(text: str, requested_seconds: int) -> list[dict[str, Any]]:
    """Recover Content Director ACTE/PARTIE/... blocks without caring about arrow syntax.

    The structural heading is authoritative. We only look for timecodes near the top of each
    block; separators/LaTeX/punctuation do not matter. If a model omits timing on one or more
    blocks, missing boundaries are inferred on the 5-second grid between known anchors instead
    of discarding an otherwise useful bible.
    """
    heading_re = re.compile(
        r"(?im)^\s*(?P<kind>ACTE|PARTIE|SECTION|CHAPITRE|SEGMENT)\b(?P<rest>[^\n]*)$"
    )
    matches = list(heading_re.finditer(text))
    if not matches:
        return []

    tc_re = re.compile(r"(?<!\d)(\d{1,2}:\d{2}(?::\d{2})?)(?!\d)")
    field_re = re.compile(r"(?im)^\s*(?:Fonction|Développement|Developpement)\s*:")
    units: list[dict[str, Any]] = []

    for i, m in enumerate(matches):
        block_end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        source_block = text[m.start():block_end].strip()
        body = text[m.end():block_end]

        # Timing may be on the heading or on one/few lines directly below it. Stop before
        # semantic fields so timestamps mentioned later in prose cannot become boundaries.
        fm = field_re.search(body)
        preamble = body[:fm.start()] if fm else "\n".join(body.splitlines()[:4])
        timing_zone = m.group(0) + "\n" + preamble
        tcs = tc_re.findall(timing_zone)
        explicit = None
        if len(tcs) >= 2:
            explicit = (parse_tc(tcs[0]), parse_tc(tcs[1]))

        rest = (m.group('rest') or '').strip()
        # Label/name must not contain timing boilerplate. Preserve creative act names when present.
        first_tc = tc_re.search(rest)
        if first_tc:
            rest = rest[:first_tc.start()]
        rest = re.sub(r"^[\s—–\-:|()\[\]]+|[\s—–\-:|()\[\]]+$", "", rest)
        label = rest or str(i + 1)
        units.append({
            "kind": m.group('kind').upper(),
            "label": label,
            "heading": m.group(0).strip(),
            "body": body,
            "source_block": source_block,
            "explicit": explicit,
        })

    n = len(units)
    boundaries: list[int | None] = [None] * (n + 1)
    boundaries[0] = 0
    boundaries[-1] = requested_seconds

    for i, unit in enumerate(units):
        if not unit["explicit"]:
            continue
        s, e = unit["explicit"]
        if boundaries[i] is not None and boundaries[i] != s:
            raise RuntimeError(f"Content Director: frontière contradictoire au début de {unit['kind']} {unit['label']}.")
        if boundaries[i + 1] is not None and boundaries[i + 1] != e:
            raise RuntimeError(f"Content Director: frontière contradictoire à la fin de {unit['kind']} {unit['label']}.")
        boundaries[i], boundaries[i + 1] = s, e

    # Fill each missing run between known anchors, preserving every structural block.
    known = [i for i, v in enumerate(boundaries) if v is not None]
    for a, b in zip(known, known[1:]):
        if b <= a + 1:
            continue
        start, end = int(boundaries[a]), int(boundaries[b])
        slots = b - a
        total = end - start
        if total <= 0 or total % 5 != 0 or total // 5 < slots:
            raise RuntimeError("Content Director: impossible d'inférer proprement les timings manquants sur une grille de 5 secondes.")
        five_units = total // 5
        base, extra = divmod(five_units, slots)
        cur = start
        for j in range(slots):
            step_units = base + (1 if j < extra else 0)
            cur += step_units * 5
            boundaries[a + j + 1] = cur

    if any(v is None for v in boundaries):
        raise RuntimeError("Content Director: timings incomplets impossibles à reconstruire.")

    out: list[dict[str, Any]] = []
    for i, unit in enumerate(units):
        s, e = int(boundaries[i]), int(boundaries[i + 1])
        out.append({**unit, "start_seconds": s, "end_seconds": e})
    return out

def _normalize_split_part_time_headers(text: str) -> str:
    """Normalize valid small-model variants where a part heading and its time range are split.

    Examples accepted without weakening timeline validation::

        ACTE I — L'INVASION
        Durée : 00:00 → 00:30

        ACTE II
        00:30 - 01:10

    Only the line immediately following a recognized ACTE/PARTIE/... heading (ignoring
    blank lines) may supply the missing range. The normal parser still validates contiguous
    coverage, 5-second boundaries and the requested total duration afterwards.
    """
    lines = text.splitlines()
    heading_re = re.compile(r"(?i)^\s*(ACTE|PARTIE|SECTION|CHAPITRE|SEGMENT)\s+.+?\s*$")
    tc_pat = r"[0-9]{1,2}(?::[0-9]{2}){1,2}"
    span_re = re.compile(
        rf"(?i)^\s*(?:DUR[ÉE]E|DUREE|TIMING|TEMPS|P[ÉE]RIODE|PERIODE)?\s*:?\s*"
        rf"(?:DE\s+)?(?P<start>{tc_pat})\s*"
        rf"(?:→|->|À|A|AU|JUSQU['’]?À|JUSQU['’]?A|—|–|-)\s*"
        rf"(?P<end>{tc_pat})(?:\s*\([^)]*\)|\s*\[[^]]*\])?\s*$"
    )
    inline_span = re.compile(
        rf"(?i){tc_pat}\s*(?:→|->|À|A|AU|JUSQU['’]?À|JUSQU['’]?A|—|–|-)\s*{tc_pat}"
    )
    out = list(lines)
    i = 0
    while i < len(lines):
        line = lines[i]
        if not heading_re.match(line) or inline_span.search(line):
            i += 1
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            break
        m = span_re.match(lines[j])
        if m:
            out[i] = f"{line.rstrip()} — {m.group('start')} → {m.group('end')}"
            out[j] = ""
            i = j + 1
            continue
        i += 1
    return "\n".join(out)


def parse_content_output(raw: str, requested_seconds: int, user_prompt: str, user_details: str, user_style: str) -> dict[str, Any]:
    """Parse the high-level Content Director bible. It intentionally contains no scenes."""
    text = clean_md(raw)
    # Small models often keep the correct temporal structure but put the time range on the
    # following line (e.g. "ACTE I — INVASION" then "Durée : 00:00 → 00:30").
    # Normalize presentation only; all semantic timeline checks below remain unchanged.
    text = _normalize_split_part_time_headers(text)
    if re.search(r"(?im)^\s*SC[ÈE]NE\s+\d+\b", text):
        raise RuntimeError("Content Director: des SCÈNES ont été produites alors que ce rôle doit s'arrêter aux actes/parties.")
    # Structural parsing first: if the director wrote ACTE/PARTIE/... blocks, keep them.
    # Arrow syntax, Markdown/LaTeX and punctuation are irrelevant to block detection.
    content_units = _content_part_blocks(text, requested_seconds)
    if not content_units:
        raise RuntimeError("Content Director: aucun ACTE/PARTIE/SECTION/CHAPITRE/SEGMENT reconnu.")

    parts: list[dict[str, Any]] = []
    for i, unit in enumerate(content_units):
        block = unit["body"]
        start_s, end_s = unit["start_seconds"], unit["end_seconds"]
        if end_s <= start_s:
            raise RuntimeError(f"Content Director: unité {i+1} a une durée invalide.")
        function = _extract_field(block, "Fonction", ("Fonction", "Développement", "Developpement"))
        development = _extract_field(block, "Développement", ("Fonction", "Développement", "Developpement"))
        if not development:
            development = _extract_field(block, "Developpement", ("Fonction", "Développement", "Developpement"))
        if not development:
            lines = [x.strip() for x in block.splitlines() if x.strip()]
            development = " ".join(lines).strip()
        kind = unit["kind"]
        label = unit["label"]
        parts.append({
            "part": i + 1,
            "kind": kind,
            "label": label,
            "name": f"{kind} {label}",
            "start_seconds": start_s,
            "end_seconds": end_s,
            "duration_seconds": end_s - start_s,
            "start": tc(start_s),
            "end": tc(end_s),
            "function": function,
            "development": development,
            "source_block": unit["source_block"],
        })

    for i, part in enumerate(parts):
        if i == 0 and part["start_seconds"] != 0:
            raise RuntimeError("Content Director: la première grande partie ne commence pas à 00:00.")
        if i > 0 and parts[i - 1]["end_seconds"] != part["start_seconds"]:
            raise RuntimeError(
                f"Content Director: trou/chevauchement entre {parts[i-1]['name']} et {part['name']}."
            )
        if part["start_seconds"] % 5 or part["end_seconds"] % 5:
            raise RuntimeError(f"Content Director: frontière non multiple de 5s pour {part['name']}.")
    if parts[-1]["end_seconds"] != requested_seconds:
        raise RuntimeError(
            f"Content Director: fin obtenue {tc(parts[-1]['end_seconds'])}, durée demandée {tc(requested_seconds)}."
        )

    def one_line(label: str) -> str:
        m = re.search(rf"(?im)^\s*{re.escape(label)}\s*:\s*(.+)$", text)
        return m.group(1).strip() if m else ""

    multiline_labels = (
        "CONCEPT / OBJECTIF", "CONCEPT",
        "DIRECTION ARTISTIQUE GLOBALE",
        "MONDE / ENVIRONNEMENTS",
        "PERSONNAGES / SUJETS",
        "ÉLÉMENTS VISUELS IMPORTANTS",
        "PROGRESSION GLOBALE",
    )
    return {
        "user_prompt": user_prompt,
        "user_details": user_details,
        "requested_duration_seconds": requested_seconds,
        "requested_duration": tc(requested_seconds),
        "user_style_direction": user_style,
        "title": one_line("TITRE PROVISOIRE"),
        "content_type": one_line("TYPE DE CONTENU"),
        "duration_text": one_line("DURÉE"),
        "genre_tone": one_line("GENRE / TON"),
        "concept": one_line("CONCEPT / OBJECTIF") or one_line("CONCEPT") or _extract_multiline_section(text, "CONCEPT / OBJECTIF", multiline_labels) or _extract_multiline_section(text, "CONCEPT", multiline_labels),
        "art_direction": _extract_multiline_section(text, "DIRECTION ARTISTIQUE GLOBALE", multiline_labels),
        "world_environment": _extract_multiline_section(text, "MONDE / ENVIRONNEMENTS", multiline_labels),
        "characters_subjects": _extract_multiline_section(text, "PERSONNAGES / SUJETS", multiline_labels),
        "visual_elements": _extract_multiline_section(text, "ÉLÉMENTS VISUELS IMPORTANTS", multiline_labels),
        "global_progression": _extract_multiline_section(text, "PROGRESSION GLOBALE", multiline_labels),
        "parts": parts,
        "raw_content_director_output": raw,
    }



def _even_five_second_boundaries(start_s: int, end_s: int, count: int, *, max_duration: int | None = None) -> list[int]:
    """Split one interval into ``count`` contiguous chunks on the 5-second grid.

    Used only as a structural recovery when a Director clearly produced the requested blocks
    but formatted or omitted their timings. It never invents semantic scene/plan content.
    """
    total = int(end_s) - int(start_s)
    if count <= 0 or total <= 0 or total % 5:
        raise RuntimeError("intervalle temporel impossible à reconstruire sur la grille de 5 secondes")
    units = total // 5
    if units < count:
        raise RuntimeError("pas assez de temps pour conserver tous les blocs produits")
    if max_duration is not None and total > count * int(max_duration):
        raise RuntimeError("trop peu de blocs produits pour respecter la durée maximale")
    base, extra = divmod(units, count)
    bounds = [int(start_s)]
    cur = int(start_s)
    for i in range(count):
        dur = (base + (1 if i < extra else 0)) * 5
        if max_duration is not None and dur > int(max_duration):
            raise RuntimeError("un bloc reconstruit dépasserait la durée maximale")
        cur += dur
        bounds.append(cur)
    return bounds


def _scene_structural_blocks(text: str) -> list[dict[str, Any]]:
    """Find Scene Director blocks first; timing syntax is deliberately secondary.

    Local models occasionally damage the heading token while leaving the scene body intact:
    ``SCÈNE '5``, ``SCÈNE lar 7``, ``SCÈlement 7``, ``SCENE#8``, etc.  We therefore
    recognize a *scene-like line* structurally instead of relying on one exact spelling.

    Safety against false positives is intentionally body-based: a candidate must start with
    ``SCÈ.../SCE...``, contain an early scene number, and be followed by normal Scene Director
    semantic fields (Lieu / Personnages / Description / etc.) or by an explicit timeline.
    This makes the parser tolerant to future small decoder corruption without treating arbitrary
    prose as a new scene.
    """
    # Broad enough for harmless decoder noise between SCÈ... and the scene number, but capped
    # to one heading-sized span so ordinary prose cannot swallow a distant number.
    heading_re = re.compile(
        r"(?im)^\s*(?:[-*>#]+\s*)*SC[ÈE][^\n\d]{0,28}?(?P<num>\d{1,3})\b(?P<rest>[^\n]*)$"
    )
    tc_re = re.compile(r"(?<!\d)(\d{1,2}:\d{2}(?::\d{2})?)(?!\d)")
    semantic_field_re = re.compile(
        r"(?im)^\s*(?:Lieu|Personnages / sujets|Personnages|Situation initiale|État initial|Etat initial|Description|"
        r"Logique de scène|Logique de scene|Continuité / éléments importants|Continuite / elements importants|"
        r"Continuité|Continuite|État final|Etat final|Fonction)\s*:"
    )

    broad = list(heading_re.finditer(text))
    if not broad:
        return []

    # Keep only structurally plausible scene headings.  A genuine heading normally has a
    # timeline on the line itself and/or semantic fields immediately after it.  Looking only a
    # short distance ahead lets us accept malformed headings without widening the grammar of the
    # actual scene body.
    matches = []
    for m in broad:
        rest = str(m.group('rest') or '')
        explicit_timeline = len(tc_re.findall(rest)) >= 1
        lookahead = text[m.end():m.end() + 900]
        semantic_nearby = bool(semantic_field_re.search(lookahead))
        if explicit_timeline or semantic_nearby:
            matches.append(m)
    if not matches:
        return []

    out: list[dict[str, Any]] = []
    for i, m in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        body = text[m.end():end]
        fm = semantic_field_re.search(body)
        preamble = body[:fm.start()] if fm else "\n".join(body.splitlines()[:4])
        timing_zone = m.group(0) + "\n" + preamble
        tcs = tc_re.findall(timing_zone)
        explicit = None
        if len(tcs) >= 2:
            try:
                explicit = (parse_tc(tcs[0]), parse_tc(tcs[1]))
            except Exception:
                explicit = None
        out.append({
            "model_scene_number": int(m.group("num")),
            "heading": m.group(0).strip(),
            "body": body,
            "source_block": text[m.start():end].strip(),
            "explicit": explicit,
        })
    return out

def _recover_scene_boundaries(blocks: list[dict[str, Any]], part: dict[str, Any]) -> tuple[list[int], bool]:
    """Use valid Director timings when coherent; otherwise preserve blocks and rebuild timing only."""
    count = len(blocks)
    part_start, part_end = int(part["start_seconds"]), int(part["end_seconds"])
    bounds: list[int | None] = [None] * (count + 1)
    bounds[0], bounds[-1] = part_start, part_end
    coherent = True
    for i, block in enumerate(blocks):
        pair = block.get("explicit")
        if not pair:
            continue
        s, e = int(pair[0]), int(pair[1])
        if s % 5 or e % 5 or e <= s or e - s > 60:
            coherent = False
            break
        if bounds[i] is not None and bounds[i] != s:
            coherent = False
            break
        if bounds[i + 1] is not None and bounds[i + 1] != e:
            coherent = False
            break
        bounds[i], bounds[i + 1] = s, e

    if coherent:
        known = [i for i, v in enumerate(bounds) if v is not None]
        try:
            for a, b in zip(known, known[1:]):
                if b <= a + 1:
                    continue
                sub = _even_five_second_boundaries(int(bounds[a]), int(bounds[b]), b - a, max_duration=60)
                for j, v in enumerate(sub):
                    bounds[a + j] = v
            if any(v is None for v in bounds):
                coherent = False
            else:
                vals = [int(v) for v in bounds]
                if any(vals[i + 1] <= vals[i] or vals[i + 1] - vals[i] > 60 for i in range(count)):
                    coherent = False
                elif vals[0] != part_start or vals[-1] != part_end:
                    coherent = False
                else:
                    return vals, not all(block.get("explicit") for block in blocks)
        except Exception:
            coherent = False

    # The scene blocks themselves are valuable. If their timing notation is malformed or
    # contradictory, keep every block and rebuild only the boundaries on the 5-second grid.
    vals = _even_five_second_boundaries(part_start, part_end, count, max_duration=60)
    return vals, True


def parse_scene_output(raw: str, part: dict[str, Any], start_scene_number: int) -> list[dict[str, Any]]:
    """Structure-first Scene Director parser: SCÈNE blocks are authoritative, formatting is not."""
    text = clean_md(raw)
    blocks = _scene_structural_blocks(text)
    if not blocks:
        raise RuntimeError(f"Scene Director {part.get('name','')}: aucune scène reconnue.")

    boundaries, recovered_timing = _recover_scene_boundaries(blocks, part)
    if recovered_timing:
        print(f"    WARN Scene Director {part.get('name','')}: scènes récupérées; timings normalisés automatiquement sur la grille de 5s.")

    scenes: list[dict[str, Any]] = []
    labels = (
        "Lieu", "Personnages / sujets", "Personnages",
        "Situation initiale", "État initial", "Etat initial",
        "Description",
        "Logique de scène", "Logique de scene",
        "Continuité / éléments importants", "Continuite / elements importants",
        "Continuité", "Continuite",
        "État final", "Etat final",
        "Fonction",
    )
    for idx, item in enumerate(blocks):
        block = item["body"]
        start_s, end_s = boundaries[idx], boundaries[idx + 1]
        dur = end_s - start_s
        location = _extract_field(block, "Lieu", labels)
        characters = _extract_first_field(block, ("Personnages / sujets", "Personnages"), labels)
        initial_state = _extract_first_field(block, ("Situation initiale", "État initial", "Etat initial"), labels)
        description = _extract_field(block, "Description", labels)
        scene_logic = _extract_first_field(block, ("Logique de scène", "Logique de scene"), labels)
        continuity_elements = _extract_first_field(
            block,
            ("Continuité / éléments importants", "Continuite / elements importants", "Continuité", "Continuite"),
            labels,
        )
        final_state = _extract_first_field(block, ("État final", "Etat final"), labels)
        function = _extract_field(block, "Fonction", labels)
        if not description:
            lines = [x.strip() for x in block.splitlines() if x.strip()]
            description = " ".join(lines).strip()
        if not scene_logic:
            scene_logic = description
        scenes.append({
            "scene": start_scene_number + idx,
            "model_scene_number": int(item["model_scene_number"]),
            "part": int(part.get("part") or 0),
            "part_type": str(part.get("kind") or ""),
            "part_label": str(part.get("label") or ""),
            "act": str(part.get("name") or ""),
            "start_seconds": start_s,
            "end_seconds": end_s,
            "duration_seconds": dur,
            "start": tc(start_s),
            "end": tc(end_s),
            "location": location,
            "characters": characters,
            "initial_state": initial_state,
            "description": description,
            "scene_logic": scene_logic,
            "continuity_elements": continuity_elements,
            "final_state": final_state,
            "function": function,
            "source_block": item["source_block"],
        })
    return scenes


def parse_plan_output(raw: str, scene: dict[str, Any], *, allow_count_mismatch: bool = False, fill_missing: bool = True) -> list[dict[str, Any]]:
    """Parse one technical 5-second PLAN block with optional multiple internal SHOTs."""
    text = clean_md(raw)
    expected = int(scene["duration_seconds"] // 5)
    heading_re = re.compile(r"(?im)^\s*PLAN\s*(?:#|N(?:[°ºo.]\s*)?)?(\d+)\b[^\n]*$")
    matches = list(heading_re.finditer(text))

    raw_blocks: list[tuple[str, str]] = []
    if matches:
        for idx, m in enumerate(matches):
            end_pos = matches[idx + 1].start() if idx + 1 < len(matches) else len(text)
            raw_blocks.append((m.group(0).strip(), text[m.end():end_pos].strip()))
    else:
        # Compatibility with old/small-model output.
        starts = list(re.finditer(r"(?im)^\s*Vue\s*:", text))
        if not starts:
            starts = list(re.finditer(r"(?im)^\s*Action\s*:", text))
        for idx, m in enumerate(starts):
            end_pos = starts[idx + 1].start() if idx + 1 < len(starts) else len(text)
            raw_blocks.append((f"PLAN {idx+1} [récupéré]", text[m.start():end_pos].strip()))

    if len(raw_blocks) > expected:
        # Some small/local models emit a non-executable PLAN placeholder before the real blocks,
        # e.g. "PLAN 3 — début → fin — durée 15 secondes" followed only by START STATE.
        # When we have too many PLAN headings, prefer blocks that actually contain executable
        # SHOT / Vue / Action content instead of blindly truncating the first headings.
        executable_blocks = [
            (heading, block) for heading, block in raw_blocks
            if re.search(r"(?im)^\s*(?:SHOT\s+\d+\b|Vue\s*:|Action\s*:)", block)
        ]
        if len(executable_blocks) >= expected:
            print(f"  WARN Plan Director S{scene['scene']}: {len(raw_blocks)} blocs reçus, {expected} utiles — suppression des placeholders non exécutables.")
            raw_blocks = executable_blocks[:expected]
        else:
            print(f"  WARN Plan Director S{scene['scene']}: {len(raw_blocks)} blocs reçus, {expected} utiles — conservation des {expected} premiers.")
            raw_blocks = raw_blocks[:expected]

    plans: list[dict[str, Any]] = []
    for idx, (heading, block) in enumerate(raw_blocks):
        start_state = ""
        end_state = ""
        purpose = ""

        m = re.search(r"(?ims)^\s*START\s+STATE\s*:\s*(.*?)(?=^\s*SHOT\s+\d+\b|^\s*END\s+STATE\s*:|^\s*BUT\s*:|\Z)", block)
        if m:
            start_state = re.sub(r"\s+", " ", m.group(1)).strip()
        m = re.search(r"(?ims)^\s*END\s+STATE\s*:\s*(.*?)(?=^\s*BUT\s*:|\Z)", block)
        if m:
            end_state = re.sub(r"\s+", " ", m.group(1)).strip()
        m = re.search(r"(?ims)^\s*BUT\s*:\s*(.*?)\s*\Z", block)
        if m:
            purpose = re.sub(r"\s+", " ", m.group(1)).strip()

        shot_re = re.compile(r"(?im)^\s*SHOT\s+(\d+)\b([^\n]*)$")
        shot_matches = list(shot_re.finditer(block))
        shots: list[dict[str, Any]] = []
        for sidx, sm in enumerate(shot_matches):
            send = shot_matches[sidx + 1].start() if sidx + 1 < len(shot_matches) else len(block)
            sblock = block[sm.end():send]
            # Do not let END STATE / BUT text leak into the final shot.
            sblock = re.split(r"(?im)^\s*(?:END\s+STATE|BUT)\s*:", sblock, maxsplit=1)[0]
            # Internal shot headings may use either seconds (1.40) or clock-style
            # values (00:00). Parse complete time tokens so ``00:00`` is not
            # accidentally read as two separate zeros.
            time_tokens = re.findall(r"\d{1,2}:\d{1,2}(?:[\.,]\d+)?|\d+(?:[\.,]\d+)?", sm.group(2))

            def _shot_time(token: str) -> float:
                token = token.replace(',', '.').strip()
                if ':' in token:
                    mm, ss = token.split(':', 1)
                    return float(mm) * 60.0 + float(ss)
                return float(token)

            rel_start = _shot_time(time_tokens[0]) if len(time_tokens) >= 1 else None
            rel_end = _shot_time(time_tokens[1]) if len(time_tokens) >= 2 else None
            vue = _extract_field(sblock, "Vue", ("Vue", "Action"))
            action = _extract_field(sblock, "Action", ("Vue", "Action"))
            if not action:
                action = re.sub(r"\s+", " ", sblock).strip()
            shots.append({
                "shot": sidx + 1,
                "start_seconds_in_clip": rel_start,
                "end_seconds_in_clip": rel_end,
                "view": vue,
                "action": action,
            })

        # Normalize multi-shot boundaries to a clean 0.00 -> 5.00 timeline.
        # Small/local LLMs sometimes emit overlapping ends (e.g. 0-5 then 3-5)
        # even when the intended cut point is clear from the next SHOT start.
        # For multiple shots, the start of the next shot is the authoritative cut.
        if len(shots) > 1:
            starts: list[float] = [0.0]
            for sidx in range(1, len(shots)):
                candidate = shots[sidx].get("start_seconds_in_clip")
                try:
                    candidate = float(candidate) if candidate is not None else None
                except Exception:
                    candidate = None
                prev = starts[-1]
                remaining = len(shots) - sidx
                if candidate is None or candidate <= prev or candidate >= 5.0:
                    # If the model's start is unusable, prefer the previous declared
                    # end when it is sane; otherwise distribute the remaining time.
                    prev_end = shots[sidx - 1].get("end_seconds_in_clip")
                    try:
                        prev_end = float(prev_end) if prev_end is not None else None
                    except Exception:
                        prev_end = None
                    if prev_end is not None and prev < prev_end < 5.0:
                        candidate = prev_end
                    else:
                        candidate = prev + (5.0 - prev) / (remaining + 1)
                starts.append(max(prev + 0.01, min(4.99, candidate)))

            for sidx, shot in enumerate(shots):
                shot["start_seconds_in_clip"] = round(starts[sidx], 3)
                shot["end_seconds_in_clip"] = round(starts[sidx + 1] if sidx + 1 < len(starts) else 5.0, 3)
        elif len(shots) == 1:
            shots[0]["start_seconds_in_clip"] = 0.0
            shots[0]["end_seconds_in_clip"] = 5.0

        # Old format remains valid as a single shot.
        if not shots:
            vue = _extract_field(block, "Vue", ("Vue", "Action", "But"))
            action = _extract_field(block, "Action", ("Vue", "Action", "But"))
            if not purpose:
                purpose = _extract_field(block, "But", ("Vue", "Action", "But"))
            if not action:
                action = re.sub(r"\s+", " ", block).strip()
            shots = [{
                "shot": 1,
                "start_seconds_in_clip": 0.0,
                "end_seconds_in_clip": 5.0,
                "view": vue,
                "action": action,
            }]

        # Compact searchable summary for refs/backward compatibility.
        summary_view = " | ".join(str(x.get("view") or "") for x in shots if x.get("view"))
        summary_action = " | ".join(str(x.get("action") or "") for x in shots if x.get("action"))
        start_sec = idx * 5
        plans.append({
            "plan": idx + 1,
            "start_seconds_in_scene": start_sec,
            "end_seconds_in_scene": start_sec + 5,
            "duration_seconds": 5,
            "start": f"{start_sec:02d}s",
            "end": f"{start_sec + 5:02d}s",
            "start_state": start_state,
            "shots": shots,
            "view": summary_view,
            "action": summary_action,
            "end_state": end_state,
            "purpose": purpose,
            "source_block": (heading + "\n" + block).strip(),
        })

    missing = expected - len(plans)
    if missing > 0 and fill_missing:
        location = str(scene.get("location") or "").strip()
        final_state = str(scene.get("final_state") or "l'état final prévu par la scène").strip()
        while len(plans) < expected:
            idx = len(plans)
            action = (
                "Continuer uniquement depuis l'END STATE du plan précédent avec une progression NOUVELLE vers l'état final de la scène. "
                "Ne rejouer aucun dialogue, alerte, arrivée, révélation, geste ou événement déjà montré dans les plans précédents. "
                f"État final cible : {final_state}"
            )
            plans.append({
                "plan": idx + 1,
                "start_seconds_in_scene": idx * 5,
                "end_seconds_in_scene": idx * 5 + 5,
                "duration_seconds": 5,
                "start": f"{idx*5:02d}s",
                "end": f"{idx*5+5:02d}s",
                "start_state": plans[-1].get("end_state", "") if plans else str(scene.get("initial_state") or ""),
                "shots": [{"shot": 1, "start_seconds_in_clip": 0.0, "end_seconds_in_clip": 5.0,
                           "view": "Plan cinématographique cohérent avec la continuité déjà rendue.", "action": action}],
                "view": "Plan cinématographique cohérent avec la continuité déjà rendue." + (f" Lieu : {location}." if location else ""),
                "action": action,
                "end_state": final_state if len(plans) + 1 == expected else "",
                "purpose": "Faire progresser la scène sans rejouer un beat déjà couvert.",
                "source_block": "[FALLBACK PLAN — anti-replay après échec de complétion LLM]",
            })
        print(f"  WARN Plan Director S{scene['scene']}: {missing} plan(s) manquant(s) complété(s) par fallback anti-replay.")
    return plans


_DIALOGUE_QUOTE_RE = re.compile(r'«([^»\n]{1,700})»|“([^”\n]{1,700})”|"([^"\n]{1,700})"')
_DIALOGUE_WORD_RE = re.compile(r"\b[\wÀ-ÿ]+(?:['’][\wÀ-ÿ]+)?\b", re.UNICODE)


def split_character_names(text: str) -> list[str]:
    """Split declared character names on normal list separators outside profile notes.

    Example: ``Kai (25 ans; cheveux courts; veste en cuir usée)`` must remain
    one character, while ``Nyx, Mathew`` must become two distinct identities.
    """
    s = re.sub(r"\bet\b", ";", text or "", flags=re.I)
    parts: list[str] = []
    buf: list[str] = []
    depth = 0
    for ch in s:
        if ch == "(":
            depth += 1
            buf.append(ch)
            continue
        if ch == ")":
            depth = max(0, depth - 1)
            buf.append(ch)
            continue
        if ch in ";/," and depth == 0:
            parts.append("".join(buf))
            buf = []
        else:
            buf.append(ch)
    parts.append("".join(buf))

    out = []
    for p in parts:
        p = re.sub(r"\([^)]*\)", "", p).strip(" .:-")
        if p and len(p) <= 80 and p.casefold() not in {"aucun", "none", "n/a"}:
            out.append(p)
    return out


def _ascii_text(s: str) -> str:
    return unicodedata.normalize("NFKD", s or "").encode("ascii", "ignore").decode("ascii")


def norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", _ascii_text(s).casefold())


def appearance_state_key(s: str) -> str:
    """Order-insensitive key for a short VLM-described temporary appearance state."""
    toks = re.findall(r"[a-z0-9]+", _ascii_text(s).casefold())
    return " ".join(sorted(set(toks)))


def ref_matches_name(ref: dict[str, Any], name: str) -> bool:
    a, b = norm(str(ref.get("subject_name") or "")), norm(name)
    return bool(a and b and (a == b or a in b or b in a))


def reference_name_aliases(name: str) -> list[str]:
    """Safe aliases derived only from one canonical label.

    Example: ``L'Envahisseur (L'Entité)`` -> full label, ``L'Envahisseur``, ``L'Entité``.
    This is generic punctuation/parenthesis handling, never film-specific alias coding.
    """
    raw = re.sub(r"\s+", " ", str(name or "")).strip(" .:-")
    if not raw:
        return []
    candidates = [raw]
    candidates.extend(x.strip(" .:-") for x in re.findall(r"\(([^()]{2,80})\)", raw))
    without_parens = re.sub(r"\([^()]*\)", " ", raw)
    candidates.append(re.sub(r"\s+", " ", without_parens).strip(" .:-"))
    for item in list(candidates):
        candidates.extend(x.strip(" .:-") for x in re.split(r"[|/;]", item))
    out: list[str] = []
    seen: set[str] = set()
    for item in candidates:
        key = norm(item)
        if len(key) < 4 or key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out


def _text_mentions_reference_alias(text: str, canonical_name: str) -> bool:
    blob = _ascii_text(text).casefold()
    for alias in reference_name_aliases(canonical_name):
        a = _ascii_text(alias).casefold().strip()
        if a and re.search(rf"(?<!\w){re.escape(a)}(?!\w)", blob):
            return True
    return False


_DECOR_STOPWORDS = {
    "dans", "avec", "sans", "sous", "sur", "vers", "pres", "entre", "depuis",
    "une", "des", "les", "aux", "du", "de", "la", "le", "un", "d", "l", "et",
    "the", "a", "an", "of", "in", "on", "at", "to", "from", "and",
    "zone", "scene", "lieu", "location", "interieur", "exterieur", "principal", "principale",
}


def _decor_tokens(name: str) -> set[str]:
    s = _ascii_text(name).casefold()
    # Parenthetical notes are usually shot/sub-area descriptions, not the stable place identity.
    s = re.sub(r"\([^)]*\)", " ", s)
    toks = {x for x in re.findall(r"[a-z0-9]+", s) if len(x) >= 3 and x not in _DECOR_STOPWORDS}
    return toks


def _decor_root(name: str) -> str:
    s = _ascii_text(name).casefold().strip()
    if "/" in s:
        return norm(s.split("/", 1)[0])
    quoted = re.findall(r'["“”]([^"“”]{3,60})["“”]', name or "")
    if quoted:
        return norm(quoted[0])
    s = re.sub(r"\([^)]*\)", " ", s)
    return norm(s)


def decor_match_score(ref_name: str, current_location: str) -> int:
    """Conservative SIMPLE adaptation of V13.9 zone-aware runtime reference selection.

    We do not have the old Spatial Blueprint anymore, so a decor ref is eligible only when
    the current Scene Director location clearly names the same place. Exact/root matches win;
    otherwise a distinctive shared location token (e.g. Safehouse) is required.
    """
    if not ref_name or not current_location:
        return 0
    a, b = norm(ref_name), norm(current_location)
    if a and a == b:
        return 1000
    if a and b and (a in b or b in a):
        return 850
    ra, rb = _decor_root(ref_name), _decor_root(current_location)
    if ra and rb and ra == rb:
        return 900
    ta, tb = _decor_tokens(ref_name), _decor_tokens(current_location)
    common = ta & tb
    if not common:
        return 0
    # One strong distinctive token is enough for explicit recurring place labels such as Safehouse.
    strongest = max((len(x) for x in common), default=0)
    if strongest < 5:
        return 0
    return 500 + min(200, 30 * len(common)) + min(100, strongest * 5)




def _scene_spatial_key(scene: dict[str, Any]) -> str:
    scene_no = int(scene.get("scene") or 0)
    location = str(scene.get("location") or "").strip()
    return f"scene_{scene_no}_{norm(_decor_root(location) or location) or 'location'}"


def get_scene_spatial_anchor(bank: dict[str, Any], scene: dict[str, Any]) -> str:
    """Return compact camera-independent layout facts for this exact scene.

    Facts are stored per named character so a close-up of one person can update that
    person's physical relation without erasing everybody else's established position.
    """
    if not isinstance(bank, dict):
        return ""
    spatial = bank.get("spatial") or {}
    if not isinstance(spatial, dict):
        return ""
    rec = spatial.get(_scene_spatial_key(scene))
    if not isinstance(rec, dict):
        return ""
    facts = rec.get("facts") or {}
    if not isinstance(facts, dict):
        return ""
    rows: list[tuple[int, str]] = []
    for item in facts.values():
        if not isinstance(item, dict):
            continue
        subject = str(item.get("subject") or "").strip()
        relation = str(item.get("relation") or "").strip()
        if not subject or not relation:
            continue
        rows.append((int(item.get("captured_clip") or 0), f"{subject}: {relation}"))
    rows.sort(key=lambda x: x[0])
    return "\n".join(x[1] for x in rows)[-1400:]


def update_scene_spatial_facts(
    bank: dict[str, Any],
    scene: dict[str, Any],
    facts: list[dict[str, Any]] | None,
    clip_number: int,
) -> dict[str, Any]:
    """Merge only clearly re-observed subject relations; never erase unseen subjects."""
    clean = []
    for item in facts or []:
        if not isinstance(item, dict):
            continue
        subject = str(item.get("subject") or "").strip()
        relation = str(item.get("relation") or "").strip()
        if not subject or not relation:
            continue
        # Screen coordinates are camera-dependent and therefore forbidden as persistent facts.
        low = _ascii_text(relation).casefold()
        if any(x in low for x in ("screen-left", "screen right", "screen-right", "a gauche de l'ecran", "a droite de l'ecran")):
            continue
        clean.append((subject, relation[:500]))
    if not clean:
        return bank
    bank.setdefault("spatial", {})
    key = _scene_spatial_key(scene)
    rec = bank["spatial"].get(key)
    if not isinstance(rec, dict):
        rec = {"scene": int(scene.get("scene") or 0), "location": str(scene.get("location") or ""), "facts": {}}
    rec.setdefault("facts", {})
    for subject, relation in clean:
        rec["facts"][norm(subject) or subject] = {
            "subject": subject,
            "relation": relation,
            "captured_clip": int(clip_number),
        }
    bank["spatial"][key] = rec
    bank.setdefault("history", []).append({
        "clip": int(clip_number), "kind": "spatial_facts", "scene": int(scene.get("scene") or 0),
        "facts": [{"subject": s, "relation": r} for s, r in clean],
    })
    return bank


def film_character_roster(film: dict[str, Any]) -> list[str]:
    out: list[str] = []
    seen: set[str] = set()
    for scene in film.get("scenes", []) if isinstance(film, dict) else []:
        for name in split_character_names(str((scene or {}).get("characters") or "")):
            k = norm(name)
            if k and k not in seen:
                seen.add(k)
                out.append(name)
    return out



def principal_character_names(content_bible: dict[str, Any], film: dict[str, Any], known_characters: list[str]) -> list[str]:
    """Return recurring named characters worth keeping a persistent voice for.

    Prefer characters explicitly defined in the Content Director's PERSONNAGES / SUJETS bible.
    If that structure is unusually terse, fall back to characters recurring in at least two scenes.
    This is deliberately content-driven: no hard-coded hero names or entity types.
    """
    bible = str((content_bible or {}).get("characters_subjects") or "")
    bible_ascii = _ascii_text(bible).casefold()
    out: list[str] = []
    seen: set[str] = set()

    for name in known_characters or []:
        readable = _ascii_text(name).casefold().strip()
        if not readable:
            continue
        # Content sections commonly put a canonical character name on its own heading/line.
        if re.search(rf"(?m)^\s*{re.escape(readable)}\s*(?:[:—-].*)?$", bible_ascii):
            k = norm(name)
            if k and k not in seen:
                seen.add(k)
                out.append(name)

    if out:
        return out

    counts: dict[str, int] = {}
    display: dict[str, str] = {}
    for sc in (film or {}).get("scenes", []) if isinstance(film, dict) else []:
        for name in split_character_names(str((sc or {}).get("characters") or "")):
            k = norm(name)
            if not k:
                continue
            counts[k] = counts.get(k, 0) + 1
            display.setdefault(k, name)
    return [display[k] for k, c in counts.items() if c >= 2]


def _dialogue_present_principals(
    principal_characters: list[str],
    scene: dict[str, Any] | None,
    plan: dict[str, Any] | None,
    known_characters: list[str] | None,
) -> tuple[list[str], list[str]]:
    principals = [x for x in principal_characters or [] if norm(x)]
    present = character_names_for_clip(scene or {}, plan or {}, known_characters or principals)
    present_principals = [
        x for x in principals
        if any(ref_matches_name({"subject_name": y}, x) for y in present)
    ]
    return principals, present_principals


def _speaker_before_dialogue_position(
    text: str,
    pos: int,
    principals: list[str],
    present_principals: list[str],
) -> str:
    """Resolve the speaker nearest a dialogue payload without guessing across characters."""
    start = max(0, pos - 700)
    raw_window = text[start:pos]
    window = _ascii_text(raw_window).casefold()

    # V5.6: an explicit `Name:` dialogue label is the strongest local speaker authority.
    # This deliberately beats any <Subject N> cue the local LLM may have guessed.
    best_label = None
    for name in principals:
        readable = _ascii_text(name).casefold().strip()
        if not readable:
            continue
        matches = list(re.finditer(rf"(?im)^\s*{re.escape(readable)}\s*:\s*$", window))
        if matches:
            cand = (matches[-1].start(), name)
            if best_label is None or cand[0] > best_label[0]:
                best_label = cand
    if best_label:
        return best_label[1]

    # Runtime-authored <Subject N> declarations are a fallback identity signal.
    subject_map: dict[str, str] = {}
    for m in re.finditer(r"<Subject\s+(\d+)>\s+is\s+([^,\n]+)", text, flags=re.I):
        candidate = m.group(2).strip()
        for name in principals:
            if ref_matches_name({"subject_name": candidate}, name):
                subject_map[m.group(1)] = name
                break
    subject_mentions = list(re.finditer(r"<Subject\s+(\d+)>", raw_window, flags=re.I))
    if subject_mentions:
        sid = subject_mentions[-1].group(1)
        if subject_map.get(sid):
            return subject_map[sid]

    # Prefer explicit speech constructions over the merely nearest name. This avoids
    # `Matt s'adresse à Nyx: «... »` being attributed to Nyx just because her name is closer.
    speech_verbs = (
        r"dit|repond|répond|demande|lance|murmure|souffle|crie|ajoute|ordonne|"
        r"annonce|s'adresse|réplique|retorque|rétorque|says|answers|asks|whispers|shouts|adds"
    )
    # Resolve the last speech verb, then choose the nearest canonical name BEFORE that verb.
    # This distinguishes the speaker from an addressee in constructions such as
    # `A s'adresse à B : <d>...</d>`.
    verb_matches = list(re.finditer(rf"(?:{speech_verbs})", window, flags=re.I))
    if verb_matches:
        verb_pos = verb_matches[-1].start()
        before_verb = window[:verb_pos]
        best_name = ""
        best_pos = -1
        for name in principals:
            readable = _ascii_text(name).casefold().strip()
            if not readable:
                continue
            matches = list(re.finditer(rf"(?<![a-z0-9]){re.escape(readable)}(?![a-z0-9])", before_verb))
            if matches and matches[-1].start() > best_pos:
                best_pos = matches[-1].start()
                best_name = name
        if best_name:
            return best_name

    # Simple `Name:` speaker labels emitted by the Clip Director.
    best = None
    for name in principals:
        readable = _ascii_text(name).casefold().strip()
        if not readable:
            continue
        matches = list(re.finditer(rf"(?im)^\s*{re.escape(readable)}\s*:\s*$", window))
        if matches:
            cand = (matches[-1].start(), name)
            if best is None or cand[0] > best[0]:
                best = cand
    if best:
        return best[1]

    # Last safe fallback: nearest canonical name, or the sole principal present.
    best_name = ""
    best_pos = -1
    for name in principals:
        readable = _ascii_text(name).casefold().strip()
        if not readable:
            continue
        matches = list(re.finditer(rf"(?<![a-z0-9]){re.escape(readable)}(?![a-z0-9])", window))
        if matches and matches[-1].start() > best_pos:
            best_pos = matches[-1].start()
            best_name = name
    if best_name:
        return best_name
    if len(present_principals) == 1:
        return present_principals[0]
    return ""


def dialogue_turns_from_prompt(
    prompt: str,
    principal_characters: list[str],
    scene: dict[str, Any] | None = None,
    plan: dict[str, Any] | None = None,
    known_characters: list[str] | None = None,
) -> list[dict[str, Any]]:
    """Return explicit dialogue turns with their canonical speaker when safely resolvable.

    V5.5 prefers H3 <d> tags, but keeps a conservative quoted-dialogue fallback so a local
    model forgetting the tag cannot silently disable a user-provided voice reference.
    """
    text = str(prompt or "")
    principals, present_principals = _dialogue_present_principals(
        principal_characters, scene, plan, known_characters
    )
    if not principals:
        return []

    turns: list[dict[str, Any]] = []
    for m in re.finditer(r"<d(?:\s[^>]*)?>(.*?)</d>", text, flags=re.I | re.S):
        speaker = _speaker_before_dialogue_position(text, m.start(), principals, present_principals)
        if not speaker:
            return []
        turns.append({
            "speaker": speaker,
            "text": m.group(1).strip(),
            "start": m.start(),
            "end": m.end(),
            "tagged": True,
        })
    if turns:
        return turns

    # Legacy/plain-output fallback. Only accept quotes with an explicit named speech construction.
    quote_patterns = [
        re.compile(r"[«“\"]([^»”\"]{1,500})[»”\"]", flags=re.S),
    ]
    speech_verbs = (
        r"dit|repond|répond|demande|lance|murmure|souffle|crie|ajoute|ordonne|"
        r"annonce|s'adresse|réplique|retorque|rétorque|says|answers|asks|whispers|shouts|adds"
    )
    ascii_text = _ascii_text(text).casefold()
    for qp in quote_patterns:
        for m in qp.finditer(text):
            before_start = max(0, m.start() - 320)
            raw_before = text[before_start:m.start()]
            before = _ascii_text(raw_before).casefold()
            best_name = ""
            verb_matches = list(re.finditer(rf"(?:{speech_verbs})", before, flags=re.I))
            if verb_matches:
                verb_pos = verb_matches[-1].start()
                before_verb = before[:verb_pos]
                best_pos = -1
                for name in principals:
                    readable = _ascii_text(name).casefold().strip()
                    if not readable:
                        continue
                    mm = list(re.finditer(rf"(?<![a-z0-9]){re.escape(readable)}(?![a-z0-9])", before_verb))
                    if mm and mm[-1].start() > best_pos:
                        best_pos = mm[-1].start()
                        best_name = name
            if not best_name:
                best_pos = -1
                for name in principals:
                    readable = _ascii_text(name).casefold().strip()
                    if not readable:
                        continue
                    mm = list(re.finditer(rf"(?im)^\s*{re.escape(readable)}\s*:\s*$", before))
                    if mm and mm[-1].start() > best_pos:
                        best_pos = mm[-1].start()
                        best_name = name
            if best_name:
                turns.append({
                    "speaker": best_name,
                    "text": m.group(1).strip(),
                    "start": m.start(),
                    "end": m.end(),
                    "tagged": False,
                })
    return turns


def dialogue_speakers_from_prompt(
    prompt: str,
    principal_characters: list[str],
    scene: dict[str, Any] | None = None,
    plan: dict[str, Any] | None = None,
    known_characters: list[str] | None = None,
) -> list[str]:
    """Identify principal characters who actually speak in this generated H3 prompt."""
    turns = dialogue_turns_from_prompt(
        prompt, principal_characters, scene, plan, known_characters
    )
    out: list[str] = []
    seen: set[str] = set()
    for turn in turns:
        name = str(turn.get("speaker") or "")
        k = norm(name)
        if k and k not in seen:
            seen.add(k)
            out.append(name)
    return out

def choose_active_voice_refs(
    bank: dict[str, Any],
    clip_prompt: str,
    scene: dict[str, Any],
    plan: dict[str, Any],
    principal_characters: list[str],
    known_characters: list[str] | None = None,
) -> list[dict[str, Any]]:
    """Attach voice refs only when an already-voiced principal character speaks now."""
    speakers = dialogue_speakers_from_prompt(
        clip_prompt, principal_characters, scene, plan, known_characters
    )
    if not speakers:
        return []
    voices = (bank or {}).get("voices") or {}
    chosen: list[dict[str, Any]] = []
    for speaker in speakers:
        matches = [
            r for k, r in voices.items()
            if isinstance(r, dict) and (
                ref_matches_name(r, speaker)
                or ref_matches_name({"subject_name": k}, speaker)
            )
        ]
        if not matches:
            continue
        ref = copy.deepcopy(matches[0])
        ref["audio_order"] = len(chosen) + 1
        chosen.append(ref)
    return chosen



def _subject_number_by_name(refs: list[dict[str, Any]]) -> dict[str, int]:
    """Mirror reference_prompt_prefix subject grouping so dialogue cues use the same Subject N."""
    groups: dict[str, list[dict[str, Any]]] = {}
    order: list[str] = []
    for r in refs or []:
        key = str(r.get("subject_key") or f"ref_{r.get('picture_order')}")
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(r)
    out: dict[str, int] = {}
    for sn, key in enumerate(order, 1):
        name = str(groups[key][0].get("subject_name") or key)
        out[norm(name)] = sn
    return out


def inject_runtime_voice_cues(
    clip_prompt: str,
    active_refs: list[dict[str, Any]],
    active_voice_refs: list[dict[str, Any]],
    scene: dict[str, Any],
    plan: dict[str, Any],
    principal_characters: list[str],
    known_characters: list[str] | None = None,
) -> str:
    """Repeat the authoritative Audio reference immediately before each tagged spoken line.

    This recreates the dialogue pattern that proved reliable with H3 while keeping all Audio/Picture
    numbering owned by the runtime rather than the local LLM.
    """
    text = str(clip_prompt or "")
    if not active_voice_refs or "<d" not in text.lower():
        return text

    turns = dialogue_turns_from_prompt(
        text, principal_characters, scene, plan, known_characters
    )
    tagged_turns = [t for t in turns if t.get("tagged")]
    if not tagged_turns:
        return text

    audio_num = {norm(str(r.get("subject_name") or "")): i for i, r in enumerate(active_voice_refs, 1)}
    subject_num = _subject_number_by_name(active_refs)

    inserts: list[tuple[int, str]] = []
    for turn in tagged_turns:
        name = str(turn.get("speaker") or "")
        k = norm(name)
        ai = audio_num.get(k)
        if not ai:
            continue
        sn = subject_num.get(k)
        if sn:
            cue = (
                f"Using specifically the voice timbre and delivery referenced from <Audio {ai}>, "
                f"<Subject {sn}> (S{sn}) says:\n"
            )
        else:
            cue = (
                f"Using specifically the voice timbre and delivery referenced from <Audio {ai}>, "
                f"{name} says:\n"
            )
        # Insert directly before the <d> tag. The existing character label / acting line remains useful.
        inserts.append((int(turn["start"]), cue))

    for pos, cue in sorted(inserts, reverse=True):
        text = text[:pos] + cue + text[pos:]
    return text


def _clip_time_value(raw: str, *, clip_duration_s: float | None = None) -> float | None:
    """Parse a Clip Director shot timestamp without confusing decimal ':' with minutes.

    H3 prompts sometimes render decimal seconds as ``2:50`` / ``5:00``.  In a
    five-second clip those values cannot mean 2m50 / 5m00, so when a clip duration
    is supplied we reinterpret that impossible MM:SS reading as 2.50 / 5.00 sec.
    Real clock syntax such as ``00:02.50`` keeps its normal meaning.
    """
    raw = str(raw or "").strip().replace(",", ".")
    if not raw:
        return None
    try:
        if ":" in raw:
            parts = raw.split(":")
            if len(parts) == 2:
                standard = float(parts[0]) * 60.0 + float(parts[1])
                if clip_duration_s is not None and standard > float(clip_duration_s) + 0.25:
                    # Director shorthand observed in real outputs: 2:50 == 2.50 seconds.
                    # Only accept the reinterpretation when it lands inside this technical clip.
                    alt = float(f"{int(float(parts[0]))}.{parts[1]}")
                    if 0.0 <= alt <= float(clip_duration_s) + 0.25:
                        return alt
                return standard
        return float(raw)
    except Exception:
        return None


def clean_single_speaker_shot_segments(
    prompt: str,
    principal_characters: list[str],
    scene: dict[str, Any],
    plan: dict[str, Any],
    known_characters: list[str],
) -> list[dict[str, Any]]:
    """Find shot windows that contain dialogue from exactly one principal speaker."""
    # Use the same FINAL H3 Shot grammar as appearance frame routing.
    # A shot is considered safe for attribution only when its dialogue labels
    # identify exactly one speaker; timing is controlled by the creator.
    out: list[dict[str, Any]] = []
    for t0, t1, block in _h3_prompt_shot_windows(prompt):
        if t1 <= t0 or (t1 - t0) > 5.25:
            continue
        turns = dialogue_turns_from_prompt(
            block, principal_characters, scene, plan, known_characters
        )
        # dialogue_turns_from_prompt on an isolated block can safely resolve explicit Name: labels.
        speakers: list[str] = []
        seen: set[str] = set()
        for turn in turns:
            name = str(turn.get("speaker") or "")
            k = norm(name)
            if k and k not in seen:
                seen.add(k)
                speakers.append(name)
        if len(speakers) != 1:
            continue
        spoken = " ".join(str(t.get("text") or "") for t in turns if norm(str(t.get("speaker") or "")) == norm(speakers[0]))
        words = re.findall(r"\b\w+\b", _ascii_text(spoken), flags=re.UNICODE)
        if len(words) < 2 or (t1 - t0) < 1.15:
            continue
        out.append({"speaker": speakers[0], "start": t0, "end": t1, "text": spoken})
    return out

def stage_dynamic_voice_ref(
    comfy: Path,
    project: str,
    video_path: Path,
    clip_number: int,
    character_name: str,
    used_motion_context: bool,
    segment_start_s: float = 0.0,
    segment_duration_s: float = 5.1,
) -> dict[str, Any]:
    """Extract one lightweight voice reference from a clean single-speaker clip/shot segment."""
    dest_dir = comfy / "input" / OUTPUT_ROOT_NAME / project / "dynamic_voice_refs"
    dest_dir.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[^A-Za-z0-9_-]+", "_", character_name).strip("_")[:64] or "character"
    dst = dest_dir / f"voice_{safe}_from_clip_{clip_number:04d}.wav"
    ffmpeg = rt.find_ffmpeg_exe(comfy)
    trim_s = (rt.MOTION_FRAMES / rt.FPS) if used_motion_context else 0.0
    start_s = max(0.0, trim_s + float(segment_start_s or 0.0))
    duration_s = max(0.6, float(segment_duration_s or 5.1))
    cmd = [ffmpeg, "-y", "-hide_banner", "-loglevel", "warning"]
    if start_s > 0:
        cmd += ["-ss", f"{start_s:.9f}"]
    cmd += [
        "-i", str(video_path), "-t", f"{duration_s:.3f}", "-vn",
        "-ac", "1", "-ar", "48000", "-c:a", "pcm_s16le", str(dst),
    ]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                          creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if proc.returncode != 0 or not dst.is_file() or dst.stat().st_size < 1024:
        raise RuntimeError("extraction audio impossible: " + (proc.stderr or proc.stdout)[-1200:])
    rel = dst.relative_to(comfy / "input").as_posix()
    return {
        "kind": "voice",
        "subject_key": f"voice_{norm(character_name)}",
        "subject_name": character_name,
        "audio_order": 0,
        "source": str(video_path),
        "path": str(dst),
        "annotated": f"{rel} [input]",
        "static": False,
        "captured_clip": clip_number,
        "source_kind": "clean_single_speaker_dialogue_segment" if segment_start_s > 0.0 or segment_duration_s < 5.0 else "first_clean_single_speaker_dialogue",
        "segment_start_s": float(segment_start_s or 0.0),
        "segment_duration_s": float(segment_duration_s or 5.1),
    }


def maybe_capture_voice_reference(
    bank: dict[str, Any],
    clip_prompt: str,
    scene: dict[str, Any],
    plan: dict[str, Any],
    principal_characters: list[str],
    known_characters: list[str],
    video_path: Path,
    used_motion_context: bool,
    comfy: Path,
    project: str,
    clip_number: int,
) -> dict[str, Any]:
    """Capture stable voices only from rendered clips with one planned speaker."""
    bank = copy.deepcopy(bank or {})
    bank.setdefault("voices", {})
    bank.setdefault("history", [])
    speakers = dialogue_speakers_from_prompt(
        clip_prompt, principal_characters, scene, plan, known_characters
    )
    if not speakers:
        return bank

    def has_voice(name: str) -> bool:
        return any(
            isinstance(r, dict) and (
                norm(str(k)) == norm(name)
                or ref_matches_name(r, name)
                or ref_matches_name({"subject_name": k}, name)
            )
            for k, r in (bank.get("voices") or {}).items()
        )

    uncaptured = [s for s in speakers if not has_voice(s)]
    if not uncaptured:
        return bank

    # Cleanest case: the whole rendered clip contains only one speaker.
    if len(speakers) == 1 and len(uncaptured) == 1:
        name = uncaptured[0]
        ref = stage_dynamic_voice_ref(
            comfy, project, video_path, clip_number, name, used_motion_context
        )
        bank["voices"][name] = ref
        bank["history"].append({
            "clip": clip_number, "kind": "voice", "name": name,
            "source": "first_clean_single_speaker_dialogue",
        })
        print(f"    Ref voix capturée : {name} | première réplique exploitable")
        return bank

    # The creator controls H3 dialogue timing. Reuse the existing shot parser and
    # extraction path for mono-speaker WINDOWS, even in a multi-speaker clip.
    # Never infer a time window from an unlabelled dialogue block.
    windows = clean_single_speaker_shot_segments(
        clip_prompt, principal_characters, scene, plan, known_characters,
    )
    captured = []
    for name in uncaptured:
        matching = [w for w in windows if norm(w["speaker"]) == norm(name)]
        if not matching:
            continue
        # Longer exclusive speech segments produce more useful timbre than a tiny cue.
        segment = max(matching, key=lambda w: (w["end"]-w["start"], -w["start"]))
        ref = stage_dynamic_voice_ref(
            comfy, project, video_path, clip_number, name, used_motion_context,
            segment_start_s=segment["start"],
            segment_duration_s=segment["end"]-segment["start"],
        )
        bank["voices"][name] = ref
        bank["history"].append({
            "clip": clip_number, "kind": "voice", "name": name,
            "source": "planned_single_speaker_shot_window",
            "start_s": segment["start"], "end_s": segment["end"],
        })
        captured.append(name)
        print(f"    Voice Ref capturée : {name} | fenêtre {segment['start']:.2f}-{segment['end']:.2f}s")
    if len(captured) < len(uncaptured):
        bank["history"].append({
            "clip": clip_number, "kind": "voice_deferred",
            "speakers": [s for s in uncaptured if s not in captured],
            "reason": "no_exclusive_shot_window_in_final_prompt",
        })
        print("    Voice Ref : aucune fenêtre mono-locuteur explicite pour les voix restantes.")
    return bank

_CHARACTER_TITLE_WORDS = {
    "mr", "mrs", "ms", "miss", "sir", "dame", "dr", "doctor", "docteur",
    "prof", "professor", "professeur", "monsieur", "madame", "mademoiselle",
    "captain", "capitaine", "commander", "commandant", "agent", "officer", "inspecteur", "inspector",
}


def character_match_aliases(name: str, all_names: list[str] | None = None) -> list[str]:
    """Readable aliases for plan/prompt character mentions, without inventing identities.

    Keeps the full canonical label, strips a leading title (e.g. Professor/Monsieur), and
    accepts a unique final name token. This fixes `Monsieur X` canonical refs being omitted
    when a director naturally writes only `X`.
    """
    raw = re.sub(r"\s+", " ", _ascii_text(name).casefold()).strip()
    if not raw:
        return []
    aliases = [raw]
    words = re.findall(r"[a-z0-9]+", raw)
    if len(words) >= 2 and words[0] in _CHARACTER_TITLE_WORDS:
        stripped = " ".join(words[1:]).strip()
        if len(norm(stripped)) >= 3:
            aliases.append(stripped)
    if len(words) >= 2 and len(words[-1]) >= 4:
        last = words[-1]
        others = []
        for other in all_names or []:
            ow = re.findall(r"[a-z0-9]+", _ascii_text(other).casefold())
            if ow:
                others.append(ow[-1])
        if not others or sum(1 for x in others if x == last) == 1:
            aliases.append(last)
    out=[]
    seen=set()
    for a in aliases:
        k=norm(a)
        if k and k not in seen:
            seen.add(k); out.append(a)
    return out


def character_names_for_clip(scene: dict[str, Any], plan: dict[str, Any] | None = None, known_characters: list[str] | None = None) -> list[str]:
    """Declared characters plus already-canonical film characters visibly mentioned in this clip.

    This fixes the conservative failure where Scene Director writes `Personnages: Aucun`
    but the description/plan still explicitly shows a known recurring character. It never
    invents a new character label.
    """
    out = split_character_names(str(scene.get("characters") or ""))
    seen = {norm(x) for x in out}
    blob = " ".join([
        scene_semantic_text(scene),
        str((plan or {}).get("view") or ""),
        str((plan or {}).get("action") or ""),
        str((plan or {}).get("purpose") or ""),
    ])
    blob_ascii = _ascii_text(blob).casefold()
    all_known = list(known_characters or [])
    for name in all_known:
        k = norm(name)
        if not k or k in seen:
            continue
        if any(re.search(rf"(?<![a-z0-9]){re.escape(alias)}(?![a-z0-9])", blob_ascii)
               for alias in character_match_aliases(name, all_known)):
            out.append(name)
            seen.add(k)
    return out


def character_names_for_plan(scene: dict[str, Any], plan: dict[str, Any] | None = None, known_characters: list[str] | None = None) -> list[str]:
    """Return only characters the CURRENT 5-second plan actually asks to show.

    The Scene Director roster is context, not proof that every listed person is visible in every
    plan. Exact plan mentions win. A small fallback keeps natural collective wording such as
    "the couple" usable without forcing names into every plan.
    """
    plan = plan or {}
    blob = " ".join(str(plan.get(k) or "") for k in ("view", "action", "purpose", "start_state", "end_state"))
    if plan.get("shots"):
        blob += " " + json.dumps(plan.get("shots"), ensure_ascii=False)
    blob_ascii = _ascii_text(blob).casefold()

    declared = split_character_names(str(scene.get("characters") or ""))
    candidates: list[str] = []
    seen: set[str] = set()
    for name in list(declared) + list(known_characters or []):
        k = norm(name)
        if k and k not in seen:
            seen.add(k)
            candidates.append(name)

    out: list[str] = []
    for name in candidates:
        if any(re.search(rf"(?<![a-z0-9]){re.escape(alias)}(?![a-z0-9])", blob_ascii)
               for alias in character_match_aliases(name, candidates)):
            out.append(name)

    if out:
        return out

    # Keep common collective plan wording useful without falling back to the whole scene roster.
    collective = bool(re.search(
        r"\b(couple|duo|tous\s+les\s+deux|toutes\s+les\s+deux|both|pair)\b",
        blob_ascii,
        flags=re.I,
    ))
    if collective and len(declared) == 2:
        return declared
    if len(declared) == 1:
        return declared
    return []


def sanitize_clip_reference_claims(text: str) -> str:
    """Remove Picture/Audio numbering invented by the LLM.

    The runtime prefix is the sole authority for <Picture N>/<Audio N> mapping. Dialogue and
    creative content are preserved; only conflicting technical mapping claims are stripped.
    """
    out: list[str] = []
    for line in str(text or "").splitlines():
        # V5.6: technical voice/subject speaking cues are runtime-owned. Keep human `Name:` labels
        # and the actual <d> payload, but discard local-LLM guesses such as <Subject 1> says.
        if re.search(r"Using\s+specifically\s+the\s+voice\s+timbre", line, flags=re.I):
            continue
        if re.search(r"^\s*<Subject\s+\d+>\s*(?:\(S\d+\))?\s*(?:says|speaks|answers|asks)\s*:\s*$", line, flags=re.I):
            continue

        # Identity/reference declarations containing a Picture number are redundant and risky.
        if re.search(r"<Picture\s+\d+>", line, flags=re.I):
            if re.search(r"<Subject\s+\d+>|defines|reference|preserve", line, flags=re.I):
                continue
            line = re.sub(r"<Picture\s+\d+>", "", line, flags=re.I)

        # Preserve who says the line, but never trust an LLM-invented Audio number.
        if re.search(r"<Audio\s+\d+>", line, flags=re.I):
            line = re.sub(
                r"Using\s+specifically\s+the\s+voice\s+timbre\s+and\s+delivery\s+referenced\s+from\s+<Audio\s+\d+>\s*,?\s*",
                "",
                line,
                flags=re.I,
            )
            line = re.sub(r"<Audio\s+\d+>", "", line, flags=re.I)
        out.append(line)
    return "\n".join(out).strip()


# V10.9: The Clip Director owns ONLY the creative shot instructions.
# Runtime-owned authorities (Picture/Audio map, global Director, spatial anchor)
# must never be copied from an earlier complete H3 prompt into a new LLM answer.
_PROTECTED_H3_HEAD = re.compile(
    r"^\s*(?:\#{1,4}\s*)?(?:\*\*\s*)?(?:"
    r"(?:VOICE\s+)?REFERENCE\s+AUTHORITY\b|"
    r"Director\s*:|Spatial\s+continuity\s*[—–-]\s*soft\s+observed\s+facts\s*:|"
    r"World\s+ambience\b"
    r")", re.I)
_CREATIVE_H3_HEAD = re.compile(
    r"^\s*(?:\#{1,4}\s*)?(?:\*\*\s*)?(?:"
    r"description_multimodale_int[ée]gr[ée]e\s*:|"
    r"\[(?:shot|plan)\s*\d+\]|"
    r"(?:soundscape_global|musique_non_di[ée]g[ée]tique|look_cam[ée]ra_et_lumi[èe]re|"
    r"r[ée]alisme_du_jeu|continuit[ée]_obligatoire|n[ée]gatifs|dialogues?)\s*:"
    r")", re.I)
_REVISION_CREATIVE_ONLY = (
    "\n\nIMPORTANT — SORTIE CRÉATIVE UNIQUEMENT. "
    "FilmMaker conserve et réinjecte lui-même, une seule fois, ses blocs "
    "REFERENCE AUTHORITY, VOICE REFERENCE AUTHORITY, Director, "
    "World ambience et Spatial continuity — soft observed facts. "
    "Ne recopie ni ne recrée aucun de ces blocs. "
    "Retourne uniquement description_multimodale_intégrée, shots, dialogues, "
    "soundscape, caméra/lumière, jeu, continuité narrative et négatifs utiles. "
    "N'invente aucun mapping <Picture N>, <Subject N> ou <Audio N>."
)


def creative_clip_body(text: str) -> str:
    """Extract ONLY creative H3 content, including from old full prompts.

    A protected section ends at the next creative heading (or another protected
    heading). Unlike broad deduplication this leaves the shot text untouched.
    The caller reattaches the original immutable runtime blocks once.
    """
    text = str(text or '')
    if not text.strip():
        return ''
    result = []
    skipping = False
    protected_count = 0
    for line in text.splitlines():
        if _PROTECTED_H3_HEAD.match(line):
            skipping = True
            protected_count += 1
            continue
        if skipping and _CREATIVE_H3_HEAD.match(line):
            skipping = False
        if not skipping:
            result.append(line)
    output = '\n'.join(result).strip()
    if protected_count and not output:
        raise ValueError('Clip Director: aucun contenu créatif après retrait des blocs système.')
    return output


def revision_creative_context(h3_prompt: str) -> str:
    """Creative portion of the last APPROVED H3 prompt (never the first retake)."""
    return sanitize_clip_reference_claims(creative_clip_body(h3_prompt))


def reconcile_clip_subject_claims(text: str, refs: list[dict[str, Any]]) -> str:
    """Repair or remove every Subject-number claim invented by the Clip Director.

    The runtime prefix is the only technical authority. Named claims are useful creatively,
    so both ``<Subject N> (Name)`` and the common reversed form ``Name (Subject N)`` are
    resolved against the active runtime ref map and rewritten with the correct number.
    Any remaining bare/unresolvable Subject numbering is stripped instead of risking a
    character being bound to another character or to the decor.
    """
    groups: dict[str, list[dict[str, Any]]] = {}
    order: list[str] = []
    for r in refs:
        key = str(r.get("subject_key") or f"ref_{r.get('picture_order')}")
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(r)
    subject_names = {i + 1: str(groups[key][0].get("subject_name") or key) for i, key in enumerate(order)}

    placeholders: dict[str, str] = {}
    placeholder_idx = 0

    def protect(subject_n: int, display_name: str) -> str:
        nonlocal placeholder_idx
        placeholder_idx += 1
        token = f"__RUNTIME_SUBJECT_CLAIM_{placeholder_idx}__"
        placeholders[token] = f"<Subject {subject_n}> ({display_name})"
        return token

    def find_subject_for_name(claimed: str) -> int | None:
        claimed = str(claimed or "").strip(" .:-")
        if not claimed:
            return None
        for other_n, other_name in subject_names.items():
            if ref_matches_name({"subject_name": other_name}, claimed):
                return other_n
        return None

    def repl_forward(m: re.Match[str]) -> str:
        n = int(m.group(1))
        claimed = str(m.group(2) or "").strip()
        actual = subject_names.get(n, "")
        if actual and ref_matches_name({"subject_name": actual}, claimed):
            return protect(n, claimed)
        other_n = find_subject_for_name(claimed)
        if other_n is not None:
            return protect(other_n, claimed)
        # Keep the readable name, discard the unsafe technical binding.
        return claimed

    work = re.sub(r"<Subject\s+(\d+)>\s*\(([^)]+)\)", repl_forward, str(text or ""), flags=re.I)

    # Clip LLMs also naturally emit `Nyx (Subject 2)` / `Le Loft (<Subject 3>)`.
    # Capture a short readable name immediately before the parenthetical claim, then map it
    # by the runtime's active subject names. The capitalized-start constraint prevents
    # swallowing prose such as `plan moyen sur` into the claimed name.
    reverse_re = re.compile(
        r"(?P<name>[A-ZÀ-ÖØ-Ý][A-Za-zÀ-ÖØ-öø-ÿ0-9'’._-]*(?:\s+[A-ZÀ-ÖØ-Ý][A-Za-zÀ-ÖØ-öø-ÿ0-9'’._-]*){0,5})"
        r"\s*\(\s*<?(?i:Subject)\s+(?P<n>\d+)>?\s*\)"
    )

    def repl_reverse(m: re.Match[str]) -> str:
        claimed = str(m.group("name") or "").strip()
        other_n = find_subject_for_name(claimed)
        if other_n is not None:
            return protect(other_n, claimed)
        return claimed

    work = reverse_re.sub(repl_reverse, work)

    # Anything still carrying a Subject number is untrusted: remove the number but preserve
    # surrounding natural-language content. Correct mappings are protected above.
    work = re.sub(r"\(\s*<?Subject\s+\d+>?\s*\)", "", work, flags=re.I)
    work = re.sub(r"<Subject\s+\d+>", "", work, flags=re.I)
    work = re.sub(r"\bSubject\s+\d+\b", "", work, flags=re.I)
    work = re.sub(r"\(\s*\)", "", work)
    work = re.sub(r"[ \t]{2,}", " ", work)

    for token, replacement in placeholders.items():
        work = work.replace(token, replacement)
    return work.strip()


def build_recurring_visual_subject_terms(film: dict[str, Any]) -> dict[str, str]:
    """Deprecated V4.8: never manufacture reusable visual refs from recurring words.

    V4.6/V4.7 could turn ordinary words such as ``changement``, ``geste`` or
    ``environnement`` into dynamic subjects.  That polluted the ref bank and consumed H3's
    image budget. Persistent visual subjects now come from explicit Studio/canonical refs;
    character appearance continuity has its own semantic LLM + visual VLM gate below.
    """
    return {}


def _text_mentions_term(text: str, term_norm: str) -> bool:
    toks = set(re.findall(r"[a-z0-9]+", _ascii_text(text).casefold()))
    return term_norm in toks


def stage_user_references(comfy: Path, project: str, char_groups: list[list[Path]], char_names: list[str], decor_groups: list[list[Path]], decor_names: list[str]) -> list[dict[str, Any]]:
    records = []
    for gi, files in enumerate(char_groups, 1):
        name = char_names[gi - 1] if gi - 1 < len(char_names) else f"Character{gi}"
        for src in files:
            records.append((src, "character", f"character_{gi}", name, rt.CHAR_REF_STRENGTH))
    for gi, files in enumerate(decor_groups, 1):
        name = decor_names[gi - 1] if gi - 1 < len(decor_names) else f"Environment{gi}"
        for src in files:
            records.append((src, "decor", f"decor_{gi}", name, rt.DECOR_REF_STRENGTH))
    if len(records) > rt.MAX_REF_IMAGES:
        print(f"  Attention: {len(records)} refs statiques -> seules les {rt.MAX_REF_IMAGES} premières sont gardées.")
        records = records[:rt.MAX_REF_IMAGES]
    dest_dir = comfy / "input" / OUTPUT_ROOT_NAME / project / "refs"
    dest_dir.mkdir(parents=True, exist_ok=True)
    refs = []
    for i, (src, kind, key, name, strength) in enumerate(records, 1):
        ext = src.suffix.lower() or ".png"
        safe = re.sub(r"[^A-Za-z0-9_-]+", "_", name).strip("_") or key
        dst = dest_dir / f"{i:02d}_{safe}{ext}"
        shutil.copy2(src, dst)
        rel = dst.relative_to(comfy / "input").as_posix()
        refs.append({
            "kind": kind,
            "subject_key": key,
            "subject_name": name,
            "picture_order": i,
            "source": str(src),
            "path": str(dst),
            "annotated": f"{rel} [input]",
            "strength": strength,
            "static": True,
        })
    return refs


def stage_dynamic_ref(comfy: Path, project: str, frame: Path, clip_number: int, kind: str, name: str, video_path: Path | None = None) -> dict[str, Any]:
    """Stage a dynamic ref at native rendered resolution whenever possible.

    `frame` is an observer/VLM JPEG and may be intentionally downscaled. The filename carries
    its source timestamp; when the rendered video is available, re-extract that exact moment
    from the original video so H3 receives a true full-resolution reference.
    """
    dest_dir = comfy / "input" / OUTPUT_ROOT_NAME / project / "dynamic_refs"
    dest_dir.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[^A-Za-z0-9_-]+", "_", name).strip("_") or kind
    dst = dest_dir / f"clip_{clip_number:04d}_{kind}_{safe}.jpg"
    source_desc = str(frame)
    full_res = False
    if video_path is not None and Path(video_path).is_file():
        m = re.search(r"_t(\d+(?:\.\d+)?)s(?:\.[^.]+)?$", Path(frame).name, flags=re.I)
        if m:
            try:
                t = float(m.group(1))
                rt.extract_fullres_frame_at_seconds(Path(video_path), t, dst)
                source_desc = f"{video_path}@{t:.3f}s"
                full_res = True
            except Exception as exc:
                print(f"    WARN ref full-res {name}: fallback miniature observateur ({exc})")
    if not full_res:
        shutil.copy2(frame, dst)
    rel = dst.relative_to(comfy / "input").as_posix()
    return {
        "kind": kind,
        "subject_key": f"dynamic_{kind}_{norm(name) or clip_number}",
        "subject_name": name,
        "picture_order": 0,
        "source": source_desc,
        "path": str(dst),
        "annotated": f"{rel} [input]",
        "strength": 0.85 if kind == "character" else 0.65,
        "static": False,
        "captured_clip": clip_number,
        "full_resolution_capture": full_res,
    }


def ensure_global_environment_reference(
    vision_model: str,
    bank: dict[str, Any],
    frames: list[Path],
    plan: dict[str, Any],
    comfy: Path,
    project: str,
    clip_number: int,
    video_path: Path | None = None,
) -> dict[str, Any]:
    """Create one persistent video-wide environment reference from the first rendered clip.

    This is intentionally separate from location-specific decor refs.  It represents the
    visual identity of the world (architecture language, materials, lighting character,
    palette and general production design), not an instruction to reuse the exact location.
    It is kept for the entire video and can be supplied even when the current scene moves
    somewhere else.
    """
    bank.setdefault("global_environment", None)
    if bank.get("global_environment"):
        return bank
    if not frames:
        return bank

    # Prefer the already-selected first-clip decor frame when one exists. This avoids a
    # second VLM pass and guarantees that the persistent world anchor is literally a frame
    # that the pipeline already judged useful as environment reference.
    if bank.get("decor"):
        candidates = [r for r in bank.get("decor", {}).values() if isinstance(r, dict)]
        if candidates:
            candidates.sort(key=lambda r: int(r.get("captured_clip") or 0), reverse=True)
            base_ref = candidates[0]
            ref = copy.deepcopy(base_ref)
            ref["kind"] = "global_environment"
            ref["subject_key"] = "global_environment"
            ref["subject_name"] = "Global Video Environment"
            ref["role"] = "persistent_world_reference"
            ref["strength"] = 0.65
            ref["reference_quality"] = base_ref.get("reference_quality", {})
            bank["global_environment"] = ref
            bank.setdefault("history", []).append({
                "clip": clip_number,
                "kind": "global_environment",
                "name": "Global Video Environment",
                "source": "reused_first_available_decor_ref",
            })
            print("    Ref environnement globale : réutilisation de la première ref décor disponible")
            return bank

    q = assess_environment_reference_quality(
        vision_model, "GLOBAL FILM ENVIRONMENT", frames, plan
    )
    idx = int(q.get("frame_index") or 0)
    idx = max(0, min(idx, len(frames) - 1))
    ref = stage_dynamic_ref(
        comfy, project, frames[idx], clip_number, "global_environment", "Global Video Environment", video_path=video_path
    )
    ref["reference_quality"] = q
    ref["strength"] = 0.65
    ref["role"] = "persistent_world_reference"
    bank["global_environment"] = ref
    bank.setdefault("history", []).append({
        "clip": clip_number,
        "kind": "global_environment",
        "name": "Global Video Environment",
        "quality": q,
    })
    print(f"    Ref environnement globale capturée : Global Video Environment | {q.get('quality','WEAK')}")
    return bank


def choose_active_refs(static_refs: list[dict[str, Any]], bank: dict[str, Any], scene: dict[str, Any], plan: dict[str, Any] | None = None, known_characters: list[str] | None = None) -> list[dict[str, Any]]:
    """Select only refs that materially help THIS 5-second clip.

    Priority: visible character identity -> current character appearance -> exact/current decor
    -> up to two scene-local continuing objects -> explicit canonical visual subject -> global world anchor.
    """
    chars = character_names_for_plan(scene, plan, known_characters)
    plan_blob = " ".join(str((plan or {}).get(k) or "") for k in ("view", "action", "purpose", "start_state", "end_state"))
    if (plan or {}).get("shots"):
        plan_blob += " " + json.dumps((plan or {}).get("shots"), ensure_ascii=False)
    subject_blob = plan_blob
    location = str(scene.get("location") or "").strip()

    dynamic_chars = [r for r in (bank.get("characters") or {}).values() if isinstance(r, dict)]
    appearance_chars = [r for r in (bank.get("character_appearance") or {}).values() if isinstance(r, dict)]
    dynamic_decor = [r for r in (bank.get("decor") or {}).values() if isinstance(r, dict)]
    dynamic_objects = [r for r in (bank.get("objects") or {}).values() if isinstance(r, dict)]

    character_refs: list[dict[str, Any]] = []

    def add_character(name: str) -> None:
        if any(ref_matches_name(x, name) for x in character_refs if str(x.get("kind")) == "character"):
            return
        static_matches = [r for r in static_refs if str(r.get("kind")) == "character" and ref_matches_name(r, name)]
        canonical = [r for r in static_matches if str(r.get("role") or "") == "canonical_identity"]
        if canonical:
            character_refs.append(copy.deepcopy(canonical[0]))
            apps = [r for r in appearance_chars if ref_matches_name(r, name)]
            if apps:
                apps.sort(key=lambda r: int(r.get("captured_clip") or 0), reverse=True)
                character_refs.append(copy.deepcopy(apps[0]))
            return
        if static_matches:
            character_refs.append(copy.deepcopy(static_matches[0]))
            return
        dyn = [r for r in dynamic_chars if ref_matches_name(r, name)]
        if dyn:
            dyn.sort(key=lambda r: int(r.get("captured_clip") or 0), reverse=True)
            character_refs.append(copy.deepcopy(dyn[0]))

    for cname in chars:
        add_character(cname)
    for visible_name in character_names_for_plan(scene, plan, known_characters):
        add_character(visible_name)

    # Preserve the old decor behavior for strong exact/root canonical matches.  The only
    # extension is that a more precise rendered sub-location can beat a broad generic world ref.
    static_decor_matches: list[tuple[int, dict[str, Any]]] = []
    dynamic_decor_matches: list[tuple[int, int, dict[str, Any]]] = []
    for r in static_refs:
        if str(r.get("kind")) != "decor":
            continue
        score = decor_match_score(str(r.get("subject_name") or ""), location)
        if score > 0:
            static_decor_matches.append((score, r))
    for r in dynamic_decor:
        score = decor_match_score(str(r.get("subject_name") or ""), location)
        if score > 0:
            dynamic_decor_matches.append((score, int(r.get("captured_clip") or 0), r))
    static_decor_matches.sort(key=lambda x: x[0], reverse=True)
    dynamic_decor_matches.sort(key=lambda x: (x[0], x[1]), reverse=True)
    best_static = static_decor_matches[0] if static_decor_matches else None
    best_dynamic = dynamic_decor_matches[0] if dynamic_decor_matches else None
    best_decor = None
    if best_static and best_static[0] >= 850:
        best_decor = best_static[1]
    elif best_dynamic and (not best_static or best_dynamic[0] > best_static[0]):
        best_decor = best_dynamic[2]
    elif best_static:
        best_decor = best_static[1]
    elif best_dynamic:
        best_decor = best_dynamic[2]

    # Object refs are bound to exact future PLAN numbers by the visual observer. No word mining.
    object_refs: list[dict[str, Any]] = []
    scene_no = int(scene.get("scene") or 0)
    plan_no = int((plan or {}).get("plan") or 0)
    for r in dynamic_objects:
        try:
            if int(r.get("source_scene") or -1) != scene_no:
                continue
        except Exception:
            continue
        active_nums = set()
        for x in r.get("active_plan_numbers") or []:
            try:
                active_nums.add(int(x))
            except Exception:
                pass
        if plan_no and plan_no in active_nums:
            object_refs.append(copy.deepcopy(r))
    object_refs.sort(key=lambda r: int(r.get("captured_clip") or 0), reverse=True)
    # two different important continuing objects maximum in a scene/clip
    seen_obj: set[str] = set()
    filtered_objects: list[dict[str, Any]] = []
    for r in object_refs:
        k = norm(str(r.get("subject_name") or ""))
        if not k or k in seen_obj:
            continue
        seen_obj.add(k)
        filtered_objects.append(r)
        if len(filtered_objects) >= 2:
            break

    subject_refs: list[dict[str, Any]] = []
    for r in [x for x in static_refs if str(x.get("kind")) == "subject"]:
        name = str(r.get("subject_name") or "").strip()
        if not name:
            continue
        mentioned = _text_mentions_reference_alias(subject_blob, name)
        if not mentioned:
            term = str(r.get("match_term") or norm(name))
            mentioned = bool(term and _text_mentions_term(subject_blob, term))
        if mentioned:
            subject_refs.append(copy.deepcopy(r))

    chosen: list[dict[str, Any]] = []
    chosen.extend(character_refs)
    if isinstance(best_decor, dict):
        chosen.append(copy.deepcopy(best_decor))
    chosen.extend(filtered_objects)
    chosen.extend(subject_refs)

    global_env = bank.get("global_environment") if isinstance(bank, dict) else None
    if best_decor is None and isinstance(global_env, dict):
        chosen.append(copy.deepcopy(global_env))

    dedup: list[dict[str, Any]] = []
    seen_paths: set[str] = set()
    for r in chosen:
        key = str(r.get("annotated") or r.get("path") or "")
        if not key or key in seen_paths:
            continue
        seen_paths.add(key)
        dedup.append(r)
    dedup = dedup[:rt.MAX_REF_IMAGES]
    for i, r in enumerate(dedup, 1):
        r["picture_order"] = i
    return dedup


def reference_prompt_prefix(refs: list[dict[str, Any]], audio_refs: list[dict[str, Any]] | None = None) -> str:
    audio_refs = audio_refs or []
    if not refs and not audio_refs:
        return ""
    groups: dict[str, list[dict[str, Any]]] = {}
    order = []
    for r in refs:
        key = str(r.get("subject_key") or f"ref_{r.get('picture_order')}")
        if key not in groups:
            groups[key] = []
            order.append(key)
        groups[key].append(r)

    lines: list[str] = []
    subject_num_by_name: dict[str, int] = {}
    if refs:
        lines.append("REFERENCE AUTHORITY — these Picture inputs are authoritative:")
        for sn, key in enumerate(order, 1):
            items = groups[key]
            name = str(items[0].get("subject_name") or key)
            subject_num_by_name[norm(name)] = sn
            pics = " and ".join(f"<Picture {int(x['picture_order'])}>" for x in items)
            kind = str(items[0].get("kind"))
            if kind == "character":
                canonical_items = [x for x in items if str(x.get("role") or "") == "canonical_identity"]
                film_items = [x for x in items if str(x.get("role") or "") == "film_appearance"]
                # Legacy first-picture identities used 'fully_preserved'. If an
                # appearance is attached, anchor it to the same stable identity
                # instead of downgrading the precise V10.13 authority contract.
                if film_items and not canonical_items:
                    canonical_items = [x for x in items if str(x.get("role") or "") == "fully_preserved"]
                if canonical_items:
                    canonical_pics = " and ".join(f"<Picture {int(x['picture_order'])}>" for x in canonical_items)
                    film_pics = " and ".join(f"<Picture {int(x['picture_order'])}>" for x in film_items)
                    lines.append(f"<Subject {sn}> is {name}. {canonical_pics} defines the canonical stable identity: preserve face, distinctive physical traits, hair identity and body proportions.")
                    if film_pics:
                        lines.append(f"{film_pics} is the latest rendered-film appearance state for the same <Subject {sn}>. It is wardrobe / temporary-state authority ONLY: it must never replace, duplicate or reinterpret the face/body identity defined by the canonical picture. Preserve that temporary visual state only while it remains compatible with the current scene. If the current scene explicitly establishes a new wardrobe, injury, dirt/wetness, disguise, armor, hairstyle state or other temporary appearance change, the current scene overrides this older appearance state while the canonical identity remains fixed.")
                    lines.append(f"<Subject {sn}>: canonical_identity - preserve identity across the film. Clothing, temporary hairstyle state, accessories, dirt, injuries or other appearance details may change when the current scene explicitly requires it.")
                else:
                    lines.append(f"<Subject {sn}> is {name}, the person defined by {pics}. Preserve the referenced facial identity, hair, body proportions, clothing and overall appearance.")
                    lines.append(f"<Subject {sn}>: fully_preserved - preserve referenced identity and stable appearance.")
            elif kind == "global_environment":
                lines.append(f"<Subject {sn}> is the Global Video Environment, defined by {pics}. Use this as a persistent visual reference for the video's persistent world / production design, architecture language, materials, palette and lighting character. It is NOT a demand to reproduce the exact location or camera framing from this image.")
                lines.append(f"<Subject {sn}>: persistent_world_reference - preserve world identity while allowing different locations and viewpoints.")
            elif kind == "object":
                lines.append(f"<Subject {sn}> is {name}, the SAME continuing physical object defined by {pics}. Preserve its real-world scale, proportions, shape, materials, markings and distinctive details across cuts. Do not enlarge, miniaturize, replace or redesign it merely because the camera changes. The current plan may explicitly move, damage, transform or remove it.")
                lines.append(f"<Subject {sn}>: continuing_object - preserve object identity and scale unless the current plan visibly changes its state.")
            elif kind == "decor":
                canonical_items = [x for x in items if str(x.get("role") or "") == "canonical_environment"]
                film_items = [x for x in items if str(x.get("role") or "") == "film_environment"]
                if canonical_items:
                    canonical_pics = " and ".join(f"<Picture {int(x['picture_order'])}>" for x in canonical_items)
                    film_pics = " and ".join(f"<Picture {int(x['picture_order'])}>" for x in film_items)
                    lines.append(f"<Subject {sn}> is {name}. {canonical_pics} defines the canonical environment identity: architecture language, spatial character, materials and production design.")
                    if film_pics:
                        lines.append(f"{film_pics} is a rendered-film continuity reference for the same <Subject {sn}> and should preserve the current on-screen state when compatible with the current scene.")
                    lines.append(f"<Subject {sn}>: canonical_environment - preserve place identity while allowing scene-authorized changes in lighting, weather, dressing, damage and state.")
                else:
                    lines.append(f"<Subject {sn}> is {name}, the established environment defined by {pics}. Preserve the referenced architecture, layout, materials, furnishings and lighting character.")
                    lines.append(f"<Subject {sn}>: strongly_referenced - preserve established environment identity and layout.")
            else:
                lines.append(f"<Subject {sn}> is {name}, the recurring visual subject/entity defined by {pics}. Preserve its established shape, materials, proportions, markings and overall visual identity.")
                lines.append(f"<Subject {sn}>: strongly_referenced - preserve the referenced subject identity and appearance.")

    if audio_refs:
        voice_rows = [(i, r) for i, r in enumerate(audio_refs, 1)
                      if str(r.get('studio_audio_use') or 'voice') != 'object_sound']
        sound_rows = [(i, r) for i, r in enumerate(audio_refs, 1)
                      if str(r.get('studio_audio_use') or 'voice') == 'object_sound']
        if voice_rows:
            if lines:
                lines.append("")
            lines.append("VOICE REFERENCE AUTHORITY — these Audio inputs are authoritative:")
            for i, ref in voice_rows:
                name = str(ref.get("subject_name") or f"Character {i}")
                sn = subject_num_by_name.get(norm(name))
                if sn:
                    lines.append(
                        f"<Audio {i}> is the voice-timbre reference for <Subject {sn}> ({name}). "
                        f"Every generated spoken line by <Subject {sn}> must use the same voice timbre and natural delivery from <Audio {i}>."
                    )
                else:
                    lines.append(
                        f"<Audio {i}> is the voice-timbre reference for {name}. "
                        f"Every generated spoken line by {name} must use the same voice timbre and natural delivery from <Audio {i}>."
                    )
        if sound_rows:
            if lines:
                lines.append("")
            lines.append("SOUND REFERENCE AUTHORITY — these Audio inputs define object sounds, not spoken voices:")
            for i, ref in sound_rows:
                name = str(ref.get("subject_name") or f"Object {i}")
                sn = subject_num_by_name.get(norm(name))
                target = f"<Subject {sn}> ({name})" if sn else name
                lines.append(
                    f"<Audio {i}> is the sound reference for {target}. "
                    f"Use its characteristic sound when this object audibly acts; "
                    f"do not treat <Audio {i}> as a character voice or invent dialogue."
                )
    return "\n".join(lines)


def observe_clip_end_state(
    vision_model: str,
    frames: list[Path],
    plan: dict[str, Any],
    scene: dict[str, Any] | None = None,
    h3_prompt: str = "",
    known_characters: list[str] | None = None,
    character_context: str = "",
    future_scene_plans: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """One compact vision pass for frontier state + identity + soft spatial facts.

    Hard rule: NEVER send more than three images to a VLM call.  The final three observer
    frames are authoritative for what physically exists at the clip frontier.  Scene-local
    spatial memory persists separately, so an insert/close-up that cannot establish layout
    simply returns no new spatial fact instead of erasing earlier good anchors.
    """
    if not frames:
        return {"state": "", "visible_characters": [], "spatial_facts": [], "observer_status": "no_frames"}
    scene = scene or {}
    # Three-frame maximum per VLM call, by design.
    inds = list(range(max(0, len(frames) - 3), len(frames)))
    imgs = [frames[i] for i in inds]

    candidates = character_names_for_clip(scene, plan, known_characters)
    names: list[str] = []
    seen: set[str] = set()
    for name in candidates:
        k = norm(name)
        if k and k not in seen:
            seen.add(k); names.append(name)
    shots = plan.get("shots") if isinstance(plan, dict) else None
    end_shot = shots[-1] if isinstance(shots, list) and shots else {}

    system = """You are a PIXEL CONTINUITY OBSERVER for a rendered film clip. Inspect the supplied frames first; text is only context for identity and continuity.

Return JSON with THREE conservative outputs:
1) state: 1-3 short sentences describing only clearly visible facts at the END frontier: visible people, posture/orientation, held/placed important objects, action still in progress, environment/light.
2) visible_characters: exact candidate names ONLY for people visibly present at the END frontier and individually supported by pixels plus unique action/position/stable traits. Never include off-screen speakers. If ambiguous, omit.
3) spatial_facts: up to 4 camera-independent facts for named visible characters when THESE THREE FRAMES clearly establish physical placement. Each item is {"subject":"Exact Name","relation":"..."}. Use relations to stable physical features or other characters: seated at the table nearest the railing, standing behind the desk facing X, seated opposite X, etc. NEVER encode screen-left/screen-right, framing, focal length, or guessed distances. A close-up/insert that does not establish placement returns no spatial fact. These facts are continuity anchors, not commands to stop planned movement.

Never infer a future event. JSON only:
{"state":"...","visible_characters":["Exact Name"],"spatial_facts":[{"subject":"Exact Name","relation":"..."}]}"""
    user = (
        f"CANDIDATE CHARACTER NAMES: {json.dumps(names, ensure_ascii=False)}\n"
        f"CHARACTER BIBLE / IDENTITY CONTEXT: {str(character_context or '').strip()[:5000] or '[none]'}\n"
        f"SCENE CONTINUITY: {str(scene.get('continuity_elements') or '')[:2500]}\n"
        f"CURRENT PLAN: {json.dumps(plan_context_payload(plan), ensure_ascii=False)}\n"
        f"END-OF-CLIP SHOT: {json.dumps(end_shot, ensure_ascii=False)}\n"
        f"EXACT H3 PROMPT THAT PRODUCED THESE PIXELS:\n{str(h3_prompt or '').strip()[:6500]}\n"
        f"You receive exactly {len(imgs)} chronological END-frontier frames (maximum 3). Observe pixels first."
    )
    try:
        raw = rt.ollama_json_images(
            vision_model, system, user, imgs, cpu_safe=rt.DIRECTOR_CPU_SAFE,
            timeout=180, label="Pixel Continuity + Identity + Layout",
        )
        state = str(raw.get("state") or "").strip()[:1200]

        incoming = raw.get("visible_characters") if isinstance(raw, dict) else []
        visible: list[str] = []
        for item in incoming if isinstance(incoming, list) else []:
            target = next((n for n in names if ref_matches_name({"subject_name": str(item)}, n)), None)
            if target and norm(target) not in {norm(x) for x in visible}:
                visible.append(target)

        spatial_facts: list[dict[str, str]] = []
        incoming_facts = raw.get("spatial_facts") if isinstance(raw, dict) else []
        for item in incoming_facts if isinstance(incoming_facts, list) else []:
            if not isinstance(item, dict):
                continue
            target = next((n for n in names if ref_matches_name({"subject_name": str(item.get('subject') or '')}, n)), None)
            relation = str(item.get("relation") or "").strip()
            if not target or not relation:
                continue
            low = _ascii_text(relation).casefold()
            if any(x in low for x in ("screen-left", "screen right", "screen-right", "a gauche de l'ecran", "a droite de l'ecran")):
                continue
            spatial_facts.append({"subject": target, "relation": relation[:500]})
            if len(spatial_facts) >= 4:
                break

        return {
            "state": state,
            "visible_characters": visible,
            "spatial_facts": spatial_facts,
            "observer_status": "vision",
        }
    except Exception as exc:
        return {
            "state": "", "visible_characters": [], "spatial_facts": [],
            "observer_status": "failed", "observer_error": str(exc),
        }


def _observer_frame_timestamp(frame: Path) -> float | None:
    m = re.search(r"_t(\d+(?:\.\d+)?)s(?:\.[^.]+)?$", Path(frame).name, flags=re.I)
    if not m:
        return None
    try:
        return float(m.group(1))
    except Exception:
        return None


def _frames_for_clip_window(frames: list[Path], start_s: float, end_s: float, *, max_frames: int = 3) -> list[Path]:
    """Choose <=3 observer frames from an intended clip-time window.

    Observer filenames retain original rendered timestamps.  Motion-Context clips may have a
    positive source offset, so comparisons use time relative to the first observer sample.
    """
    if not frames or max_frames <= 0:
        return []
    stamped = [(f, _observer_frame_timestamp(f)) for f in frames]
    valid = [(f, t) for f, t in stamped if t is not None]
    if not valid:
        # Deterministic fallback, still obeying three-image maximum.
        if len(frames) <= max_frames:
            return list(frames)
        return [frames[round((len(frames)-1)*i/(max_frames-1))] for i in range(max_frames)]
    base = min(t for _, t in valid)
    a = max(0.0, min(5.0, float(start_s)))
    b = max(a, min(5.0, float(end_s)))
    targets = [a + (b-a)*x for x in (0.18, 0.50, 0.82)] if b-a > 0.05 else [a]
    chosen: list[Path] = []
    # Prefer samples genuinely inside the requested shot/window, with a small quantization tolerance.
    inside = [(f, max(0.0, t-base)) for f, t in valid if a-0.20 <= max(0.0, t-base) <= b+0.20]
    pool = inside or [(f, max(0.0, t-base)) for f, t in valid]
    for target in targets:
        ranked = sorted(pool, key=lambda ft: abs(ft[1]-target))
        for f, _ in ranked:
            if f not in chosen:
                chosen.append(f)
                break
        if len(chosen) >= max_frames:
            break
    return chosen[:max_frames]


def plan_continuity_object_candidates(
    backend: dict[str, Any],
    h3_prompt: str,
    plan: dict[str, Any],
    future_scene_plans: list[dict[str, Any]],
    *,
    label: str,
) -> list[dict[str, Any]]:
    """Text-only pre-render gate: decide whether 0..2 dynamic objects deserve visual refs.

    The LLM reads the EXACT prompt that will be sent to H3 and later plans.  It does NOT guess
    appearance.  It only decides continuity importance and the current visibility window so the
    VLM can later inspect exactly three relevant rendered frames.
    """
    if not h3_prompt or not future_scene_plans:
        return []
    current_no = int(plan.get("plan") or 0)
    later = [plan_context_payload(p) for p in future_scene_plans if int(p.get("plan") or 0) > current_no]
    if not later:
        return []
    system = """You are a CONTINUITY OBJECT PLANNER for a 5-second H3 film clip. Read the exact H3 prompt and later plans. Return 0, 1 or at most 2 PHYSICAL DYNAMIC OBJECTS that genuinely deserve a rendered visual reference for continuity.

Select an object only when ALL are true:
- it is a specific physical object visibly present in the CURRENT clip (held, manipulated, moving, carried, used, or otherwise materially important);
- the SAME individual object is explicitly reused in one or more LATER plans of THIS SAME scene;
- preserving its scale, proportions, shape, materials or distinctive details matters across the cut.

Reject generic/incidental clutter, ordinary furniture, architecture/decor, food/drink/tableware unless uniquely plot-critical, screens/code/light/effects, generic vehicles/drones that may be different instances, and objects that never recur. Do not select an object just because its noun repeats. Decide semantic identity from the actions.

For each accepted object give the exact CURRENT clip visibility window, in seconds 0.0..5.0, where the object should be clearest. This window comes from the H3 prompt/shot timing; do not invent pixels.

JSON only:
{"objects":[{"label":"short specific object label","start_s":0.0,"end_s":2.5,"future_plan_numbers":[2,3],"reason":"why same object continuity matters"}]}"""
    user = (
        f"CURRENT PLAN: {json.dumps(plan_context_payload(plan), ensure_ascii=False)}\n"
        f"EXACT FINAL H3 PROMPT SENT FOR THIS CLIP:\n{h3_prompt[:9000]}\n\n"
        f"LATER PLANS IN THE SAME SCENE:\n{json.dumps(later, ensure_ascii=False)}"
    )
    try:
        raw_text = director_text(backend, system, user, label=label, num_ctx=12288, num_predict=900)
        raw = _extract_json_object(raw_text)
    except Exception:
        return []
    incoming = raw.get("objects") if isinstance(raw, dict) else []
    valid_future = {int(p.get("plan") or 0) for p in future_scene_plans if int(p.get("plan") or 0) > current_no}
    out: list[dict[str, Any]] = []
    for item in incoming if isinstance(incoming, list) else []:
        if not isinstance(item, dict):
            continue
        obj_label = str(item.get("label") or "").strip()
        try:
            a = float(item.get("start_s"))
            b = float(item.get("end_s"))
        except Exception:
            continue
        a = max(0.0, min(5.0, a)); b = max(0.0, min(5.0, b))
        if b <= a + 0.05:
            continue
        nums: list[int] = []
        for x in item.get("future_plan_numbers") or []:
            try:
                n = int(x)
            except Exception:
                continue
            if n in valid_future and n not in nums:
                nums.append(n)
        if not obj_label or not nums:
            continue
        out.append({
            "label": obj_label[:120], "start_s": a, "end_s": b,
            "future_plan_numbers": nums,
            "reason": str(item.get("reason") or "")[:400],
        })
        if len(out) >= 2:
            break
    return out


def verify_continuity_object_reference(
    vision_model: str,
    candidate: dict[str, Any],
    frames: list[Path],
    plan: dict[str, Any],
    h3_prompt: str,
) -> dict[str, Any]:
    """Vision confirmation on exactly the object's intended window, <=3 frames."""
    try:
        a = float(candidate.get("start_s")); b = float(candidate.get("end_s"))
    except Exception:
        return {"accept": False, "reason": "invalid time window"}
    imgs = _frames_for_clip_window(frames, a, b, max_frames=3)
    if not imgs:
        return {"accept": False, "reason": "no frames in object window"}
    system = """You are a CONTINUITY OBJECT VISUAL GATE. Inspect ONLY these rendered frames from the planned visibility window. Confirm whether the requested specific physical object is clearly visible and reusable as a continuity reference. Do not redesign it and do not infer it from text if pixels do not show it. Reject if the frame shows a different instance, only a vague category, severe blur/occlusion, or if scale/form/materials cannot be read. Choose the best frame. JSON only: {"accept":true,"best_image_number":1,"quality":"GOOD|EXCELLENT|REJECT","reason":"short"}."""
    user = (
        f"TARGET CONTINUITY OBJECT: {candidate.get('label','')}\n"
        f"PLANNED VISIBILITY WINDOW: {a:.2f}s-{b:.2f}s\n"
        f"CURRENT PLAN: {json.dumps(plan_context_payload(plan), ensure_ascii=False)}\n"
        f"H3 PROMPT CONTEXT: {h3_prompt[:6500]}\n"
        f"You receive {len(imgs)} rendered frames from that window (maximum 3). Pixels are authoritative."
    )
    try:
        raw = rt.ollama_json_images(
            vision_model, system, user, imgs, cpu_safe=rt.DIRECTOR_CPU_SAFE,
            timeout=180, label=f"Object Ref {candidate.get('label','object')}",
        )
    except Exception as exc:
        return {"accept": False, "quality": "REJECT", "reason": str(exc)}
    accept = raw.get("accept", False)
    if isinstance(accept, str):
        accept = accept.strip().lower() in {"1", "true", "yes", "oui"}
    identity_match = raw.get("identity_match", None)
    if identity_match is None:
        # Backward-compatible with older/instruct VLMs that omit the new field.
        # The frame router remains the primary identity gate; an explicit false always rejects.
        identity_match = True
    elif isinstance(identity_match, str):
        identity_match = identity_match.strip().lower() in {"1", "true", "yes", "oui"}
    quality = str(raw.get("quality") or "REJECT").upper()
    try:
        best = max(1, min(int(raw.get("best_image_number") or 1), len(imgs)))
    except Exception:
        best = 1
    if not accept or quality not in {"GOOD", "EXCELLENT"}:
        return {"accept": False, "quality": quality, "reason": str(raw.get("reason") or "not clear")}
    selected = imgs[best-1]
    try:
        frame_index = frames.index(selected)
    except ValueError:
        return {"accept": False, "quality": "REJECT", "reason": "selected frame not in observer strip"}
    return {"accept": True, "quality": quality, "reason": str(raw.get("reason") or ""), "frame_index": frame_index}


def resolve_pixel_character_identities(
    text_model: str,
    observed_state: str,
    h3_prompt: str,
    scene: dict[str, Any],
    plan: dict[str, Any],
    known_characters: list[str] | None = None,
    character_context: str = "",
) -> dict[str, Any]:
    """Legacy compatibility helper — NO LLM CALL.

    Runtime identity is now resolved directly inside `observe_clip_end_state()` from pixels.
    This helper is kept only for older callers/tests and trusts names that are already literally
    present in a supplied state; it can never trigger the old fragile text-only resolver.
    """
    state = str(observed_state or "").strip()
    names = character_names_for_clip(scene, plan, known_characters)
    ascii_state = _ascii_text(state).casefold()
    visible: list[str] = []
    for n in names:
        aliases = character_match_aliases(n, names)
        if any(re.search(rf"(?<![a-z0-9]){re.escape(a)}(?![a-z0-9])", ascii_state) for a in aliases):
            if norm(n) not in {norm(x) for x in visible}:
                visible.append(n)
    return {"state": state[:1200], "visible_characters": visible, "resolver_status": "legacy_literal_no_llm"}


def assess_environment_reference_quality(vision_model: str, location: str, frames: list[Path], plan: dict[str, Any], h3_prompt: str = "") -> dict[str, Any]:
    """Choose the best available frame for a location and ALWAYS keep one when frames exist.

    V13.9 behavior was permissive for environments: decor capture was not blocked by the strict
    character-quality gate. The VLM is therefore a selector/ranker, not a reject gate.
    """
    if not frames:
        return {"accept": False, "quality": "REJECT", "reason": "no frames"}

    # Hard rule: maximum three images per VLM call.
    if len(frames) <= 3:
        inds = list(range(len(frames)))
    else:
        inds = sorted(set(round((len(frames) - 1) * i / 2) for i in range(3)))
    imgs = [frames[i] for i in inds]
    fallback_slot = len(imgs) // 2

    system = """You are an ENVIRONMENT REFERENCE SELECTOR. Your only task is to choose the BEST reusable frame among the supplied rendered frames for the requested video location. Do not redesign the location and do not reject all images: a decor reference MUST be selected whenever images exist. Prefer the frame that best shows persistent architecture, spatial layout, major furniture/structures, materials and lighting character. Avoid tight face shots, severe motion blur, heavy obstruction, doorway-only transition frames, or shots dominated by a person when a clearer environment frame is available. Even if all candidates are imperfect, choose the least-bad one. Return JSON only: {\"best_image_number\":1,\"quality\":\"GOOD|EXCELLENT|WEAK\",\"reason\":\"short\"}."""
    user = (
        f"TARGET LOCATION LABEL: {location}\n"
        f"CURRENT 5-SECOND PLAN (context only): {json.dumps(plan, ensure_ascii=False)}\n"
        f"FINAL H3 SHOTS (time and composition, context only): {str(h3_prompt or '')[:3500]}\n"
        f"There are {len(imgs)} chronological candidate images. Choose the single best reusable environment reference. You must choose one."
    )

    try:
        raw = rt.ollama_json_images(
            vision_model, system, user, imgs,
            cpu_safe=rt.DIRECTOR_CPU_SAFE, timeout=180,
            label=f"Decor Ref Quality {location}",
        )
        try:
            best = max(1, min(int(raw.get("best_image_number") or (fallback_slot + 1)), len(imgs)))
        except Exception:
            best = fallback_slot + 1
        quality = str(raw.get("quality") or "WEAK").upper()
        if quality not in {"GOOD", "EXCELLENT", "WEAK"}:
            quality = "WEAK"
        reason = str(raw.get("reason") or "best available environment frame")
        return {
            "accept": True,
            "quality": quality,
            "reason": reason,
            "frame_index": inds[best - 1],
            "forced_decor_capture": True,
        }
    except Exception as exc:
        # Decor must still be captured. Use a stable middle candidate as a no-VLM fallback.
        return {
            "accept": True,
            "quality": "FALLBACK",
            "reason": f"VLM unavailable; middle frame kept automatically: {exc}",
            "frame_index": inds[fallback_slot],
            "forced_decor_capture": True,
        }


def assess_character_reference_simple(vision_model: str, character: str, frames: list[Path], plan: dict[str, Any], scene: dict[str, Any] | None = None) -> dict[str, Any]:
    if not frames:
        return {"accept": False, "reason": "no frames", "appearance_capture": False}
    # Hard rule: maximum three images per VLM call.
    if len(frames) <= 3:
        inds = list(range(len(frames)))
    else:
        inds = sorted(set(round((len(frames) - 1) * i / 2) for i in range(3)))
    imgs = [frames[i] for i in inds]
    system = """You are a CHARACTER REFERENCE QUALITY GATE. The target character label comes from the current video plan; you are NOT doing celebrity recognition. Select a reusable frame only if the target character is visually unambiguous in this clip. Reject if multiple people make the target ambiguous. Prefer a clear FRONT or THREE_QUARTER face with useful upper-body/wardrobe context. Reject tiny, blurry, heavily occluded, silhouette, back-only, background or ambiguous-person frames. If no frame is strong enough, reject and wait for a later clip.

Also decide whether this rendered clip establishes a MATERIAL, PERSISTENT APPEARANCE STATE for this character that should be carried into later clips in addition to canonical identity. Set appearance_capture=true ONLY when the scene/plan explicitly authorizes a visible state worth continuity, such as wardrobe/clothing, armor or worn equipment, disguise/mask/helmet, injury/blood/bruising, dirt/wetness/burn damage, or a temporary hairstyle/state. Do NOT capture merely for pose, expression, camera angle, lighting, attractiveness, body type, or canonical facial/physical traits. If the scene does not establish such a persistent state, appearance_capture=false. Keep appearance_state short and concrete.

Return JSON only: {"accept":true,"best_image_number":1,"quality":"GOOD|EXCELLENT|WEAK|REJECT","face_view":"FRONT|THREE_QUARTER|PROFILE|BACK|UNCLEAR","subject_prominence":"MAIN|CLEAR_SECONDARY|BACKGROUND|UNCLEAR","appearance_capture":false,"appearance_state":"","reason":"short"}."""
    scene = scene or {}
    user = (
        f"TARGET CHARACTER LABEL: {character}\n"
        f"SCENE INITIAL STATE: {scene.get('initial_state','')}\n"
        f"SCENE DESCRIPTION: {scene.get('description','')}\n"
        f"SCENE CONTINUITY: {scene.get('continuity_elements','')}\n"
        f"SCENE FINAL STATE: {scene.get('final_state','')}\n"
        f"CURRENT 5-SECOND PLAN: {json.dumps(plan, ensure_ascii=False)}\n"
        f"There are {len(imgs)} chronological candidate images. Choose the best reusable frame of that exact target only, or reject all."
    )
    try:
        raw = rt.ollama_json_images(vision_model, system, user, imgs, cpu_safe=rt.DIRECTOR_CPU_SAFE, timeout=180, label=f"Ref Quality {character}")
    except Exception as exc:
        return {"accept": False, "quality": "REJECT", "appearance_capture": False, "appearance_state": "", "reason": str(exc)}
    accept = raw.get("accept", False)
    if isinstance(accept, str):
        accept = accept.strip().lower() in {"1", "true", "yes", "oui"}
    q = str(raw.get("quality") or "REJECT").upper()
    face = str(raw.get("face_view") or "UNCLEAR").upper()
    prom = str(raw.get("subject_prominence") or "UNCLEAR").upper()
    appearance_capture = raw.get("appearance_capture", False)
    if isinstance(appearance_capture, str):
        appearance_capture = appearance_capture.strip().lower() in {"1", "true", "yes", "oui"}
    appearance_state = str(raw.get("appearance_state") or "").strip()
    try:
        best = max(1, min(int(raw.get("best_image_number") or 1), len(imgs)))
    except Exception:
        best = 1
    if q not in {"GOOD", "EXCELLENT"} or prom not in {"MAIN", "CLEAR_SECONDARY"} or face in {"BACK", "UNCLEAR"}:
        accept = False
    if not accept or not appearance_state:
        appearance_capture = False
    return {
        "accept": bool(accept), "quality": q, "face_view": face, "subject_prominence": prom,
        "appearance_capture": bool(appearance_capture), "appearance_state": appearance_state,
        "reason": str(raw.get("reason") or ""), "frame_index": inds[best - 1],
    }

def assess_character_appearance_intent(
    text_model: str,
    characters: list[str],
    bank: dict[str, Any],
    scene: dict[str, Any],
    plan: dict[str, Any],
    h3_prompt: str,
) -> dict[str, dict[str, Any]]:
    """Text-only semantic gate: does the SENT H3 prompt intentionally establish a new persistent look?

    This is deliberately separate from frame quality.  The LLM decides intent from the exact
    prompt that generated the clip; the VLM later confirms that H3 actually rendered that state.
    Any parse/model failure safely means NO capture.
    """
    names = [x for x in characters if norm(x)]
    if not names or not str(h3_prompt or "").strip():
        return {}
    previous: dict[str, str] = {}
    for name in names:
        old = next((r for r in (bank.get("character_appearance") or {}).values() if isinstance(r, dict) and ref_matches_name(r, name)), None)
        previous[name] = str((old or {}).get("appearance_state") or "[aucun état temporaire enregistré]")

    system = """You are a CHARACTER APPEARANCE CONTINUITY INTENT GATE. Read the exact H3 prompt that was sent for the current 5-second clip. For each TARGET CHARACTER, decide whether this clip INTENTIONALLY ESTABLISHES A NEW MATERIAL VISUAL STATE that should persist into later clips in addition to canonical identity. YES only for concrete character appearance states such as clothing/wardrobe change, armor or worn gear, disguise/mask/helmet, injury/blood/bruising, dirt/wetness/burn damage, or a temporary hairstyle/state. NO for pose, expression, gesture, body type, attractiveness, camera angle, lighting, mood, location, interaction, or vague words like change/environment/data. Compare with PREVIOUS APPEARANCE: if the prompt merely continues the same state, answer NO. Do not infer from story genre; use only what the sent H3 prompt actually establishes. Return JSON only: {\"characters\":[{\"name\":\"exact target\",\"capture\":false,\"change_type\":\"\",\"appearance_state\":\"\",\"reason\":\"short\"}]}"""
    user = (
        f"TARGET CHARACTERS: {json.dumps(names, ensure_ascii=False)}\n"
        f"PREVIOUS APPEARANCE: {json.dumps(previous, ensure_ascii=False)}\n"
        f"SCENE: {json.dumps(scene_context_payload(scene), ensure_ascii=False)}\n"
        f"CURRENT PLAN: {json.dumps(plan_context_payload(plan), ensure_ascii=False)}\n"
        "EXACT H3 PROMPT SENT:\n" + str(h3_prompt or "")
    )
    safe = {norm(n): {"name": n, "capture": False, "change_type": "", "appearance_state": "", "reason": "semantic gate unavailable"} for n in names}
    try:
        raw = ollama_text(text_model, system, user, label="Appearance Intent", num_ctx=12288, num_predict=700)
        obj = _extract_json_object(raw)
        items = obj.get("characters") if isinstance(obj, dict) else None
        if not isinstance(items, list):
            return safe
        for item in items:
            if not isinstance(item, dict):
                continue
            incoming = str(item.get("name") or "").strip()
            target = next((n for n in names if ref_matches_name({"subject_name": incoming}, n)), None)
            if not target:
                continue
            capture = item.get("capture", False)
            if isinstance(capture, str):
                capture = capture.strip().lower() in {"1", "true", "yes", "oui"}
            state = str(item.get("appearance_state") or "").strip()
            ctype = str(item.get("change_type") or "").strip()
            # A YES without a concrete state is unsafe and becomes NO.
            safe[norm(target)] = {
                "name": target,
                "capture": bool(capture and state),
                "change_type": ctype,
                "appearance_state": state if capture else "",
                "reason": str(item.get("reason") or "").strip(),
            }
        return safe
    except Exception as exc:
        for v in safe.values():
            v["reason"] = f"semantic gate failed safely: {exc}"
        return safe



def _observer_frame_time_seconds(frame: Path) -> float | None:
    m = re.search(r"_t(\d+(?:\.\d+)?)s(?:\.[^.]+)?$", Path(frame).name, flags=re.I)
    if not m:
        return None
    try:
        return float(m.group(1))
    except Exception:
        return None


def _text_mentions_character(text: str, character: str, all_names: list[str]) -> bool:
    hay = _ascii_text(str(text or "")).casefold()
    if not hay:
        return False
    return any(
        re.search(rf"(?<![a-z0-9]){re.escape(alias)}(?![a-z0-9])", hay)
        for alias in character_match_aliases(character, all_names)
    )


def _h3_prompt_shot_windows(prompt: str) -> list[tuple[float, float, str]]:
    """Extract FINAL H3 shot intervals; never infer presence from planned events alone."""
    text = str(prompt or "")
    # H3's real prompt notation includes **[Shot 1] 0:00–2.5s** as well as
    # 0.00–2.50 and 0:00–0:02.5. Both audio and visual routing share this parser.
    clock = r"([0-9]+(?::[0-9]+)?(?:\.[0-9]+)?)"
    pattern = (r"^[ \t]*(?:\*\*)?\[Shot\s+\d+\][ \t]*" + clock +
               r"[ \t]*s?[ \t]*[–—-][ \t]*" + clock +
               r"[ \t]*s?[ \t]*(?:\*\*)?")
    matches = list(re.finditer(pattern, text, re.I | re.M))
    result = []
    for i, m in enumerate(matches):
        a = _clip_time_value(m.group(1), clip_duration_s=5.0)
        b = _clip_time_value(m.group(2), clip_duration_s=5.0)
        if a is None or b is None or not (0 <= a < b <= 5.25):
            continue
        block = text[m.end(): matches[i+1].start() if i+1 < len(matches) else len(text)]
        result.append((max(0., a), min(5., b), block))
    return result


def _frames_for_clip_window_strict(frames: list[Path], start_s: float, end_s: float) -> list[Path]:
    """Never silently swap a character's shot for out-of-window observer frames."""
    times = [(_observer_frame_timestamp(f), f) for f in frames]
    valid = [(t, f) for t, f in times if t is not None]
    if not valid:
        return []
    base = min(t for t, _ in valid)
    inside = [(t-base, f) for t, f in valid
              if start_s-0.15 <= t-base <= end_s+0.15]
    if not inside:
        return []
    mid = (start_s+end_s)/2
    ranked = sorted(inside, key=lambda x: abs(x[0]-mid))
    chosen = [f for _, f in ranked[:3]]
    return sorted(chosen, key=lambda f: _observer_frame_timestamp(f) or 0)


def world_ambient_mini_pitch(content_bible: dict[str, Any], active_refs: list[dict[str, Any]]) -> str:
    """Compact universe cue in EVERY H3 clip, subordinated to local Picture authority.

    Preserve the existing reference selection and the exact H3 context budget.
    The Content Director's world is primary; fallback is existing project context,
    never a fabricated place or a guessed time period.
    """
    world = next((str(content_bible.get(k) or '').strip() for k in
                  ('world_environment', 'art_direction', 'user_style_direction', 'concept', 'user_prompt')
                  if str(content_bible.get(k) or '').strip()), '')
    world = ' '.join(world.split())
    if not world:
        world = 'Univers non précisé par le Content Director.'
    first = world[:320].rsplit('. ', 1)[0] if len(world)>320 else world
    return ('**World ambience — secondary context (not a Picture reference):** '
            + first.strip() +
            ' This describes the broader universe/era only. The current scene, shot '
            'and any canonical local environment Picture have priority for specific '
            'architecture, objects and visible details.')


def ensure_world_ambient_in_h3_prompt(h3_prompt: str, world_block: str) -> str:
    """Enforce the same runtime-owned world cue before ANY renderer route.

    RAW retakes, manual Clip Director edits and resumed approvals can rebuild a
    complete H3 prompt without passing through the initial assembly. Do not
    rewrite the creator's edited text; prepend only if a world block is absent.
    """
    if not world_block or re.search(r'(?im)^\s*(?:\*\*\s*)?World\s+ambience\b', h3_prompt):
        return h3_prompt
    return world_block.strip() + '\n\n' + h3_prompt.lstrip()


def select_character_appearance_frames(
    vision_model: str,
    character: str,
    frames: list[Path],
    scene: dict[str, Any],
    plan: dict[str, Any],
    h3_prompt: str = "",
    character_context: str = "",
    candidate_characters: list[str] | None = None,
    canonical_frame: Path | None = None,
) -> list[Path]:
    """Route Appearance observation to frames that actually belong to ``character``.

    This is intentionally CHARACTER-ONLY.  Environment/decor reference selection continues to
    receive the original full observer strip unchanged.

    The final H3 shot schedule narrows the candidates; the VLM verifies real
    identity from pixels. End-of-clip Pixel Identity is deliberately NOT an
    authority over earlier frames. If an identified shot has no observer sample,
    retain the old reference rather than sample a different person's shot.

    We deliberately do NOT send the same ambiguous multi-person frame set to every character.
    """
    if not frames:
        return []

    names: list[str] = []
    seen: set[str] = set()
    for name in (candidate_characters or character_names_for_clip(scene, plan, None) or [character]):
        k = norm(name)
        if k and k not in seen:
            seen.add(k)
            names.append(name)
    if not any(norm(n) == norm(character) for n in names):
        names.append(character)

    # The FINAL Clip Director H3 prompt defines the intended shot windows.
    # Planning narrows WHAT the VLM sees, but does not prove WHO pixels show.
    # Never accept a time window without a visual identity confirmation.
    shots = _h3_prompt_shot_windows(h3_prompt)
    if not shots:
        shots = [
            (float(x.get("start_seconds_in_clip") or 0),
             float(x.get("end_seconds_in_clip") or 0),
             str(x.get("view") or "") + "\n" + str(x.get("action") or ""))
            for x in (plan.get("shots") or []) if isinstance(x, dict)
        ]
    # The shot header identifies the subject; dialogue lines may name other
    # actors without showing them. Equal two-shots are never a safe appearance
    # source even when the named target is one of the speakers.
    def is_primary_shot(text: str) -> bool:
        lead = re.split(r'(?im)^\s*(?:[A-Za-zÀ-ÿ ]{2,35}\s*:\s*$|Using specifically)',text, maxsplit=1)[0][:430]
        lead_ascii = _ascii_text(lead).casefold()
        if re.search(r'\b(two.shot|deux.personnages|plan\s+à\s+deux|plan\s+moyen\s*\(two)', lead_ascii):
            return False
        if not _text_mentions_character(lead,character,names):
            return False
        # A close-up on the other named person takes priority over a target
        # who is only looked at or mentioned in the shot.
        closeup = re.search(r'(?:gros\s+plan|close.up|macro|portrait)(?:\s+macro)?\s+(?:sur|of|de|on)\s+(?:le\s+visage\s+de\s+)?([\w-]+)',lead_ascii)
        if closeup:
            subject = closeup.group(1)
            if subject not in character_match_aliases(character,names):
                return False
        return True
    windows = [(a, b) for a, b, block in shots if b>a and is_primary_shot(block)]
    if shots and not windows:
        # Never replace Matt from a Brad close-up or an ambiguous two-shot.
        return []
    if windows:
        pool = []
        for a, b in windows:
            for f in _frames_for_clip_window_strict(frames, a, b):
                if f not in pool:
                    pool.append(f)
        if not pool:
            return []
        frames = pool
    # If no authored window mentions the target at all, a pixel-only VLM route
    # over the strip may still find an unplanned but real appearance.

    # Otherwise ask the VLM only to ROUTE images, never to describe wardrobe.
    # Maximum three images TOTAL, including one authoritative canonical photo.
    # A named canonical identity must be visually available. Do not downgrade a
    # missing/corrupt canonical image to a text-only multi-person guess.
    if canonical_frame is not None and not Path(canonical_frame).is_file():
        return []
    canonical_ok = bool(canonical_frame and Path(canonical_frame).is_file())
    capacity = 2 if canonical_ok else 3
    inds = sorted(set(round((len(frames)-1)*i/max(1,capacity-1)) for i in range(capacity))) if len(frames)>capacity else list(range(len(frames)))
    imgs = ([Path(canonical_frame)] if canonical_ok else []) + [frames[i] for i in inds]
    system = """You are a TARGET CHARACTER FRAME ROUTER for continuity reference capture. Your job is NOT to describe clothing and NOT to recognize a celebrity. Select only candidate images in which the requested TARGET CHARACTER is individually unambiguous and its body/wardrobe can be read without borrowing visual traits from another person.

Use the exact film plan, H3 prompt and character bible only to map visible people to names by action, position and stable identity context. Pixels remain authority. Prefer, in order: TARGET alone; TARGET clearly dominant/foreground; TARGET clearly separable by unique action/position while another person is minor/background. Reject equal two-shots, overlapping bodies, ambiguous people, back-only tiny figures, or any frame where you could plausibly describe the other person's hair/clothes as TARGET's.

Return 1 to 3 useful image numbers, best first. If none is safe, return an empty list. JSON only: {"usable_image_numbers":[1],"confidence":"HIGH|MEDIUM|LOW","reason":"short"}."""
    user = (
        f"TARGET CHARACTER: {character}\n"
        + ("IMAGE 1 = CANONICAL TARGET IDENTITY, not a candidate for appearance capture. Compare the following rendered frames to it; NEVER select Image 1.\n" if canonical_ok else "")
        + f"OTHER POSSIBLE CHARACTERS: {json.dumps([n for n in names if norm(n) != norm(character)], ensure_ascii=False)}\n"
        f"CHARACTER BIBLE / IDENTITY CONTEXT: {str(character_context or '').strip()[:5000] or '[none]'}\n"
        f"SCENE: {json.dumps(scene_context_payload(scene), ensure_ascii=False)}\n"
        f"CURRENT PLAN: {json.dumps(plan_context_payload(plan), ensure_ascii=False)}\n"
        f"EXACT H3 PROMPT THAT PRODUCED THESE PIXELS:\n{str(h3_prompt or '').strip()[:6500]}\n"
        f"There are {len(imgs)-(1 if canonical_ok else 0)} chronological rendered candidate frames. Route frames for TARGET only."
    )
    try:
        raw = rt.ollama_json_images(
            vision_model, system, user, imgs,
            cpu_safe=rt.DIRECTOR_CPU_SAFE, timeout=180,
            label=f"Appearance Frame Route {character}",
        )
        confidence = str(raw.get("confidence") or "LOW").upper() if isinstance(raw, dict) else "LOW"
        incoming = raw.get("usable_image_numbers") if isinstance(raw, dict) else []
        selected: list[Path] = []
        # Cross-character appearance contamination is worse than missing an update.
        # Only a HIGH-confidence visual route is allowed to create/update a ref.
        if confidence == "HIGH" and isinstance(incoming, list):
            for item in incoming:
                try:
                    slot = int(item)
                except Exception:
                    continue
                if (2 if canonical_ok else 1) <= slot <= len(imgs):
                    f = frames[inds[slot - 1 - (1 if canonical_ok else 0)]]
                    if f not in selected:
                        selected.append(f)
                if len(selected) >= 3:
                    break
        if selected:
            return selected
    except Exception:
        pass

    # A declared solo character is still not visual proof. Keep the previous
    # appearance rather than storing a potentially unrelated frame.
    return []


def assess_character_appearance_visual(
    vision_model: str,
    character: str,
    appearance_state: str,
    frames: list[Path],
    scene: dict[str, Any],
    plan: dict[str, Any],
    h3_prompt: str = "",
    character_context: str = "",
) -> dict[str, Any]:
    """VLM gate: confirm the LLM-requested appearance state is ACTUALLY visible in H3 output."""
    if not frames or not appearance_state:
        return {"accept": False, "quality": "REJECT", "reason": "no frames/state"}
    if len(frames) <= 3:
        inds = list(range(len(frames)))
    else:
        inds = sorted(set(round((len(frames) - 1) * i / 2) for i in range(3)))
    imgs = [frames[i] for i in inds]
    system = """You are a VISUAL CHARACTER APPEARANCE CONFIRMATION GATE. A text-only continuity gate has already decided that the H3 prompt intended a new persistent appearance state. Your only job is to verify that the TARGET CHARACTER actually and clearly shows that EXACT state in the rendered frames, and choose the best continuity frame. CHARACTER BIBLE and H3 prompt context are identity-disambiguation aids only: pixels remain authoritative for current wardrobe/state. Set identity_match=true ONLY when the visible person's stable identity traits/action-position are actually compatible with TARGET. Reject if the state is missing, ambiguous, mostly hidden, belongs to another person, or cannot be verified visually. Canonical identity is handled by a separate reference, so prioritize clear evidence of wardrobe/injury/dirt/wetness/armor/disguise/hairstyle while still requiring the target person to be unambiguous. Return JSON only: {"accept":true,"identity_match":true,"best_image_number":1,"quality":"GOOD|EXCELLENT|REJECT","visibility":"CLEAR|PARTIAL|UNCLEAR","reason":"short"}."""
    user = (
        f"TARGET CHARACTER: {character}\n"
        f"CHARACTER BIBLE / IDENTITY CONTEXT: {str(character_context or '').strip()[:5000] or '[none]'}\n"
        f"INTENDED NEW APPEARANCE STATE: {appearance_state}\n"
        f"SCENE: {json.dumps(scene_context_payload(scene), ensure_ascii=False)}\n"
        f"CURRENT PLAN: {json.dumps(plan_context_payload(plan), ensure_ascii=False)}\n"
        f"H3 PROMPT THAT PRODUCED THESE FRAMES: {str(h3_prompt or '').strip()[:6000]}\n"
        f"There are {len(imgs)} chronological rendered candidate frames. Confirm the state or reject."
    )
    try:
        raw = rt.ollama_json_images(vision_model, system, user, imgs, cpu_safe=rt.DIRECTOR_CPU_SAFE, timeout=180, label=f"Appearance Visual {character}")
    except Exception as exc:
        return {"accept": False, "quality": "REJECT", "reason": str(exc)}
    accept = raw.get("accept", False)
    if isinstance(accept, str):
        accept = accept.strip().lower() in {"1", "true", "yes", "oui"}
    quality = str(raw.get("quality") or "REJECT").upper()
    visibility = str(raw.get("visibility") or "UNCLEAR").upper()
    try:
        best = max(1, min(int(raw.get("best_image_number") or 1), len(imgs)))
    except Exception:
        best = 1
    identity_match = raw.get("identity_match", False)
    if isinstance(identity_match, str):
        identity_match = identity_match.strip().lower() in {"1", "true", "yes", "oui"}
    ok = bool(accept and identity_match and quality in {"GOOD", "EXCELLENT"} and visibility == "CLEAR")
    return {
        "accept": ok, "quality": quality, "visibility": visibility,
        "reason": str(raw.get("reason") or ""), "frame_index": inds[best - 1],
    }



def assess_character_appearance_observed(
    vision_model: str,
    character: str,
    previous_state: str,
    frames: list[Path],
    scene: dict[str, Any],
    plan: dict[str, Any],
    h3_prompt: str = "",
    character_context: str = "",
) -> dict[str, Any]:
    """Small VLM observer for the actual rendered appearance.

    With no previous state it captures the first clear on-film wardrobe/temporary appearance baseline.
    With a previous state it only accepts a clear MATERIAL change (e.g. shirtless -> T-shirt, new
    jacket/armor, injury, dirt/wetness, temporary hair state). Pose, expression, lighting and camera
    changes never count. This lets H3's real rendered wardrobe become the continuity state without
    confusing a blurry/ambiguous frame with a deliberate change.
    """
    if not frames:
        return {"capture": False, "quality": "REJECT", "reason": "no frames"}
    if len(frames) <= 3:
        inds = list(range(len(frames)))
    else:
        inds = sorted(set(round((len(frames) - 1) * i / 2) for i in range(3)))
    imgs = [frames[i] for i in inds]
    baseline = not bool(str(previous_state or "").strip())
    if baseline:
        task = (
            "This is the first clear on-film appearance baseline. Capture only if the target is "
            "unambiguous and its material appearance is clearly visible. Describe clothing/wardrobe, "
            "exposed torso if relevant, worn gear/accessories, and any obvious temporary injury/dirt/wetness/"
            "hairstyle state. Ignore pose, expression, lighting and camera angle."
        )
    else:
        task = (
            "Compare the rendered target to PREVIOUS APPEARANCE. Capture only if there is a CLEAR MATERIAL "
            "visible change that should persist for continuity, such as different clothing/outerwear, "
            "shirtless versus clothed, armor/worn gear, injury, dirt/wetness, disguise or temporary hairstyle. "
            "Reject if it is the same state, uncertain, hidden, caused only by angle/lighting, or belongs to another person. "
            "If several people are visible and the TARGET cannot be distinguished unambiguously, REJECT rather than copying another person's wardrobe, hair or temporary state."
        )
    system = f"""You are a CONSERVATIVE RENDERED CHARACTER APPEARANCE OBSERVER. The target label is supplied by the film plan; do not perform celebrity recognition. {task} CHARACTER BIBLE and the exact H3 prompt are identity-disambiguation aids only: use them to decide which visible person is the TARGET, but NEVER copy wardrobe/hair/current-state details from text when the pixels do not clearly show them. The rendered pixels are authoritative for current appearance. Set identity_match=true ONLY when the visible person's stable identity traits/action-position are actually compatible with TARGET; if another candidate person fits better or identity is ambiguous, set false and reject. Choose the best continuity frame. Return JSON only: {{"capture":true,"identity_match":true,"best_image_number":1,"quality":"GOOD|EXCELLENT|REJECT","visibility":"CLEAR|PARTIAL|UNCLEAR","appearance_state":"short concrete visible state","change_type":"baseline|wardrobe|gear|injury|surface_state|hair|other","reason":"short"}}."""
    user = (
        f"TARGET CHARACTER: {character}\n"
        f"CHARACTER BIBLE / IDENTITY CONTEXT: {str(character_context or '').strip()[:5000] or '[none]'}\n"
        f"PREVIOUS APPEARANCE: {previous_state or '[none — first baseline]'}\n"
        f"SCENE: {json.dumps(scene_context_payload(scene), ensure_ascii=False)}\n"
        f"CURRENT PLAN: {json.dumps(plan_context_payload(plan), ensure_ascii=False)}\n"
        f"H3 PROMPT THAT PRODUCED THESE FRAMES: {str(h3_prompt or '').strip()[:6000]}\n"
        f"There are {len(imgs)} chronological rendered candidate frames."
    )
    try:
        raw = rt.ollama_json_images(vision_model, system, user, imgs, cpu_safe=rt.DIRECTOR_CPU_SAFE, timeout=180, label=f"Appearance Observe {character}")
    except Exception as exc:
        return {"capture": False, "quality": "REJECT", "reason": str(exc)}
    capture = raw.get("capture", False)
    if isinstance(capture, str):
        capture = capture.strip().lower() in {"1", "true", "yes", "oui"}
    # Require an explicit visual identity decision before updating the RefBank.
    # If a VLM omits this field, the safe outcome is to keep the previous image.
    identity_match = raw.get("identity_match", False)
    if isinstance(identity_match, str):
        identity_match = identity_match.strip().lower() in {"1", "true", "yes", "oui"}
    quality = str(raw.get("quality") or "REJECT").upper()
    visibility = str(raw.get("visibility") or "UNCLEAR").upper()
    state = str(raw.get("appearance_state") or "").strip()
    try:
        best = max(1, min(int(raw.get("best_image_number") or 1), len(imgs)))
    except Exception:
        best = 1
    ok = bool(capture and identity_match and state and quality in {"GOOD", "EXCELLENT"} and visibility == "CLEAR")
    if previous_state and appearance_state_key(state) == appearance_state_key(previous_state):
        ok = False
    return {
        "capture": ok, "quality": quality, "visibility": visibility, "appearance_state": state if ok else "",
        "change_type": str(raw.get("change_type") or ("baseline" if baseline else "other")),
        "reason": str(raw.get("reason") or ""), "frame_index": inds[best - 1],
    }


def assess_extra_subject_reference_simple(vision_model: str, candidate_terms: list[tuple[str, str]], frames: list[Path], scene: dict[str, Any], plan: dict[str, Any]) -> dict[str, Any]:
    """Optionally recover one recurring visual subject omitted from Scene Director `Personnages`.

    Candidate terms come only from words that recur across multiple Scene Director descriptions.
    The VLM is deliberately conservative: abstract effects, crowds, scenery and ordinary props must be rejected.
    """
    if not frames or not candidate_terms:
        return {"accept": False, "reason": "no candidates"}
    if len(frames) <= 3:
        inds = list(range(len(frames)))
    else:
        inds = sorted(set(round((len(frames) - 1) * i / 2) for i in range(3)))
    imgs = [frames[i] for i in inds]
    labels = [display for _, display in candidate_terms[:8]]
    system = """You are a CONSERVATIVE RECURRING VISUAL SUBJECT REFERENCE GATE. The candidate labels were copied from recurring words in the Scene Director scene descriptions. Select ONE candidate only if the rendered clip clearly shows a visually distinctive reusable subject whose stable appearance matters across clips: for example a creature, alien entity, robot, vehicle, distinctive machine, artifact or other persistent visual identity. Reject crowds, generic humans already covered by Characters, architecture/environment, screens, light, code, signals, explosions, weather, generic furniture/props, or abstract visual effects. Never invent a new label: label must be copied exactly from CANDIDATE LABELS. If no candidate is clearly suitable, reject. Return JSON only: {"accept":true,"label":"exact candidate","best_image_number":1,"quality":"GOOD|EXCELLENT|REJECT","reason":"short"}."""
    user = (
        f"CANDIDATE LABELS: {json.dumps(labels, ensure_ascii=False)}\n"
        f"DECLARED CHARACTERS: {scene.get('characters','')}\n"
        f"SCENE DESCRIPTION: {scene.get('description','')}\n"
        f"CURRENT 5-SECOND PLAN: {json.dumps(plan, ensure_ascii=False)}\n"
        f"There are {len(imgs)} chronological rendered images. Select only a strong reusable omitted visual subject, or reject."
    )
    try:
        raw = rt.ollama_json_images(vision_model, system, user, imgs, cpu_safe=rt.DIRECTOR_CPU_SAFE, timeout=180, label="Extra Subject Ref Quality")
    except Exception as exc:
        return {"accept": False, "quality": "REJECT", "reason": str(exc)}
    accept = raw.get("accept", False)
    if isinstance(accept, str):
        accept = accept.strip().lower() in {"1", "true", "yes", "oui"}
    label = str(raw.get("label") or "").strip()
    by_display = {display.casefold(): (term, display) for term, display in candidate_terms}
    chosen = by_display.get(label.casefold())
    quality = str(raw.get("quality") or "REJECT").upper()
    if not accept or chosen is None or quality not in {"GOOD", "EXCELLENT"}:
        return {"accept": False, "quality": "REJECT", "reason": str(raw.get("reason") or "not a stable visual subject")}
    try:
        best = max(1, min(int(raw.get("best_image_number") or 1), len(imgs)))
    except Exception:
        best = 1
    return {
        "accept": True,
        "quality": quality,
        "reason": str(raw.get("reason") or ""),
        "label": chosen[1],
        "match_term": chosen[0],
        "frame_index": inds[best - 1],
    }



def update_reference_bank(vision_model: str, static_refs: list[dict[str, Any]], bank: dict[str, Any], frames: list[Path], scene: dict[str, Any], plan: dict[str, Any], comfy: Path, project: str, clip_number: int, known_characters: list[str] | None = None, recurring_subject_terms: dict[str, str] | None = None, h3_prompt: str = "", video_path: Path | None = None, visible_character_names: list[str] | None = None, persistent_character_names: list[str] | None = None, character_context: str = "", continuity_objects: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    bank = copy.deepcopy(bank or {"characters": {}, "character_appearance": {}, "subjects": {}, "decor": {}, "history": []})
    bank.setdefault("characters", {})
    bank.setdefault("character_appearance", {})
    bank.setdefault("subjects", {})
    bank.setdefault("objects", {})
    bank.setdefault("spatial", {})
    bank.setdefault("subject_attempts", {})
    bank.setdefault("decor", {})
    bank.setdefault("global_environment", None)
    bank.setdefault("voices", {})
    bank.setdefault("history", [])
    static_chars = [r for r in static_refs if str(r.get("kind")) == "character"]
    static_decor = [r for r in static_refs if str(r.get("kind")) == "decor"]
    static_subjects = [r for r in static_refs if str(r.get("kind")) == "subject"]

    current_names = character_names_for_plan(scene, plan, known_characters)
    # Pixel Identity describes the LAST frames for the next-clip raccord.
    # It must not veto references for characters visible earlier in this clip.
    # Each appearance has its own time-targeted VLM identity check below.
    canonical_names = []
    for _name in current_names:
        _matched = [r for r in static_chars if ref_matches_name(r, _name)]
        if any(str(r.get("role") or "") == "canonical_identity" for r in _matched):
            canonical_names.append(_name)

    # V5.6: first clear appearance is established visually before the semantic change gate is used.
    # The text Appearance LLM only evaluates characters that already have a rendered-film baseline.
    appearance_intent_names = [
        n for n in canonical_names
        if any(isinstance(r, dict) and ref_matches_name(r, n) and str(r.get("appearance_state") or "").strip()
               for r in (bank.get("character_appearance") or {}).values())
    ]
    appearance_intents = assess_character_appearance_intent(
        vision_model, appearance_intent_names, bank, scene, plan, h3_prompt
    ) if appearance_intent_names else {}

    for name in current_names:
        matched_static = [r for r in static_chars if ref_matches_name(r, name)]
        canonical = [r for r in matched_static if str(r.get("role") or "") == "canonical_identity"]

        if canonical:
            # CHARACTER-ONLY routing: never let Matt and Nyx inspect the same ambiguous
            # multi-person frame strip. Decor/environment capture below still receives the
            # untouched original `frames` list.
            target_frames = select_character_appearance_frames(
                vision_model, name, frames, scene, plan,
                h3_prompt=h3_prompt, character_context=character_context,
                candidate_characters=current_names,
                canonical_frame=Path(str(canonical[0].get('path') or '').split(' [',1)[0]),
            )
            bank["history"].append({
                "clip": clip_number, "kind": "character_appearance_frame_route",
                "name": name, "selected_frames": [str(Path(f).name) for f in target_frames],
            })
            if not target_frames:
                print(f"    Apparence ciblée : {name} -> aucune frame individuelle sûre, ancienne ref conservée")
                continue

            previous = next((r for r in bank["character_appearance"].values() if isinstance(r, dict) and ref_matches_name(r, name)), None)
            previous_state = str((previous or {}).get("appearance_state") or "").strip()
            previous_key = str((previous or {}).get("appearance_state_key") or "")

            # V5.6: first clear rendered view becomes the on-film appearance baseline.
            if not previous_state:
                observed = assess_character_appearance_observed(
                    vision_model, name, "", target_frames, scene, plan,
                    h3_prompt=h3_prompt, character_context=character_context,
                )
                bank["history"].append({"clip": clip_number, "kind": "character_appearance_baseline", "name": name, "quality": observed})
                if observed.get("capture"):
                    state = str(observed.get("appearance_state") or "").strip()
                    idx = int(observed["frame_index"])
                    ref = stage_dynamic_ref(comfy, project, target_frames[idx], clip_number, "character", name, video_path=video_path)
                    ref["reference_quality"] = observed
                    ref["role"] = "film_appearance"
                    ref["subject_key"] = str(canonical[0].get("subject_key") or f"canonical_character_{norm(name)}")
                    ref["appearance_state"] = state
                    ref["appearance_state_key"] = appearance_state_key(state)
                    ref["appearance_change_type"] = "baseline"
                    ref["strength"] = 0.80
                    bank["character_appearance"][name] = ref
                    print(f"    Ref apparence baseline : {name} | {state} | {observed.get('quality')}")
                else:
                    print(f"    Apparence baseline : {name} -> attente d'une vue claire")
                continue

            intent = appearance_intents.get(norm(name), {"capture": False, "appearance_state": "", "reason": "no semantic change"})
            bank["history"].append({"clip": clip_number, "kind": "character_appearance_intent", "name": name, "intent": intent})

            # First use the existing semantic intent gate for explicit/intentional changes.
            if intent.get("capture"):
                state = str(intent.get("appearance_state") or "").strip()
                state_key = appearance_state_key(state)
                if state_key and state_key != previous_key:
                    print(f"    Apparence LLM : {name} -> OUI | {state}")
                    q = assess_character_appearance_visual(
                        vision_model, name, state, target_frames, scene, plan,
                        h3_prompt=h3_prompt, character_context=character_context,
                    )
                    bank["history"].append({"clip": clip_number, "kind": "character_appearance_visual", "name": name, "state": state, "quality": q})
                    if q.get("accept"):
                        idx = int(q["frame_index"])
                        ref = stage_dynamic_ref(comfy, project, target_frames[idx], clip_number, "character", name, video_path=video_path)
                        ref["reference_quality"] = q
                        ref["role"] = "film_appearance"
                        ref["subject_key"] = str(canonical[0].get("subject_key") or f"canonical_character_{norm(name)}")
                        ref["appearance_state"] = state
                        ref["appearance_state_key"] = state_key
                        ref["appearance_change_type"] = str(intent.get("change_type") or "")
                        ref["strength"] = 0.80
                        bank["character_appearance"][name] = ref
                        print(f"    Ref apparence capturée : {name} | {state} | {q.get('quality')}")
                        continue
                    print(f"    Ref apparence non capturée : {name} | changement non confirmé visuellement")

            # If the prompt did not announce a change, still compare the ACTUAL rendered wardrobe/state.
            # This catches clear H3 changes such as shirtless -> T-shirt without locking angle/light noise.
            observed = assess_character_appearance_observed(
                vision_model, name, previous_state, target_frames, scene, plan,
                h3_prompt=h3_prompt, character_context=character_context,
            )
            bank["history"].append({"clip": clip_number, "kind": "character_appearance_observed_change", "name": name, "previous": previous_state, "quality": observed})
            if observed.get("capture"):
                state = str(observed.get("appearance_state") or "").strip()
                state_key = appearance_state_key(state)
                if state_key and state_key != previous_key:
                    idx = int(observed["frame_index"])
                    ref = stage_dynamic_ref(comfy, project, target_frames[idx], clip_number, "character", name, video_path=video_path)
                    ref["reference_quality"] = observed
                    ref["role"] = "film_appearance"
                    ref["subject_key"] = str(canonical[0].get("subject_key") or f"canonical_character_{norm(name)}")
                    ref["appearance_state"] = state
                    ref["appearance_state_key"] = state_key
                    ref["appearance_change_type"] = str(observed.get("change_type") or "observed")
                    ref["strength"] = 0.80
                    bank["character_appearance"][name] = ref
                    print(f"    Ref apparence mise à jour : {name} | {state} | {observed.get('quality')}")
                    continue
            print(f"    Apparence LLM/VLM : {name} -> pas de changement matériel clair")
            continue

        # Legacy/user static refs without the Studio canonical role keep V4.4 behavior: they are
        # authoritative and we do not invent an additional appearance layer for them.
        if matched_static:
            continue

        # No supplied identity at all: only create a persistent dynamic identity for a character
        # that the film has promoted as durable (preproduction main/secondary, or safe legacy principal).
        # Scene-local passers-by / vendors / drivers / crowd roles are intentionally free to exist
        # without polluting the persistent RefBank.
        if persistent_character_names is not None:
            persistent_norms = {norm(x) for x in persistent_character_names if norm(x)}
            if norm(name) not in persistent_norms:
                bank["history"].append({"clip": clip_number, "kind": "incidental_character_no_persist", "name": name})
                print(f"    Ref personnage ponctuel : {name} -> pas de capture persistante")
                continue

        # Once a good identity frame already exists, do not re-run the VLM every clip.
        if any(ref_matches_name(r, name) for r in bank["characters"].values() if isinstance(r, dict)):
            continue
        q = assess_character_reference_simple(vision_model, name, frames, plan, scene)
        bank["history"].append({"clip": clip_number, "kind": "character", "name": name, "quality": q})
        if q.get("accept"):
            idx = int(q["frame_index"])
            ref = stage_dynamic_ref(comfy, project, frames[idx], clip_number, "character", name, video_path=video_path)
            ref["reference_quality"] = q
            bank["characters"][name] = ref
            print(f"    Ref personnage capturée : {name} | {q.get('quality')} {q.get('face_view')}")
        else:
            print(f"    Ref personnage différée : {name} | {q.get('quality','REJECT')} | {q.get('reason','')}")

    # V4.8: no automatic dynamic visual-subject capture from recurring words.
    # Explicit/canonical Studio subjects remain available through choose_active_refs().

    location = str(scene.get("location") or "").strip()
    # Keep the previous proven decor system. Only a BROAD/generic static match may allow a
    # more precise rendered sub-location ref (e.g. terrace inside a generic megacity).
    static_scores = [decor_match_score(str(r.get("subject_name") or ""), location) for r in static_decor] if location else []
    strong_static_decor = max(static_scores, default=0) >= 850
    allow_film_decor_capture = not strong_static_decor
    if location and allow_film_decor_capture:
        strong_existing = []
        for key, r in bank["decor"].items():
            if not isinstance(r, dict):
                continue
            score = decor_match_score(str(r.get("subject_name") or key), location)
            if score >= 850:
                strong_existing.append((score, int(r.get("captured_clip") or 0), key))
        if strong_existing:
            strong_existing.sort(reverse=True)
            existing_key = strong_existing[0][2]
            bank["history"].append({"clip": clip_number, "kind": "decor_alias", "name": location, "reused": existing_key})
            print(f"    Ref décor réutilisée : {location} -> {existing_key}")
        elif not any(norm(k) == norm(location) for k in bank["decor"].keys()):
            q = assess_environment_reference_quality(vision_model, location, frames, plan, h3_prompt=h3_prompt)
            bank["history"].append({"clip": clip_number, "kind": "decor", "name": location, "quality": q})
            if q.get("accept"):
                idx = int(q["frame_index"])
                ref = stage_dynamic_ref(comfy, project, frames[idx], clip_number, "decor", location, video_path=video_path)
                ref["reference_quality"] = q
                bank["decor"][location] = ref
                print(f"    Ref décor capturée : {location} | {q.get('quality')}")
            else:
                print(f"    Ref décor différée : {location} | {q.get('quality','REJECT')} | {q.get('reason','')}")

    # Up to TWO scene-local important dynamic objects.  The text LLM already decided WHY
    # continuity matters and WHEN the object should be visible; the VLM now inspects only
    # <=3 rendered frames from that exact window and confirms the real object before capture.
    scene_no = int(scene.get("scene") or 0)
    existing_scene_objects = [
        r for r in bank["objects"].values()
        if isinstance(r, dict) and int(r.get("source_scene") or -1) == scene_no
    ]
    remaining_slots = max(0, 2 - len(existing_scene_objects))
    for obj in (continuity_objects or []):
        if not isinstance(obj, dict):
            continue
        label = str(obj.get("label") or "").strip()
        nums: list[int] = []
        for x in obj.get("future_plan_numbers") or []:
            try:
                n = int(x)
            except Exception:
                continue
            if n > int(plan.get("plan") or 0) and n not in nums:
                nums.append(n)
        if not label or not nums:
            continue

        # If this exact scene-local physical object was already captured, extend its
        # plan lifetime instead of recapturing it. Importance decides whether an object
        # enters the RefBank; once captured, the same object reference must remain active
        # on every later plan where that same object is explicitly visible/reused.
        existing_match = next((
            r for r in existing_scene_objects
            if norm(label) == norm(str(r.get("subject_name") or ""))
        ), None)
        if existing_match is not None:
            active: list[int] = []
            for x in existing_match.get("active_plan_numbers") or []:
                try:
                    n = int(x)
                except Exception:
                    continue
                if n not in active:
                    active.append(n)
            merged = sorted(set(active + nums))
            if merged != sorted(set(active)):
                existing_match["active_plan_numbers"] = merged
                existing_match["last_extended_clip"] = clip_number
                bank["history"].append({
                    "clip": clip_number,
                    "kind": "object_lifetime_extend",
                    "name": str(existing_match.get("subject_name") or label),
                    "active_plan_numbers": merged,
                })
                print(f"    Ref objet continuité prolongée : {existing_match.get('subject_name') or label} -> plans {merged}")
            continue

        if remaining_slots <= 0:
            continue
        key = f"scene_{scene_no}_{norm(label) or clip_number}"
        qobj = verify_continuity_object_reference(vision_model, obj, frames, plan, h3_prompt)
        if not qobj.get("accept"):
            print(f"    Ref objet continuité différée : {label} | {qobj.get('reason','pas assez clair')}")
            continue
        idx = int(qobj.get("frame_index") or 0)
        if not (0 <= idx < len(frames)):
            continue
        ref = stage_dynamic_ref(comfy, project, frames[idx], clip_number, "object", label, video_path=video_path)
        ref["reference_quality"] = {"quality": str(qobj.get("quality") or "GOOD"), "source": "targeted_object_window_vlm"}
        ref["role"] = "film_object"
        ref["source_scene"] = scene_no
        ref["active_plan_numbers"] = nums
        ref["strength"] = 0.65
        ref["object_visibility_window"] = [float(obj.get("start_s") or 0.0), float(obj.get("end_s") or 0.0)]
        bank["objects"][key] = ref
        existing_scene_objects.append(ref)
        remaining_slots = max(0, remaining_slots - 1)
        print(f"    Ref objet continuité capturée : {label} | fenêtre {obj.get('start_s',0):.2f}-{obj.get('end_s',0):.2f}s | plans suivants {nums}")

    bank["history"] = bank["history"][-240:]
    return bank


def _graph_node_by_title(graph: dict[str, Any], ctype: str, needle: str, required: bool = True) -> tuple[str, dict[str, Any]] | tuple[None, None]:
    needle_l = needle.lower()
    for nid, node in graph.items():
        title = str((node.get("_meta") or {}).get("title") or "")
        if node.get("class_type") == ctype and needle_l in title.lower():
            return nid, node
    if required:
        raise RuntimeError(f"Node {ctype} / {needle} introuvable dans le workflow H3 API CLEAN.")
    return None, None


def _saved_video_from_record(
    record: dict[str, Any], save_id: str | None, label: str, expected_fragment: str = "",
    comfy: Path | None = None, not_before: float = 0.0,
) -> str:
    outputs = record.get("outputs") or {}
    source = outputs.get(str(save_id), {}) if save_id is not None else {}
    vids = list(rt.iter_saved_files(source))
    if vids:
        return rt.annotated_name(vids[-1])

    # Multi-output ComfyUI versions can place SaveVideo metadata under another output
    # entry. Recover the exact requested artifact by its unique runtime filename prefix
    # instead of assuming a stable SaveVideo history node id.
    all_vids = list(rt.iter_saved_files(outputs))
    frag = str(expected_fragment or "").replace("\\", "/").lower()
    if frag:
        matches = []
        for item in all_vids:
            filename = str(item.get("filename") or "")
            subfolder = str(item.get("subfolder") or "")
            joined = (subfolder.rstrip("/") + "/" + filename).strip("/").lower()
            if frag in joined or frag in filename.lower():
                matches.append(item)
        if matches:
            return rt.annotated_name(matches[-1])

    # Last safety net: SaveVideo may have written the file successfully while omitting
    # file metadata from /history. Search only files created by this render so an old
    # clip can never be mistaken for the current one.
    if comfy is not None and frag:
        root = comfy / "output"
        disk_matches = []
        if root.is_dir():
            for path in root.rglob("*"):
                if not path.is_file() or path.suffix.lower() not in rt.VIDEO_EXTS:
                    continue
                rel = path.relative_to(root).as_posix().lower()
                if frag not in rel and frag not in path.name.lower():
                    continue
                try:
                    mtime = path.stat().st_mtime
                except OSError:
                    continue
                if not_before and mtime < (not_before - 5.0):
                    continue
                disk_matches.append((mtime, path))
        if disk_matches:
            path = max(disk_matches, key=lambda x: x[0])[1]
            rel = path.relative_to(root)
            item = {
                "filename": path.name,
                "subfolder": rel.parent.as_posix() if rel.parent.as_posix() != "." else "",
                "type": "output",
            }
            return rt.annotated_name(item)

    ids = ", ".join(sorted(str(k) for k in outputs.keys()))
    raise RuntimeError(
        f"H3 API CLEAN: aucune vidéo trouvée pour {label} "
        f"(SaveVideo {save_id}; fragment={expected_fragment!r}; outputs={ids or 'aucun'})."
    )


def _stage_previous_final_for_load(comfy: Path, project: str, clip_number: int, annotated: str) -> str:
    src = rt.annotated_to_path(comfy, annotated)
    if not src.is_file():
        raise RuntimeError(f"FINAL précédent introuvable pour le join H3: {src}")
    rel = Path("h3film_api") / project / f"previous_final_for_clip_{clip_number:04d}{src.suffix.lower() or '.mp4'}"
    dst = comfy / "input" / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    return rel.as_posix()


def _set_loadvideo_file(node: dict[str, Any], relative_input_path: str) -> None:
    inputs = node.get("inputs") or {}
    # ComfyUI changed this scalar name between video-node revisions. Use the one
    # that gui_to_api discovered from this machine's live /object_info schema.
    for key in ("video", "file", "filename", "video_file"):
        if key in inputs:
            inputs[key] = relative_input_path
            return
    candidates = [
        k for k, v in inputs.items()
        if isinstance(v, str) and "upload" not in k.lower()
    ]
    if len(candidates) == 1:
        inputs[candidates[0]] = relative_input_path
        return
    raise RuntimeError(
        "Impossible de piloter LoadVideo pour le FINAL précédent; entrées disponibles: "
        + ", ".join(sorted(inputs))
    )


def _remove_cumulative_join_branch(graph: dict[str, Any]) -> None:
    # Kept for compatibility/debug helpers. The V4 renderer normally keeps the full graph
    # and prunes each automatic API phase to a SINGLE SaveVideo output.
    needles = (
        "CHARGE FINAL VISIBLE PRECEDENT",
        "QUEUE DU FINAL PRECEDENT",
        "FINAL VISIBLE PRECEDENT",
        "COUPE 22 FRAMES MC",
        "NOUVEAU CLIP VISIBLE",
        "H3STUDIO JOIN FIX",
        "CREE LE NOUVEAU CLIP",
        "FINAL NO-OOM",
        "FINAL CUMULATIF 1920",
    )
    drop = set()
    for nid, node in graph.items():
        title = str((node.get("_meta") or {}).get("title") or "").upper()
        if any(x in title for x in needles):
            drop.add(str(nid))
    for nid in drop:
        graph.pop(nid, None)
    for node in graph.values():
        for key, value in list((node.get("inputs") or {}).items()):
            if isinstance(value, list) and len(value) == 2 and str(value[0]) in drop:
                node["inputs"].pop(key, None)


def _upstream_only(graph: dict[str, Any], output_id: str) -> dict[str, Any]:
    """Return the exact dependency closure for ONE output node.

    ComfyUI normally supports many output nodes in one prompt, but this H3 graph contains
    stateful RAW/cache/refine bridge nodes. On the user's current build the RAW SaveVideo can
    complete and the prompt can be marked successful without the independent VISIBLE output
    being scheduled. V4 therefore submits one terminal output per API prompt. Node ids and
    scalar inputs stay identical between phases, so ComfyUI reuses the exact RAW latent/cache.
    """
    output_id = str(output_id)
    if output_id not in graph:
        raise RuntimeError(f"Sortie API {output_id} absente du graphe H3.")
    keep: set[str] = set()
    stack = [output_id]
    while stack:
        nid = str(stack.pop())
        if nid in keep:
            continue
        node = graph.get(nid)
        if node is None:
            raise RuntimeError(f"Dépendance H3 absente du graphe API: node {nid}")
        keep.add(nid)
        for value in (node.get("inputs") or {}).values():
            if isinstance(value, list) and len(value) == 2:
                src = str(value[0])
                # API links are [node_id, output_slot]. Scalar list-valued widgets are not
                # numeric node ids and therefore are ignored here.
                if src in graph:
                    stack.append(src)
    return {nid: copy.deepcopy(graph[nid]) for nid in graph if nid in keep}


def _stage_output_video_for_load(comfy: Path, project: str, clip_number: int,
                                 annotated: str, label: str) -> tuple[str, Path]:
    """Copy an output video into ComfyUI/input so core LoadVideo can consume it."""
    src = rt.annotated_to_path(comfy, annotated)
    if not src.is_file():
        raise RuntimeError(f"{label} introuvable pour LoadVideo H3: {src}")
    safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", label.lower()).strip("_") or "video"
    rel = Path("h3film_api") / project / f"{safe}_clip_{clip_number:04d}{src.suffix.lower() or '.mp4'}"
    dst = comfy / "input" / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
    return rel.as_posix(), dst


def _restore_validated_audio(comfy: Path, rendered: Path, *,
                             approved: Path | None = None,
                             preceding_final: Path | None = None,
                             current_visible: Path | None = None,
                             trim_motion_context: bool = False) -> Path:
    """Keep H3's HD *video*, but NEVER use H3's re-synthesized audio for a retouch.

    Single VISIBLE: stream-copy the exact approved MP4 audio packets.
    Cumulative FINAL: rebuild audio from the previously accepted FINAL and the
    current VISIBLE, trimming MC22 from the current audio like the video join.
    No sampler/workflow/input video is modified. Files are swapped only AFTER
    FFmpeg has finished; the H3 version is archived separately for diagnosis.
    """
    one_clip = approved is not None and preceding_final is None and current_visible is None
    joined = approved is None and preceding_final is not None and current_visible is not None
    if one_clip == joined:
        raise ValueError('Audio HD: fournir soit approved, soit preceding_final + current_visible')
    inputs = [Path(approved)] if one_clip else [Path(preceding_final), Path(current_visible)]
    if not rendered.is_file() or not all(x.is_file() for x in inputs):
        raise RuntimeError('Audio HD : fichier vidéo manquant ; sauvegarde inchangée')
    ffmpeg = rt.find_ffmpeg_exe(comfy)
    temp = rendered.with_name('.' + rendered.stem + '.audio_' + uuid.uuid4().hex[:10] + '.mp4')
    cmd = [ffmpeg, '-y', '-hide_banner', '-loglevel', 'error', '-i', str(rendered)]
    for inp in inputs:
        cmd += ['-i', str(inp)]
    if one_clip:
        # Bit-exact AAC/MP4 source audio: not decoded by H3, not re-encoded by us.
        cmd += ['-map', '0:v:0', '-map', '1:a:0', '-c:v', 'copy', '-c:a', 'copy']
    else:
        # ComfyUI slices MC22 from the current VIDEO; audio must start at the
        # same instant. Reconstruct only sound; copy the FINAL video bitstream.
        trim = rt.MOTION_FRAMES / rt.FPS if trim_motion_context else 0.0
        sound_filter = (
            '[1:a:0]asetpts=PTS-STARTPTS[p];'
            f'[2:a:0]atrim=start={trim:.9f},asetpts=PTS-STARTPTS[c];'
            '[p][c]concat=n=2:v=0:a=1[a];[a]apad[aout]'
        )
        cmd += ['-filter_complex', sound_filter, '-map', '0:v:0', '-map', '[aout]',
                '-c:v', 'copy', '-c:a', 'aac', '-b:a', '256k', '-shortest']
    cmd += ['-map_metadata', '0', '-movflags', '+faststart', str(temp)]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=180,
                              creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        if proc.returncode or not temp.is_file() or temp.stat().st_size < 1000:
            raise RuntimeError('Audio HD : fusion FFmpeg échouée ; la vidéo H3 reste intacte : '
                               + (proc.stderr or proc.stdout)[-1400:])
        # Retain a separate diagnostic copy of ComfyUI's original HD/FINAL;
        # never shadow normal "clip_XXXX_VISIBLE_1920*" glob discovery.
        archive = rendered.parent.parent / '_studio' / 'audio_before_restore'
        archive.mkdir(parents=True, exist_ok=True)
        original = archive / (rendered.stem + '__' + uuid.uuid4().hex[:10] + rendered.suffix)
        os.replace(rendered, original)
        try:
            os.replace(temp, rendered)
        except BaseException:
            os.replace(original, rendered)
            raise
        print(f'    AUDIO HD préservé : {"original MP4 (copie des paquets)" if one_clip else "FINAL + clip courant (MC22 aligné)"} ; vidéo H3 inchangée ; archive: {original.name}')
        return rendered
    finally:
        temp.unlink(missing_ok=True)


def _next_api_node_id(graph: dict[str, Any]) -> str:
    nums = [int(k) for k in graph if str(k).isdigit()]
    return str((max(nums) if nums else 1000) + 1000)


def _phase_assert_raw_hd(graph: dict[str, Any], hd_dimensions: tuple[int,int] = (1920, 1080)) -> None:
    types = [str(n.get("class_type")) for n in graph.values()]
    titles = [str((n.get("_meta") or {}).get("title") or "") for n in graph.values()]
    required = {
        "H3StudioImageToVideo",
        "H3RawCacheHold",
        "H3StoreRawLatentExact",
        "MinimaxH3LatentUpscaler3D",
        "H3RefineResizeConditioningDropVisualRefs",
        "H3V15ProjectHardLock",
        "H3V15ProjectStoreHDTail",
        "H3RawCacheRestore",
    }
    if not ({'H3RawSavedAutoGate','H3RawSavedStudioGate'} & set(types)):
        raise RuntimeError('Sécurité V10: aucune porte RAW->HD')
    if sum(x in {'H3RawSavedAutoGate','H3RawSavedStudioGate'} for x in types) != 1:
        raise RuntimeError('Sécurité V10: exactement une porte RAW->HD requise')
    missing = sorted(required - set(types))
    if missing:
        raise RuntimeError("Sécurité H3 V9: pipeline RAW->HD incomplet: " + ", ".join(missing))
    if "H3RefineResizeConditioningDropRefVideo" in types or "H3RefineResizeConditioning" in types:
        raise RuntimeError("Sécurité H3 V9: ancien refine conditioning détecté; les refs visuelles seraient conservées en HD.")
    if "H3LoadRawLatentExact" in types:
        raise RuntimeError("Sécurité H3 V9: le chemin normal RAW->HD ne doit PAS recharger le latent depuis disque.")
    if types.count("H3StudioImageToVideo") != 1:
        raise RuntimeError(f"Sécurité H3 V9: H3Studio doit être exécuté exactement une fois, trouvé {types.count('H3StudioImageToVideo')}.")
    if not any("8 STEPS COMPLETS" in t.upper() for t in titles):
        raise RuntimeError("Sécurité H3 V9: sampler RAW 8 steps absent.")
    if not any("REFINE" in t.upper() and "4 SIGMA" in t.upper() for t in titles):
        raise RuntimeError("Sécurité H3 V9: refine 4 sigma absent.")
    up = next((n for n in graph.values() if n.get("class_type") == "MinimaxH3LatentUpscaler3D"), None)
    if not up:
        raise RuntimeError("Sécurité H3 V9: upscaler 1920 absent.")
    inp = up.get("inputs") or {}
    expected = {"mode": "target dimensions", "mode.width": hd_dimensions[0], "mode.height": hd_dimensions[1], "align": 32}
    bad = [f"{k}={inp.get(k)!r}" for k, v in expected.items() if inp.get(k) != v]
    if bad:
        raise RuntimeError("Sécurité H3 V9: paramètres upscaler invalides: " + ", ".join(bad))


def _phase_assert_final(graph: dict[str, Any]) -> None:
    forbidden = {
        "H3StudioImageToVideo", "UNETLoader", "CLIPLoader", "VAELoader",
        "SamplerCustomAdvanced", "MinimaxH3LatentUpscaler3D",
        "H3RefineResizeConditioning", "H3RefineResizeConditioningDropRefVideo",
        "H3RefineResizeConditioningDropVisualRefs",
        "H3V15ProjectHardLock", "H3V15ProjectStoreHDTail",
        "H3RawCacheHold", "H3RawCacheRestore", "H3StoreRawLatentExact", "H3LoadRawLatentExact", "H3RawSavedAutoGate", "H3RawSavedStudioGate",
    }
    leaked = sorted({str(n.get("class_type")) for n in graph.values()} & forbidden)
    if leaked:
        raise RuntimeError("Sécurité H3 V6: Phase FINAL relancerait H3/refine: " + ", ".join(leaked))
    types = {str(n.get("class_type")) for n in graph.values()}
    if "H3VisibleJoinMatch" not in types or "H3V15ConcatVideosNoOOM" not in types:
        raise RuntimeError("Sécurité H3 V6: Phase FINAL sans join H3VisibleJoinMatch/NoOOM.")


def set_render_orientation(graph: dict[str, Any], hd_dimensions: tuple[int,int]) -> None:
    """Mutate only a render's private API graph when portrait is requested.

    Film/landscape leaves the graph byte-for-byte unchanged. Keep the node IDs,
    RAW/HD latent paths, Motion Context and output filenames exactly as before.
    """
    if hd_dimensions not in ((1920,1080),(1080,1920)):
        raise ValueError('Orientation HD invalide')
    if hd_dimensions == (1920,1080):
        return
    ups=[n for n in graph.values() if n.get('class_type') == 'MinimaxH3LatentUpscaler3D']
    if len(ups) != 1:
        raise RuntimeError('Portrait: upscaler HD unique introuvable')
    up=ups[0]['inputs']
    if (up.get('mode.width'),up.get('mode.height'))!=(1920,1080):
        raise RuntimeError('Portrait: la base HD n’est plus le workflow paysage validé')
    up['mode.width']=1080
    up['mode.height']=1920


def render_clip(base: dict[str, Any], h3_id: str, save_id: str, comfy: Path, project: str, client_id: str,
                clip_number: int, prompt: str, refs: list[dict[str, Any]], audio_refs: list[dict[str, Any]],
                prev_raw: str, prev_final: str, width: int, height: int,
                force_mc_reencode: bool = False, loras: list[dict] | None = None, lora_objinfo: dict | None = None,
                hd_dimensions: tuple[int,int] = (1920, 1080)) -> tuple[str, str, str, bool]:
    """Render one clip with the manual-workflow execution semantics restored.

    Phase A (ONE ComfyUI prompt) — H3Studio + optional MC22 -> RAW sampler 8 steps ->
              H3RawCacheHold -> optional exact .pt safety copy -> Save RAW ->
              H3RawSavedAutoGate -> SAME in-memory AV latent -> latent upscale 1920 ->
              strip visual refs + resize MC conditioning -> HD HardLock -> refine 4 sigma -> Store HD tail ->
              H3RawCacheRestore -> VISIBLE MP4.
    Phase B (clip 2+ only) — previous FINAL + current VISIBLE (trim MC22) -> join -> new FINAL.

    This deliberately avoids the V6 performance regression where a second API prompt reran
    H3Studio/ref conditioning and changed ComfyUI model/cache pressure before the HD refine.
    H3RefineBridge remains untouched.
    """
    graph = copy.deepcopy(base)
    set_render_orientation(graph, hd_dimensions)
    if loras:
        graph = studio_refbank_module("studio_lora").apply(graph, loras, lora_objinfo or {})
    h3 = graph[h3_id]["inputs"]
    rt.clear_runtime_media(h3)
    rt.apply_reference_inputs(h3, refs, audio_refs)
    h3["prompt"] = prompt
    h3["width"] = width
    h3["height"] = height
    use_mc = bool(prev_raw)
    h3["length"] = rt.CONT_FRAME_COUNT if use_mc else rt.FIRST_FRAME_COUNT
    if use_mc:
        h3["first_frame_file"] = ""
        h3["motion_context_file"] = prev_raw
        h3["motion_context_end_seconds"] = 0.0
        h3["motion_context_frames"] = rt.MOTION_FRAMES
        h3["motion_context_audio_frames"] = rt.MOTION_AUDIO_FRAMES
        # A resumed process must re-encode the saved RAW MP4 instead of trusting
        # a potentially stale in-process H3Studio cache from a DIFFERENT project.
        h3["motion_context_reuse_latent"] = not force_mc_reencode
        h3["motion_context_anchor_brightness"] = True
        h3["motion_context_strength"] = rt.MOTION_STRENGTH
        if "motion_scale" in h3:
            h3["motion_scale"] = 1.0
    else:
        h3["motion_context_file"] = ""
        h3["motion_context_end_seconds"] = 0.0

    raw_save_id, raw_save = _graph_node_by_title(graph, "SaveVideo", "RAW H3STUDIO")
    final_save_id, final_save = _graph_node_by_title(graph, "SaveVideo", "FINAL CUMULATIF 1920", required=False)
    _project_id, project_node = _graph_node_by_title(graph, "H3V15Project", "NOM DU PROJET")
    project_node["inputs"]["project_name"] = project

    # Exact RAW LATENT persistence is a separate custom node. Keep H3RawCacheHold in front
    # of it so the existing H3Studio internal cache is still protected independently.
    raw_hold_id, _raw_hold = _graph_node_by_title(graph, "H3RawCacheHold", "CACHE + RAW + REFINE")
    raw_vdecode_id, raw_vdecode = _graph_node_by_title(graph, "VAEDecode", "VAE Decode RAW video")
    raw_adecode_id, raw_adecode = _graph_node_by_title(graph, "VAEDecodeAudio", "VAE Decode RAW audio")
    split_id, _split = _graph_node_by_title(graph, "LTXVSeparateAVLatent", "Split AV latent")

    latent_name = f"clip_{clip_number:04d}_RAW_LATENT"
    store_id = _next_api_node_id(graph)
    graph[store_id] = {
        "class_type": "H3StoreRawLatentExact",
        "inputs": {
            "latent": [str(raw_hold_id), 0],
            "project_name": project,
            "latent_name": latent_name,
        },
        "_meta": {"title": f"API — STORE EXACT RAW LATENT {latent_name}"},
    }
    # Make RAW SaveVideo depend on the disk persistence node, so a completed RAW MP4 proves
    # the exact latent sidecar is already atomically committed.
    raw_vdecode["inputs"]["samples"] = [store_id, 0]
    raw_adecode["inputs"]["samples"] = [store_id, 0]

    # V7: force RAW SaveVideo to be an upstream dependency of the HD path, exactly like
    # H3RawReviewPause did in the manual workflow, but without any human pause. This keeps
    # BOTH the AV latent and the H3 conditioning in memory inside one prompt.
    gate_id = _next_api_node_id(graph)
    graph[gate_id] = {
        "class_type": "H3RawSavedAutoGate",
        "inputs": {
            "latent": [store_id, 0],
            "raw_video_saved": [str(raw_save_id), 0],
        },
        "_meta": {"title": "API — RAW SAVED AUTO GATE — SAME IN-MEMORY LATENT"},
    }
    if studio.enabled() and studio._get('config.json',{}).get('reviews',{}).get('raw',False):
        graph[gate_id]['class_type'] = 'H3RawSavedStudioGate'
        graph[gate_id]['inputs'].update({'project_name':project,'clip_number':clip_number})
        graph[gate_id]['_meta']['title']='API — STUDIO RAW REVIEW GATE — SAME IN-MEMORY LATENT'
    graph[str(split_id)]["inputs"]["av_latent"] = [gate_id, 0]

    graph[save_id]["inputs"]["filename_prefix"] = f"{OUTPUT_ROOT_NAME}/{project}/clips/clip_{clip_number:04d}_VISIBLE_1920"
    raw_save["inputs"]["filename_prefix"] = f"{OUTPUT_ROOT_NAME}/{project}/raw/clip_{clip_number:04d}_RAW_MC"

    use_join = bool(prev_final)
    staged_paths: list[Path] = []
    if use_join:
        _load_id, load_node = _graph_node_by_title(graph, "LoadVideo", "CHARGE FINAL VISIBLE PRECEDENT")
        prev_rel, prev_dst = _stage_output_video_for_load(comfy, project, clip_number, prev_final, "previous_final")
        staged_paths.append(prev_dst)
        _set_loadvideo_file(load_node, prev_rel)
        if final_save_id is None or final_save is None:
            raise RuntimeError("Le workflow H3 API CLEAN ne possède pas la sortie FINAL cumulative.")
        final_save["inputs"]["filename_prefix"] = f"{OUTPUT_ROOT_NAME}/{project}/final/H3_VISIBLE_FINAL_1920"

    # ONE seed for the clip. Phase 2 no longer needs the RAW sampler, but refine keeps this
    # same noise seed exactly as in the original single-prompt workflow.
    rt.set_seed(graph)
    rt.assert_v2_h3_clean(h3)
    studio.raise_if_stopped()
    rt.comfy_hard_free(f"Avant H3 clip {clip_number}")

    project_out = comfy / "output" / OUTPUT_ROOT_NAME / project
    raw_dir = project_out / "raw"
    visible_dir = project_out / "clips"
    final_dir = project_out / "final"
    state_dir = project_out / "_state"
    latent_state_path = state_dir / f"{latent_name}.pt"
    raw_prefix = f"clip_{clip_number:04d}_RAW_MC"
    visible_prefix = f"clip_{clip_number:04d}_VISIBLE_1920"
    final_prefix = "H3_VISIBLE_FINAL_1920"

    def disk_ann(directory: Path, prefix: str, label: str, not_before: float) -> str:
        candidates = rt._fresh_video_candidates(directory, prefix, not_before)
        if not candidates:
            raise RuntimeError(
                f"H3 API CLEAN: {label} absent dans le dossier du film après rendu complet: "
                f"{directory} / {prefix}*"
            )
        path = candidates[-1]
        rel = path.relative_to(comfy / "output")
        return rt.annotated_name({
            "filename": path.name,
            "subfolder": rel.parent.as_posix() if rel.parent.as_posix() != "." else "",
            "type": "output",
        })

    visible_ok = False
    try:
        # V7 — RAW + HD in ONE dependency chain and ONE prompt. RAW SaveVideo is no longer
        # an independent output: H3RawSavedAutoGate consumes it before allowing the SAME
        # in-memory latent to reach SeparateAV/upscale/refine. This restores the manual
        # workflow's model/cache/conditioning behaviour and avoids V6's second H3Studio run.
        raw_hd_graph = _upstream_only(graph, save_id)
        _phase_assert_raw_hd(raw_hd_graph, hd_dimensions)
        render_started = time.time()
        if studio.enabled():
            studio.publish('render',f'Clip {clip_number} — sampler RAW 8 steps',{'clip':clip_number,'phase':'raw','refs':refs,'audio_refs':audio_refs,'text':prompt,'ref_count':len(refs),'audios':len(audio_refs),'mc':use_mc,'frames':h3['length'],'started':render_started})
        print(
            f"    H3 phase RAW+HD — UN SEUL PROMPT: RAW 8 steps -> Save RAW -> SAME latent en mémoire "
            f"-> upscale 1920 -> HardLock -> refine 4 sigma -> {visible_prefix}"
        )
        studio.raise_if_stopped()
        render_pid = rt.queue_graph(raw_hd_graph, client_id)
        if studio.enabled():
            studio._write('active_prompt.json', {'id':render_pid,'project':project,'clip':clip_number})
        def _check_render_abort():
            if not studio.enabled() or not (studio.DIR/'stop.request').is_file():
                return
            # If the user pressed STOP during the tiny queue-submit race, the
            # web API may not yet have seen this prompt id. Clean up ONLY ours.
            try:
                queue=rt.http_json(rt.COMFY_URL+'/queue',timeout=5)
                running={str(row[1]) for row in queue.get('queue_running',[]) if len(row)>1}
                pending={str(row[1]) for row in queue.get('queue_pending',[]) if len(row)>1}
                if render_pid in running:
                    rt.http_json(rt.COMFY_URL+'/interrupt','POST',{},timeout=5)
                elif render_pid in pending:
                    rt.http_json(rt.COMFY_URL+'/queue','POST',{'delete':[render_pid]},timeout=5)
            except Exception as abort_error:
                print(f'    WARN annulation ComfyUI (signal conservé): {abort_error}')
            raise studio.StudioStop()
        monitor_stop=threading.Event()
        if studio.enabled():
            def _watch_raw_to_hd():
                reviewing=bool(studio._get('config.json',{}).get('reviews',{}).get('raw',False))
                waiting_path=project_out/'_studio'/'gates'/f'clip_{clip_number:04d}.waiting.json'
                seen_raw=False
                seen_wait=False
                refine_announced=False
                raw_elapsed=0
                while not monitor_stop.wait(1.5):
                    try:
                        if not seen_raw and rt._fresh_video_candidates(raw_dir,raw_prefix,render_started):
                            seen_raw=True
                            raw_elapsed=round(time.time()-render_started,1)
                            if reviewing:
                                studio.publish('raw_ready',f'Clip {clip_number} — RAW sauvegardé, validation demandée',{
                                    'clip':clip_number,'refs':refs,'audio_refs':audio_refs,'text':prompt,'ref_count':len(refs),
                                    'frames':h3['length'],'raw_elapsed':raw_elapsed,'phase':'raw_review'})
                            else:
                                studio.publish('render',f'Clip {clip_number} — RAW terminé, refine HD en cours',{
                                    'clip':clip_number,'refs':refs,'audio_refs':audio_refs,'text':prompt,'ref_count':len(refs),
                                    'frames':h3['length'],'raw_elapsed':raw_elapsed,'phase':'refine'})
                                return
                        if reviewing and seen_raw:
                            if waiting_path.is_file():
                                seen_wait=True
                            if seen_wait and not waiting_path.is_file() and not refine_announced:
                                # RAW gate has been released. Rejection/STOP also clears it:
                                # only announce refine when no stop/redo is pending.
                                if (studio.DIR/'stop.request').exists() or (project_out/'_studio'/'gates'/f'clip_{clip_number:04d}.redo.json').exists():
                                    return
                                refine_announced=True
                                studio.publish('render',f'Clip {clip_number} — RAW validé, refine HD en cours',{
                                    'clip':clip_number,'refs':refs,'audio_refs':audio_refs,'text':prompt,'ref_count':len(refs),
                                    'frames':h3['length'],'raw_elapsed':raw_elapsed,'phase':'refine'})
                                return
                    except (OSError,ValueError):
                        pass
            threading.Thread(target=_watch_raw_to_hd,daemon=True).start()
        try:
            try:
                rt.wait_for_disk_video(
                    render_pid, visible_dir, visible_prefix, render_started,
                milestone=(raw_dir, raw_prefix, "RAW MC"),
                max_seconds=rt.MAX_H3_RENDER_SECONDS,
                stop_signal_path=(comfy/'output'/OUTPUT_ROOT_NAME/project/'_studio'/'gates'/f'clip_{clip_number:04d}.redo.json') if studio.enabled() else None,
                review_wait_path=(comfy/'output'/OUTPUT_ROOT_NAME/project/'_studio'/'gates'/f'clip_{clip_number:04d}.waiting.json') if studio.enabled() and studio._get('config.json',{}).get('reviews',{}).get('raw',False) else None,
                    abort_check=_check_render_abort if studio.enabled() else None,
                )
            except RuntimeError:
                transfer=project_out/'_studio'/'gates'/f'clip_{clip_number:04d}.retouch.requested.json'
                if not studio.enabled() or not transfer.is_file() or (studio.DIR/'stop.request').exists():
                    raise
                # Gate has cancelled the original prompt. Never launch H3 while
                # ComfyUI still holds that blocked gate on its worker thread.
                until=time.monotonic()+45
                while rt._prompt_is_still_queued(render_pid):
                    studio.raise_if_stopped()
                    if time.monotonic()>until:raise RuntimeError('ComfyUI n’a pas libéré le graphe RAW pour Retouches')
                    time.sleep(0.35)
                # The ordinary (unmodified) redo gate creates this sidecar.
                # It must NOT be interpreted by the main loop as a Director retry.
                (project_out/'_studio'/'gates'/f'clip_{clip_number:04d}.redo.json').unlink(missing_ok=True)
                rt.comfy_hard_free(f'RAW clip {clip_number} libéré pour Retouches')
                approved=_await_approved_retouch(project_out,clip_number,transfer)
                return _render_approved_retouch_hd(
                    graph,h3_id,save_id,comfy,project,clip_number,client_id,prev_final,use_mc,
                    hd_dimensions,raw_dir,raw_prefix,transfer,approved)
        finally:
            monitor_stop.set()
            if studio.enabled(): studio._write('active_prompt.json', {})
        raw_ann = disk_ann(raw_dir, raw_prefix, "RAW Motion Context", render_started)
        raw_file=rt.annotated_to_path(comfy,raw_ann)
        raw_mark=raw_file.stat().st_mtime if raw_file.exists() else render_started
        print(f'    TEMPS RAW MESURÉ (fichier): {max(0,raw_mark-render_started):.1f}s ; {len(refs)} ref(s) MAX ; {h3["length"]} frames ; MC={use_mc}')
        visible_ann = disk_ann(visible_dir, visible_prefix, "VISIBLE COURANT 1920", render_started)
        hd_file=rt.annotated_to_path(comfy,visible_ann)
        hd_mark=hd_file.stat().st_mtime if hd_file.exists() else raw_mark
        timing={}
        timing_file=project_out/'_studio'/'gates'/f'clip_{clip_number:04d}.timing.json'
        if timing_file.is_file():
            try:timing=json.loads(timing_file.read_text(encoding='utf-8'))
            except (OSError,ValueError):timing={}
        review_seconds=float(timing.get('review_seconds') or 0)
        print(f'    TEMPS RAW→HD MESURÉ (fichiers): {max(0,hd_mark-raw_mark-review_seconds):.1f}s (upscale + refine + export, hors attente humaine {review_seconds:.1f}s) ; V9 graph intact')
        visible_ok = True

        if latent_state_path.is_file() and latent_state_path.stat().st_size > 0:
            print(
                f"    RAW+HD OK -> même latent AV utilisé en mémoire; copie sécurité .pt: {latent_state_path.name}"
            )
        else:
            print("    RAW+HD OK -> même latent AV utilisé en mémoire; copie sécurité .pt absente (non bloquant)")

        # V10 Studio: keep every exact RAW .pt for future non-destructive edits.
        # Normal RAW->HD still passes the same in-memory latent; no disk reload.

        final_ann = visible_ann
        if use_join and final_save_id is not None:
            # FINAL stays a separate lightweight disk-video phase: no H3Studio/model/refine.
            current_rel, current_dst = _stage_output_video_for_load(
                comfy, project, clip_number, visible_ann, "current_visible"
            )
            staged_paths.append(current_dst)
            final_graph_full = copy.deepcopy(graph)
            current_slice_id, current_slice = _graph_node_by_title(
                final_graph_full, "Video Slice", "COUPE 22 FRAMES MC"
            )
            prev_load_id, prev_load = _graph_node_by_title(
                final_graph_full, "LoadVideo", "CHARGE FINAL VISIBLE PRECEDENT"
            )
            current_load_id = _next_api_node_id(final_graph_full)
            current_load = copy.deepcopy(prev_load)
            current_load["_meta"] = {"title": "API — CHARGE VISIBLE COURANT POUR JOIN"}
            _set_loadvideo_file(current_load, current_rel)
            final_graph_full[current_load_id] = current_load
            current_slice["inputs"]["video"] = [current_load_id, 0]
            final_graph = _upstream_only(final_graph_full, final_save_id)
            _phase_assert_final(final_graph)
            final_started = time.time()
            print("    H3 phase FINAL — FINAL précédent + VISIBLE courant trim MC22 -> join no-OOM")
            final_pid = rt.queue_graph(final_graph, client_id)
            rt.wait_for_disk_video(final_pid, final_dir, final_prefix, final_started)
            final_ann = disk_ann(final_dir, final_prefix, "FINAL cumulatif", final_started)

        return visible_ann, raw_ann, final_ann, use_mc
    finally:
        # On failure keep the .pt safety copy for diagnosis/recovery. Staged videos are disposable.
        for staged in staged_paths:
            try:
                staged.unlink(missing_ok=True)
            except Exception:
                pass

def _render_approved_retouch_hd(graph: dict[str, Any], h3_id: str, save_id: str,
                                comfy: Path, project: str, clip_number: int, client_id: str,
                                prev_final: str, use_mc: bool, hd_dimensions: tuple[int,int],
                                raw_dir: Path, raw_prefix: str, request_path: Path,
                                approved_path: Path) -> tuple[str,str,str,bool]:
    """Opt-in separate RAW-retouch -> 4sigma HD branch. NO RAW sampling, no fake .pt.

    The original RAW->HD branch is never modified for direct approvals. The H3Studio
    V2V encoder creates a new AV latent from the approved complete video; the existing
    upscale/HardLock/4sigma nodes perform the HD pass. This path must be validated
    against a real ComfyUI object_info before the first GPU request.
    """
    project_out=comfy/'output'/OUTPUT_ROOT_NAME/project
    gate_dir=project_out/'_studio'/'gates'
    original_files=sorted(raw_dir.glob(raw_prefix+'*.mp4'))
    if not original_files:
        raise RuntimeError('Retouche approuvée : RAW original absent; aucun HD lancé')
    original_raw=original_files[-1]
    # Keep the original MP4 and its exact .pt immutable; the approved video is a new branch.
    retouch_dir=project_out/'raw_retouched';retouch_dir.mkdir(parents=True,exist_ok=True)
    target=retouch_dir/f'clip_{clip_number:04d}_RAW_RETOUCHED_{int(time.time())}.mp4'
    import shutil as _shutil
    _shutil.copy2(approved_path,target)
    if not target.is_file() or target.stat().st_size<1000:
        raise RuntimeError('Retouche approuvée vide : refuse le refine HD')
    approved_json=gate_dir/f'clip_{clip_number:04d}.retouch.approved.json'
    provenance={'source_original_raw':str(original_raw),'source_original_latent':str(project_out/'_state'/f'clip_{clip_number:04d}_RAW_LATENT.pt'),
                'approved_source':str(approved_path),'retouched_raw':str(target),'created_at':time.time(),
                'hd_kind':'H3Studio V2V -> latent upscaler -> HardLock -> refine 4sigma',
                'motion_context_reencode_next_clip':True}
    save_json(gate_dir/f'clip_{clip_number:04d}.retouch.handoff.json',provenance)
    # Stage copy in ComfyUI/input for H3Studio V2V video encoder. No MP4->fake exact .pt.
    ann_original=rt.annotated_name({'filename':target.name,
                   'subfolder':target.relative_to(comfy/'output').parent.as_posix(),'type':'output'})
    v2v_rel, staged=_stage_output_video_for_load(comfy,project,clip_number,ann_original,'approved_retouch_v2v')
    staged_paths=[staged]
    try:
        hd_graph=copy.deepcopy(graph)
        hd_h3=hd_graph[str(h3_id)]['inputs']
        # H3Studio input encoder supports video via v2v_video_file (same node as the
        # validated RAW workflow). No second eight-step sampler is attached here.
        hd_h3['v2v_video_file']=v2v_rel
        hd_h3['v2v_start_seconds']=0.0
        hd_h3['v2v_end_seconds']=0.0
        hd_h3['v2v_denoise']=0.0
        hd_h3['v2v_noise']=0.0
        # The source MP4 already contains its MC prefix. Never inject it twice.
        hd_h3['motion_context_file']=''
        hd_h3['motion_context_reuse_latent']=False
        split_id,_=_graph_node_by_title(hd_graph,'LTXVSeparateAVLatent','Split AV latent')
        hd_graph[str(split_id)]['inputs']['av_latent']=[str(h3_id),1]
        restore_id,restore_node=_graph_node_by_title(hd_graph,'H3RawCacheRestore','RESTAURE CACHE RAW')
        bypass=restore_node['inputs']['latent']
        if not isinstance(bypass,list) or len(bypass)!=2:
            raise RuntimeError('Refine retouché : bypass cache H3 invalide')
        for node in hd_graph.values():
            for name,value in list((node.get('inputs') or {}).items()):
                if isinstance(value,list) and len(value)==2 and str(value[0])==str(restore_id):
                    node['inputs'][name]=list(bypass)
        # Retouch path must be GPU-light: a *single* 4sigma sampler and no RAW sampler.
        hd_graph=_upstream_only(hd_graph,save_id)
        classes=[n.get('class_type') for n in hd_graph.values()]
        if classes.count('SamplerCustomAdvanced')!=1 or 'H3StudioImageToVideo' not in classes:
            raise RuntimeError('Refine retouché : échec du contrôle du graphe 4sigma unique')
        if any(t in classes for t in ('H3RawSavedStudioGate','H3RawSavedAutoGate','H3RawCacheHold','H3RawCacheRestore')):
            raise RuntimeError('Refine retouché : dépendance RAW/gate résiduelle')
        ups=[node for node in hd_graph.values() if node.get('class_type')=='MinimaxH3LatentUpscaler3D']
        if len(ups)!=1 or (ups[0]['inputs'].get('mode.width'),ups[0]['inputs'].get('mode.height'))!=hd_dimensions:
            raise RuntimeError('Refine retouché : upscaler 1920 non conforme')
        if not any(n.get('class_type')=='H3V15ProjectHardLock' for n in hd_graph.values()):
            raise RuntimeError('Refine retouché : HardLock absent')
        # Live Comfy schema check, fail *before* spending GPU on incompatible nodes.
        objinfo=rt.http_json(rt.COMFY_URL+'/object_info',timeout=20)
        studio_spec=objinfo.get('H3StudioImageToVideo') or {}
        supported=set((studio_spec.get('input') or {}).get('required',{}))|set((studio_spec.get('input') or {}).get('optional',{}))
        if 'v2v_video_file' not in supported:
            raise RuntimeError('Ce H3Studio ne prend pas en charge le V2V MP4; refine retouché bloqué sans dégrader la vidéo')
        for typ in {'H3StudioImageToVideo','H3V15ProjectHardLock','MinimaxH3LatentUpscaler3D','SamplerCustomAdvanced','H3V15ProjectStoreHDTail'}:
            if typ not in objinfo:raise RuntimeError(f'Noeud refine retouché manquant dans ComfyUI: {typ}')
        rt.comfy_hard_free(f'Avant refine HD retouché clip {clip_number}')
        studio.publish('render',f'Clip {clip_number} — refine 4sigma depuis MP4 retouché',
            {'clip':clip_number,'phase':'retouched_refine','retouched_raw':str(target)})
        visible_dir=project_out/'clips';visible_prefix=f'clip_{clip_number:04d}_VISIBLE_1920'
        started=time.time()
        pid=rt.queue_graph(hd_graph,client_id)
        if studio.enabled():studio._write('active_prompt.json',{'id':pid,'project':project,'clip':clip_number})
        try:
            rt.wait_for_disk_video(pid,visible_dir,visible_prefix,started,
                abort_check=studio.raise_if_stopped if studio.enabled() else None)
        finally:
            if studio.enabled():studio._write('active_prompt.json',{})
        candidates=rt._fresh_video_candidates(visible_dir,visible_prefix,started)
        if not candidates:raise RuntimeError('Refine retouché HD absent après rendu ComfyUI')
        current=candidates[-1]
        # The V2V/HD decoder is not an audio-editing engine. Copy the actual
        # approved retouch soundtrack to HD BEFORE staging this clip for FINAL.
        _restore_validated_audio(comfy,current,approved=target)
        visible_ann=rt.annotated_name({'filename':current.name,
            'subfolder':current.relative_to(comfy/'output').parent.as_posix(),'type':'output'})
        final_ann=visible_ann
        if prev_final:
            prior_rel,prior_staged=_stage_output_video_for_load(comfy,project,clip_number,prev_final,'previous_final_retouch')
            staged_paths.append(prior_staged)
            current_rel,current_staged=_stage_output_video_for_load(comfy,project,clip_number,visible_ann,'current_visible_retouch')
            staged_paths.append(current_staged)
            join_graph=copy.deepcopy(graph)
            final_id,final_save=_graph_node_by_title(join_graph,'SaveVideo','FINAL CUMULATIF 1920')
            load_id,prev_load=_graph_node_by_title(join_graph,'LoadVideo','CHARGE FINAL VISIBLE PRECEDENT')
            _set_loadvideo_file(prev_load,prior_rel)
            current_id=_next_api_node_id(join_graph)
            cur_loader=copy.deepcopy(prev_load)
            cur_loader['_meta']={'title':'API — RETOUCHE VISIBLE ACTUEL'}
            _set_loadvideo_file(cur_loader,current_rel)
            join_graph[current_id]=cur_loader
            slice_id,current_slice=_graph_node_by_title(join_graph,'Video Slice','COUPE 22 FRAMES MC')
            current_slice['inputs']['video']=[current_id,0]
            final_save['inputs']['filename_prefix']=f'{OUTPUT_ROOT_NAME}/{project}/final/H3_VISIBLE_FINAL_1920'
            only_join=_upstream_only(join_graph,final_id)
            _phase_assert_final(only_join)
            started_join=time.time()
            join_pid=rt.queue_graph(only_join,client_id)
            final_dir=project_out/'final'
            rt.wait_for_disk_video(join_pid,final_dir,'H3_VISIBLE_FINAL_1920',started_join,
                abort_check=studio.raise_if_stopped if studio.enabled() else None)
            finals=rt._fresh_video_candidates(final_dir,'H3_VISIBLE_FINAL_1920',started_join)
            if not finals:raise RuntimeError('FINAL cumulatif absent après refine retouché')
            last=finals[-1]
            # The join node is only the authority for VIDEO. Rebuild sound from
            # the previous FINAL + approved current soundtrack, with MC trim.
            _restore_validated_audio(comfy,last,
                                     preceding_final=rt.annotated_to_path(comfy,prev_final),
                                     current_visible=current,trim_motion_context=use_mc)
            final_ann=rt.annotated_name({'filename':last.name,
                'subfolder':last.relative_to(comfy/'output').parent.as_posix(),'type':'output'})
        request_path.unlink(missing_ok=True)
        approved_json.unlink(missing_ok=True)
        studio.publish('render',f'Clip {clip_number} — HD retouché intégré au film',
                       {'clip':clip_number,'phase':'retouched_hd_ready'})
        return visible_ann,ann_original,final_ann,use_mc
    finally:
        for path in staged_paths:
            try:path.unlink(missing_ok=True)
            except OSError:pass


def _await_approved_retouch(project_out: Path, clip_number: int, request_path: Path):
    """Wait with zero GPU usage until a Retouches result is validated."""
    gate_dir=project_out/'_studio'/'gates'
    approval=gate_dir/f'clip_{clip_number:04d}.retouch.approved.json'
    studio.publish('raw_retouch',f'Clip {clip_number} — RAW à retoucher · ComfyUI libéré',
                   {'clip':clip_number,'phase':'retouch_waiting'})
    while True:
        studio.raise_if_stopped()
        if not request_path.is_file():
            raise RuntimeError('Session de retouche abandonnée sans validation RAW')
        if approval.is_file():
            row=json.loads(approval.read_text('utf-8'))
            if int(row.get('clip') or 0)!=clip_number or row.get('project')!=project_out.name or row.get('session')!=studio.DIR.name:
                raise RuntimeError('Résultat retouché d’une autre session refusé')
            f=Path(row.get('approved_path') or '').resolve()
            # Only accept the immutable approval archive, not arbitrary files.
            approvals=(Path(__file__).resolve().parent/'studio_sessions'/'retouches'/'review'/'approved').resolve()
            if f.parent!=approvals or f.suffix.lower()!='.mp4' or not f.is_file():
                raise RuntimeError('Vidéo validée hors archive Retouches : refus de reprise')
            return f
        time.sleep(0.4)


def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")



def build_fallback_clip_prompt(plan: dict[str, Any], previous_h3_prompt: str) -> str:
    """Deterministic H3 prompt used only when Clip Director cannot return text."""
    view = str(plan.get("view") or "cinematic shot").strip()
    action = str(plan.get("action") or "Continue the scene naturally.").strip()
    purpose = str(plan.get("purpose") or "Maintain narrative continuity.").strip()
    shots = plan.get("shots") or []
    if shots:
        seq = []
        for sh in shots:
            a = sh.get("start_seconds_in_clip")
            b = sh.get("end_seconds_in_clip")
            seq.append(f"Shot {sh.get('shot')}: {a}-{b}s | {sh.get('view','')} | {sh.get('action','')}")
        action = " ; ".join(seq)
    continuity = ""
    if previous_h3_prompt:
        continuity = " Continue naturally from the previous clip without changing established characters, environment, lighting, or action state."
    return (
        "Cinematic, photorealistic MiniMax H3 video. 5-second continuous shot. "
        f"Camera/view: {view}. Action: {action}. Narrative purpose: {purpose}. "
        "Natural human motion, restrained acting, physically coherent movement, realistic timing, "
        "no unnecessary gestures or exaggerated expressions." + continuity
    )



def build_fallback_content(requested_seconds: int, user_prompt: str, user_details: str, user_style: str, reason: str) -> dict[str, Any]:
    part = {
        "part": 1,
        "kind": "PARTIE",
        "label": "1",
        "name": "PARTIE 1",
        "start_seconds": 0,
        "end_seconds": requested_seconds,
        "duration_seconds": requested_seconds,
        "start": tc(0),
        "end": tc(requested_seconds),
        "function": "Réaliser fidèlement la demande utilisateur.",
        "development": user_prompt,
        "source_block": "[FALLBACK CONTENT]",
    }
    print(f"  WARN Content Director: fallback minimal utilisé après échec : {reason}")
    return {
        "user_prompt": user_prompt,
        "user_details": user_details,
        "requested_duration_seconds": requested_seconds,
        "requested_duration": tc(requested_seconds),
        "user_style_direction": user_style,
        "title": "",
        "content_type": "Contenu vidéo",
        "duration_text": tc(requested_seconds),
        "genre_tone": user_style,
        "concept": user_prompt,
        "art_direction": user_style,
        "world_environment": "",
        "characters_subjects": "",
        "visual_elements": "",
        "global_progression": user_prompt,
        "parts": [part],
        "recovery": {"mode": "fallback", "reason": reason},
    }


def build_fallback_scenes(part: dict[str, Any], start_scene_number: int) -> list[dict[str, Any]]:
    """Last-resort technical segmentation only; real runs should be produced by Scene Director."""
    scenes: list[dict[str, Any]] = []
    start = int(part["start_seconds"])
    end_total = int(part["end_seconds"])
    n = start_scene_number
    while start < end_total:
        end = min(end_total, start + 60)
        # part boundaries are multiples of 5, so this remains H3-compatible.
        scenes.append({
            "scene": n,
            "model_scene_number": n,
            "part": int(part.get("part") or 0),
            "part_type": str(part.get("kind") or ""),
            "part_label": str(part.get("label") or ""),
            "act": str(part.get("name") or ""),
            "start_seconds": start,
            "end_seconds": end,
            "duration_seconds": end - start,
            "start": tc(start),
            "end": tc(end),
            "location": "",
            "characters": "",
            "initial_state": "",
            "description": str(part.get("development") or part.get("function") or "Poursuite du contenu.").strip(),
            "scene_logic": str(part.get("development") or part.get("function") or "Poursuite du contenu.").strip(),
            "continuity_elements": "",
            "final_state": "",
            "function": str(part.get("function") or "").strip(),
            "source_block": "[FALLBACK SCENE — segmentation technique après échec Scene Director]",
        })
        n += 1
        start = end
    return scenes

def repair_director_output(backend: dict[str, Any], system: str, user: str, raw: str, issue: str,
                           *, label: str, num_ctx: int, num_predict: int) -> str:
    """One targeted correction call; never changes the Director's base prompt."""
    repair_user = (
        user + "\n\nCORRECTION REQUEST — THE PREVIOUS OUTPUT WAS NOT EXECUTABLE."
        + "\nPROBLEM DETECTED: " + issue
        + "\nPREVIOUS OUTPUT:\n" + (raw or "[NO OUTPUT]")
        + "\n\nReturn the corrected complete output only. Preserve all valid creative content. "
          "Do not explain the correction. Respect the exact timing/count constraints."
    )
    return director_text(backend, system, repair_user, label=label + " — correction", num_ctx=num_ctx, num_predict=num_predict)



def _studio_content_payload(content: dict[str, Any]) -> dict[str, Any]:
    """Compact, source-faithful Content Director result used by Studio helpers."""
    return {
        "title": content.get("title", ""),
        "content_type": content.get("content_type", ""),
        "duration_text": content.get("duration_text", ""),
        "genre_tone": content.get("genre_tone", ""),
        "concept": content.get("concept", ""),
        "art_direction": content.get("art_direction", ""),
        "world_environment": content.get("world_environment", ""),
        "characters_subjects": content.get("characters_subjects", ""),
        "visual_elements": content.get("visual_elements", ""),
        "global_progression": content.get("global_progression", ""),
        "parts": [
            {
                "part": x.get("part"), "kind": x.get("kind"), "label": x.get("label"),
                "name": x.get("name"), "start": x.get("start"), "end": x.get("end"),
                "duration_seconds": x.get("duration_seconds"),
                "function": x.get("function", ""), "development": x.get("development", ""),
                **({"scene_count": x["scene_count"]} if x.get("scene_count") is not None else {}),
            }
            for x in content.get("parts", []) if isinstance(x, dict)
        ],
    }


def _extract_json_object(text: str) -> dict[str, Any]:
    """Best-effort JSON extraction for local-LLM helper calls."""
    raw = (text or "").strip().replace("```json", "").replace("```JSON", "").replace("```", "").strip()
    candidates = [raw]
    start = raw.find("{")
    end = raw.rfind("}")
    if start >= 0 and end > start:
        candidates.append(raw[start:end + 1])
    for candidate in candidates:
        variants = [candidate, re.sub(r",\s*([}\]])", r"\1", candidate)]
        for variant in variants:
            try:
                obj = json.loads(variant)
                if isinstance(obj, dict):
                    return obj
            except Exception:
                pass
    raise ValueError("aucun objet JSON valide")


def _reference_items_from_text(raw: str) -> tuple[list[dict[str, str]], str]:
    """Recover Reference Planner items even when the outer JSON is slightly broken."""
    allowed = {"main_character", "secondary_character", "decor", "element"}
    raw = (raw or "").strip()
    candidates: list[dict[str, Any]] = []
    mode = "salvaged"
    try:
        obj = _extract_json_object(raw)
        if isinstance(obj.get("items"), list):
            candidates = [x for x in obj["items"] if isinstance(x, dict)]
            mode = "json"
    except Exception:
        pass

    if not candidates:
        # Recover each balanced object independently. This survives missing commas,
        # a truncated outer array, or one malformed neighboring item.
        # Reference items are flat objects; recover those directly even when the outer
        # {"items": [...]} container is malformed.
        fragments: list[str] = [m.group(0) for m in re.finditer(r"\{[^{}]*[\"']?category[\"']?\s*:[^{}]*\}", raw, re.I | re.S)]
        if not fragments:
            depth = 0
            start = None
            in_string = False
            escape = False
            for i, ch in enumerate(raw):
                if in_string:
                    if escape:
                        escape = False
                    elif ch == "\\":
                        escape = True
                    elif ch == '"':
                        in_string = False
                    continue
                if ch == '"':
                    in_string = True
                    continue
                if ch == "{":
                    if depth == 0:
                        start = i
                    depth += 1
                elif ch == "}" and depth:
                    depth -= 1
                    if depth == 0 and start is not None:
                        fragments.append(raw[start:i + 1])
                        start = None

        def field(fragment: str, key: str) -> str:
            # Double-quoted JSON-style field first; then a simple unquoted-value fallback.
            pat = re.compile(r'["\']?' + re.escape(key) + r'["\']?\s*:\s*["\'](?P<v>.*?)["\']\s*(?=,|}|\n|$)', re.I | re.S)
            m = pat.search(fragment)
            if m:
                return m.group("v").strip()
            pat2 = re.compile(r'["\']?' + re.escape(key) + r'["\']?\s*:\s*(?P<v>[^,}\n]+)', re.I)
            m = pat2.search(fragment)
            return m.group("v").strip().strip('"\' ') if m else ""

        for frag in fragments:
            cat = field(frag, "category")
            name = field(frag, "name")
            if not cat or not name:
                continue
            candidates.append({
                "category": cat,
                "name": name,
                "description": field(frag, "description"),
                "reason": field(frag, "reason"),
            })

    out: list[dict[str, str]] = []
    seen = set()
    for item in candidates:
        cat = str(item.get("category") or "").strip().lower()
        name = str(item.get("name") or "").strip()
        if cat not in allowed or not name:
            continue
        key = (cat, norm(name))
        if key in seen:
            continue
        seen.add(key)
        out.append({
            "category": cat,
            "name": name,
            "description": str(item.get("description") or "").strip(),
            "reason": str(item.get("reason") or "").strip(),
        })
    return out, (mode if out else "empty")


def studio_scene_edit_source(raw: str, scenes: list[dict[str, Any]], part: dict[str, Any], start_number: int) -> str:
    """Editable source must always reconstruct the ACTUAL parsed proposal, even after fallback."""
    try:
        checked = parse_scene_output(raw, part, start_number)
        if len(checked) == len(scenes):
            return raw
    except Exception:
        pass
    fields = [('Lieu','location'),('Personnages','characters'),('Situation initiale','initial_state'),
              ('Description','description'),('Logique de scène','scene_logic'),
              ('Continuité / éléments importants','continuity_elements'),('État final','final_state'),('Fonction','function')]
    return '\n\n'.join(
        f"SCÈNE {sc['scene']} — {sc['start']} → {sc['end']}\n" +
        '\n'.join(f'{label}: {sc.get(key) or ""}' for label,key in fields)
        for sc in scenes
    )


def studio_plan_edit_source(raw: str, plans: list[dict[str, Any]], scene: dict[str, Any]) -> str:
    """Keep LLM output untouched unless technical fallback changed the executable plan list."""
    try:
        checked = parse_plan_output(raw, scene, fill_missing=False)
        if len(checked)==len(plans):
            return raw
    except Exception:
        pass
    blocks=[]
    for plan in plans:
        shots=plan.get('shots') or []
        shot_lines=[]
        for j, shot in enumerate(shots):
            begin=shot.get('start_seconds_in_clip')
            end=shot.get('end_seconds_in_clip')
            if begin is None: begin=0
            if end is None: end=5
            shot_lines.extend([f'SHOT {j+1} {begin}–{end}', f'Vue: {shot.get("view") or ""}', f'Action: {shot.get("action") or ""}'])
        blocks.append('\n'.join([f'PLAN {plan["plan"]}',f'START STATE: {plan.get("start_state") or ""}',
            *shot_lines,f'END STATE: {plan.get("end_state") or ""}',f'BUT: {plan.get("purpose") or ""}']))
    return '\n\n'.join(blocks)


def _studio_review_fallback(content: dict[str, Any]) -> str:
    """Readable fallback if the review LLM is unavailable; never invents content."""
    c = _studio_content_payload(content)
    lines = [
        f"{c.get('title') or 'PROJET'} — {c.get('duration_text') or ''}",
        f"Type : {c.get('content_type') or '?'}",
        f"Ton : {c.get('genre_tone') or '?'}",
        "",
        "CONCEPT / FILM",
        str(c.get("concept") or "[non renseigné]"),
        "",
        "PERSONNAGES / RELATIONS",
        str(c.get("characters_subjects") or "[non renseigné]"),
        "",
        "STRUCTURE",
    ]
    for part in c.get("parts", []):
        lines.append(f"- {part.get('name')} {part.get('start')}→{part.get('end')} — {part.get('function')}")
        dev = re.sub(r"\s+", " ", str(part.get("development") or "")).strip()
        if dev:
            lines.append(f"  {dev}")
    lines += [
        "", "MONDE / DÉCORS", str(c.get("world_environment") or "[non renseigné]"),
        "", "ÉLÉMENTS VISUELS IMPORTANTS", str(c.get("visual_elements") or "[non renseigné]"),
        "", "PROGRESSION GLOBALE", str(c.get("global_progression") or "[non renseigné]"),
    ]
    return "\n".join(lines)


def studio_review_summary(backend: dict[str, Any], content: dict[str, Any]) -> str:
    system = """Tu es le PREPRODUCTION REVIEWER d'un projet vidéo. Tu ne modifies rien et tu n'inventes rien. À partir de la bible fournie, présente au créateur une version lisible et assez détaillée pour qu'il puisse décider de modifier le film AVANT les scènes. Conserve les noms, personnalités, relations, événements et timings. Montre clairement : 1) pitch/synopsis, 2) personnages principaux et secondaires utiles avec personnalité/relations/rôle, 3) structure complète acte/partie par acte/partie avec timing, fonction et événements majeurs, 4) lieux/décors et éléments visuels importants, 5) place prévue pour dialogues/action/relations si la bible l'indique. Environ 35 à 70 lignes selon la complexité. Pas de conseil, pas de critique, pas d'ajout créatif. Texte français lisible, pas de JSON."""
    user = "BIBLE CONTENT DIRECTOR À PRÉSENTER SANS LA MODIFIER :\n" + json.dumps(
        _studio_content_payload(content), ensure_ascii=False, indent=2
    )
    try:
        return director_text(backend, system, user, label="Studio Review", num_ctx=24576, num_predict=3200)
    except Exception as exc:
        print(f"  WARN Studio Review: résumé LLM indisponible, affichage direct de la bible. {exc}")
        return _studio_review_fallback(content)


def _parse_studio_content_json_revision(
    raw: str, current: dict[str, Any], requested_seconds: int,
    user_prompt: str, user_details: str, user_style: str,
) -> dict[str, Any]:
    """Accept a complete Studio revision returned as JSON instead of prose headings.

    The Studio modifier is shown a structured JSON bible, so local models sometimes answer
    with the same structure. This parser validates that structure rather than rejecting a
    semantically valid revision only because it omitted textual ACTE/PARTIE headings.
    """
    obj = _extract_json_object(raw)
    if isinstance(obj.get("content"), dict):
        root = dict(obj["content"])
        if "parts" not in root and isinstance(obj.get("parts"), list):
            root["parts"] = obj["parts"]
    else:
        root = obj
    if isinstance(root.get("scenes"), list) and root.get("scenes"):
        raise RuntimeError("Content Director Studio: la révision JSON contient des scènes.")
    raw_parts = root.get("parts")
    if not isinstance(raw_parts, list) or not raw_parts:
        raise RuntimeError("Content Director Studio: JSON sans parties exploitables.")

    parts: list[dict[str, Any]] = []
    cursor = 0
    for i, item in enumerate(raw_parts):
        if not isinstance(item, dict):
            raise RuntimeError("Content Director Studio: partie JSON invalide.")
        start_v = item.get("start_seconds")
        end_v = item.get("end_seconds")
        try:
            start_s = int(start_v) if start_v is not None else (parse_tc(str(item.get("start"))) if item.get("start") else cursor)
            if end_v is not None:
                end_s = int(end_v)
            elif item.get("end"):
                end_s = parse_tc(str(item.get("end")))
            elif item.get("duration_seconds") is not None:
                end_s = start_s + int(item.get("duration_seconds"))
            else:
                raise ValueError("missing end")
        except Exception as exc:
            raise RuntimeError(f"Content Director Studio: timing JSON invalide pour partie {i+1}: {exc}")
        if start_s != cursor or end_s <= start_s or start_s % 5 or end_s % 5:
            raise RuntimeError(f"Content Director Studio: frontières JSON invalides pour partie {i+1}.")
        kind = str(item.get("kind") or "PARTIE").upper().strip()
        if kind not in {"ACTE", "PARTIE", "SECTION", "CHAPITRE", "SEGMENT"}:
            kind = "PARTIE"
        label = str(item.get("label") or item.get("name") or (i + 1)).strip()
        # Avoid duplicating KIND in name when label already contains it.
        name = str(item.get("name") or "").strip() or f"{kind} {label}"
        explicit_scene_count = item.get("scene_count")
        if explicit_scene_count is not None:
            if type(explicit_scene_count) is not int or not 1 <= explicit_scene_count <= (end_s - start_s) // 5:
                raise RuntimeError(f"Content Director Studio: scene_count invalide pour partie {i+1} (1 à {(end_s-start_s)//5}).")
            if end_s - start_s > explicit_scene_count * 60:
                raise RuntimeError(f"Content Director Studio: {explicit_scene_count} scènes de 60s maximum ne couvrent pas la partie {i+1}.")
        parts.append({
            "part": i + 1, "kind": kind, "label": label, "name": name,
            "start_seconds": start_s, "end_seconds": end_s,
            "duration_seconds": end_s - start_s, "start": tc(start_s), "end": tc(end_s),
            "function": str(item.get("function") or "").strip(),
            "development": str(item.get("development") or "").strip(),
            "source_block": json.dumps(item, ensure_ascii=False),
            **({"scene_count": explicit_scene_count} if explicit_scene_count is not None else {}),
        })
        cursor = end_s
    if cursor != requested_seconds:
        raise RuntimeError(
            f"Content Director Studio: fin JSON {tc(cursor)}, durée demandée {tc(requested_seconds)}."
        )

    def value(key: str, default: str = "") -> str:
        return str(root[key]) if key in root and root[key] is not None else str(current.get(key, default) or default)

    return {
        "user_prompt": user_prompt,
        "user_details": user_details,
        "requested_duration_seconds": requested_seconds,
        "requested_duration": tc(requested_seconds),
        "user_style_direction": user_style,
        "title": value("title"),
        "content_type": value("content_type"),
        "duration_text": value("duration_text", tc(requested_seconds)),
        "genre_tone": value("genre_tone"),
        "concept": value("concept"),
        "art_direction": value("art_direction"),
        "world_environment": value("world_environment"),
        "characters_subjects": value("characters_subjects"),
        "visual_elements": value("visual_elements"),
        "global_progression": value("global_progression"),
        "parts": parts,
        "raw_content_director_output": raw,
    }


def _studio_regenerate_content(
    backend: dict[str, Any], current: dict[str, Any], base_user: str,
    requested_seconds: int, user_prompt: str, user_details: str, user_style: str,
    changes: str, revision_index: int, project_dir: Path, content_predict: int,
    *, conservative_edit: bool = False,
) -> dict[str, Any]:
    payload = _studio_content_payload(current)
    if conservative_edit:
        edit_contract = (
            "\n\nMODE STUDIO — MODIFICATION CONSERVATRICE.\n"
            "La version actuelle ci-dessous est la SOURCE AUTORITAIRE à éditer, pas un simple brouillon à remplacer. "
            "Applique précisément les changements demandés par le créateur. Tout élément, détail, idée, lieu, personnage, relation, "
            "événement, enjeu ou richesse visuelle qui n'est pas concerné par la demande doit être conservé. "
            "Ne résume pas les sections non visées et n'appauvris pas la proposition. Une modification peut enrichir ou corriger les zones concernées, "
            "mais elle ne justifie jamais de supprimer ailleurs un élément compatible déjà présent. "
            "Ne retire ou remplace un élément existant que si le créateur le demande explicitement ou si sa nouvelle consigne le rend réellement contradictoire. "
            "Si la demande cible un acte, un personnage, une météo, un lieu ou un aspect précis, limite les changements de fond à cette portée et aux conséquences strictement nécessaires. "
            "Avant de répondre, vérifie mentalement que toute information supprimée est justifiée par la demande. "
            "Renvoie malgré tout la proposition COMPLÈTE, avec au moins le même niveau de richesse et de précision que la version actuelle.\n"
        )
    else:
        edit_contract = (
            "\n\nMODE STUDIO — NOUVELLE PROPOSITION.\n"
            "Refais librement la proposition complète du Content Director à partir du brief et des changements demandés. "
            "Les consignes nouvelles du créateur ont priorité sur la version précédente.\n"
        )
    revision_user = (
        base_user
        + edit_contract
        + "Voici la version actuellement proposée :\n"
        + json.dumps(payload, ensure_ascii=False, indent=2)
        + "\n\nCHANGEMENTS DEMANDÉS PAR LE CRÉATEUR :\n"
        + changes.strip()
        + "\n\nNe produis toujours aucune scène. Conserve exactement la durée totale et des frontières de parties multiples de 5 secondes."
    )
    raw = director_text(
        backend, CONTENT_DIRECTOR_PROMPT, revision_user,
        label=f"Content Director Studio révision {revision_index}", num_ctx=32768, num_predict=content_predict,
    )
    pre = project_dir / "preproduction"
    pre.mkdir(parents=True, exist_ok=True)
    (pre / f"content_revision_{revision_index:02d}.txt").write_text(raw, encoding="utf-8")
    try:
        revised = parse_content_output(raw, requested_seconds, user_prompt, user_details, user_style)
    except Exception as first_exc:
        # Studio shows the current bible as JSON; local models may legitimately answer in JSON.
        # Accept and validate that structure before asking the model to rewrite its formatting.
        try:
            revised = _parse_studio_content_json_revision(
                raw, current, requested_seconds, user_prompt, user_details, user_style
            )
            print(f"  OK : révision Studio #{revision_index} récupérée directement depuis JSON structuré.")
        except Exception:
            repaired = repair_director_output(
                backend, CONTENT_DIRECTOR_PROMPT, revision_user, raw, str(first_exc),
                label=f"Content Director Studio révision {revision_index}", num_ctx=32768, num_predict=content_predict,
            )
            (pre / f"content_revision_{revision_index:02d}_retry.txt").write_text(repaired, encoding="utf-8")
            try:
                revised = parse_content_output(repaired, requested_seconds, user_prompt, user_details, user_style)
            except Exception:
                revised = _parse_studio_content_json_revision(
                    repaired, current, requested_seconds, user_prompt, user_details, user_style
                )
            raw = repaired
    revised["raw_content_director_output_studio_revision"] = raw
    save_json(pre / f"content_revision_{revision_index:02d}.json", revised)
    return revised


def studio_review_loop(
    backend: dict[str, Any], content: dict[str, Any], base_user: str,
    requested_seconds: int, user_prompt: str, user_details: str, user_style: str,
    project_dir: Path, content_predict: int,
) -> dict[str, Any]:
    """Human-in-the-loop Content Director review. Enter validates immediately."""
    revision = 0
    pre = project_dir / "preproduction"
    pre.mkdir(parents=True, exist_ok=True)
    while True:
        summary = studio_review_summary(backend, content)
        (pre / f"review_{revision:02d}.txt").write_text(summary, encoding="utf-8")
        if studio.enabled():
            decision = studio.checkpoint('content', 'Proposition du Content Director', {
                'text':summary,'content':_studio_content_payload(content),
                'revision':revision,'director':'Content Director',
            },allow_revise=True)
            action = str(decision.get('action') or 'continue').strip().lower()
            if action == 'continue':
                direct = decision.get('edits')
                if isinstance(direct, dict) and 'text' in direct:
                    updated = _parse_studio_content_json_revision(
                        direct['text'], content, requested_seconds, user_prompt, user_details, user_style
                    )
                    content = {**content, **updated}
                    # Keep the exact accepted structured document for reproducibility.
                    (pre / f'content_direct_edit_{revision:02d}.json').write_text(direct['text'], encoding='utf-8')
                save_json(pre / 'content_validated.json', content)
                return content
            if action == 'redo':
                changes = 'Propose une autre version créative du même brief. Garde uniquement les obligations explicites de l’utilisateur et la durée, mais repense la structure et le développement.'
            elif action == 'revise':
                changes = str(decision.get('feedback') or '').strip()
                if not changes:
                    print('  Studio: modification vide, proposition conservée.')
                    continue
            else:
                print(f'  Studio: action inconnue {action!r}, proposition conservée.')
                continue
        else:
            print("\n" + "=" * 78)
            print('STUDIO — PROPOSITION DU FILM / CONTENU')
            print('=' * 78)
            print(summary.strip())
            print('=' * 78)
            print('[Entrée/V] VALIDER   [M] MODIFIER avec tes consignes   [R] REFAIRE une autre proposition')
            action = input('> ').strip().lower()
            if action in {'', 'v', 'valider', 'ok', 'oui', 'y'}:
                save_json(pre / 'content_validated.json', content)
                return content
            if action not in {'m','modifier','r','refaire'}:
                print('  Choix non reconnu. Entrée=valider, M=modifier, R=refaire.')
                continue
            if action in {'r','refaire'}:
                changes = 'Propose une autre version créative du même brief. Garde uniquement les obligations explicites de l’utilisateur et la durée, mais repense la structure et le développement.'
            else:
                print('\nÉcris les changements voulus :')
                changes = input('> ').strip()
                if not changes: continue
        revision += 1
        try:
            content = _studio_regenerate_content(
                backend, content, base_user, requested_seconds, user_prompt, user_details, user_style,
                changes, revision, project_dir, content_predict,
                conservative_edit=(action in {"m", "modifier", "revise"}),
            )
            print(f"  OK : nouvelle proposition Studio #{revision} générée.")
        except Exception as exc:
            print(f"  WARN : révision impossible, proposition actuelle conservée. {exc}")


def studio_ui_choice(title: str, description: str, options: list[dict], *, input_type='choice', image=False, progress=None) -> str:
    """Structured browser choice; terminal operation stays exactly as before."""
    if studio.enabled():
        return studio.ask_input('> ', context={
            'title':title, 'description':description, 'options':options,
            'input_type':input_type, 'image':bool(image),
            'image_path':str(image) if isinstance(image,(str,Path)) else '',
            'progress':progress or {}})
    return input('> ')


def studio_reference_plan(backend: dict[str, Any], content_bible: dict[str, Any], parts: list[dict[str, Any]]) -> list[dict[str, str]]:
    system = """Tu es le REFERENCE PLANNER d'un film. Tu lis uniquement la bible validée et identifies les identités visuelles pour lesquelles une image de référence canonique pourrait réellement être utile. N'invente aucun personnage, décor ou objet. Classe en exactement quatre catégories : main_character, secondary_character, decor, element. `main_character` et `secondary_character` sont réservés aux personnages incarnés dont l'identité personnelle doit rester reconnaissable. `secondary_character` signifie une identité réellement récurrente ou narrativement importante dont la continuité visuelle compte; jamais un passant, vendeur, conducteur, collègue ponctuel, figurant, membre de foule ou autre rôle local créé seulement pour faire vivre une scène. Une ville / un lieu est `decor`. Une flotte, un véhicule, une machine, une technologie, une créature ou une entité visuelle non personnifiée est `element` sauf si la bible en fait clairement un personnage incarné récurrent avec une identité personnelle. `element` signifie une entité/objet/technologie/créature/vehicule visuellement distinctif et récurrent ou narrativement important; pas la pluie, la lumière, la foule ni un effet abstrait. Les décors doivent être des lieux réutilisables identifiables, pas chaque angle de caméra. Retourne JSON uniquement : {"items":[{"category":"main_character|secondary_character|decor|element","name":"nom exact","description":"description visuelle fidèle et courte","reason":"pourquoi la continuité visuelle compte"}]}. Déduplique. Reste raisonnable : tous les personnages principaux, seulement les secondaires durables dont l'identité doit persister, et les principaux décors/éléments visuels."""
    user = "BIBLE VALIDÉE :\n" + json.dumps({**content_bible, "parts": parts}, ensure_ascii=False, indent=2)
    raw = director_text(backend, system, user, label="Studio Reference Planner", num_ctx=24576, num_predict=3000)
    items, mode = _reference_items_from_text(raw)
    if mode == "salvaged":
        print("  WARN Reference Planner : JSON imparfait, éléments récupérés localement sans nouvel appel LLM.")
    elif mode == "empty":
        print("  WARN Reference Planner : aucune entrée exploitable récupérée; Studio continue sans refs canoniques.")
    return items


def _krea_prune_to_output(api: dict[str, Any], output_node_id: str) -> dict[str, Any]:
    keep: set[str] = set()
    stack = [str(output_node_id)]
    while stack:
        nid = stack.pop()
        if nid in keep or nid not in api:
            continue
        keep.add(nid)
        for v in api[nid].get("inputs", {}).values():
            if isinstance(v, list) and len(v) == 2 and isinstance(v[0], str) and v[0] in api:
                stack.append(v[0])
    return {nid: copy.deepcopy(node) for nid, node in api.items() if nid in keep}


def _wait_comfy_image(prompt_id: str, save_id: str, max_seconds: int = 900) -> dict[str, Any]:
    started = time.time()
    next_notice = started + 20
    while True:
        hist = rt.http_json(rt.COMFY_URL + "/history/" + prompt_id, timeout=30)
        rec = hist.get(prompt_id)
        if rec:
            st = rec.get("status") or {}
            if st.get("status_str") == "error":
                raise RuntimeError("Erreur ComfyUI Krea:\n" + json.dumps(st.get("messages") or [], ensure_ascii=False, indent=2)[-5000:])
            out = (rec.get("outputs") or {}).get(str(save_id), {})
            images = out.get("images") or []
            if images:
                return images[-1]
            if st.get("status_str") == "success" or st.get("completed") is True:
                raise RuntimeError("Krea terminé mais aucune image SaveImage trouvée.")
        now = time.time()
        if now - started > max_seconds:
            try:
                rt.http_json(rt.COMFY_URL + "/interrupt", "POST", {}, timeout=10)
            except Exception:
                pass
            raise RuntimeError("Krea bloqué depuis trop longtemps; interruption envoyée.")
        if now >= next_notice:
            print(f"      ... Krea calcule ({int(now-started)} s)")
            next_notice = now + 20
        time.sleep(1.5)


def ensure_krea_gpu_ready(*, label: str, polls: int = 10, interval: float = 2.0) -> None:
    """Avoid queuing a second heavyweight Krea render while GPU memory is full.

    This does NOT unload models, clear user queues, or modify graph nodes.  It only
    observes the NVIDIA global VRAM state AFTER the legacy ComfyUI cleanup.  If
    memory is still occupied by something else, fail BEFORE queue_graph rather
    than letting ComfyUI spill the Krea model into Windows RAM unexpectedly.
    An unavailable nvidia-smi cannot prevent the historical rendering flow.
    """
    first = rt.query_gpu_vram()
    if not first:
        print(f'  {label}: mesure VRAM indisponible ; chemin Krea historique conservé.')
        return
    minimum = max(4096, int(first['total'] * 0.35))
    if first['free'] >= minimum:
        return
    print(f'  {label}: VRAM saturée après nettoyage ({first["used"]}/{first["total"]} MiB) ; '
          'attente de libération avant Krea, sans nouvelle interruption ComfyUI.')
    current = first
    for _ in range(max(0, polls)):
        time.sleep(interval)
        current = rt.query_gpu_vram()
        if current is None:
            print(f'  {label}: surveillance indisponible ; chemin historique conservé.')
            return
        if current['free'] >= minimum:
            print(f'  {label}: mémoire libérée ({current["free"]} MiB libres).')
            return
    details = ''
    try:
        queue = rt.http_json(rt.COMFY_URL + '/queue', timeout=4)
        if isinstance(queue, dict):
            details = (f' File ComfyUI : '
                       f'{len(queue.get("queue_running") or [])} actif(s), '
                       f'{len(queue.get("queue_pending") or [])} en attente.')
    except Exception:
        pass
    raise RuntimeError(
        f'{label}: VRAM encore saturée après nettoyage ({current["used"]}/{current["total"]} MiB). '
        f'Rendu Krea non lancé pour éviter les échanges massifs VRAM/RAM.' + details +
        ' Vérifier les modèles/anciennes générations ComfyUI actifs ; relancer ComfyUI si nécessaire.'
    )


def render_krea_reference(
    comfy: Path, objinfo: dict[str, Any], project: str, name: str, category: str,
    image_prompt: str, attempt: int, *, source_image: Path | None = None,
    reference_strength: float = 0.55, mode: str = 'transform', seed: int | None = None,
) -> Path:
    workflow_file = (KREA_REFERENCE_SREF_WORKFLOW if mode == 'style' else
                     KREA_REFERENCE_IMG_WORKFLOW if source_image is not None else KREA_REFERENCE_WORKFLOW)
    if mode == 'style' and source_image is None:
        raise ValueError('Style Transfer S-Ref nécessite une image de référence')
    if not workflow_file.is_file():
        raise RuntimeError(f"Workflow Krea Studio manquant: {workflow_file}")
    gui = json.loads(workflow_file.read_text(encoding="utf-8-sig"))
    if mode == 'style':
        missing = [n for n in ('Krea2StyleReference','Krea2StyleTransfer') if n not in objinfo]
        if missing:
            raise RuntimeError('Style Transfer S-Ref : nodes ComfyUI absents : ' + ', '.join(missing) +
                               '. Installer ComfyUI-Krea2-StyleTransfer puis redémarrer ComfyUI.')
    api = rt.gui_to_api(gui, objinfo)
    save_id, save = rt.find_node(api, "SaveImage")
    api = _krea_prune_to_output(api, save_id)

    _clip_id, enc = rt.find_node(api, "CLIPTextEncode")
    enc["inputs"]["text"] = image_prompt
    latent = None
    if source_image is None or mode == 'style':
        _latent_id, latent = rt.find_node(api, "EmptyLatentImage")
    if category in {"main_character", "secondary_character"}:
        w, h = 960, 1440
    elif category == "decor":
        w, h = 1440, 960
    else:
        w, h = 1024, 1024
    if latent is not None:
        if "width" in latent["inputs"]: latent["inputs"]["width"] = w
        if "height" in latent["inputs"]: latent["inputs"]["height"] = h
        if "batch_size" in latent["inputs"]: latent["inputs"]["batch_size"] = 1

    if source_image is not None:
        # Entirely separate path. The original txt2img workflow is never edited.
        image = Path(source_image).resolve()
        if not image.is_file() or image.suffix.lower() not in {'.png','.jpg','.jpeg','.webp'}:
            raise ValueError('Image source Krea introuvable ou format non pris en charge')
        dst_dir = comfy/'input'/OUTPUT_ROOT_NAME/project/'studio_krea_sources'
        dst_dir.mkdir(parents=True,exist_ok=True)
        import hashlib
        suffix = image.suffix.lower()
        digest = hashlib.sha256(image.read_bytes()).hexdigest()[:16]
        staged = dst_dir/f'krea_source_{digest}{suffix}'
        if not staged.exists():
            shutil.copy2(image, staged)
        load_id, load = rt.find_node(api, 'LoadImage')
        load['inputs']['image'] = staged.relative_to(comfy/'input').as_posix()
        if mode == 'style':
            # Style model feeds base txt2img sampler; source does not enter
            # VAEEncode/latent. Therefore a classroom cannot become a classroom
            # merely because it was used as style reference for a pen.
            assert any(n.get('class_type')=='Krea2StyleTransfer' for n in api.values())
        else:
            scale_id, scale = rt.find_node(api, 'ImageScale')
            scale['inputs'].update({'width':w,'height':h,'upscale_method':'bicubic','crop':'center'})
            vaeencode_id, vaeencode = rt.find_node(api, 'VAEEncode')
            vaeencode['inputs']['pixels']=[str(scale_id),0]
            vae_id, _vae = rt.find_node(api,'VAELoader')
            vaeencode['inputs']['vae']=[str(vae_id),0]
            # The FIRST KSampler (original base latent input), not the HD refining sampler.
            samplers=[(nid,n) for nid,n in api.items() if n.get('class_type')=='KSampler'
                      and n.get('inputs',{}).get('latent_image')==[str(vaeencode_id),0]]
            if len(samplers)!=1:
                raise RuntimeError('Workflow Krea img2img : source latente non raccordée au sampler primaire')
            samplers[0][1]['inputs']['denoise']=max(0.3,min(0.85,float(reference_strength)))

    # Only the active Krea sampler survives pruning; fresh seed for every retry.
    for node in api.values():
        if node.get("class_type") == "KSampler" and "seed" in node.get("inputs", {}):
            node["inputs"]["seed"] = int(seed if seed is not None else uuid.uuid4().int % (2**63 - 1))
    safe = re.sub(r"[^A-Za-z0-9_-]+", "_", name).strip("_") or "reference"
    if "filename_prefix" in save["inputs"]:
        save["inputs"]["filename_prefix"] = f"{OUTPUT_ROOT_NAME}/{project}/studio_krea/{safe}_try{attempt:02d}"

    rt.comfy_hard_free(f"Avant Krea ref {name}")
    ensure_krea_gpu_ready(label=f'Avant Krea ref {name}')
    pid = rt.queue_graph(api, str(uuid.uuid4()))
    item = _wait_comfy_image(pid, save_id)
    ann = rt.annotated_name(item)
    path = rt.annotated_to_path(comfy, ann)
    if not path.is_file():
        raise RuntimeError(f"Image Krea introuvable après rendu: {path}")
    rt.comfy_hard_free(f"Après Krea ref {name}")
    return path


def _open_image_preview(path: Path) -> None:
    if studio.enabled():
        # Images are shown in the Browser Studio; do not spawn external viewers.
        return
    try:
        if os.name == "nt":
            os.startfile(str(path))  # type: ignore[attr-defined]
        else:
            subprocess.Popen(["xdg-open", str(path)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except Exception as exc:
        print(f"      Aperçu automatique impossible ({exc}). Ouvre manuellement: {path}")


def studio_reference_image_prompt(
    backend: dict[str, Any], item: dict[str, str], content_bible: dict[str, Any], user_description: str,
    previous_prompt: str = "", correction: str = "", *, mode: str = 'text',
) -> str:
    # Leave the HISTORICAL text->image route precisely as it was in V10.24.
    # Mode and image-role metadata are supplied only for image-conditioned routes.
    system = """Tu es un REFERENCE IMAGE PROMPT WRITER pour Krea 2. Tu fabriques UNE image canonique utile à la continuité d'un film. Tu n'inventes ni identité ni lore : la bible et les précisions du créateur sont les seules autorités. Retourne uniquement le prompt final en anglais, sans titre ni explication. L'image doit être photoréaliste/live-action lorsque la bible le demande, lisible, sans texte incrusté ni collage. Pour un personnage : une seule personne clairement identifiable, visage lisible, proportions naturelles, cadrage permettant de réutiliser l'identité; un vêtement peut être montré mais n'est pas une identité permanente. Pour un décor : montrer clairement architecture, spatialité, matières et lumière, sans personnage dominant. Pour un élément : montrer son identité visuelle complète et distinctive, sans décor parasite. Évite le rendu concept-art ou game-cinematic si la bible vise le réel."""
    payload = {
        "reference_item": item,
        "creator_description": user_description or "[aucune précision supplémentaire — utiliser la bible]",
        "bible": content_bible,
    }
    if mode in ('style', 'transform'):
        system += (" En mode STYLE / S-REF, l'image source apporte uniquement son style visuel "
                   "(palette, éclairage, matières), jamais son sujet ou sa composition. "
                   "En mode TRANSFORM / img2img, la source est le sujet de départ : "
                   "conserve ce sujet et applique seulement les changements demandés.")
        payload['mode'] = mode
        payload['source_image_role'] = ('style_only_not_subject' if mode == 'style'
                                        else 'content_and_subject_to_transform')
    if previous_prompt:
        payload["previous_image_prompt"] = previous_prompt
    if correction:
        payload["creator_correction"] = correction
    return director_text(
        backend, system, json.dumps(payload, ensure_ascii=False, indent=2),
        label=f"Studio Image Prompt — {item.get('name')}", num_ctx=24576, num_predict=1200,
    ).strip()


def studio_clip_krea_prompt(backend: dict[str, Any], *, user_description: str,
                            name: str, category: str, mode: str,
                            content_bible: dict[str, Any] | None = None,
                            last_prompt: str = "") -> str:
    """Film-context reference prompt, reusing the same Director runtime.

    The supplied source image is NOT available to this text model: only its
    intended role is described. Image-content/style is handled in ComfyUI.
    """
    system = ("You are a precise Krea2 image PROMPT DIRECTOR. Return only one actionable English "
              "image-generation prompt with a clearly stated MAIN SUBJECT, framing, material, and style. "
              "Never accidentally change the requested subject into the reference-image subject. "
              "Do not invent character identities or events. For STYLE: source controls only palette, "
              "materials, visual language and lighting, NOT content/composition; create the requested NEW "
              "main subject in a suitable uncluttered framing. For TRANSFORM: same base image and subject, "
              "apply requested visual changes and preserve other important details. For TEXT: create "
              "the named subject from scratch. Respect the film universe as soft visual context.")
    payload={'subject_name':name,'subject_category':category,'mode':mode,
             'creator_instruction':user_description,
             'world_environment':str((content_bible or {}).get('world_environment') or '')[:1500],
             'previous_prompt':last_prompt[:2200],
             'source_image_role':('style_only_not_subject' if mode=='style' else
                                  'content_and_composition_to_transform' if mode=='transform' else 'none')}
    answer=director_text(backend,system,json.dumps(payload,ensure_ascii=False),
                         label='Krea Clip Prompt Director',num_ctx=8192,num_predict=950).strip()
    if not (25 <= len(answer) <= 4500):
        raise ValueError('Krea Prompt Director : proposition insuffisante, création annulée avant GPU')
    return answer


def stage_canonical_reference(
    comfy: Path, project: str, sources: list[Path], category: str, name: str,
) -> list[dict[str, Any]]:
    kind = "character" if category in {"main_character", "secondary_character"} else ("decor" if category == "decor" else "subject")
    role = "canonical_identity" if kind == "character" else ("canonical_environment" if kind == "decor" else "canonical_subject")
    strength = rt.CHAR_REF_STRENGTH if kind == "character" else rt.DECOR_REF_STRENGTH
    dest_dir = comfy / "input" / OUTPUT_ROOT_NAME / project / "canonical_refs"
    dest_dir.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[^A-Za-z0-9_-]+", "_", name).strip("_") or kind
    refs: list[dict[str, Any]] = []
    for idx, src in enumerate(sources, 1):
        ext = src.suffix.lower() or ".png"
        dst = dest_dir / f"{safe}_{idx:02d}{ext}"
        shutil.copy2(src, dst)
        rel = dst.relative_to(comfy / "input").as_posix()
        refs.append({
            "kind": kind,
            "subject_key": f"canonical_{kind}_{norm(name)}",
            "subject_name": name,
            "picture_order": 0,
            "source": str(src),
            "path": str(dst),
            "annotated": f"{rel} [input]",
            "strength": strength,
            "static": True,
            "role": role,
            "studio_category": category,
        })
    return refs


AUDIO_REF_EXTS = {".wav", ".mp3", ".m4a", ".aac", ".flac", ".ogg", ".opus"}

def collect_audio_reference_files(raw: str) -> list[Path]:
    raw = (raw or "").strip()
    if not raw:
        return []
    out: list[Path] = []
    for chunk in [c.strip() for c in raw.split(";") if c.strip()]:
        p = Path(chunk.strip().strip('"').strip("'")).expanduser()
        if p.is_dir():
            files = sorted(x for x in p.iterdir() if x.is_file() and x.suffix.lower() in AUDIO_REF_EXTS)
            if not files:
                raise RuntimeError(f"Aucun audio trouvé dans: {p}")
            out.append(files[0])
        elif p.is_file() and p.suffix.lower() in AUDIO_REF_EXTS:
            out.append(p)
        else:
            raise RuntimeError(f"Référence audio introuvable ou format non-audio: {p}")
    seen: set[str] = set()
    unique: list[Path] = []
    for f in out:
        k = str(f.resolve()).lower()
        if k not in seen:
            seen.add(k)
            unique.append(f)
    return unique

def stage_canonical_voice_reference(comfy: Path, project: str, source: Path, name: str) -> dict[str, Any]:
    dest_dir = comfy / "input" / OUTPUT_ROOT_NAME / project / "canonical_voice_refs"
    dest_dir.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[^A-Za-z0-9_-]+", "_", name).strip("_")[:64] or "character"
    ext = source.suffix.lower() or ".wav"
    dst = dest_dir / f"voice_{safe}{ext}"
    shutil.copy2(source, dst)
    rel = dst.relative_to(comfy / "input").as_posix()
    return {
        "kind": "voice",
        "subject_key": f"voice_{norm(name)}",
        "subject_name": name,
        "audio_order": 0,
        "source": str(source),
        "path": str(dst),
        "annotated": f"{rel} [input]",
        "static": True,
        "role": "canonical_voice",
        "source_kind": "studio_manual_audio_reference",
    }

def studio_audio_preproduction(
    principal_characters: list[str],
    comfy: Path,
    project: str,
    project_dir: Path,
    ref_bank: dict[str, Any],
) -> dict[str, Any]:
    bank = copy.deepcopy(ref_bank or {})
    bank.setdefault("voices", {})
    bank.setdefault("history", [])
    principals = [x for x in principal_characters or [] if norm(x)]
    if not principals:
        return bank
    print("\n[STUDIO] AUDIO REFS — personnages principaux")
    print("Les refs audio manuelles sont optionnelles. Si tu mets N, la Voice Bank automatique capturera plus tard une voix exploitable dès qu’un passage vocal propre et isolé existe dans un clip ou un shot.")
    for name in principals:
        already = next((v for k, v in (bank.get("voices") or {}).items() if norm(k) == norm(name) and isinstance(v, dict)), None)
        status = "déjà fournie" if already else "aucune"
        print(f"\nAUDIO — {name} (actuel: {status})")
        print("  [Entrée/N] aucune ref audio   [F] fournir fichier audio existant")
        action = studio_ui_choice(f'Référence audio — {name}',
            f'Voix de {name} · actuelle : {status}', [
                {'value':'','label':'Sans référence audio'},
                {'value':'f','label':'Importer un fichier audio'}]).strip().lower()
        if action not in {"f", "fichier", "file"}:
            continue
        print("  Chemin du fichier audio existant :")
        raw = studio_ui_choice(f'Importer la voix de {name}', 'Choisis un fichier audio.', [], input_type='file').strip()
        try:
            files = collect_audio_reference_files(raw)
            if not files:
                raise RuntimeError("Aucun fichier audio exploitable fourni.")
            ref = stage_canonical_voice_reference(comfy, project, files[0], name)
            bank["voices"][name] = ref
            bank["history"].append({
                "kind": "voice", "name": name, "source": "studio_manual_audio_reference", "path": ref["path"]
            })
            print(f"  OK : ref audio canonique ajoutée pour {name}.")
        except Exception as exc:
            print(f"  WARN : ref audio ignorée : {exc}")
    save_json(project_dir / "refs" / "ref_bank.json", bank)
    return bank

def studio_reference_preproduction(
    backend: dict[str, Any], content_bible: dict[str, Any], parts: list[dict[str, Any]],
    comfy: Path, objinfo: dict[str, Any], project: str, project_dir: Path,
) -> tuple[list[dict[str, Any]], list[dict[str, str]]]:
    print("\n[STUDIO] REFERENCE PLANNER — personnages / décors / éléments importants", flush=True)
    # This LLM pass can take a while. Publish before invoking it: otherwise the
    # UI misleadingly keeps showing the Content Director proposal as 'in progress'.
    studio.publish('reference_planning', 'Reference Planner — recherche des références du film',
                   {'phase':'llm','director':'content'})
    try:
        items = studio_reference_plan(backend, content_bible, parts)
    except Exception as exc:
        print(f"  WARN Reference Planner indisponible : {exc}")
        return [], []
    pre = project_dir / "preproduction"
    pre.mkdir(parents=True, exist_ok=True)
    save_json(pre / "reference_plan.json", {"items": items})
    studio.publish('references_ready', f'Reference Planner — {len(items)} référence(s) proposées',
                   {'phase':'ready','count':len(items)})
    if not items:
        print("  Aucun élément canonique proposé. Le système de refs dynamiques reste actif normalement.")
        return [], items

    labels = {
        "main_character": "PERSONNAGE PRINCIPAL",
        "secondary_character": "PERSONNAGE SECONDAIRE",
        "decor": "DÉCOR",
        "element": "ÉLÉMENT / SUJET VISUEL",
    }
    print("\nÉléments proposés par la bible :")
    for i, item in enumerate(items, 1):
        print(f"  {i:02d}. [{labels[item['category']]}] {item['name']} — {item.get('description','')}")
    print("\n[Entrée] choisir élément par élément   [S] tout ignorer et continuer comme la version Quick")
    if studio_ui_choice('Références canoniques proposées',
        'Choisir les sujets à créer ou à importer avant les scènes.', [
            {'value':'','label':'Parcourir les références une par une'},
            {'value':'s','label':'Ignorer toutes les références canoniques'}]).strip().lower() in {'s','skip','ignorer','n','non'}:
        print("  Références canoniques ignorées. Ref Quality fonctionnera comme avant pendant le film.")
        return [], items

    static_refs: list[dict[str, Any]] = []
    for i, item in enumerate(items, 1):
        progress={'index':i,'total':len(items),'remaining':len(items)-i,'accepted':len(static_refs)}
        studio.publish('references', f'Référence {i}/{len(items)} — {item["name"]}', progress)
        print(f"\n[{i}/{len(items)}] {labels[item['category']]} — {item['name']}")
        if item.get("reason"):
            print(f"  {item['reason']}")
        print("  [Entrée/N] aucune ref   [C] Krea texte   [I] Krea + image source   [F] importer")
        desc = None
        while True:
            action = studio_ui_choice(f"{labels[item['category']]} — {item['name']}", 
                item.get('description') or item.get('reason') or '', [
                    {'value':'','label':'Aucune référence'},
                    {'value':'c','label':'Créer avec Krea'},
                    {'value':'i','label':'Créer avec Krea + image source'},
                    {'value':'f','label':'Importer une image'}],progress=progress).strip().lower()
            if action not in {"c", "creer", "créer", "i", "f", "fichier"}:
                # Explicit 'Aucune référence' is TERMINAL for the current item.
                # It must never reuse a prior Krea selection or image source.
                print(f'  Aucune référence canonique demandée pour {item["name"]} ; Krea non appelé.')
                desc = None
                break
            if action in {"f", "fichier"}:
                print("  Chemin fichier/dossier image :")
                raw = studio_ui_choice(f"Importer — {item['name']}", 'Fichier image ou dossier', [], input_type='file').strip()
                try:
                    groups = rt.collect_reference_groups(raw)
                    sources = [p for g in groups for p in g]
                    static_refs.extend(stage_canonical_reference(comfy, project, sources, item["category"], item["name"]))
                    print(f"  OK : ref canonique ajoutée pour {item['name']} ({len(sources)} image(s)).")
                except Exception as exc:
                    print(f"  WARN : ref existante ignorée : {exc}")
                break

            source_image = None
            krea_mode = 'text'
            if action == 'i':
                # Existing references can ground a new costume/object/environment variant.
                while True:
                    picked_mode = studio_ui_choice(
                        f'Mode Krea + image source — {item["name"]}',
                        "Choisis comment utiliser l'image source pour cette référence.", [
                            {'value':'transform','label':'Transformer une image'},
                            {'value':'style','label':'S’inspirer d’une image — Style Transfer (S-Ref)'},
                        ]).strip().lower()
                    if picked_mode in {'__back_to_krea_choices__','b','back','retour',''}:
                        # Empty/Back returns to the reference action choice; never
                        # trap the creator in an endless mode-selection loop.
                        krea_mode = ''
                        break
                    if picked_mode in {'transform','style'}:
                        krea_mode = picked_mode
                        break
                    print('  WARN : mode Krea inconnu ; choisis Transformer ou S-Ref, ou Retour.')
                if not krea_mode:
                    continue
                choices=[{'value':str(j),'label':str(r.get('subject_name') or r.get('kind') or 'Image')}
                         for j,r in enumerate(static_refs) if r.get('path')]
                choices.append({'value':'f','label':'Importer une autre image source'})
                while True:
                    picked=studio_ui_choice(f'Image source pour {item["name"]}',
                        'Choisis une référence existante ou importe une image de départ.',choices).strip()
                    if picked=='__BACK_TO_KREA_CHOICES__':
                        source_image = Path()
                        krea_mode = ''
                        break
                    if picked.isdigit() and int(picked)<len(static_refs):
                        source_image=Path(str(static_refs[int(picked)].get('path') or ''))
                        break
                    if picked=='f':
                        imported=studio_ui_choice('Importer une source Krea',
                           'Image source pour le mode image vers image',[],input_type='file').strip()
                        if imported=='__BACK_TO_SOURCES__':
                            continue
                        if imported:source_image=Path(imported)
                    break
                if not krea_mode:
                    continue
                if not source_image or not source_image.is_file():
                    print('  WARN : source Krea absente; image ignorée (pas de repli silencieux vers texte seul).')
                    continue
            print("  Description / précisions facultatives (Entrée = laisser la bible décider) :")
            desc = studio_ui_choice(f"Précisions Krea — {item['name']}", 'Facultatif : ajoute des contraintes visuelles avant la génération.', [], input_type='text').strip()
            if desc == '__BACK_TO_KREA_CHOICES__':
                # Clear the previous render intent. A later "Aucune référence"
                # must stop immediately, with neither prompt-writer nor GPU job.
                desc = None
                source_image = None
                krea_mode = 'text'
                continue
            break
        if desc is None:
            continue
        try:
            image_prompt = studio_reference_image_prompt(backend, item, content_bible, desc, mode=krea_mode)
        except Exception as exc:
            print(f"  WARN : prompt image impossible : {exc}")
            continue
        attempt = 0
        while True:
            attempt += 1
            # Krea needs the GPU; never keep a large Director model resident during image generation.
            studio.publish('krea',f'Krea prépare {item["name"]} — essai {attempt}',{**progress,'name':item['name'],'phase':'generating'})
            release_all_text_models_for_h3(label=f"Avant Krea — {item['name']}")
            try:
                image_path = render_krea_reference(comfy, objinfo, project, item["name"], item["category"], image_prompt, attempt, source_image=source_image, mode=krea_mode)
            except Exception as exc:
                print(f"  WARN Krea : {exc}")
                break
            print(f"  Image créée : {image_path}")
            _open_image_preview(image_path)
            studio.publish('krea',f'Image Krea créée — {item["name"]}',{**progress,'name':item['name'],'phase':'ready','image_path':str(image_path)})
            print("  [Entrée/V] valider   [R] refaire (nouveau seed)   [M] modifier le prompt   [N] abandonner cette ref")
            choice = studio_ui_choice(f"Image Krea — {item['name']}", image_prompt, [
                {'value':'','label':'Valider cette image'},
                {'value':'r','label':'Refaire · nouveau seed'},
                {'value':'m','label':'Modifier le prompt'},
                {'value':'n','label':'Abandonner cette référence'}],image=image_path,progress=progress).strip().lower()
            if choice in {"", "v", "valider", "ok", "oui", "y"}:
                static_refs.extend(stage_canonical_reference(comfy, project, [image_path], item["category"], item["name"]))
                print(f"  OK : {item['name']} devient une ref canonique officielle.")
                break
            if choice in {"n", "non", "abandonner"}:
                print(f'  Image Krea non validée pour {item["name"]} : aucune référence canonique enregistrée.')
                break
            if choice in {"r", "refaire"}:
                continue
            if choice in {"m", "modifier"}:
                print("  Précision à appliquer à la prochaine image :")
                correction = studio_ui_choice(f"Modifier l'image — {item['name']}", 'Décris précisément la correction à appliquer.', [], input_type='text').strip()
                if not correction:
                    continue
                try:
                    image_prompt = studio_reference_image_prompt(
                        backend, item, content_bible, desc, previous_prompt=image_prompt, correction=correction, mode=krea_mode
                    )
                except Exception as exc:
                    print(f"  WARN : modification du prompt impossible : {exc}")
                continue
            print("  Choix non reconnu; image non validée.")

    save_json(project_dir / "refs" / "static_refs.json", static_refs)
    print(f"\n  Studio refs canoniques validées : {len(static_refs)} image(s).")
    return static_refs, items

def main() -> int:
    print("\n=== H3 VIDEO STUDIO V3.7 - PREPRODUCTION / CANONICAL REFS ===")
    print("CONTENT DIRECTOR -> STUDIO REVIEW -> REFERENCE PREPRODUCTION -> SCENE DIRECTOR -> PLAN DIRECTOR -> CLIP DIRECTOR -> REF QUALITY -> H3STUDIO")

    # Fail before running any Director if the packaged Studio helpers are missing.
    # Their explicit-path loader also works under the embedded Python -I mode.
    print("[FILM][INIT 1/5] Composants du Studio...", flush=True)
    timeline_module = studio_refbank_module('studio_timeline_extension')
    studio_refbank_module('studio_emergency_stop')

    print("[FILM][INIT 2/5] Localisation et disponibilite de ComfyUI...", flush=True)
    comfy = rt.find_comfy_dir()
    rt.wait_for_comfy()
    print("[FILM][INIT 3/5] Inventaire des noeuds H3 (object_info, 60 s)...", flush=True)
    objinfo = rt.http_json(rt.COMFY_URL + "/object_info", timeout=60)
    if "H3StudioImageToVideo" not in objinfo:
        raise RuntimeError("H3StudioImageToVideo n'est pas chargé dans ComfyUI.")
    print("[FILM][INIT 4/5] Contact Ollama (11434)...", flush=True)
    tags = rt.http_json(rt.OLLAMA_URL + "/api/tags", timeout=10)
    print("[FILM][INIT 5/5] Choix des Directeurs, puis reprise du projet...", flush=True)

    content_backend = select_text_backend(tags, role="CONTENT DIRECTOR", env_var="H3FILM_CONTENT_MODEL")
    scene_backend = select_text_backend(tags, role="SCENE DIRECTOR", env_var="H3FILM_SCENE_MODEL")
    plan_backend = select_text_backend(tags, role="PLAN DIRECTOR", env_var="H3FILM_PLAN_MODEL")
    clip_backend = select_text_backend(tags, role="CLIP DIRECTOR", env_var="H3FILM_CLIP_MODEL")
    vision_model = rt.choose_vision_model(tags)

    print(f"ComfyUI : {comfy}")
    print(f"LLM Content Director : {content_backend.get('display') or content_backend.get('model')}")
    print(f"LLM Scene Director : {scene_backend.get('display') or scene_backend.get('model')}")
    print(f"LLM Plan Director : {plan_backend.get('display') or plan_backend.get('model')}")
    print(f"LLM Clip Director : {clip_backend.get('display') or clip_backend.get('model')}")
    print(f"VLM Ref Quality : {vision_model}")

    print("\nIDÉE / CONTENU VIDÉO")
    user_prompt = " ".join(sys.argv[1:]).strip() or input("> ").strip()
    if not user_prompt:
        print("Aucune idée de contenu.")
        return 1

    print("\nDÉTAILS / PRÉCISIONS (optionnel)")
    print("Ex: éléments obligatoires, personnes/sujets, informations, fin souhaitée, contraintes, produit, message...")
    user_details = input("> ").strip()

    print("\nDURÉE TOTALE (ex: 1h, 15m, 2m ; un nombre seul = minutes)")
    requested_seconds = parse_duration_seconds(input("> ").strip())
    if requested_seconds < 5 or requested_seconds % 5 != 0:
        raise RuntimeError("La durée totale doit être un multiple de 5 secondes et au moins 5 secondes.")

    print("\nSTYLE / DIRECTION ARTISTIQUE (optionnel)")
    print("ex: blockbuster futuriste, documentaire brut, publicité luxe, vidéo YouTube dynamique")
    user_style = input("> ").strip()

    print("\nDIRECTOR H3 (optionnel — ajouté tel quel à chaque prompt envoyé à H3)")
    print("ex: consigne globale de réalisation supplémentaire ; Entrée = aucune")
    user_h3_director = input("> ").strip()

    # Optional human review of the INITIAL brief, before the first Content Director call.
    # Revisions here affect the authoritative input, never a later Director's output.
    while not os.environ.get("H3FILM_RESUME_PROJECT"):
        decision = studio.checkpoint('brief', 'Valider le brief avant Content Director', {
            'text': '\n'.join([user_prompt, user_details, f'Durée: {tc(requested_seconds)}',
                               f'Style: {user_style}', f'Direction H3: {user_h3_director}']),
            'prompt': user_prompt, 'details': user_details, 'duration': tc(requested_seconds),
            'style': user_style, 'director': user_h3_director,
        }, allow_revise=True)
        requested_change = str(decision.get('feedback') or '').strip()
        if decision.get('action') != 'revise' or not requested_change:
            break
        user_details = (user_details + '\n' + requested_change).strip()
        print('  Studio : complément ajouté au brief avant Content Director.')

    if studio.enabled() and not os.environ.get("H3FILM_RESUME_PROJECT"):
        cfg=studio._get('config.json',{})
        answers=cfg.get('initial_answers') or []
        if answers:
            answers[0]=user_details
            cfg['initial_answers']=answers
            studio._write('config.json',cfg)

    width, height = workflow_raw_dimensions()
    quality = "workflow"
    # Configuration from Studio; on resume the saved project settings below take precedence.
    studio_cfg = studio._get('config.json',{}) if studio.enabled() else {}
    content_type = str(studio_cfg.get('content_type') or 'film')
    orientation = str(studio_cfg.get('orientation') or 'landscape')


    resume_project = os.environ.get("H3FILM_RESUME_PROJECT", "").strip()
    resume_mode = bool(resume_project)
    if resume_mode and not re.fullmatch(r"[A-Za-z0-9_-]+", resume_project):
        raise RuntimeError("Nom de projet de reprise invalide")
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    project = resume_project if resume_mode else f"{stamp}_studio"
    project_dir = comfy / "output" / OUTPUT_ROOT_NAME / project
    if resume_mode and not (project_dir / "_studio" / "resume_state.json").is_file():
        raise RuntimeError("Reprise impossible : état de production absent (aucun point sûr enregistré).")
    project_dir.mkdir(parents=True, exist_ok=True)
    print(f"\nProjet : {project_dir}")
    info_file = project_dir / '_studio' / 'project_info.json'
    prior_info = json.loads(info_file.read_text(encoding='utf-8')) if resume_mode and info_file.is_file() else {}
    if resume_mode:
        # Existing historical films are landscape/Film. A project's orientation
        # and team are immutable once its first clip has been generated.
        content_type = str(prior_info.get('content_type') or 'film')
        orientation = str(prior_info.get('orientation') or 'landscape')
    teams_module = studio_refbank_module('studio_content_types')
    content_type = teams_module.normalize_type(content_type)
    if orientation not in ('landscape','portrait'):
        raise RuntimeError('Orientation invalide : '+orientation)
    hd_dimensions=(1920,1080) if orientation=='landscape' else (1080,1920)
    if orientation=='portrait':
        if (width,height)!=(1152,640):
            raise RuntimeError('Portrait refusé : dimensions RAW du workflow de base inconnues. Aucun rendu lancé.')
        width,height=640,1152
        # Give the Directors a composition cue; real pixel dimensions are set
        # independently on the H3 graph. This is never injected in landscape.
        user_style = (user_style + '\nFORMAT VERTICAL 9:16 : cadrer les sujets, actions et mouvements pour une image en hauteur ; ne pas concevoir comme une image horizontale recadrée.').strip()
    print(f"\nH3 RAW : {width}x{height} ; HD : {hd_dimensions[0]}x{hd_dimensions[1]} ; équipe : {teams_module.TYPES[content_type]}")
    prompts = teams_module.project_team(ROOT, project_dir, content_type, resume_mode)
    global CONTENT_DIRECTOR_PROMPT, SCENE_DIRECTOR_PROMPT, PLAN_DIRECTOR_PROMPT, CLIP_DIRECTOR_PROMPT
    CONTENT_DIRECTOR_PROMPT = prompts['CONTENT']
    SCENE_DIRECTOR_PROMPT = prompts['SCENE']
    PLAN_DIRECTOR_PROMPT = prompts['PLAN']
    CLIP_DIRECTOR_PROMPT = prompts['CLIP']
    if studio.enabled():
        project_title=str(studio._get('config.json',{}).get('title') or '').strip()
        if not resume_mode:
            save_json(info_file,{'title':project_title,'created':datetime.now().isoformat(),
                                 'content_type':content_type,'orientation':orientation})
        studio._write('active_project.json', {'name':project,'path':str(project_dir),'title':project_title,
                                               'content_type':content_type,'orientation':orientation})

    if resume_mode:
        print(f"  REPRISE depuis checkpoint du projet : {project}")
        content = json.loads((project_dir / 'content.json').read_text(encoding='utf-8'))
        scenes_data = json.loads((project_dir / 'scenes.json').read_text(encoding='utf-8'))
        all_scenes = scenes_data['scenes']
        if not all_scenes or not (project_dir/'film.json').is_file():
            raise RuntimeError("Reprise impossible : content/scenes/film incomplets.")
        content_bible = scenes_data['content']
        static_refs = json.loads((project_dir/'refs'/'static_refs.json').read_text(encoding='utf-8'))
        ref_bank = json.loads((project_dir/'refs'/'ref_bank.json').read_text(encoding='utf-8'))
        reference_items = json.loads((project_dir/'preproduction'/'reference_plan.json').read_text(encoding='utf-8')).get('items', []) if (project_dir/'preproduction'/'reference_plan.json').is_file() else []
    else:
        # Studio starts with an empty reference bank. Canonical refs are proposed only AFTER
        # the Content Director draft has been reviewed and validated by the user.
        static_refs: list[dict[str, Any]] = []
        ref_bank: dict[str, Any] = {
            "characters": {}, "subjects": {}, "objects": {}, "spatial": {}, "subject_attempts": {},
            "decor": {}, "global_environment": None, "voices": {}, "history": []
        }
        save_json(project_dir / "refs" / "static_refs.json", static_refs)
        save_json(project_dir / "refs" / "ref_bank.json", ref_bank)

        # 1) CONTENT DIRECTOR — whole-content design only. NO scenes here.
        print("\n[1] CONTENT DIRECTOR — conception globale — 1 appel")
        studio.publish('content_work','Content Director — écriture du film',{'phase':'llm','director':'content'})
        content_user = (
            f"INVITE UTILISATEUR :\n{user_prompt}\n\n"
            f"DÉTAILS / PRÉCISIONS UTILISATEUR :\n{user_details or '[aucune précision supplémentaire]'}\n\n"
            f"DURÉE TOTALE : {tc(requested_seconds)} ({requested_seconds} secondes)\n\n"
            f"STYLE / DIRECTION ARTISTIQUE :\n{user_style or '[non fourni — décide toi-même]'}\n\n"
            "Conçois le contenu entier et ses grandes parties. Ne produis AUCUNE scène. "
            "Les frontières des grandes parties doivent tomber sur des multiples de 5 secondes et couvrir exactement la durée totale."
        )
        content_predict = 7000 if content_backend.get("key") in {"qwen38", "jpetrina"} else 12000
        content_raw_original = ""
        content_raw_repaired = ""
        try:
            content_raw = director_text(
                content_backend, CONTENT_DIRECTOR_PROMPT, content_user,
                label="Content Director", num_ctx=32768, num_predict=content_predict,
            )
            content_raw_original = content_raw
        except Exception as exc:
            content_raw = ""
            print(f"  WARN Content Director: appel LLM indisponible — fallback minimal. {exc}")
            content = build_fallback_content(requested_seconds, user_prompt, user_details, user_style, str(exc))
        else:
            (project_dir / "content_raw.txt").write_text(content_raw, encoding="utf-8")
            try:
                content = parse_content_output(content_raw, requested_seconds, user_prompt, user_details, user_style)
            except Exception as first_exc:
                print(f"  WARN Content Director: parsing en échec — correction ciblée : {first_exc}")
                try:
                    repaired = repair_director_output(
                        content_backend, CONTENT_DIRECTOR_PROMPT, content_user, content_raw, str(first_exc),
                        label="Content Director", num_ctx=32768, num_predict=content_predict,
                    )
                    (project_dir / "content_raw_retry.txt").write_text(repaired, encoding="utf-8")
                    content = parse_content_output(repaired, requested_seconds, user_prompt, user_details, user_style)
                    content_raw_repaired = repaired
                    content_raw = repaired
                    print("  OK : Content Director corrigé après retry ciblé.")
                except Exception as second_exc:
                    content = build_fallback_content(requested_seconds, user_prompt, user_details, user_style, str(second_exc))

        if content_raw_original:
            content["raw_content_director_output_original"] = content_raw_original
        if content_raw_repaired:
            content["raw_content_director_output_repaired"] = content_raw_repaired
        save_json(project_dir / "content.json", content)
        print(f"  OK : type={content.get('content_type') or '?'}, {len(content['parts'])} grande(s) partie(s) -> content.json")

        # STUDIO: the user can reshape plot, acts/parts, personalities, relationships, dialogue density,
        # missing beats, ending, etc. before any Scene Director call exists. Enter validates immediately.
        content = studio_review_loop(
            content_backend, content, content_user, requested_seconds, user_prompt, user_details, user_style,
            project_dir, content_predict,
        )
        save_json(project_dir / "content.json", content)
        print(f"  STUDIO VALIDÉ : {len(content.get('parts', []))} grande(s) partie(s) -> content.json")

        if not same_text_backend(content_backend, scene_backend):
            unload_text_backend(content_backend, label="Après validation Content Studio — changement de modèle")

        # Compact persistent bible: enough detail for every downstream role without the raw response noise.
        content_bible = {
            "title": content.get("title", ""),
            "content_type": content.get("content_type", ""),
            "genre_tone": content.get("genre_tone", ""),
            "concept": content.get("concept", ""),
            "art_direction": content.get("art_direction", ""),
            "world_environment": content.get("world_environment", ""),
            "characters_subjects": content.get("characters_subjects", ""),
            "visual_elements": content.get("visual_elements", ""),
            "global_progression": content.get("global_progression", ""),
            "user_style_direction": content.get("user_style_direction", ""),
        }

        # STUDIO: discover refs from the validated film, then let the creator skip, supply, or create each one.
        # No mandatory refs: choosing S/none reproduces the normal dynamic Ref Quality behavior.
        static_refs, reference_items = studio_reference_preproduction(
            content_backend, content_bible, content.get("parts", []), comfy, objinfo, project, project_dir
        )
        save_json(project_dir / "refs" / "static_refs.json", static_refs)

        # Reuse the SAME Reference Planner result for audio refs. Never call the planner twice:
        # malformed helper JSON must not turn a non-critical preproduction step into a crash.
        principal_characters = [
            str(x.get("name") or "").strip()
            for x in reference_items
            if str(x.get("category") or "") == "main_character" and str(x.get("name") or "").strip()
        ]
        ref_bank = studio_audio_preproduction(principal_characters, comfy, project, project_dir, ref_bank)

        # Krea/reference prompt generation may have reloaded the Content backend. Respect the usual
        # backend boundary before Scene Director; director_text will reload transparently when needed.
        if not same_text_backend(content_backend, scene_backend):
            unload_text_backend(content_backend, label="Après préproduction refs Studio — changement de modèle")

        # 2) SCENE DIRECTOR — one call per high-level part.
        print("\n[2] SCENE DIRECTOR — découpage des grandes parties en scènes")
        scene_raw_dir = project_dir / "scenes" / "raw"
        scene_raw_dir.mkdir(parents=True, exist_ok=True)
        all_scenes: list[dict[str, Any]] = []
        previous_scene_for_scene_director: dict[str, Any] | None = None
        next_scene_number = 1

        for part in content["parts"]:
            print(f"\n  SCENE DIRECTOR — {part['name']} {part['start']}→{part['end']} — 1 appel")
            scene_user = (
                "BIBLE GLOBALE DU CONTENT DIRECTOR — AUTORITÉ SUR LE CONTENU ET L'IDENTITÉ VISUELLE :\n"
                + json.dumps(content_bible, ensure_ascii=False, indent=2)
                + "\n\nGRANDE PARTIE À TRANSFORMER EN SCÈNES — AUTORITÉ SUR CET INTERVALLE :\n"
                + json.dumps(part, ensure_ascii=False, indent=2)
                + "\n\nDERNIÈRE SCÈNE DE LA PARTIE PRÉCÉDENTE — raccord uniquement :\n"
                + (json.dumps(previous_scene_for_scene_director, ensure_ascii=False, indent=2)
                   if previous_scene_for_scene_director else "AUCUNE — début du contenu")
                + f"\n\nPREMIER NUMÉRO DE SCÈNE À UTILISER : {next_scene_number}\n"
                + f"Tes scènes doivent couvrir EXACTEMENT {part['start']} → {part['end']}, sans trou ni chevauchement, "
                  "avec des durées variables adaptées au contenu, toutes multiples de 5 secondes et jamais supérieures à 60 secondes. "
                  "Pour chaque scène, construis sa réalité concrète avec Situation initiale, Description, Logique de scène, "
                  "Continuité / éléments importants et État final. Adapte la quantité de détail à ce qui compte réellement. "
                  "Ne crée aucun plan caméra."
            )
            exact_scenes = part.get('scene_count')
            if exact_scenes is not None:
                scene_user += (f"\n\nCONTRAINTE EXPLICITE DU RÉALISATEUR : cette partie contient "
                               f"EXACTEMENT {exact_scenes} scènes, ni plus ni moins. "
                               "Conserve les scènes de 60s maximum, avec une couverture continue.")
            scene_predict = 8192 if scene_backend.get("key") in {"qwen38", "jpetrina"} else 12000
            try:
                scene_raw = director_text(
                    scene_backend, SCENE_DIRECTOR_PROMPT, scene_user,
                    label=f"Scene Director {part['name']}", num_ctx=32768, num_predict=scene_predict,
                )
            except Exception as exc:
                scene_raw = ""
                print(f"    WARN Scene Director {part['name']}: appel indisponible — fallback technique. {exc}")
                part_scenes = build_fallback_scenes(part, next_scene_number)
            else:
                raw_path = scene_raw_dir / f"part_{int(part['part']):03d}_raw.txt"
                raw_path.write_text(scene_raw, encoding="utf-8")
                try:
                    part_scenes = parse_scene_output(scene_raw, part, next_scene_number)
                except Exception as first_exc:
                    print(f"    WARN Scene Director {part['name']}: parsing en échec — correction ciblée : {first_exc}")
                    try:
                        repaired = repair_director_output(
                            scene_backend, SCENE_DIRECTOR_PROMPT, scene_user, scene_raw, str(first_exc),
                            label=f"Scene Director {part['name']}", num_ctx=32768, num_predict=scene_predict,
                        )
                        (scene_raw_dir / f"part_{int(part['part']):03d}_retry.txt").write_text(repaired, encoding="utf-8")
                        part_scenes = parse_scene_output(repaired, part, next_scene_number)
                        scene_raw = repaired
                        print(f"    OK : Scene Director {part['name']} corrigé après retry ciblé.")
                    except Exception as second_exc:
                        print(f"    WARN Scene Director {part['name']}: fallback technique après échec de correction. {second_exc}")
                        part_scenes = build_fallback_scenes(part, next_scene_number)

            if exact_scenes is not None and len(part_scenes) != exact_scenes:
                # Never silently ignore an explicit structural edit. One targeted correction,
                # then a transparent failure if the model still cannot comply.
                correction_user = (scene_user + "\n\nLA SORTIE PRÉCÉDENTE N'A PAS RESPECTÉ LA CONTRAINTE : "
                    + f"{len(part_scenes)} scènes au lieu de {exact_scenes}.\nSORTIE À CORRIGER :\n" + scene_raw
                    + f"\nRenvoie exactement {exact_scenes} scènes complètes en conservant les événements.")
                corrected = director_text(scene_backend, SCENE_DIRECTOR_PROMPT, correction_user,
                    label=f"Scene Director {part['name']} count correction", num_ctx=32768, num_predict=scene_predict)
                checked = parse_scene_output(corrected, part, next_scene_number)
                if len(checked) != exact_scenes:
                    raise RuntimeError(f"Scene Director : contrainte du réalisateur non respectée pour {part['name']}: {len(checked)} scènes au lieu de {exact_scenes}.")
                part_scenes, scene_raw = checked, corrected

            scene_raw = studio_scene_edit_source(scene_raw, part_scenes, part, next_scene_number)
            while True:
                verdict=studio.checkpoint('scenes',f"Scènes — {part['name']}",{
                    'part':part,'scenes':part_scenes,'text':scene_raw,
                },allow_revise=True,allow_redo=True)
                changes=str(verdict.get('feedback') or '').strip()
                action=str(verdict.get('action') or 'continue')
                if action=='continue':
                    direct = verdict.get('edits')
                    if isinstance(direct,dict) and 'text' in direct:
                        part_scenes = parse_scene_output(direct['text'],part,next_scene_number)
                        if exact_scenes is not None and len(part_scenes) != exact_scenes:
                            raise RuntimeError('La modification directe ne respecte pas scene_count.')
                        scene_raw = direct['text']
                    break
                if action=='revise' and not changes:
                    break
                try:
                    if action=='redo':
                        # Fresh candidate based on the original scene brief. Never copy
                        # the old proposal unless the director explicitly requests it.
                        scene_revision_user=(scene_user +
                            '\n\nNOUVELLE PROPOSITION COMPLÈTE : crée une variante différente des scènes sur les mêmes frontières temporelles.'+
                            ('\nPRÉCISIONS DU RÉALISATEUR :\n'+changes if changes else ''))
                    else:
                        scene_revision_user=(scene_user + '\n\nANCIEN DÉCOUPAGE :\n'+scene_raw+
                            '\n\nCORRECTIONS DU RÉALISATEUR :\n'+changes+
                            '\nRENVOIE toutes les scènes corrigées de cette partie, exactement sur les mêmes frontières temporelles globales.')
                    amended=director_text(scene_backend,SCENE_DIRECTOR_PROMPT,
                        scene_revision_user,
                        label=f"Scene Director {part['name']} Studio {'redo' if action=='redo' else 'revision'}",num_ctx=32768,num_predict=scene_predict)
                    tested=parse_scene_output(amended,part,next_scene_number)
                    if not tested or tested[0]['start_seconds']!=part['start_seconds'] or tested[-1]['end_seconds']!=part['end_seconds']:
                        raise ValueError('Les frontières de partie ne sont plus respectées.')
                    if exact_scenes is not None and len(tested) != exact_scenes:
                        raise ValueError(f'Contrainte de {exact_scenes} scènes non respectée.')
                    part_scenes,scene_raw=tested,amended
                    print(f"  Studio: {len(part_scenes)} scènes corrigées pour {part['name']}")
                except Exception as exc:
                    print(f'  WARN révision scènes rejetée; ancienne proposition conservée: {exc}')

            save_json(project_dir / "scenes" / f"scenes_part_{int(part['part']):03d}.json", {
                "part": part,
                "previous_scene_context": previous_scene_for_scene_director,
                "scenes": part_scenes,
                "raw_scene_director_output": scene_raw,
            })
            all_scenes.extend(part_scenes)
            next_scene_number += len(part_scenes)
            if part_scenes:
                previous_scene_for_scene_director = part_scenes[-1]
            print(f"    OK : {len(part_scenes)} scène(s)")

        if not all_scenes:
            raise RuntimeError("Scene Director n'a produit aucune scène.")
        if all_scenes[0]["start_seconds"] != 0 or all_scenes[-1]["end_seconds"] != requested_seconds:
            raise RuntimeError("Scene Director: couverture temporelle globale invalide.")
        for i in range(1, len(all_scenes)):
            if all_scenes[i - 1]["end_seconds"] != all_scenes[i]["start_seconds"]:
                raise RuntimeError(f"Scene Director: trou/chevauchement global avant scène {all_scenes[i]['scene']}.")

        save_json(project_dir / "scenes.json", {
            "content": content_bible,
            "parts": content["parts"],
            "scenes": all_scenes,
        })

    # Compatibility aggregate for all existing reference/plan/clip helpers.
    film = {
        **{k: v for k, v in content.items() if k != "raw_content_director_output"},
        "acts": [
            {
                "act": p["name"], "start_seconds": p["start_seconds"], "end_seconds": p["end_seconds"],
                "start": p["start"], "end": p["end"], "function": p.get("function", "")
            }
            for p in content["parts"]
        ],
        "scenes": all_scenes,
        "actual_duration_seconds": all_scenes[-1]["end_seconds"],
        "actual_duration": tc(all_scenes[-1]["end_seconds"]),
    }
    save_json(project_dir / "film.json", film)
    print(f"\n  OK : {len(all_scenes)} scène(s) totales -> scenes.json + film.json (compatibilité)")

    if not same_text_backend(scene_backend, plan_backend):
        unload_text_backend(scene_backend, label="Après Scene Director — changement de modèle")

    known_characters = film_character_roster(film)
    principal_characters = principal_character_names(content_bible, film, known_characters)
    persistent_character_names = [
        str(x.get("name") or "").strip()
        for x in reference_items
        if str(x.get("category") or "") in {"main_character", "secondary_character"}
        and str(x.get("name") or "").strip()
    ]
    if not persistent_character_names:
        # If preproduction reference discovery was unavailable, preserve the previous safe behavior
        # for recurring/principal characters rather than making every scene-local role persistent.
        persistent_character_names = list(principal_characters)
    recurring_subject_terms = build_recurring_visual_subject_terms(film)
    if principal_characters:
        print("  Personnages principaux — banque voix : " + ", ".join(principal_characters))
    if persistent_character_names:
        print("  Personnages durables — RefBank : " + ", ".join(persistent_character_names))
    save_json(project_dir / "refs" / "model_roles.json", {
        "content": content_backend.get("display") or content_backend.get("model"),
        "scene": scene_backend.get("display") or scene_backend.get("model"),
        "plan": plan_backend.get("display") or plan_backend.get("model"),
        "clip": clip_backend.get("display") or clip_backend.get("model"),
    })

    if studio.enabled() and not resume_mode:
        studio.save_resume_state(project_dir, {
            'completed_clip': 0, 'rendered': [], 'mc_flags': [],
            'previous_raw': '', 'previous_final': '',
            'previous_h3_prompt': '', 'previous_actual_state': '',
        })

    base, h3_id, save_id = rt.prepare_base_graph(comfy, objinfo)
    client_id = str(uuid.uuid4())

    rendered: list[str] = []
    mc_flags: list[bool] = []
    previous_h3_prompt = ""
    # Continuity states are deliberately separate:
    # - previous_raw feeds H3 Motion Context before upscale/refine
    # - previous_final feeds only the visible cumulative join
    # - H3V15Project keeps the per-project HD latent tail on disk
    previous_raw = ""
    previous_final = ""
    previous_actual_state = ""
    previous_scene: dict[str, Any] | None = None
    global_clip = 0

    resume_completed = 0
    if resume_mode:
        checkpoint = studio.load_resume_state(project_dir)
        resume_completed = int(checkpoint.get('completed_clip') or 0)
        previous_raw = str(checkpoint.get('previous_raw') or '')
        previous_final = str(checkpoint.get('previous_final') or '')
        previous_h3_prompt = str(checkpoint.get('previous_h3_prompt') or '')
        previous_actual_state = str(checkpoint.get('previous_actual_state') or '')
        rendered = list(checkpoint.get('rendered') or [])
        mc_flags = list(checkpoint.get('mc_flags') or [])
        if len(rendered) != resume_completed or len(mc_flags) != resume_completed:
            raise RuntimeError('Checkpoint incomplet : historique des vidéos incohérent')
        for ann in rendered:
            if not rt.annotated_to_path(comfy, ann).is_file():
                raise RuntimeError(f'Checkpoint invalide : vidéo disparue {ann}')
        if resume_completed:
            hd_source=project_dir/'_studio'/'checkpoints'/f'clip_{resume_completed:04d}'/'H3_HDTAIL_LAST_V15.pt'
            hd_target=comfy/'output'/'video'/'H3studio'/project/'_state'/'H3_HDTAIL_LAST_V15.pt'
            if not hd_source.is_file():
                raise RuntimeError(f'Reprise HD bloquée: archive manquante {hd_source}')
            hd_target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(hd_source, hd_target)
        print(f'  Reprise sûre : {resume_completed} clips validés, rendu suivant sans recalcul des clips précédents.')

    # Resolve by exact ZIP-local file path: ComfyUI's isolated Python (-I)
    # cannot import project files by their bare module names.
    read_pending = timeline_module.read_pending
    pending_path = timeline_module.pending_path
    extension_part = timeline_module.extension_part
    validate_future_scenes = timeline_module.validate_future_scenes
    atomic_json = timeline_module.atomic_json

    # A Studio timeline change is processed at the NEXT SAFE SCENE BOUNDARY.
    # List iteration is intentionally dynamic: newly approved unrendered scenes
    # are added without regenerating earlier clips or their saved plans.
    scene_cursor = 0
    safe_extension_cursor = 0
    # Finished-film continuation: all old clips already exist. Do not walk their
    # scenes, re-plan them or increment their clip numbers a second time.
    continuation_completed = bool(resume_mode and studio.load_resume_state(project_dir).get('completed'))
    if continuation_completed:
        if not read_pending(project_dir):
            raise RuntimeError('Film terminé : aucune extension autorisée en attente.')
        scene_cursor = len(all_scenes)
        safe_extension_cursor = scene_cursor
        global_clip = resume_completed
        previous_scene = all_scenes[-1]

    # Existing future plan files from an interrupted earlier attempt belong to
    # the OLD screenplay. Once the Director approves a replacement suffix, do
    # not silently reuse those plans (even when their lengths happen to match).
    invalidated_future_plan_start: int | None = None
    if resume_mode and resume_completed:
        # A request queued before a suspended/aborted session must never
        # regenerate a scene containing an already validated clip.
        counted = 0
        for i, existing_scene in enumerate(all_scenes):
            scene_end_clip = counted + int(existing_scene['duration_seconds']//5)
            if counted < resume_completed:
                safe_extension_cursor = i+1
            counted = scene_end_clip
            if counted >= resume_completed:
                break
    while True:
        studio.pause_boundary()
        try:
            pending_extension = read_pending(project_dir) if studio.enabled() and scene_cursor>=safe_extension_cursor else None
        except ValueError as exc:
            print(f"  ATTENTION prolongation : {exc}")
            pending_extension = None
        if pending_extension:
            request_id = str(pending_extension.get('id') or '')
            extra_seconds = int(pending_extension.get('extra_seconds') or 0)
            instructions = str(pending_extension.get('instructions') or '').strip()
            future = all_scenes[scene_cursor:]
            boundary = int(future[0]['start_seconds']) if future else int(all_scenes[-1]['end_seconds'])
            old_end = int(all_scenes[-1]['end_seconds'])
            status_file = project_dir/'_studio'/'timeline_extension_status.json'
            atomic_json(status_file, {'id':request_id,'status':'processing','boundary':boundary,
                                      'extra_seconds':extra_seconds,'instructions':instructions})
            studio.publish('extension','Prolongation — Content Director réécrit la suite',
                           {'boundary':boundary,'extra_seconds':extra_seconds})
            try:
                if not future and not extra_seconds:
                    raise ValueError('Toutes les scènes sont déjà rendues. Ajoute du temps pour continuer.')
                # Reuse the existing Content/Scene Directors, not a synthetic scenario engine.
                content_extension_user = (
                    'FILM ORIGINAL VALIDÉ — préserve absolument le passé et ses identités :\n'
                    + json.dumps(content_bible, ensure_ascii=False, indent=2)
                    + '\n\nPARTIES VALIDÉES :\n' + json.dumps(content['parts'], ensure_ascii=False, indent=2)
                    + '\n\nSCÈNES RESTANT À TOURNER (peuvent être redistribuées) :\n'
                    + json.dumps(future, ensure_ascii=False, indent=2)
                    + '\n\nDERNIÈRE SCÈNE DÉJÀ TOURNÉE (ne rien réécrire) :\n'
                    + (json.dumps(all_scenes[scene_cursor-1], ensure_ascii=False, indent=2) if scene_cursor else '[aucune]')
                    + f'\n\nFRONTIÈRE NON NÉGOCIABLE : {tc(boundary)}. '
                    + f'NOUVELLE FIN : {tc(old_end+extra_seconds)}. '
                    + 'Ne reviens jamais sur les clips déjà rendus.\n'
                    + 'DEMANDE DU RÉALISATEUR :\n' + (instructions or 'Donne davantage de temps aux événements restant à montrer.')
                    + '\n\nAgis comme Content Director : propose la progression dramatique détaillée '
                    + 'de la SEULE PARTIE NON TOURNÉE, qui couvre la frontière donnée jusqu’à la nouvelle fin. '
                    + 'Décris les séquences et leur causalité; ne rédige AUCUNE scène ni plan technique.'
                )
                revised_development = director_text(
                    content_backend, CONTENT_DIRECTOR_PROMPT, content_extension_user,
                    label='Content Director — prolongation du film',num_ctx=32768,num_predict=6500)
                if len(str(revised_development).strip()) < 40:
                    raise ValueError('Content Director : progression restante insuffisante ; demande non appliquée')
                candidate_content, extension_part_data = extension_part(
                    content, all_scenes, scene_cursor, extra_seconds, revised_development, tc)
                studio.publish('extension_scenes','Prolongation — Scene Director redistribue les scènes restantes',
                               {'boundary':boundary,'extra_seconds':extra_seconds})
                scene_extension_user = (
                    'BIBLE DE FILM VALIDÉE :\n' + json.dumps(content_bible,ensure_ascii=False,indent=2)
                    + '\n\nPROGRESSION DES PARTIES EN COURS (révision Content Director) :\n'
                    + json.dumps(extension_part_data,ensure_ascii=False,indent=2)
                    + '\n\nSCÈNES PRÉCÉDEMMENT PRÉVUES POUR LA PARTIE RESTANTE :\n'
                    + json.dumps(future,ensure_ascii=False,indent=2)
                    + '\n\nDERNIÈRE SCÈNE DÉJÀ RENDUE (raccord, ne pas modifier) :\n'
                    + (json.dumps(all_scenes[scene_cursor-1],ensure_ascii=False) if scene_cursor else '[aucune]')
                    + '\n\nINSTRUCTION DU RÉALISATEUR :\n' + instructions
                    + f'\n\nCommence à la scène {scene_cursor+1}, '
                    + f'couvre exactement {extension_part_data["start"]} → {extension_part_data["end"]} '
                    + 'sans trou/chevauchement, avec scènes de 5 à 60 secondes multiples de 5s. '
                    + 'Préserve les événements indispensables des anciennes scènes restantes, '
                    + 'en leur donnant le temps nécessaire. Ne réécris aucun clip déjà tourné.'
                )
                scene_raw = director_text(scene_backend, SCENE_DIRECTOR_PROMPT, scene_extension_user,
                                          label='Scene Director — prolongation du film',num_ctx=32768,num_predict=12000)
                next_no = scene_cursor+1
                try:
                    candidate_scenes = parse_scene_output(scene_raw, extension_part_data, next_no)
                    validate_future_scenes(candidate_scenes, extension_part_data, next_no)
                except Exception as exc:
                    corrected = repair_director_output(scene_backend, SCENE_DIRECTOR_PROMPT,
                        scene_extension_user, scene_raw, str(exc),label='Scene Director extension repair',
                        num_ctx=32768, num_predict=12000)
                    candidate_scenes = parse_scene_output(corrected, extension_part_data, next_no)
                    validate_future_scenes(candidate_scenes, extension_part_data, next_no)
                    scene_raw = corrected
                # Human Studio has a normal scene review before committing an extension.
                while True:
                    reviewed = studio.checkpoint('scenes', 'Scènes restantes — prolongation', {
                        'part':extension_part_data,'scenes':candidate_scenes,
                        'text':studio_scene_edit_source(scene_raw,candidate_scenes,extension_part_data,next_no),
                    },allow_revise=True,allow_redo=True)
                    action = str(reviewed.get('action') or 'continue')
                    if action == 'continue':
                        break
                    feedback = str(reviewed.get('feedback') or '').strip()
                    prompt = scene_extension_user+'\n\nDERNIÈRE PROPOSITION :\n'+scene_raw+'\n\nCORRECTION :\n'+(feedback or 'Propose un autre découpage des scènes.')
                    scene_raw = director_text(scene_backend,SCENE_DIRECTOR_PROMPT,prompt,
                        label='Scene Director extension revision',num_ctx=32768,num_predict=12000)
                    candidate_scenes = parse_scene_output(scene_raw,extension_part_data,next_no)
                    validate_future_scenes(candidate_scenes,extension_part_data,next_no)
                # Validation complete: commit the suffix only. Old clips + HDTAIL are immutable.
                revised_all_scenes = all_scenes[:scene_cursor] + candidate_scenes
                revised_scenes_data = {'content':content_bible,'scenes':revised_all_scenes}
                old_film = json.loads((project_dir/'film.json').read_text(encoding='utf-8'))
                old_film['scenes'] = revised_all_scenes
                old_film['parts'] = [{'part': x['part'],'kind':x['kind'],'name':x['name'],
                     'start':x['start'],'end':x['end'],'function':x.get('function','')}
                     for x in candidate_content['parts']]
                old_film['actual_duration_seconds'] = revised_all_scenes[-1]['end_seconds']
                old_film['actual_duration'] = tc(revised_all_scenes[-1]['end_seconds'])
                # Keep durable copies of the original story before changing ANY
                # timeline file. Roll back all three if an IO error occurs.
                backup=project_dir/'_studio'/'timeline_extension_backups'/request_id
                backup.mkdir(parents=True,exist_ok=True)
                targets={'content.json':candidate_content,'scenes.json':revised_scenes_data,
                         'film.json':old_film}
                for filename in targets:
                    shutil.copy2(project_dir/filename,backup/filename)
                try:
                    for filename,payload in targets.items():
                        atomic_json(project_dir/filename,payload)
                except Exception:
                    for filename in targets:
                        shutil.copy2(backup/filename,project_dir/filename)
                    raise
                all_scenes[scene_cursor:] = candidate_scenes
                invalidated_future_plan_start = scene_cursor + 1
                content = candidate_content
                known_characters = film_character_roster(old_film)
                recurring_subject_terms = build_recurring_visual_subject_terms(old_film)
                requested_seconds = old_end + extra_seconds
                (project_dir/'_studio'/'extension_content_latest.txt').write_text(revised_development,encoding='utf-8')
                atomic_json(status_file,{'id':request_id,'status':'applied',
                         'extra_seconds':extra_seconds,'total_seconds':requested_seconds,
                         'scenes_remaining':len(candidate_scenes)})
                pending_path(project_dir).unlink(missing_ok=True)
                print(f"  PROLONGATION VALIDÉE : {len(candidate_scenes)} scènes restantes, fin {tc(requested_seconds)}")
                studio.publish('extension_applied','Nouvelle durée et scènes restantes validées',
                               {'duration':requested_seconds,'scenes':len(candidate_scenes)})
            except (studio.StudioStop,studio.StudioSuspend):
                raise
            except Exception as exc:
                print(f'  ATTENTION prolongation non appliquée : {exc}')
                atomic_json(status_file,{'id':request_id,'status':'failed','error':str(exc)[:800]})
                pending_path(project_dir).unlink(missing_ok=True)
                studio.publish('extension_failed','Prolongation non appliquée — film original conservé',
                               {'error':str(exc)[:800]})
        if scene_cursor >= len(all_scenes):
            break
        scene = all_scenes[scene_cursor]
        scene_index = scene_cursor+1
        scene_cursor += 1
        parts_by_no = {int(p["part"]): p for p in content["parts"]}
        current_part = parts_by_no.get(int(scene.get("part") or 0), {})
        studio.publish('scene',f"Scène {scene['scene']} — Plan Director",{'scene':scene['scene']})

        saved_plans_path = project_dir/'plans'/f"plans_scene_{int(scene['scene']):03d}.json"
        if (resume_mode and saved_plans_path.is_file()
                and (invalidated_future_plan_start is None
                     or scene_index < invalidated_future_plan_start)):
            saved_plan = json.loads(saved_plans_path.read_text(encoding='utf-8'))
            scene_plans = saved_plan['plans']
            if len(scene_plans) != int(scene['duration_seconds']//5):
                raise RuntimeError(f"Reprise : plan de scène {scene['scene']} incomplet")
            print(f"  Reprise scène {scene['scene']}: {len(scene_plans)} plans existants réutilisés sans appel LLM.")
        else:
            # 3) PLAN DIRECTOR — exactly one LLM call for this scene.
            print(f"\n[3] PLAN DIRECTOR — scène {scene['scene']}/{len(all_scenes)} — 1 appel")
            plan_user = (
                "BIBLE GLOBALE DU CONTENT DIRECTOR — contexte persistant, ne la réécris pas :\n"
                + json.dumps(content_bible, ensure_ascii=False, indent=2)
                + "\n\nACTE / PARTIE ACTUELLE — contexte macro :\n"
                + json.dumps(current_part, ensure_ascii=False, indent=2)
                + "\n\nPRÉCISIONS / INTENTIONS GLOBALES DE L'UTILISATEUR :\n"
                + (user_details or "[aucune précision supplémentaire]")
                + "\n\nSCÈNE ACTUELLE DU SCENE DIRECTOR — SOURCE DE VÉRITÉ ABSOLUE :\n"
                + json.dumps(scene, ensure_ascii=False, indent=2)
                + "\n\nSCÈNE PRÉCÉDENTE — contexte de raccord uniquement :\n"
                + (json.dumps(previous_scene, ensure_ascii=False, indent=2) if previous_scene else "AUCUNE — première scène")
                + f"\n\nLa scène actuelle dure {scene['duration_seconds']} secondes : renvoie exactement {scene['duration_seconds']//5} plans successifs de 5 secondes. "
                  "La scène actuelle reste l'autorité absolue sur ce qui doit arriver."
            )
            try:
                plan_raw = director_text(
                    plan_backend, PLAN_DIRECTOR_PROMPT, plan_user,
                    label=f"Plan Director S{scene['scene']}", num_ctx=32768, num_predict=10000,
                )
            except Exception as exc:
                plan_raw = ""
                print(f"  WARN Plan Director S{scene['scene']}: appel LLM indisponible — fallback plans. {exc}")

            raw_plan_dir = project_dir / "plans" / "raw"
            raw_plan_dir.mkdir(parents=True, exist_ok=True)
            (raw_plan_dir / f"plan_scene_{int(scene['scene']):03d}_raw.txt").write_text(plan_raw, encoding="utf-8")
            try:
                scene_plans = parse_plan_output(plan_raw, scene, fill_missing=False)
                expected_plan_count = int(scene["duration_seconds"] // 5)
                if len(scene_plans) < expected_plan_count:
                    missing = expected_plan_count - len(scene_plans)
                    print(f"  WARN Plan Director S{scene['scene']}: sortie partielle ({len(scene_plans)}/{expected_plan_count}) — complétion LLM ciblée de {missing} plan(s).")
                    existing_summary = json.dumps([plan_context_payload(p) for p in scene_plans], ensure_ascii=False, indent=2)
                    completion_user = (
                        plan_user
                        + "\n\nPLANS DÉJÀ RÉCUPÉRÉS — VALIDES, NE PAS LES RÉÉCRIRE NI LES REJOUER :\n"
                        + existing_summary
                        + f"\n\nIl manque exactement {missing} PLAN(s) de 5 secondes à la FIN de cette scène. "
                          "Retourne UNIQUEMENT les plans manquants. Commence depuis le dernier END STATE récupéré. "
                          "Chaque nouveau plan doit apporter une progression nouvelle : ne répète aucune réplique, alerte, arrivée, révélation, action ou première apparition déjà couverte. "
                          "Le dernier plan manquant doit atteindre exactement l'ÉTAT FINAL de la scène."
                    )
                    completion_raw = director_text(
                        plan_backend, PLAN_DIRECTOR_PROMPT, completion_user,
                        label=f"Plan Director S{scene['scene']} completion", num_ctx=32768, num_predict=max(2500, missing * 2500),
                    )
                    (raw_plan_dir / f"plan_scene_{int(scene['scene']):03d}_completion.txt").write_text(completion_raw, encoding="utf-8")
                    combined_raw = (plan_raw.rstrip() + "\n\n" + completion_raw.strip()).strip()
                    completed_plans = parse_plan_output(combined_raw, scene, fill_missing=False)
                    if len(completed_plans) != expected_plan_count:
                        raise RuntimeError(f"complétion partielle encore incomplète: {len(completed_plans)}/{expected_plan_count}")
                    scene_plans = completed_plans
                    plan_raw = combined_raw
                    print(f"  OK : Plan Director S{scene['scene']} complété sans rejouer les plans récupérés.")
            except Exception as first_exc:
                print(f"  WARN Plan Director S{scene['scene']}: parsing en échec — correction ciblée : {first_exc}")
                try:
                    repaired = repair_director_output(
                        plan_backend, PLAN_DIRECTOR_PROMPT, plan_user, plan_raw, str(first_exc),
                        label=f"Plan Director S{scene['scene']}", num_ctx=32768, num_predict=10000,
                    )
                    (raw_plan_dir / f"plan_scene_{int(scene['scene']):03d}_retry.txt").write_text(repaired, encoding="utf-8")
                    scene_plans = parse_plan_output(repaired, scene, fill_missing=False)
                    if len(scene_plans) != int(scene["duration_seconds"] // 5):
                        raise RuntimeError(f"sortie corrigée incomplète: {len(scene_plans)}/{int(scene['duration_seconds'] // 5)}")
                    plan_raw = repaired
                    print(f"  OK : Plan Director S{scene['scene']} corrigé après retry ciblé.")
                except Exception as second_exc:
                    try:
                        scene_plans = parse_plan_output(plan_raw, scene, allow_count_mismatch=True)
                    except Exception:
                        scene_plans = parse_plan_output("", scene, allow_count_mismatch=True)
                    print(f"  WARN Plan Director S{scene['scene']}: fallback plans utilisé après échec de correction. {second_exc}")

            if not same_text_backend(plan_backend, clip_backend):
                unload_text_backend(plan_backend, label=f"Après Plan Director S{scene['scene']} — changement de modèle")

            plan_raw = studio_plan_edit_source(plan_raw, scene_plans, scene)
            plan_file = {
                "content_context": content_bible,
                "part_context": current_part,
                "scene": scene,
                "previous_scene_context": previous_scene,
                "plans": scene_plans,
                "raw_plan_director_output": plan_raw,
            }
            save_json(project_dir / "plans" / f"plans_scene_{int(scene['scene']):03d}.json", plan_file)
            print(f"  OK : {len(scene_plans)} plans x 5s")
            while True:
                verdict = studio.checkpoint('plans', f"Scène {scene['scene']} — Plans Director", {
                    'scene': scene, 'plans': scene_plans, 'text': plan_raw,
                }, allow_revise=True)
                correction = str(verdict.get('feedback') or '').strip()
                if verdict.get('action') == 'continue':
                    direct = verdict.get('edits')
                    if isinstance(direct,dict) and 'text' in direct:
                        scene_plans = parse_plan_output(direct['text'], scene, fill_missing=False)
                        if len(scene_plans) != scene['duration_seconds']//5:
                            raise RuntimeError('Le nombre de plans édités ne couvre pas la scène.')
                        plan_raw = direct['text']
                        plan_file['plans'], plan_file['raw_plan_director_output'] = scene_plans, plan_raw
                        save_json(project_dir / 'plans' / f"plans_scene_{int(scene['scene']):03d}.json", plan_file)
                    break
                if verdict.get('action') != 'revise' or not correction:
                    break
                print(f"  Studio: révision des plans scène {scene['scene']} : {correction}")
                try:
                    candidate = director_text(plan_backend, PLAN_DIRECTOR_PROMPT,
                        plan_user + "\n\nPLANS PROPOSÉS :\n" + plan_raw +
                        "\n\nCORRECTION OBLIGATOIRE DEMANDÉE PAR LE RÉALISATEUR :\n" + correction +
                        "\nRetourne le plan complet corrigé sans changer les frontières de la scène.",
                        label=f"Plan Director S{scene['scene']} Studio revision", num_ctx=32768, num_predict=10000)
                    candidate_plans = parse_plan_output(candidate, scene, fill_missing=False)
                    if len(candidate_plans) != scene['duration_seconds']//5:
                        raise ValueError('Nombre de plans invalide dans révision Studio')
                    scene_plans, plan_raw = candidate_plans, candidate
                    plan_file['plans'], plan_file['raw_plan_director_output'] = scene_plans, plan_raw
                    save_json(project_dir / 'plans' / f"plans_scene_{int(scene['scene']):03d}.json", plan_file)
                except Exception as exc:
                    print(f"  WARN revision plan non appliquée : {exc}")

        for plan in scene_plans:
            global_clip += 1
            if resume_mode and global_clip <= resume_completed:
                continue  # valid output and checkpoint already persisted
            studio.publish('clip',f"Clip {global_clip} — Clip Director",{'clip':global_clip})
            studio.pause_boundary()
            # 4) CLIP DIRECTOR — exactly one LLM call for this plan.
            print(f"\n[4] CLIP DIRECTOR — clip {global_clip}, scène {scene['scene']} plan {plan['plan']} — 1 appel")
            # Keep the full plan list only in saved debug JSON; never expose future plans to Clip Director.
            scene_plan_context = [plan_context_payload(p) for p in scene_plans]

            spatial_anchor = get_scene_spatial_anchor(ref_bank, scene)
            # V5.2: Clip Director knows the whole current scene so it can stage/foreshadow intelligently,
            # but the current 5-second block remains the only authority on events that may actually occur now.
            # Previous H3 prompt + Motion Context + optional pixel end-state provide continuity from the real prior clip.
            clip_user = (
                "SCÈNE COMPLÈTE — CONTEXTE DE RÉALISATION. Tu peux connaître sa progression pour mieux préparer le plan courant, mais tu ne dois jamais exécuter un événement futur avant son bloc :\n"
                + json.dumps(scene_context_payload(scene), ensure_ascii=False, indent=2)
                + "\n\nPROMPT H3 DU CLIP PRÉCÉDENT — continuité de ce qui avait été demandé juste avant :\n"
                + (previous_h3_prompt or "[aucun — premier clip]")
                + "\n\nÉTAT RÉEL COMPACT DU CLIP PRÉCÉDENT — complément pixel lorsqu'il est disponible :\n"
                + (previous_actual_state or "[aucun — premier clip ou observation indisponible]")
                + "\n\nANCRAGE SPATIAL LÉGER — faits physiques observés par personnage. Le PLAN courant reste prioritaire et peut déplacer les sujets. La caméra peut changer d'angle; ne transforme jamais ces faits en gauche/droite écran :\n"
                + (spatial_anchor or "[aucun ancrage spatial fiable]")
                + "\n\nUNIVERS / ÉPOQUE / DIRECTION DU MONDE — rappel compact, non prioritaire sur les références de décors spécifiques :\n"
                + (str(content_bible.get("world_environment") or content_bible.get("art_direction") or "[non précisé]").strip()[:550])
                + "\n\nPRÉCISIONS GLOBALES DE L'UTILISATEUR :\n"
                + (user_details or "[aucune précision supplémentaire]")
                + "\n\nPLAN TECHNIQUE COURANT — SEULE AUTORITÉ TEMPORELLE SUR CE QUI PEUT DEVENIR VISIBLE / ARRIVER PENDANT CES 5 SECONDES :\n"
                + json.dumps(plan_context_payload(plan), ensure_ascii=False, indent=2)
                + "\n\nMotion Context fournit les pixels du clip précédent lorsqu'il existe. La suite de la SCÈNE peut influencer le cadrage, l'orientation, le rythme, l'attention, la préparation spatiale ou sonore du bloc courant si cela reste naturel. Mais ne montre, ne révèle, ne déclenche et ne fais jamais réagir à un événement futur tant qu'il n'appartient pas au PLAN TECHNIQUE COURANT. Exécute les SHOTS présents et termine sur END STATE. Renvoie directement le prompt MiniMax/H3 final."
            )
            # The checkpoint is per successfully validated clip. If the user
            # stopped on a rejected RAW, don't waste an ordinary Director call
            # before recovering the rejected prompt + feedback.
            incoming_retake=project_dir/'_studio'/'gates'/f'clip_{global_clip:04d}.retake.json'
            incoming_state=json.loads(incoming_retake.read_text(encoding='utf-8')) if studio.enabled() and incoming_retake.is_file() else {}
            if incoming_state.get('status') in ('requested','approved'):
                clip_prompt=str(incoming_state.get('clip_prompt') or (json.loads((project_dir/'prompts'/f'clip_{global_clip:04d}.json').read_text(encoding='utf-8')).get('clip_director_output') if (project_dir/'prompts'/f'clip_{global_clip:04d}.json').is_file() else '') or build_fallback_clip_prompt(plan,previous_h3_prompt))
                studio.publish('retake_restore',f'Clip {global_clip} — reprise de la modification RAW',{
                    'clip':global_clip,'feedback':incoming_state.get('feedback',''),
                    'text':incoming_state.get('previous_prompt',''),'phase':'retake_restoring',
                    'started':time.time()})
            else:
                try:
                    clip_prompt = director_text(
                        clip_backend, CLIP_DIRECTOR_PROMPT, clip_user,
                        label=f"Clip Director {global_clip}", num_ctx=24576, num_predict=3500,
                    )
                except Exception as exc:
                    print(f"  WARN Clip Director {global_clip}: sortie indisponible — fallback prompt H3. {exc}")
                    clip_prompt = build_fallback_clip_prompt(plan, previous_h3_prompt)

            # The Clip Director owns creative execution, not technical Picture/Audio numbering.
            # Strip any guessed mapping before the runtime attaches the authoritative refs.
            cleaned_clip_prompt = sanitize_clip_reference_claims(creative_clip_body(clip_prompt))
            if cleaned_clip_prompt != clip_prompt.strip():
                print(f"  Clip Director {global_clip}: mapping Picture/Audio technique normalisé par le runtime.")
            clip_prompt = cleaned_clip_prompt

            # Dialogue duration budget: one targeted LLM rewrite only when a shot
            # actually contains >3 spoken words/second. Keep all actions, shots
            # and events intact. Never invent a following clip to hide extra words.
            budget_gate = studio_refbank_module('studio_dialogue_budget')
            initial_dialogue_before = clip_prompt
            initial_dialogue_auto_modified = False
            exceeded = budget_gate.check(clip_prompt)
            if exceeded:
                print('  Dialogue trop dense : '+budget_gate.feedback(exceeded))
                try:
                    shortened = director_text(
                        clip_backend, CLIP_DIRECTOR_PROMPT,
                        clip_user+'\n\nDERNIÈRE PROPOSITION H3 À CORRIGER :\n'+clip_prompt+
                        '\n\nBUDGET DE PAROLE PAR SHOT (3 mots prononcés/seconde, cumul de toutes les voix) :\n'+
                        budget_gate.feedback(exceeded)+
                        '\nGarde EXACTEMENT les shots, fenêtres, actions, personnages, raccords, son et caméra. '
                        'Raccourcis UNIQUEMENT les phrases <d> des shots trop longs. '
                        'Conserve autant de mots essentiels que le budget autorise, sans les réduire à deux mots si sept peuvent naturellement tenir. '
                        'Ne déplace pas les répliques dans un autre shot ou un futur clip. '
                        'Renvoie un prompt H3 complet corrigé, pas une explication.',
                        label=f'Clip Director {global_clip} dialogue budget', num_ctx=24576, num_predict=3500,
                    )
                    shortened = sanitize_clip_reference_claims(creative_clip_body(shortened))
                    if not budget_gate.check(shortened):
                        clip_prompt=shortened
                        initial_dialogue_auto_modified = clip_prompt != initial_dialogue_before
                        print(f'  Dialogue Clip Director {global_clip}: ramené à 3 mots/s maximum.')
                    else:
                        print('  WARN : correction de débit insuffisante, revue humaine requise avant H3.')
                except Exception as exc:
                    print(f'  WARN : révision du débit vocal indisponible : {exc}')

            # References are attached technically after the Clip Director.
            active_refs = choose_active_refs(static_refs, ref_bank, scene, plan, known_characters)
            reconciled_clip_prompt = reconcile_clip_subject_claims(clip_prompt, active_refs)
            if reconciled_clip_prompt != clip_prompt:
                print(f"  Clip Director {global_clip}: Subject N incohérent réparé par la map runtime.")
            clip_prompt = reconciled_clip_prompt
            image_prefix = reference_prompt_prefix(active_refs)
            speaker_probe = (image_prefix + "\n\n" + clip_prompt).strip() if image_prefix else clip_prompt
            active_voice_refs = choose_active_voice_refs(
                ref_bank, speaker_probe, scene, plan, principal_characters, known_characters
            )
            clip_prompt_for_h3 = inject_runtime_voice_cues(
                clip_prompt, active_refs, active_voice_refs, scene, plan,
                principal_characters, known_characters,
            )
            prefix = reference_prompt_prefix(active_refs, active_voice_refs)
            world_block = world_ambient_mini_pitch(content_bible,active_refs)
            director_block = (f"**Director :**\n{user_h3_director}" if user_h3_director else "")
            spatial_block = (
                "**Spatial continuity — soft observed facts:**\n" + spatial_anchor
                + "\nThese are camera-independent physical relations observed previously. Preserve them as the STARTING layout unless the CURRENT PLAN visibly moves/repositions a subject. Camera angle/framing may change; never force screen-left/screen-right."
                if spatial_anchor else ""
            )
            h3_prompt = "\n\n".join(
                part.strip() for part in (prefix, world_block, director_block, spatial_block, clip_prompt_for_h3) if str(part or "").strip()
            ).strip()
            retake_file=project_dir/'_studio'/'gates'/f'clip_{global_clip:04d}.retake.json'
            retake_state={}
            if studio.enabled() and retake_file.is_file():
                retake_state=json.loads(retake_file.read_text(encoding='utf-8'))
                if retake_state.get('status')=='requested' and retake_state.get('previous_prompt'):
                    # Resume exactly the latest rejected H3 prompt, not the very first
                    # Clip Director output from this plan.
                    h3_prompt=str(retake_state['previous_prompt'])
                    if 'refs' in retake_state:active_refs=retake_state['refs']
                    if 'audio_refs' in retake_state:active_voice_refs=retake_state['audio_refs']
                    prefix=reference_prompt_prefix(active_refs,active_voice_refs)
                if retake_state.get('status')=='approved' and retake_state.get('h3_prompt'):
                    h3_prompt=str(retake_state['h3_prompt'])
                    clip_prompt=str(retake_state.get('clip_prompt') or clip_prompt)
                    if 'refs' in retake_state:active_refs=retake_state['refs']
                    if 'audio_refs' in retake_state:active_voice_refs=retake_state['audio_refs']
                    studio.publish('retake_ready',f'Clip {global_clip} — correction RAW restaurée',{
                        'clip':global_clip,'text':h3_prompt,'refs':active_refs,'audio_refs':active_voice_refs,
                        'feedback':retake_state.get('feedback',''),'phase':'retake_approved'})

            default_loras = studio_refbank_module('studio_lora').normalize(
                studio._get('config.json',{}).get('loras',[]) if studio.enabled() else []
            )
            clip_loras = list(default_loras)
            # RAW retake/restart must retain the LoRA choice of the LAST sent
            # prompt, not silently revert to the film-wide preset.
            if resume_mode and retake_state.get('status') in ('requested','approved'):
                sent_file = project_dir/'prompts'/f'clip_{global_clip:04d}.json'
                if sent_file.is_file():
                    sent_data=json.loads(sent_file.read_text(encoding='utf-8'))
                    if 'loras' in sent_data:
                        clip_loras=studio_refbank_module('studio_lora').validate(sent_data['loras'],objinfo)
            while not (retake_state.get('status')=='requested'):
                if studio.enabled() and studio._get('config.json',{}).get('reviews',{}).get('clips'):
                    release_all_text_models_for_h3(label=f'Attente validation Clip Director {global_clip}')
                verdict = studio.checkpoint('clips', f"Clip {global_clip} — prompt H3 avant rendu", {
                    'clip':global_clip,'scene':scene['scene'], 'plan':plan, 'text':h3_prompt,
                    'authority_prefix':reference_prompt_prefix(active_refs,active_voice_refs),
                    'refs':active_refs,'audio_refs':active_voice_refs,'loras':clip_loras,
                    'dialogue_auto_changed':initial_dialogue_auto_modified,
                    'dialogue_previous':initial_dialogue_before if initial_dialogue_auto_modified else '',
                }, allow_revise=True, force=initial_dialogue_auto_modified)
                h3_prompt,active_refs,active_voice_refs=apply_clip_studio_edits(verdict,h3_prompt,active_refs,active_voice_refs,comfy,project_dir)
                if isinstance(verdict.get('edits'),dict) and 'loras' in verdict['edits']:
                    clip_loras=studio_refbank_module('studio_lora').validate(verdict['edits']['loras'],objinfo)
                ref_bank = json.loads((project_dir/'refs'/'ref_bank.json').read_text(encoding='utf-8'))
                static_refs = json.loads((project_dir/'refs'/'static_refs.json').read_text(encoding='utf-8'))
                prefix=reference_prompt_prefix(active_refs,active_voice_refs)
                correction=str(verdict.get('feedback') or '').strip()
                if verdict.get('action') != 'revise' or not correction:
                    break
                try:
                    clip_prompt=director_text(clip_backend, CLIP_DIRECTOR_PROMPT,
                        clip_user + "\n\nDERNIÈRE PARTIE CRÉATIVE H3 ACTUELLE (modifications directes incluses):\n" + revision_creative_context(h3_prompt) +
                        "\n\nCORRECTION DU RÉALISATEUR :\n" + correction +
                        "\nRéécris seulement la partie créative du même plan de cinq secondes sans inventer de nouvel événement." + _REVISION_CREATIVE_ONLY,
                        label=f"Clip Director {global_clip} Studio revision", num_ctx=24576,num_predict=3500)
                    clip_prompt=reconcile_clip_subject_claims(sanitize_clip_reference_claims(creative_clip_body(clip_prompt)),active_refs)
                    clip_prompt_for_h3=inject_runtime_voice_cues(clip_prompt,active_refs,active_voice_refs,scene,plan,principal_characters,known_characters)
                    world_block=world_ambient_mini_pitch(content_bible,active_refs)
                    h3_prompt="\n\n".join(p.strip() for p in (prefix,world_block,director_block,spatial_block,clip_prompt_for_h3) if p.strip()).strip()
                except Exception as exc:
                    print(f"  WARN revision Clip Director impossible : {exc}")

            h3_prompt = ensure_world_ambient_in_h3_prompt(h3_prompt,world_block)
            dialogue_gate = studio_refbank_module('studio_dialogue_budget')
            # Automatic dialogue repair, not a second independent narrative planner.
            # Keep the approved image/audio authority, shot windows, speakers, actions,
            # camera and environment byte-for-byte. Transplant only <d> content.
            def _auto_dialogue_gate(current_prompt: str, phase: str):
                def _dialogue_director(last_prompt: str, issues: list[dict], attempt: int):
                    details=dialogue_gate.feedback(issues)
                    guidance=(
                        'CORRECTION DE DIALOGUES UNIQUEMENT. La limite est 3 mots prononcés '
                        'par seconde PAR SHOT. Conserve le SENS de chaque réplique. '
                        'RÉTRÉCIS AU MINIMUM NÉCESSAIRE. Vise aussi près que possible '
                        'du plafond autorisé, sans remplissage. '
                        'Si une réplique est plus importante, tu peux répartir ses propos '
                        'sur les autres shots du MÊME clip, en particulier le SHOT '
                        'SUIVANT UNIQUEMENT si ce même locuteur y possède '
                        'DÉJÀ une balise <d> et si ce slot peut être raccourci pour '
                        'accueillir cette suite; sinon pas de déplacement. '
                        'Tu peux condenser ou remplacer le dialogue suivant du MÊME '
                        'locuteur, jamais celui d’un autre. Ne supprime jamais '
                        'un Shot ni une action du Plan Director. Si la réplique '
                        'nécessite le PROCHAIN clip, ne déplace rien silencieusement. '
                        'Si un seul Shot est disponible, si le suivant est indispensable '
                        'ou ne peut être raccourci, réduis intelligemment la réplique '
                        'en gardant le sens, l’intention, le ton et les informations '
                        'importantes. Ne transforme pas une phrase significative en '
                        'deux mots lorsque le budget permet davantage. '
                        'Renvoie le clip créatif COMPLET avec EXACTEMENT les mêmes '
                        '[Shot], horaires, locuteurs, nombre et emplacements de '
                        'balises <d>; seules les PAROLES peuvent être modifiées. '
                        'Aucune modification des personnages, des actions, de la '
                        'caméra, des sons, des événements, des références, ni des '
                        'balises techniques. Ne crée ni shot ni clip supplémentaire.'
                    )
                    reply=director_text(
                        clip_backend, CLIP_DIRECTOR_PROMPT,
                        clip_user+'\n\nDERNIER PROMPT CRÉATIF EN COURS :\n'+revision_creative_context(last_prompt)+
                        '\n\nDÉBIT DES DIALOGUES À CORRIGER :\n'+details+
                        '\n\n'+guidance,
                        label=f'Clip Director {global_clip} dialogue auto {phase} {attempt}/3',
                        num_ctx=24576, num_predict=3500)
                    return creative_clip_body(reply)
                corrected,issues=dialogue_gate.repair(current_prompt,_dialogue_director,max_attempts=3)
                if corrected!=current_prompt:
                    print(f'  Dialogues {phase} : correction automatique du Director appliquée, '
                          f'{len(dialogue_gate.check(corrected))} dépassement(s) restant(s)')
                return corrected,issues

            dialogue_override_approved = False  # explicit Studio consent only; never an automatic fallback

            def _show_corrected_dialogue(before: str, proposed: str, phase: str) -> str:
                nonlocal dialogue_override_approved
                """A Director rewrite is never silently accepted before H3.

                The existing Clip Director editor is reused, including protected
                reference management. No renderer workflow, GPU model or shot timing
                changes. A correction edited during review is budget-checked again.
                """
                nonlocal active_refs, active_voice_refs, clip_loras
                if before == proposed or not studio.enabled():
                    return proposed
                for review_attempt in range(1, 7):
                    # Forced even in Auto when the Director materially changes a
                    # line: the creator explicitly requires seeing those changes.
                    verdict = studio.checkpoint(
                        'clips', f'Clip {global_clip} — vérifier les dialogues corrigés ({phase})',
                        {'clip':global_clip,'scene':scene['scene'],'plan':plan,
                         'text':proposed,'authority_prefix':reference_prompt_prefix(active_refs,active_voice_refs),'refs':active_refs,'audio_refs':active_voice_refs,
                         'loras':clip_loras,'dialogue_auto_changed':True,
                         'dialogue_previous':before},
                        allow_revise=True, force=True)
                    if verdict.get('action') == 'revise':
                        feedback = str(verdict.get('feedback') or '').strip()
                        if not feedback:
                            continue
                        response = director_text(
                            clip_backend, CLIP_DIRECTOR_PROMPT,
                            clip_user+'\n\nDERNIER PROMPT CRÉATIF :\n'+revision_creative_context(proposed)+
                            '\n\nCORRECTION DU RÉALISATEUR SUR LES DIALOGUES :\n'+feedback+
                            '\nPréserve les personnes, les événements, les fenêtres temporelles, '
                            'les sons, la caméra et tous les blocs de références. '
                            'Garde un maximum de mots utiles sans dépasser 3 mots/seconde par shot. '
                            'Rends le prompt créatif complet avec les mêmes <d> aux mêmes emplacements.',
                            label=f'Clip Director {global_clip} revue dialogues {review_attempt}',
                            num_ctx=24576,num_predict=3500)
                        try:
                            candidate = dialogue_gate.transplant_spoken(
                                proposed, creative_clip_body(response))
                        except ValueError as exc:
                            print(f'  Revue dialogue : proposition refusée : {exc}')
                            continue
                    else:
                        candidate, active_refs, active_voice_refs = apply_clip_studio_edits(
                            verdict, proposed, active_refs, active_voice_refs, comfy, project_dir)
                        if isinstance(verdict.get('edits'),dict) and 'loras' in verdict['edits']:
                            clip_loras=studio_refbank_module('studio_lora').validate(
                                verdict['edits']['loras'],objinfo)
                    issues=dialogue_gate.check(candidate)
                    if issues and verdict.get('action')=='continue':
                        # The creator has read/edited this prompt and explicitly pressed
                        # Valider. Respect that choice rather than imposing a fresh loop.
                        dialogue_override_approved=True
                        print('  AVERTISSEMENT : dialogue validé explicitement malgré budget : '+dialogue_gate.feedback(issues))
                        return candidate
                    if issues:
                        repaired, remaining=_auto_dialogue_gate(candidate,'retouches utilisateur')
                        if remaining:
                            print('  Revue dialogue : dépassement persistant — correction à valider, pas de H3. '+dialogue_gate.feedback(remaining))
                            before=candidate
                            proposed=candidate
                            continue
                        before=candidate
                        proposed=repaired
                        continue
                    if verdict.get('action') == 'revise' and candidate != proposed:
                        before=proposed
                        proposed=candidate
                        continue
                    return candidate
                raise ValueError('Dialogues : nombre de retouches dépassé. Le rendu reste bloqué pour éviter un dialogue non validé.')

            # An already requested RAW retake must go to its Director first.
            # Never spend an extra LLM call rewriting the rejected version.
            if retake_state.get('status') == 'requested':
                dialogue_overflow = []
            else:
                dialogue_before_validation=h3_prompt
                h3_prompt, dialogue_overflow = _auto_dialogue_gate(h3_prompt,'validation')
                if not dialogue_overflow:
                    h3_prompt = _show_corrected_dialogue(dialogue_before_validation,h3_prompt,'validation')
            while dialogue_overflow:
                details = dialogue_gate.feedback(dialogue_overflow)
                if not studio.enabled() or studio._get('config.json',{}).get('mode') == 'auto':
                    raise ValueError('Clip Director : impossible de conserver le sens du dialogue '
                                     'dans les fenêtres existantes après trois corrections. '
                                     'Le plan suivant doit reprendre le dialogue (pas de report '
                                     'silencieux). '+details)
                # Emergency Studio fallback after autonomous corrections failed.
                # A human may explicitly approve the remaining dialogue as-is.
                release_all_text_models_for_h3(label=f'Dialogue toujours trop long clip {global_clip}')
                correction_verdict = studio.checkpoint('clips',f'Clip {global_clip} — dialogue non résolu après 3 essais',{
                    'clip':global_clip,'scene':scene['scene'],'plan':plan,
                    'text':h3_prompt,'authority_prefix':reference_prompt_prefix(active_refs,active_voice_refs),'refs':active_refs,'audio_refs':active_voice_refs,
                    'loras':clip_loras,'dialogue_issue':details,
                },allow_revise=True,force=True)
                if correction_verdict.get('action')=='revise':
                    feedback=str(correction_verdict.get('feedback') or '').strip() or details
                    revised = director_text(clip_backend,CLIP_DIRECTOR_PROMPT,
                        clip_user+'\n\nDERNIER PROMPT CRÉATIF :\n'+revision_creative_context(h3_prompt)+
                        '\n\nPRÉCISIONS DU RÉALISATEUR :\n'+feedback+
                        '\nGarde le sens des répliques. Raccourcis si possible, sinon '
                        'répartis entre les shots déjà parlés, ou indique qu’une suite '
                        'dans le prochain clip est nécessaire. Ne modifie pas les actions.',
                        label=f'Clip Director {global_clip} dialogue fallback',num_ctx=24576,num_predict=3500)
                    try:h3_prompt=dialogue_gate.transplant_spoken(h3_prompt,creative_clip_body(revised))
                    except ValueError as err:print(f'  WARN : révision dialogue rejetée : {err}')
                else:
                    h3_prompt,active_refs,active_voice_refs=apply_clip_studio_edits(
                        correction_verdict,h3_prompt,active_refs,active_voice_refs,comfy,project_dir)
                    if isinstance(correction_verdict.get('edits'),dict) and 'loras' in correction_verdict['edits']:
                        clip_loras=studio_refbank_module('studio_lora').validate(
                            correction_verdict['edits']['loras'],objinfo)
                    prefix=reference_prompt_prefix(active_refs,active_voice_refs)
                h3_prompt=ensure_world_ambient_in_h3_prompt(h3_prompt,world_block)
                if correction_verdict.get('action')=='continue':
                    # Approval of the FORCED dialogue-warning review is an explicit
                    # human decision: do not force another three LLM rewrites.
                    remaining=dialogue_gate.check(h3_prompt)
                    if remaining:
                        dialogue_override_approved=True
                        print('  AVERTISSEMENT : débit de dialogue accepté par le réalisateur : '+dialogue_gate.feedback(remaining))
                    dialogue_overflow=[]
                    break
                dialogue_before_revalidation=h3_prompt
                h3_prompt,dialogue_overflow=_auto_dialogue_gate(h3_prompt,'revalidation')
                if not dialogue_overflow:
                    h3_prompt=_show_corrected_dialogue(dialogue_before_revalidation,h3_prompt,'revalidation')
            future_plans_for_objects = [
                p for p in scene_plans if int(p.get("plan") or 0) > int(plan.get("plan") or 0)
            ]
            continuity_object_candidates = plan_continuity_object_candidates(
                clip_backend, h3_prompt, plan, future_plans_for_objects,
                label=f"Object Continuity Planner clip {global_clip}",
            )
            if continuity_object_candidates:
                print("  Objets continuité candidats : " + " | ".join(
                    f"{x.get('label')} @{float(x.get('start_s') or 0):.2f}-{float(x.get('end_s') or 0):.2f}s -> plans {x.get('future_plan_numbers')}"
                    for x in continuity_object_candidates
                ))

            prompt_dir = project_dir / "prompts"
            prompt_dir.mkdir(parents=True, exist_ok=True)
            (prompt_dir / f"clip_{global_clip:04d}.txt").write_text(h3_prompt, encoding="utf-8")
            save_json(prompt_dir / f"clip_{global_clip:04d}.json", {
                "content_context": content_bible,
                "part_context": part_context_payload(current_part),
                "scene": scene["scene"],
                "scene_context": scene_context_payload(scene),
                "all_scene_plans": scene_plan_context,
                "plan": plan_context_payload(plan),
                "previous_actual_state": previous_actual_state,
                "previous_h3_prompt": previous_h3_prompt,
                "clip_director_output": clip_prompt,
                "active_references": active_refs,
                "active_audio_references": active_voice_refs,
                "director_h3_instruction": user_h3_director,
                "continuity_object_candidates": continuity_object_candidates,
                "h3_prompt_sent": h3_prompt,
                "dialogue_budget_human_override": dialogue_override_approved,
                "dialogue_budget_warning_at_approval": dialogue_gate.feedback(dialogue_gate.check(h3_prompt)) if dialogue_override_approved else '',
                "loras": clip_loras,
            })

            studio.publish('render', f'Clip {global_clip} — génération RAW / HD', {
                'clip': global_clip, 'scene': scene['scene'], 'plan': plan.get('plan'),
                'text': h3_prompt, 'refs': active_refs, 'audio_refs': active_voice_refs,
                'previous_raw': previous_raw, 'phase': 'raw',
            })
            # Release LLM before H3 for VRAM safety.
            release_all_text_models_for_h3(label=f"Avant H3 clip {global_clip}")

            print(
                f"  H3Studio clip {global_clip} | refs={len(active_refs)} | voice_refs={len(active_voice_refs)} "
                f"| Motion Context={'OUI' if previous_raw else 'NON'} | Last FINAL={'OUI' if previous_final else 'NON'}"
            )
            rendered_ok=False
            for studio_raw_attempt in range(12):
                studio.publish('render', f'Clip {global_clip} — RAW/HD (essai {studio_raw_attempt+1})', {
                    'clip': global_clip, 'scene': scene['scene'], 'plan': plan.get('plan'),
                    'text': h3_prompt, 'refs': active_refs, 'audio_refs': active_voice_refs,
                    'previous_raw': previous_raw,
                })
                try:
                    h3_prompt=ensure_world_ambient_in_h3_prompt(h3_prompt,world_block)
                    # A retake requested by the user before a restart must NOT render
                    # the original prompt again. Route through the same Clip Director
                    # recovery as an in-session RAW rejection.
                    retake=retake_file.is_file() and json.loads(retake_file.read_text(encoding='utf-8')) or {}
                    if retake.get('status')=='requested':
                        raise RuntimeError('Retake RAW persistant : révision du Clip Director avant GPU')
                    final_before_gate=h3_prompt
                    if dialogue_override_approved:
                        # Still record any warning. The user—not the Director—approved it.
                        last_dialogue_issues=dialogue_gate.check(h3_prompt)
                        if last_dialogue_issues:
                            print('  AVERTISSEMENT confirmé avant H3 (dérogation utilisateur) : '+dialogue_gate.feedback(last_dialogue_issues))
                    else:
                        h3_prompt, last_dialogue_issues = _auto_dialogue_gate(h3_prompt,'avant RAW/H3')
                        if last_dialogue_issues:
                            raise dialogue_gate.DialogueBudgetError('Débit dialogue non résolu : rendu H3 interdit. '+
                                                                     dialogue_gate.feedback(last_dialogue_issues))
                    if h3_prompt != final_before_gate:
                        h3_prompt=_show_corrected_dialogue(final_before_gate,h3_prompt,'avant H3')
                        # This final review may itself change refs or text. Recheck
                        # before touching ComfyUI; no silent over-budget approval.
                        if dialogue_gate.check(h3_prompt):
                            raise dialogue_gate.DialogueBudgetError('Dialogue modifié après revue : toujours trop de mots. '+
                                                                      dialogue_gate.feedback(dialogue_gate.check(h3_prompt)))
                        # Persist final spoken words before GPU. The original refs,
                        # motion context and technical H3 blocks are untouched.
                        (prompt_dir/f'clip_{global_clip:04d}.txt').write_text(h3_prompt,encoding='utf-8')
                        metadata=project_dir/'prompts'/f'clip_{global_clip:04d}.json'
                        if metadata.is_file():
                            saved=json.loads(metadata.read_text(encoding='utf-8'))
                            saved['h3_prompt_sent']=h3_prompt
                            saved.setdefault('dialogue_revisions',[]).append({'phase':'pre_h3','prompt':h3_prompt})
                            save_json(metadata,saved)
                        if retake.get('status')=='approved':
                            retake['h3_prompt']=h3_prompt
                            tmp=retake_file.with_suffix('.retake.tmp')
                            tmp.write_text(json.dumps(retake,ensure_ascii=False,indent=2),encoding='utf-8')
                            os.replace(tmp,retake_file)
                    video_ann, raw_ann, cumulative_final_ann, used_mc = render_clip(
                        base, h3_id, save_id, comfy, project, client_id, global_clip,
                        h3_prompt, active_refs, active_voice_refs, previous_raw, previous_final, width, height,
                        force_mc_reencode=((resume_mode and global_clip == resume_completed + 1)
                            or ('RAW_RETOUCHED_' in previous_raw)),
                        loras=clip_loras, lora_objinfo=objinfo, hd_dimensions=hd_dimensions,
                    )
                    rendered_ok=True
                    break
                except Exception as exc:
                    # A speech-budget rejection is NOT a ComfyUI failure. Do not
                    # consume another RAW attempt, nor silently omit this clip
                    # from the final montage. Preserve its checkpoint for review.
                    if isinstance(exc, dialogue_gate.DialogueBudgetError):
                        raise
                    redo_file=project_dir/'_studio'/'gates'/f'clip_{global_clip:04d}.redo.json'
                    retake=retake_file.is_file() and json.loads(retake_file.read_text(encoding='utf-8')) or {}
                    if studio.enabled() and (redo_file.is_file() or retake.get('status')=='requested'):
                        feedback=str(retake.get('feedback') or '')
                        if not feedback and redo_file.is_file():
                            feedback=json.loads(redo_file.read_text(encoding='utf-8')).get('feedback','')
                        # Keep the durable retake request until the revised prompt has
                        # actually been approved and persisted. Never drop it here.
                        redo_file.unlink(missing_ok=True)
                        if not feedback.strip(): feedback='Refais ce RAW avec une autre réalisation du même plan, plus fidèle au plan source.'
                        print(f"  STUDIO : RAW refusé, retour au Clip Director. Correction : {feedback}")
                        studio.publish('retake_preparing',f'Clip {global_clip} — libération GPU avant correction',{
                            'clip':global_clip,'text':h3_prompt,'refs':active_refs,'audio_refs':active_voice_refs,
                            'feedback':feedback,'phase':'retake_unloading'})
                        rt.comfy_hard_free(f'RAW rejected clip {global_clip}')
                        # Always use latest approved text for in-process retakes; on restart
                        # the requested state was recovered from the latest prompts/clip_N.txt.
                        rejected_h3_prompt=h3_prompt
                        studio.publish('director',f'Clip Director — correction du RAW clip {global_clip}',{
                            'clip':global_clip,'text':rejected_h3_prompt,'refs':active_refs,
                            'audio_refs':active_voice_refs,'feedback':feedback,'phase':'retake_director',
                            'started':time.time()})
                        try:
                            clip_prompt=director_text(clip_backend,CLIP_DIRECTOR_PROMPT,
                                clip_user + '\n\nDERNIER PROMPT CRÉATIF H3 REJETÉ :\n'+revision_creative_context(rejected_h3_prompt)+'\n\nMODIFICATIONS DU RÉALISATEUR :\n'+feedback+'\nRéécris seulement le contenu créatif de ce même plan.'+_REVISION_CREATIVE_ONLY,
                                label=f'Clip Director {global_clip} RAW redo',num_ctx=24576,num_predict=3500)
                            clip_prompt=reconcile_clip_subject_claims(sanitize_clip_reference_claims(creative_clip_body(clip_prompt)),active_refs)
                            cue=inject_runtime_voice_cues(clip_prompt,active_refs,active_voice_refs,scene,plan,principal_characters,known_characters)
                            h3_prompt='\n\n'.join(p.strip() for p in (prefix,world_block,director_block,spatial_block,cue) if p.strip()).strip()
                            # Always show the revised prompt and source plan before another costly RAW.
                            # This review is forced even if ordinary pre-clip reviews are disabled.
                            while studio.enabled():
                                release_all_text_models_for_h3(label=f'Attente validation retake clip {global_clip}')
                                review=studio.checkpoint('clips',f'Clip {global_clip} — vérifier la correction RAW',{
                                    'clip':global_clip,'scene':scene['scene'],'plan':plan,
                                    'text':h3_prompt,'authority_prefix':reference_prompt_prefix(active_refs,active_voice_refs),'refs':active_refs,'audio_refs':active_voice_refs,
                                    'feedback':feedback,'previous_prompt':rejected_h3_prompt,
                                    'raw_retake':True,
                                },allow_revise=True,force=True)
                                h3_prompt,active_refs,active_voice_refs=apply_clip_studio_edits(review,h3_prompt,active_refs,active_voice_refs,comfy,project_dir)
                                ref_bank = json.loads((project_dir/'refs'/'ref_bank.json').read_text(encoding='utf-8'))
                                static_refs = json.loads((project_dir/'refs'/'static_refs.json').read_text(encoding='utf-8'))
                                prefix=reference_prompt_prefix(active_refs,active_voice_refs)
                                followup=str(review.get('feedback') or '').strip()
                                if review.get('action')!='revise' or not followup:break
                                clip_prompt=director_text(clip_backend,CLIP_DIRECTOR_PROMPT,
                                    clip_user+'\n\nDERNIER PROMPT CRÉATIF H3 À REVOIR:\n'+revision_creative_context(h3_prompt)+'\n\nCORRECTION DU RÉALISATEUR:\n'+followup+
                                    '\nRéécris seulement le contenu créatif de ce plan.'+_REVISION_CREATIVE_ONLY,
                                    label=f'Clip Director {global_clip} RAW revised review',num_ctx=24576,num_predict=3500)
                                clip_prompt=reconcile_clip_subject_claims(sanitize_clip_reference_claims(creative_clip_body(clip_prompt)),active_refs)
                                cue=inject_runtime_voice_cues(clip_prompt,active_refs,active_voice_refs,scene,plan,principal_characters,known_characters)
                                h3_prompt='\n\n'.join(p.strip() for p in (prefix,world_block,director_block,spatial_block,cue) if p.strip()).strip()
                            # RAW retake: validate the NEW words BEFORE persisting the approved
                            # retake or launching a second GPU render. The pre-H3 gate below
                            # performs another independent validation on every attempt.
                            before_retake_dialogue=h3_prompt
                            h3_prompt, retake_dialogue_issues=_auto_dialogue_gate(h3_prompt,'retake RAW')
                            if retake_dialogue_issues:
                                raise ValueError('Correction RAW : dialogue encore trop long après les essais du Director. '
                                                 +dialogue_gate.feedback(retake_dialogue_issues))
                            if h3_prompt!=before_retake_dialogue:
                                h3_prompt=_show_corrected_dialogue(before_retake_dialogue,h3_prompt,'retake RAW')
                                if dialogue_gate.check(h3_prompt):
                                    raise ValueError('Correction RAW : dialogue toujours trop long après validation. '
                                                     +dialogue_gate.feedback(dialogue_gate.check(h3_prompt)))
                            (prompt_dir/f'clip_{global_clip:04d}.txt').write_text(h3_prompt,encoding='utf-8')
                            # Record the revision without losing original prompt metadata.
                            original_path=prompt_dir/f'clip_{global_clip:04d}.json'
                            meta=json.loads(original_path.read_text(encoding='utf-8'))
                            meta.setdefault('revisions',[]).append({'feedback':feedback,'prompt':h3_prompt,'time':datetime.now().isoformat()})
                            meta['h3_prompt_sent']=h3_prompt
                            meta['clip_director_output']=clip_prompt
                            meta['active_references']=active_refs
                            meta['active_audio_references']=active_voice_refs
                            save_json(original_path,meta)
                            # Commit only AFTER the director generated a prompt and the
                            # user accepted it. A crash before this point keeps 'requested'.
                            retake_state={'clip':global_clip,'status':'approved','feedback':feedback,
                                          'previous_prompt':rejected_h3_prompt,'h3_prompt':h3_prompt,
                                          'clip_prompt':clip_prompt,'refs':active_refs,'audio_refs':active_voice_refs,'approved_at':time.time()}
                            tmp=retake_file.with_suffix('.retake.tmp')
                            tmp.write_text(json.dumps(retake_state,ensure_ascii=False,indent=2),encoding='utf-8')
                            os.replace(tmp,retake_file)
                        except Exception as revision_exc:
                            raise RuntimeError(f'Clip Director RAW refusé : correction impossible, ancien prompt NON réutilisé : {revision_exc}') from revision_exc
                        release_all_text_models_for_h3(label=f"Avant nouveau RAW clip {global_clip}")
                        continue
                    # A validated retouch must never be silently dropped from the film.
                    # Preserve the raw original, approved MP4 and failed HD evidence.
                    handoff=project_dir/'_studio'/'gates'/f'clip_{global_clip:04d}.retouch.handoff.json'
                    pending_retouch=project_dir/'_studio'/'gates'/f'clip_{global_clip:04d}.retouch.requested.json'
                    if handoff.is_file() or pending_retouch.is_file():
                        raise RuntimeError(f'Retouche validée clip {global_clip}: reprise HD impossible. Film arrêté sans ignorer le clip. Détail: {exc}') from exc
                    print(f"  WARN H3 clip {global_clip}: génération échouée — clip ignoré, suite du contenu. {exc}")
                    rt.comfy_hard_free(f"Après échec H3 clip {global_clip}")
                    break
            if not rendered_ok:
                continue
            rendered.append(video_ann)
            mc_flags.append(used_mc)
            previous_raw = raw_ann
            previous_final = cumulative_final_ann
            previous_h3_prompt = h3_prompt
            if studio.enabled():
                # Immutable per-clip history. H3RefineBridge itself is not altered.
                checkpoint_dir=project_dir/'_studio'/'checkpoints'/f'clip_{global_clip:04d}'
                checkpoint_dir.mkdir(parents=True,exist_ok=True)
                archived=[]
                # H3RefineBridge V15 writes under output/video/H3studio/<project>/_state,
                # NOT under output/H3FilmSimple/<project>/_state.
                hd_source=comfy/'output'/'video'/'H3studio'/project/'_state'/'H3_HDTAIL_LAST_V15.pt'
                if hd_source.is_file():
                    dest=checkpoint_dir/hd_source.name
                    shutil.copy2(hd_source,dest)
                    archived.append(str(dest))
                else:
                    print(f'  STUDIO WARN: HD tail absent, checkpoint clip {global_clip} RAW-only: {hd_source}')
                # The retouched composite is never the same latent as the original
                # RAW .pt. Registry keeps the authentic RAW/.pt pair for future Retake.
                handoff_data=json.loads((project_dir/'_studio'/'gates'/f'clip_{global_clip:04d}.retouch.handoff.json').read_text('utf-8')) if (project_dir/'_studio'/'gates'/f'clip_{global_clip:04d}.retouch.handoff.json').is_file() else {}
                original_raw=handoff_data.get('source_original_raw') or raw_ann
                studio.snapshot_clip(project_dir,global_clip,{
                    'clip':global_clip,'scene':scene['scene'],'plan':plan.get('plan'),
                    'raw':original_raw,'retouched_raw':raw_ann if handoff_data else '',
                    'video':video_ann,'final':cumulative_final_ann,
                    'raw_pt':str(project_dir/'_state'/f'clip_{global_clip:04d}_RAW_LATENT.pt'),
                    'hd_pt_archives':archived,'prompt_file':str(project_dir/'prompts'/f'clip_{global_clip:04d}.txt'),
                    'refs':[r.get('annotated') for r in active_refs],
                    'voices':[r.get('annotated') for r in active_voice_refs],
                    'mc':used_mc,'created':datetime.now().isoformat(),
                })
            print(f"  OK VISIBLE -> {video_ann}")
            print(f"     RAW MC   -> {raw_ann}")
            if cumulative_final_ann != video_ann:
                print(f"     FINAL    -> {cumulative_final_ann}")

            rt.comfy_hard_free(f"Après H3 clip {global_clip}")

            video_path = rt.annotated_to_path(comfy, video_ann)

            # Voice bank: zero work on silent/non-dialogue clips. Capture only the first
            # usable clean single-speaker dialogue clip/shot segment for a principal character, then reuse it.
            try:
                ref_bank = maybe_capture_voice_reference(
                    ref_bank, h3_prompt, scene, plan, principal_characters, known_characters,
                    video_path, used_mc, comfy, project, global_clip,
                )
                save_json(project_dir / "refs" / "ref_bank.json", ref_bank)
            except Exception as exc:
                print(f"    Attention Voice Ref : {exc}")

            frame_dir = project_dir / "ref_quality_frames" / f"clip_{global_clip:04d}"
            try:
                frames = rt.extract_observer_frames(video_path, frame_dir, skip_frames=rt.MOTION_FRAMES if used_mc else 0)
                observation = observe_clip_end_state(
                    vision_model, frames, plan, scene=scene, h3_prompt=h3_prompt,
                    known_characters=known_characters,
                    character_context=str(content_bible.get("characters_subjects") or ""),
                    future_scene_plans=[p for p in scene_plans if int(p.get("plan") or 0) > int(plan.get("plan") or 0)],
                )
                observed_state = str(observation.get("state") or "").strip()
                visible_character_names = list(observation.get("visible_characters") or [])
                pixel_identity_failed = str(observation.get("observer_status") or "") == "failed"
                spatial_facts = list(observation.get("spatial_facts") or [])
                continuity_objects = continuity_object_candidates
                if observed_state:
                    previous_actual_state = observed_state
                    print(f"    Pixel Continuity : {observed_state}")
                    if visible_character_names:
                        print("    Pixel Identity : " + ", ".join(visible_character_names))
                    elif pixel_identity_failed:
                        print("    Pixel Identity : observation vision indisponible -> frame-router ciblé par personnage")
                else:
                    previous_actual_state = str(plan.get("end_state") or "").strip()
                if spatial_facts:
                    ref_bank = update_scene_spatial_facts(ref_bank, scene, spatial_facts, global_clip)
                    print("    Spatial Continuity : " + " | ".join(f"{x.get('subject')}: {x.get('relation')}" for x in spatial_facts if isinstance(x, dict)))
                before = json.dumps(ref_bank, sort_keys=True, ensure_ascii=False)
                # Character Appearance is gated by the SAME vision observation that produced
                # Pixel Continuity. If that vision call itself fails, do not turn the failure into
                # a hard veto: let the existing character-specific frame router try safely.
                # If vision succeeds but no identity is safe, keep previous appearance refs.
                appearance_visible_filter = None if pixel_identity_failed else visible_character_names
                if not visible_character_names and not pixel_identity_failed:
                    print("    Pixel Identity : aucune identité sûre -> Ref Appearance inchangée pour ce clip")
                ref_bank = update_reference_bank(
                    vision_model, static_refs, ref_bank, frames, scene, plan,
                    comfy, project, global_clip,
                    known_characters=known_characters,
                    recurring_subject_terms=recurring_subject_terms,
                    h3_prompt=h3_prompt,
                    video_path=video_path,
                    visible_character_names=appearance_visible_filter,
                    persistent_character_names=persistent_character_names,
                    character_context=str(content_bible.get("characters_subjects") or ""),
                    continuity_objects=continuity_objects,
                )
                if not ref_bank.get("global_environment"):
                    ref_bank = ensure_global_environment_reference(
                        vision_model, ref_bank, frames, plan, comfy, project, global_clip, video_path=video_path
                    )
                save_json(project_dir / "refs" / "ref_bank.json", ref_bank)
                after = json.dumps(ref_bank, sort_keys=True, ensure_ascii=False)
                if before == after:
                    print("    Ref Quality : aucune nouvelle référence retenue.")
            except Exception as exc:
                print(f"    Attention Ref Quality : {exc}")
            finally:
                rt.unload_ollama_model(vision_model)
                rt.unload_all_ollama_models()
                rt.wait_ollama_released(vision_model, max_wait=75, label=f"Après Ref Quality clip {global_clip}")

            # This is the safe, durable resume boundary: AFTER Ref Quality and reference bank writes.
            if studio.enabled():
                studio.save_resume_state(project_dir, {
                    'completed_clip': global_clip, 'rendered': rendered, 'mc_flags': mc_flags,
                    'previous_raw': previous_raw, 'previous_final': previous_final,
                    'previous_h3_prompt': previous_h3_prompt, 'previous_actual_state': previous_actual_state,
                })
                # Do not discard the approved retake until Ref Quality and the
                # immutable project checkpoint are BOTH safely committed.
                retake_file.unlink(missing_ok=True)
                (project_dir/'_studio'/'gates'/f'clip_{global_clip:04d}.redo.json').unlink(missing_ok=True)
        previous_scene = scene

    print("\n[FINAL] Assemblage des clips avec retrait exact du chevauchement Motion Context...")
    final_path = project_dir / "VIDEO_FINAL.mp4"
    if not rendered:
        print("WARN FINAL : aucun clip H3 n'a pu être rendu. Le projet est conservé sans vidéo finale.")
        save_json(project_dir / "run_summary.json", {
            "project": project,
            "content_json": str(project_dir / "content.json"),
            "scenes_json": str(project_dir / "scenes.json"),
            "film_compat_json": str(project_dir / "film.json"),
            "scene_count": len(all_scenes), "clip_count": 0, "final_video": "",
            "content_model": content_backend.get("display") or content_backend.get("model"),
            "scene_model": scene_backend.get("display") or scene_backend.get("model"),
            "plan_model": plan_backend.get("display") or plan_backend.get("model"),
            "clip_model": clip_backend.get("display") or clip_backend.get("model"),
            "vision_model": vision_model, "quality": quality, "resolution": [width, height], "hd_resolution": list(hd_dimensions), "orientation": orientation, "content_type": content_type,
            "warning": "Aucun clip rendu",
        })
        return 0

    # The prior completed edit remains on disk if extension fails; the export is
    # performed only after the new scenes have actually been rendered.
    rt.export_reel_lowram(comfy, rendered, mc_flags, final_path)
    save_json(project_dir / "run_summary.json", {
        "project": project,
        "content_json": str(project_dir / "content.json"),
        "scenes_json": str(project_dir / "scenes.json"),
        "film_compat_json": str(project_dir / "film.json"),
        "scene_count": len(all_scenes),
        "clip_count": len(rendered),
        "final_video": str(final_path),
        "content_model": content_backend.get("display") or content_backend.get("model"),
        "scene_model": scene_backend.get("display") or scene_backend.get("model"),
        "plan_model": plan_backend.get("display") or plan_backend.get("model"),
        "clip_model": clip_backend.get("display") or clip_backend.get("model"),
        "vision_model": vision_model,
        "quality": quality,
        "resolution": [width, height],
        "hd_resolution": list(hd_dimensions), "orientation": orientation, "content_type": content_type,
    })
    if studio.enabled():
        studio.mark_completed(project_dir)
        studio.publish('complete', 'Film terminé — montage exporté', {'final': str(final_path)})
    print(f"\nTERMINE -> {final_path}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except studio.StudioStop:
        print("\nStudio : production annulée à la demande (dernier checkpoint intact).")
        studio.publish('stopped','Production arrêtée à la demande')
        stop_llama_server(label="Arrêt Studio")
        rt.unload_all_ollama_models()
        raise SystemExit(0)
    except studio.StudioSuspend:
        print("\nStudio : projet suspendu sur un checkpoint sûr ; reprise possible ultérieurement.")
        stop_llama_server(label="Suspension Studio")
        rt.unload_all_ollama_models()
        raise SystemExit(0)
    except KeyboardInterrupt:
        print("\nCtrl+C : arrêt global llama-server/Ollama, interruption H3 et vidage de ComfyUI...")
        problems = studio_refbank_module('studio_emergency_stop').emergency_stop()
        for issue in problems:
            print("  Attention arrêt :", issue)
        stop_llama_server(label="Interruption")
        print("Interrompu.")
        raise SystemExit(130)
    except Exception as exc:
        stop_llama_server(label="Erreur")
        rt.unload_all_ollama_models()
        print(f"\nERREUR: {exc}")
        raise
