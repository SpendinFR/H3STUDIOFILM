"""Automatic generative first-frame reconstruction for Person Remover.

Uses the demonstrated LanPaint image-inpainting mechanism with the Krea 2 Turbo
weights that are already part of the Studio workflows (LanPaint Example_28).
No OpenCV Telea/Navier-Stokes or pixel-neighbour reconstruction is performed.
"""
from __future__ import annotations

from pathlib import Path
import json
import shutil
import subprocess

KREA_MODEL = 'krea2_turbo_fp8_scaled.safetensors'
KREA_CLIP = 'qwen3vl_4b_fp8_scaled.safetensors'
KREA_VAE = 'qwen_image_vae.safetensors'

REQUIRED_NODES = (
    'LoadImage', 'LoadImageMask', 'UNETLoader', 'CLIPLoader', 'VAELoader',
    'CLIPTextEncode', 'ConditioningZeroOut', 'VAEEncodeForInpaint',
    'LanPaint_KSampler', 'VAEDecode', 'SaveImage',
)


def _options(info, node, field):
    raw = (((info.get(node) or {}).get('input') or {}).get('required') or {}).get(field)
    if isinstance(raw, (list, tuple)) and raw:
        if raw[0] == 'COMBO' and len(raw) > 1 and isinstance(raw[1], dict):
            return raw[1].get('options') or []
        if isinstance(raw[0], (list, tuple)):
            return raw[0]
    return []


def validate(info):
    missing = [name for name in REQUIRED_NODES if name not in info]
    for cls, key, model in (("UNETLoader", "unet_name", KREA_MODEL),
                            ("CLIPLoader", "clip_name", KREA_CLIP),
                            ("VAELoader", "vae_name", KREA_VAE)):
        names = _options(info, cls, key)
        if names and model not in names:
            missing.append(f'{model} dans ComfyUI/models/')
    if missing:
        raise RuntimeError('Préparation image propre Krea2/LanPaint indisponible : ' + ', '.join(missing))


def graph(info, first_file, mask_file, target, job_id, replacement_prompt=None):
    from retouches_masked_core import _make
    validate(info)
    def node(kind, **inputs):
        return {'class_type': kind, 'inputs': _make(info, kind, **inputs)['inputs']}
    def ref(n): return [str(n), 0]
    positive = (
        'Photorealistic clean background plate of this exact scene, same room, '
        'same walls, furniture, floor, objects, lighting, materials and perspective. '
        'The ' + str(target) + ' is completely absent. Fill only the masked area '
        'with the physically plausible scenery that was hidden behind them. '
        'Do not add a person, body parts, clothes, accessories, hats or new furniture.'
    )
    if replacement_prompt is not None:
        description=str(replacement_prompt).strip()
        if not description:raise ValueError('Décris le nouvel élément avant la génération automatique Krea.')
        positive = (
            'Photorealistic image edit of the exact input scene, same camera framing, perspective, '
            'lighting, and composition. REPLACE the selected '+str(target)+' ONLY inside the mask '
            'according to this instruction: '+description+'. Keep the new object fully present and '
            'visually correct from this very first frame. Preserve ALL unmasked content unchanged. '
            'Do not recreate any part of the old object inside the mask.'
        )
    pfx = 'H3FilmSimple/retouches/' + job_id + '_krea_clean_plate'
    return {
        '1': node('LoadImage', image=first_file),
        '2': node('LoadImageMask', image=mask_file, channel='red'),
        '3': node('UNETLoader', unet_name=KREA_MODEL, weight_dtype='default'),
        '4': node('CLIPLoader', clip_name=KREA_CLIP, type='krea2', device='default'),
        '5': node('VAELoader', vae_name=KREA_VAE),
        '6': node('CLIPTextEncode', text=positive, clip=ref(4)),
        '7': node('ConditioningZeroOut', conditioning=ref(6)),
        '8': node('VAEEncodeForInpaint', pixels=ref(1), vae=ref(5), mask=ref(2), grow_mask_by=12),
        '9': node('LanPaint_KSampler', model=ref(3), seed=904234, steps=8, cfg=1.0,
                  sampler_name='euler', scheduler='simple', positive=ref(6), negative=ref(7),
                  latent_image=ref(8), denoise=1.0, LanPaint_NumSteps=3,
                  LanPaint_PromptMode='Prompt First', Inpainting_mode='🖼️ Image Inpainting',
                  LanPaint_Info='Krea2 / LanPaint first-frame generative inpainting'),
        '10': node('VAEDecode', samples=ref(9), vae=ref(5)),
        '11': node('SaveImage', images=ref(10), filename_prefix=pfx),
    }


def extract_frame(source, destination):
    destination.parent.mkdir(parents=True, exist_ok=True)
    res = subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(source),
                          '-frames:v','1',str(destination)],capture_output=True,text=True,timeout=60)
    if res.returncode or not destination.is_file():
        raise RuntimeError('Extraction image initiale impossible : ' + res.stderr[-500:])
    return destination


def resolve_generated_png(history, comfy, output_node='11'):
    base = (comfy / 'output').resolve()
    outputs = (history.get('outputs') or {}).get(str(output_node)) or {}
    for row in outputs.get('images', []):
        if not isinstance(row, dict): continue
        name = Path(str(row.get('filename') or '')).name
        sub = Path(str(row.get('subfolder') or '').replace('\\','/'))
        if '..' in sub.parts or not name.lower().endswith('.png'):continue
        path = (base / sub / name).resolve()
        if path.is_relative_to(base) and path.is_file():return path
    raise RuntimeError('LanPaint/Krea2 a terminé sans exporter la première image propre.')


def prepare(source, mask_paths, job_id, comfy, info, target, submit, await_history, *, replacement_prompt=None):
    """Create/stage a clean first frame; `submit` and `await_history` are injected for testability."""
    if not mask_paths:raise RuntimeError('Aucun masque SAM3 reçu pour créer la première image.')
    from PIL import Image, ImageFilter
    root = (comfy / 'input').resolve()
    first = root / f'retouches_{job_id}_original_frame.png'
    mask = root / f'retouches_{job_id}_initial_mask.png'
    plate = root / f'retouches_{job_id}_krea_clean_plate.png'
    extract_frame(source, first)
    with Image.open(first) as image, Image.open(mask_paths[0]) as srcmask:
        dims = image.size
        m = srcmask.convert('L')
        if m.size != dims:
            m = m.resize(dims, Image.Resampling.NEAREST)
        # Widen segmentation for hair/shadows before neural inpainting.
        # This morphological mask operation does not reconstruct any pixels.
        mask_pixels = m.point(lambda x: 255 if x > 100 else 0)
        mask_pixels = mask_pixels.filter(ImageFilter.MaxFilter(17))
        mask_pixels.save(mask)
    g = graph(info, first.name, mask.name, target, job_id, replacement_prompt=replacement_prompt)
    reply = submit(g)
    prompt_id = reply.get('prompt_id')
    if not prompt_id:
        raise RuntimeError('ComfyUI a refusé le graphe de première image propre : ' + str(reply.get('node_errors') or reply)[:650])
    history = await_history(prompt_id)
    generated = resolve_generated_png(history, comfy)
    from PIL import ImageChops, ImageStat
    with Image.open(generated) as im, Image.open(first) as original, Image.open(mask) as selected:
        if im.size != dims:
            raise RuntimeError(f'Image propre Krea2 : dimensions modifiées ({im.size} au lieu de {dims}).')
        rgb=im.convert('RGB')
        delta=ImageChops.difference(rgb, original.convert('RGB'))
        change=sum(ImageStat.Stat(delta, mask=selected).mean)/3.0
        if change < 6.0:
            raise RuntimeError(
                f'Krea2/LanPaint n’a presque rien changé dans la zone ciblée ({change:.1f}/255). '
                'Génération H3 annulée pour éviter un rendu inutile.')
        rgb.save(plate)
    return plate
