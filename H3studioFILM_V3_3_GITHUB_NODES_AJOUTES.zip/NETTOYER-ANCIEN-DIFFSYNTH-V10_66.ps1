param([switch]$ConfirmerSuppression)
$ErrorActionPreference='Stop'
# On ne SUPPRIME QUE le répertoire dédié créé pour ce projet.
# Aucun gestionnaire de paquets exécuté; Python311/ComfyUI/CUDA/caches globaux ne sont jamais visés.
$expected=[IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'H3RetouchDiffSynth'))
$root=Join-Path $env:LOCALAPPDATA 'H3RetouchDiffSynth'
if (!(Test-Path -LiteralPath $root -PathType Container)) {
    Write-Host '[OK] Aucun environnement DiffSynth dédié à retirer.' -ForegroundColor Green
    exit 0
}
$item=Get-Item -LiteralPath $root -Force
if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'JONCTION/SYMLINK: Refus de supprimer un dossier lié.' }
$resolved=(Resolve-Path -LiteralPath $root).ProviderPath
if ([IO.Path]::GetFullPath($resolved) -ine $expected) { throw 'CHEMIN INATTENDU. Aucune suppression.' }
Write-Host "Environnement dédié: $resolved" -ForegroundColor Cyan
$links=Get-ChildItem -LiteralPath $root -Recurse -Force -ErrorAction Stop | Where-Object { ($_.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0 }
if ($links) { throw 'Sous-dossier lien symbolique/jonction détecté : aucune suppression.' }
$files=Get-ChildItem -LiteralPath $root -Recurse -File -Force -ErrorAction Stop
$bytes=($files | Measure-Object -Property Length -Sum).Sum
Write-Host ('Fichiers: '+$files.Count+' ; Taille: '+[Math]::Round($bytes/1GB,2)+' Go')
Get-ChildItem -LiteralPath $root -Force | Select-Object Name, FullName | Format-Table -AutoSize
if (!$ConfirmerSuppression) {
    Write-Host '[PREVISUALISATION] Aucun fichier supprimé. Pour retirer uniquement ce dossier, relance avec -ConfirmerSuppression.' -ForegroundColor Yellow
    exit 0
}
# Empêcher suppression pendant que le Python de cet environnement tourne.
$busy=Get-CimInstance Win32_Process -ErrorAction Stop | Where-Object {
    $_.ExecutablePath -and $_.ExecutablePath.StartsWith($expected + '\',[StringComparison]::OrdinalIgnoreCase)
}
if ($busy) { throw 'DiffSynth est encore en cours : ferme-le, aucune suppression effectuée.' }
Remove-Item -LiteralPath $root -Recurse -Force -ErrorAction Stop
Write-Host '[OK] Seul le dossier H3RetouchDiffSynth a été supprimé. Environnements globaux inchangés.' -ForegroundColor Green
