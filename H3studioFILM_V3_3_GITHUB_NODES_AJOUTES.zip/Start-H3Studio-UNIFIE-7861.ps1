$ErrorActionPreference = 'Stop'
$Host.UI.RawUI.WindowTitle = 'H3 Studio unifie - Direction + Retouches - 7861'
$comfy = 'C:\AI\ComfyUI_windows_portable\ComfyUI'
$py = 'C:\AI\ComfyUI_windows_portable\python_embeded\python.exe'
if (-not (Test-Path -LiteralPath $py)) { throw "Python embarque ComfyUI introuvable : $py" }
if (-not (Test-Path -LiteralPath $comfy)) { throw "ComfyUI introuvable : $comfy" }
$env:COMFYUI_DIR = $comfy
$env:H3_RETOUCH_ONLY = '1'
$env:PYTHONUNBUFFERED = '1'
$env:PYTHONIOENCODING = 'utf-8'
$env:PYTHONUTF8 = '1'
$env:PYTHONPATH = "$PSScriptRoot;$env:PYTHONPATH"
Write-Host 'Direction + Retouches dans un seul Studio : http://127.0.0.1:7861/' -ForegroundColor Cyan
Write-Host 'ComfyUI reste sur 8188, jamais arrete ou redemarre automatiquement.' -ForegroundColor Green
& $py -u (Join-Path $PSScriptRoot 'launch_h3_unified.py')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
