"""Fresh full-clip H3 generation from Gemma's rewritten prompt.
Does not load, mask, or V2V-condition on original clip RAW latent.
"""
from __future__ import annotations
import hashlib,json


def seed_for_source(project,clip,load_project):
    # Recover source noise seed only when stored; otherwise freeze a stable new seed.
    try:
        folder=load_project(project)
        registry=json.loads((folder/'_studio'/'clips.json').read_text(encoding='utf-8'))
        entry=(registry.get('clips') or {}).get(str(clip),{})
        for v in [entry.get('noise_seed'),entry.get('seed')]:
            if v is not None and 0 <= int(v) < 2**63:return int(v)
    except (OSError,ValueError,TypeError,AttributeError):pass
    digest=hashlib.sha256(f'performance:{project}:{clip}'.encode('utf-8')).digest()
    return int.from_bytes(digest[:8],'big')%(2**63-1)


def original_seed_known(project,clip,load_project):
    """Return True only when metadata contains the recorded original sampler seed."""
    try:
        folder=load_project(project)
        registry=json.loads((folder/'_studio'/'clips.json').read_text(encoding='utf-8'))
        entry=(registry.get('clips') or {}).get(str(clip),{})
        for v in (entry.get('noise_seed'),entry.get('seed')):
            if v is not None and 0<=int(v)<2**63:return True
    except (OSError,ValueError,TypeError,AttributeError):pass
    return False


def build(info, source, ident, seconds, prompt, seed, *, first_frame_name, snapshot, metadata, comfy, rt, preflight):
    graph=rt.gui_to_api(snapshot(),info)
    rt.patch_models(graph,info)
    h3id,h3=next(((nid,n) for nid,n in graph.items() if n['class_type']=='H3StudioImageToVideo'))
    rt.reset_h3_optional_inputs(h3,info)
    meta=metadata(source,comfy)
    h3inp=h3['inputs']
    h3inp.update(prompt=prompt,width=meta['width'],height=meta['height'],length=int(seconds['frames']))
    if meta['width']%32 or meta['height']%32:
        raise ValueError('Performance : dimensions H3 non alignées sur 32')
    # New shot from text + the TRUE first image of the original RAW video.
    # This is NOT a video-to-video retake, no original latent is used.
    for name in ('ref_image_files','ref_audio_files','ref_video_files','first_frame_file','last_frame_file',
                 'motion_context_file','timed_text','v2v_video_file','ref_spec','ref_video_spec',
                 'ref_video_crops','ref_video_spec','motion_context_file'):
        if name in h3inp:h3inp[name]=''
    if not first_frame_name or 'first_frame_file' not in h3inp:
        raise RuntimeError('Performance : ancre visuelle obligatoire first_frame_file non disponible dans H3Studio.')
    h3inp['first_frame_file']=str(first_frame_name)
    if 'motion_context_reuse_latent' in h3inp:h3inp['motion_context_reuse_latent']=False
    if 'motion_context_anchor_brightness' in h3inp:h3inp['motion_context_anchor_brightness']=False
    # The source H3Studio produces a *new* latent, connected directly to native sampler.
    if graph['207']['inputs'].get('latent_image') != [h3id,1]:
        raise RuntimeError('Performance : graphe natif H3Studio -> sampler RAW introuvable')
    # Prune the cached FilmMaker node but preserve RAW save path.
    for n in graph.values():
        for field,v in list(n.get('inputs',{}).items()):
            if isinstance(v,list) and len(v)==2 and str(v[0])=='201':n['inputs'][field]=['207',0]
    graph.pop('201',None)
    graph['191']['inputs']['filename_prefix']=f'h3performance_v1096/{ident}_RAW'
    for n in graph.values():
        if n.get('class_type')=='RandomNoise':n['inputs']['noise_seed']=seed
    banned={'H3RetouchMaskV58','H3LoadRawLatentExact','H3RoychoAnimatedMaskV62'}
    if any(n.get('class_type') in banned for n in graph.values()):
        raise RuntimeError('Performance : graphe natif contaminé par un moteur de retouche')
    preflight(graph,info)
    return graph
