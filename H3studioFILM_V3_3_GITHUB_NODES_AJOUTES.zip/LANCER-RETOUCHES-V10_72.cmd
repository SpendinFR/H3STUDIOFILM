@echo off
setlocal
set "H3_RETOUCH_ONLY=1"
set "COMFYUI_DIR=C:\AI\ComfyUI_windows_portable\ComfyUI"
set "PY=C:\AI\ComfyUI_windows_portable\python_embeded\python.exe"
if not exist "%PY%" (
 echo ERREUR : Python embarque ComfyUI introuvable.
 pause
 exit /b 1
)
cd /d "%~dp0"
echo Retouches V10.72 - Gemma26 / retake H3 adaptatif / fenetre precise et denoise V2V expérimental.
echo Aucun pip, DiffSynth, modele LLM ou paquet CUDA installe.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALLER-NOUVEAUX-MOTEURS-V10_66.ps1"
if errorlevel 1 (
 echo Verification des nodes ComfyUI en echec.
 pause
 exit /b 1
)
echo Studio Retouches V10.72 : http://127.0.0.1:7861/
"%PY%" -u "%~dp0studio_web.py" --port 7861
if errorlevel 1 pause
endlocal
