@echo off
chcp 65001 >NUL
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-H3FilmStudio-V10.ps1" %*
pause
