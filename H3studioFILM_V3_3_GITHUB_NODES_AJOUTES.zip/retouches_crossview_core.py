"""Native flat CrossViewWarp / MoGe2 / MiniMax H3 Ref2VA engine.

No conversion of third-party LiteGraph subgraph UUIDs/GetNode/SetNode.
The source and its MoGe-warped view are distinct H3 Ref2VA references.
"""
from retouches_masked_core import _make, _ref


def _find_moge(info):
    """Read MoGe filenames from current ComfyUI COMBO schema (and legacy lists).

    New ComfyUI reports model_name as ['COMBO', {'options': [...]}].
    The former implementation mistook 'COMBO' for the model list and silently
    marked an installed geometry_estimation model as missing.
    """
    spec=((info.get('LoadMoGeModel') or {}).get('input') or {}).get('required') or {}
    raw=spec.get('model_name')
    if not raw:
        return None
    choices=[]
    if isinstance(raw,(list,tuple)):
        if raw and raw[0]=='COMBO':
            if len(raw)>1 and isinstance(raw[1],dict):
                choices=raw[1].get('options') or []
        elif raw and isinstance(raw[0],(list,tuple)):
            choices=raw[0]
    elif isinstance(raw,dict):
        choices=raw.get('options') or []
    if not isinstance(choices,(list,tuple)):
        return None
    preferred=[x for x in choices if isinstance(x,str) and 'moge_2_vitl' in x.lower()]
    if not preferred:
        preferred=[x for x in choices if isinstance(x,str) and 'moge_2' in x.lower()]
    return preferred[0] if preferred else None


def build(info,source_filename,model_name,azimuth,elevation,frames,width,height,
          quality='test',job_id='preview',preview_only=False):
    if not(-90<=float(azimuth)<=90 and -35<=float(elevation)<=45):
        raise ValueError('Angle CrossView hors des limites')
    if not(model_name and width%32==0 and height%32==0 and frames>=5 and (frames-5)%17==0):
        raise ValueError('H3 CrossView : dimensions/framerate incorrects')
    name=_find_moge(info)
    if not name:raise RuntimeError('Modèle MoGe2 manquant dans geometry_estimation')
    prefix='H3FilmSimple/retouches/'+job_id
    g={}
    def add(i,t,**kwargs):g[str(i)]=_make(info,t,**kwargs)
    add(1,'LoadVideo',file=source_filename)
    add(2,'GetVideoComponents',video=_ref(1))
    add(3,'LoadMoGeModel',model_name=name)
    add(4,'MoGeInference',moge_model=_ref(3),image=_ref(2),resolution_level=8,batch_size=2,
        force_projection=True,apply_mask=True)
    add(5,'CrossViewWarp',frames=_ref(2),moge_geometry=_ref(4),
        azimuth=float(azimuth),elevation=float(elevation),distance=1.0,
        hfov=0.0,vertical_shift=0.0,depth_ratio=6.0,
        smooth_depth=False,invert_depth=False,use_keyframes=False,
        keep_source_aim=True,pivot_override=True,pivot_x=0.0,pivot_y=0.0,pivot_z=1.05)
    if preview_only:
        add(50,'CreateVideo',images=_ref(5),audio=_ref(2,1),fps=24,bit_depth='auto',color_space='sRGB',codec='none')
        add(51,'SaveVideo',video=_ref(50),filename_prefix=prefix+'_warp_preview',format='mp4',
            **{'format.codec':'h264','format.codec.encoding':'re-encode','format.codec.encoding.crf':16})
        return g
    add(10,'VAELoader',vae_name='minimax_h3_video_vae_fp16.safetensors')
    add(11,'VAELoader',vae_name='minimax_h3_audio_vae_fp32.safetensors')
    add(12,'CLIPLoader',clip_name='qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors',type='minimax',device='default')
    add(13,'UNETLoader',unet_name=model_name,weight_dtype='default')
    add(14,'LoraLoaderModelOnly',model=_ref(13),lora_name='MiniMax-H3_Ref2VA-LoRA-CrossView-Warp_v1_3500.safetensors',strength_model=0.8)
    add(15,'GetImageSizeAndCount',image=_ref(2))
    add(16,'MiniMaxH3ReferenceToVideo',clip=_ref(12),vae=_ref(10),audio_vae=_ref(11),
        prompt='crossview',width=_ref(15,1),height=_ref(15,2),length=_ref(15,3),
        ref_image_size='max',**{'ref_videos.ref_video_0':_ref(2),
                               'ref_videos.ref_video_1':_ref(5),
                               'ref_video_audios.ref_video_audio_0':_ref(2,1)})
    add(17,'BasicGuider',model=_ref(14),conditioning=_ref(16))
    add(18,'RandomNoise',noise_seed=904234)
    add(19,'BasicScheduler',model=_ref(14),scheduler='simple',steps=12 if quality=='test' else 20,denoise=1.0)
    add(20,'KSamplerSelect',sampler_name='euler')
    add(21,'SamplerCustomAdvanced',noise=_ref(18),guider=_ref(17),sampler=_ref(20),
        sigmas=_ref(19),latent_image=_ref(16,1))
    add(22,'LTXVSeparateAVLatent',av_latent=_ref(21,1))
    add(23,'VAEDecode',samples=_ref(22),vae=_ref(10))
    add(24,'CreateVideo',images=_ref(23),audio=_ref(2,1),fps=24,bit_depth='auto',color_space='sRGB',codec='none')
    add(25,'SaveVideo',video=_ref(24),filename_prefix=prefix,format='mp4',
        **{'format.codec':'h264','format.codec.encoding':'re-encode','format.codec.encoding.crf':16})
    return g
