"""Standalone ComfyUI H3 retouch workflow runner.

All artifacts are namespaced; no FilmMaker jobs, prompts, checkpoints or FINAL files
are modified. Upstream creator ComfyUI workflows must be installed into
retouches_workflows/; model weights are never bundled or downloaded silently.
"""
from __future__ import annotations
import copy
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import threading
import time
import uuid
import urllib.request
import urllib.error
from retouches_workflow_compat import flatten_to_api
from retouches_masked_core import build as build_masked_graph, MASK_MODES
from retouches_crossview_core import build as build_crossview_graph, _find_moge

HERE = Path(__file__).resolve().parent
WF_DIR = HERE/'retouches_workflows'
JOBS_ROOT = HERE/'studio_sessions'/'retouches'/'jobs'
RESULTS = HERE/'studio_sessions'/'retouches'/'results'
CURL = 'http://127.0.0.1:8188'
LOCK = threading.RLock()
RUNNING = set()
CANCELLED = set()

ELEMENT_BACKENDS = {'remove_element':'remove_person', 'replace_element':'swap_person'}

def underlying_mode(mode):
    return ELEMENT_BACKENDS.get(mode, mode)


def target_for_mode(data):
    """Avoid calling an unknown manually-selected object a 'person'."""
    return str(data.get('target') or ('selected object' if data.get('mode') in ELEMENT_BACKENDS else 'person')).strip()


def element_prompt(mode, target, instructions='', *, photo_reference=True):
    item=(target or 'selected object').strip()
    user=(instructions or '').strip()
    if mode=='remove_element':
        return ('Remove the green-masked '+item+' from every frame starting at the very first frame. '
                'Reconstruct only the background that was hidden by the object. Preserve camera, lighting, '
                'other objects and all original motion. '+user).strip()
    if mode=='replace_element':
        if not photo_reference:
            return ('Replace only the selected '+item+' with the following requested new element: '+user+'. '
                    'Use the automatically generated first-frame image in <Picture 1> as the scene-consistent '
                    'visual reference, not as a new camera shot. The new object must be fully present in frame zero '
                    'and remain coherent throughout the clip. Preserve every other subject, the surroundings, '
                    'camera movement and timing.').strip()
        return ('Replace only the selected '+item+' in <Video 1> with the object in <Picture 1>. '
                'Match the picture object appearance, scale, perspective and movement from the first frame. '
                'Preserve every other subject, the surroundings, camera and timing. '+user).strip()
    raise ValueError('Not an element mode')


def apply_element_prompt(graph, mode, target, instructions='', *, photo_reference=True):
    if mode in ELEMENT_BACKENDS:
        if graph['33']['class_type']!='MiniMaxH3ReferenceToVideo':
            raise ValueError('Element mode needs Ref2VA H3 graph')
        graph['33']['inputs']['prompt']=element_prompt(mode,target,instructions,photo_reference=photo_reference)
    return graph

WORKFLOWS = {
 'remove_person': {
   'name':'Suppression d’acteur · Akatz SAM3',
   'file':'remove_person.json',
   'url':'https://huggingface.co/akatz-ai/MiniMax-H3-Person-Remover-LoRA/resolve/main/examples/Person-Remover-Window-Reroll-V1.json',
   'nodes':['H3RelayPersonRemover'],
   'loras':['H3-Person-Remover-V1.safetensors'],
   'requires_ref':True,
 },
 'swap_person': {
   'name':'Changement d’acteur · Akatz',
   'file':'swap_person.json',
   'url':'https://huggingface.co/akatz-ai/MiniMax-H3-Character-Swap-LoRA/resolve/main/examples/H3%20Character%20Swap%20v1%20Ref2VA.json',
   'nodes':[],
   'loras':['h3_character_swap_pro4500_1000.safetensors'],
   'requires_ref':True,
 },
 'remove_element': {
   'name':'Supprimer un élément · méthode V10.73',
   'file':'remove_person.json',
   'url':'https://huggingface.co/akatz-ai/MiniMax-H3-Person-Remover-LoRA/resolve/main/examples/Person-Remover-Window-Reroll-V1.json',
   'nodes':['H3RelayPersonRemover'],
   'loras':['H3-Person-Remover-V1.safetensors'],
   'requires_ref':True,
 },
 'replace_element': {
   'name':'Remplacer un élément · méthode V10.73',
   'file':'swap_person.json',
   'url':'https://huggingface.co/akatz-ai/MiniMax-H3-Character-Swap-LoRA/resolve/main/examples/H3%20Character%20Swap%20v1%20Ref2VA.json',
   'nodes':[],
   'loras':['h3_character_swap_pro4500_1000.safetensors'],
   'requires_ref':True,
 },
 'move_camera': {
   'name':'Nouvel angle · CrossView-Warp H3',
   'file':'move_camera.json',
   'url':'https://huggingface.co/datasets/Cseti/ComfyUI-Workflows/resolve/main/minimax-h3/crossview-warp/crossview-warp-h3.json',
   'nodes':['CrossViewWarp'],
   'loras':['MiniMax-H3_Ref2VA-LoRA-CrossView-Warp_v1_3500.safetensors'],
   'requires_ref':False,
 },
 'local_edit': {
   'name':'Retouche masquée · LanPaint H3',
   'file':'_builtin_lanpaint_api.json',
   'url':'https://raw.githubusercontent.com/scraed/LanPaint/master/example_workflows/MiniMax_H3_AV_EncodeDecode_Inpaint.json',
   'nodes':['LanPaint_VideoMaskEditor','LanPaint_AVEncode','LanPaint_AVDecode'],
   'loras':[],
   'requires_ref':False,
 },
 'replace_background': {
   'name':'Changement de décor · LanPaint H3',
   'file':'_builtin_lanpaint_api.json',
   'url':'https://raw.githubusercontent.com/scraed/LanPaint/master/example_workflows/MiniMax_H3_AV_EncodeDecode_Inpaint.json',
   'nodes':['LanPaint_VideoMaskEditor','LanPaint_AVEncode','LanPaint_AVDecode'],
   'loras':[],
   'requires_ref':False,
 },
}


def comfy_json(url_path, data=None, timeout=25):
    if not url_path.startswith('/'):raise ValueError('Route ComfyUI invalide')
    payload=None if data is None else json.dumps(data).encode('utf-8')
    req=urllib.request.Request(CURL+url_path,data=payload,headers={'Content-Type':'application/json'})
    try:
        with urllib.request.urlopen(req,timeout=timeout) as resp:
            return json.loads(resp.read(12*1024*1024).decode('utf-8'))
    except urllib.error.HTTPError as exc:
        details=exc.read(6000).decode('utf-8','replace')
        raise RuntimeError('ComfyUI a refusé le workflow (HTTP '+str(exc.code)+') : '+details[:1400]) from exc


def workflow_path(mode):
    """Prefer this version's workflow, then reuse existing sibling Studios read-only.

    This allows migrating from separately extracted V10.33/V10.34 folders on
    Windows without copying or redownloading the author's JSON assets.
    """
    filename=WORKFLOWS[underlying_mode(mode)]['file']
    local=WF_DIR/filename
    if local.is_file():
        return local
    for top in (HERE.parent, HERE.parent.parent):
        if not top.is_dir():
            continue
        for older in top.glob('H3Film_STUDIO_V10_*'):
            if not older.is_dir() or older.resolve()==HERE.resolve():
                continue
            for installed in (older, older/older.name):
                existing=installed/'retouches_workflows'/filename
                if existing.is_file():
                    return existing
    return local


def install_workflows():
    """Download only missing author workflow JSON files, never model weights.

    Workflows have one filename per editing mode.  The old implementation
    mistakenly attempted ``WORKFLOWS[dict]``, causing ``unhashable type: dict``
    even before the first download; keep the de-duplication on *filenames*.
    """
    WF_DIR.mkdir(parents=True, exist_ok=True)
    report=[]
    seen_files=set()
    for mode, info in WORKFLOWS.items():
        if mode in ('local_edit','replace_background'):
            continue  # Author JSONs preserved for archival/legacy users only.
        filename=info['file']
        if filename in seen_files:
            continue
        seen_files.add(filename)
        target=WF_DIR/filename
        found=workflow_path(mode)
        if found.is_file():
            report.append({'mode':mode, 'status':'existant', 'path':str(found)})
            continue
        try:
            req=urllib.request.Request(info['url'], headers={
                'User-Agent':'H3FilmStudio-Retouches/1.0',
                'Accept':'application/json, text/plain, */*',
            })
            with urllib.request.urlopen(req, timeout=55) as response:
                raw=response.read(4*1024*1024)
            obj=json.loads(raw)
            if not isinstance(obj,dict):
                raise ValueError('Le fichier reçu n’est pas un workflow ComfyUI JSON')
            if 'nodes' in obj:
                if not isinstance(obj['nodes'],list) or not obj['nodes']:
                    raise ValueError('Workflow ComfyUI : liste de nodes absente ou vide')
            elif not (obj and all(isinstance(v,dict) and 'class_type' in v for v in obj.values())):
                raise ValueError('Workflow ComfyUI : format API non reconnu')
            tmp=target.with_suffix('.json.tmp')
            try:
                tmp.write_bytes(raw)
                os.replace(tmp,target)
            finally:
                tmp.unlink(missing_ok=True)
            report.append({'mode':mode, 'status':'installé', 'path':str(target)})
        except Exception as exc:
            report.append({'mode':mode, 'status':'erreur',
                           'message':str(exc)[:500], 'url':info['url']})
    return {'workflows':report}


def _meta_path(job_id):
    if not re.fullmatch('[0-9a-f]{32}',str(job_id or '')):raise ValueError('ID de rendu invalide')
    return JOBS_ROOT/(job_id+'.json')

def _write_job(job):
    path=_meta_path(job['id']);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.tmp')
    tmp.write_text(json.dumps(job,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(tmp,path)

def job(job_id):
    path=_meta_path(job_id)
    try:return json.loads(path.read_text(encoding='utf-8'))
    except OSError:raise ValueError('Retouche introuvable')

def jobs():
    rows=[]
    for p in sorted(JOBS_ROOT.glob('*.json'),key=lambda x:x.stat().st_mtime,reverse=True)[:45] if JOBS_ROOT.is_dir() else []:
        try:rows.append(json.loads(p.read_text(encoding='utf-8')))
        except (ValueError,OSError):continue
    return rows

def _cancelled(job_id):
    with LOCK:return job_id in CANCELLED


def _abort_if_cancelled(job_id):
    if _cancelled(job_id):
        raise InterruptedError('Retouche annulée par l’utilisateur')


def stop(job_id):
    """Cancel only the retouch prompt; leave ComfyUI and other jobs running.

    ComfyUI supports targeted /interrupt {prompt_id}, plus queue deletion by ID.
    These operations never send global /interrupt or queue clear.
    """
    with LOCK:
        row=job(job_id)
        if row['status'] in ('complete','error','cancelled'):
            return {'id':job_id,'status':row['status']}
        CANCELLED.add(job_id)
        pid=row.get('prompt_id') or row.get('mask_prompt_id')
        row['status']='cancelling';_write_job(row)
    if pid:
        try:comfy_json('/queue',{'delete':[pid]},timeout=10)
        except Exception:pass
        try:comfy_json('/interrupt',{'prompt_id':pid},timeout=10)
        except Exception:pass
    return {'id':job_id,'status':'cancelling'}

def job_result(job_id):
    row=job(job_id)
    if row.get('status')!='complete':return None
    path=RESULTS/(job_id+'.mp4')
    return path if path.is_file() else None

def clean_plate_result(job_id, comfy):
    row=job(job_id)  # validates the ID before touching the filesystem
    if row.get('mode') not in ('remove_person','remove_element','replace_element') or not row.get('clean_plate_ready'):return None
    path=(comfy/'input'/f'retouches_{job_id}_krea_clean_plate.png').resolve()
    base=(comfy/'input').resolve()
    return path if path.is_relative_to(base) and path.is_file() else None

def _available_loras(objinfo):
    inp=(objinfo.get('LoraLoaderModelOnly') or {}).get('input',{}).get('required',{})
    return (inp.get('lora_name') or [[]])[0]


def _available_h3_models(objinfo):
    """Ask the live ComfyUI loader for exact installed checkpoint identifiers."""
    options=((((objinfo.get('UNETLoader') or {}).get('input') or {}).get('required') or {}).get('unet_name') or [[]])[0]
    return [str(x) for x in options if isinstance(x,str)]


def _select_h3_model(objinfo, mode, choice="singularity"):
    """Choose the best installed H3 base for the isolated retouch engine.

    Singularity is preferred by default for every mode. For LanPaint, an
    explicit FL2VA choice is available as a fallback. That task family differs
    from Ref2VA; selecting Singularity is an experiment, not proven equivalent.
    """
    available=_available_h3_models(objinfo)
    h3=[x for x in available if 'h3' in x.lower() or 'minimax' in x.lower()]
    if not h3:return None

    ref2va=[x for x in h3 if 'ref2va' in x.lower()]
    fl2va=[x for x in h3 if 'fl2va' in x.lower() and 'ref2va' not in x.lower()]

    def pick(pool, preferred):
        for name in preferred:
            for x in pool:
                if x.lower()==name:
                    return x
        return pool[0] if pool else None

    # User-requested global preference: Singularity first whenever usable.
    preferred_ref2va=(
        'minimax-h3_singularity_ref2va_pruned_v1.3_int8.safetensors',
        'minimax_h3_ref2va_pruned_nvfp4.safetensors',
        'minimax_h3_ref2va_pruned_int8_convrot.safetensors',
    )
    preferred_fl2va=(
        'minimax_h3_fl2va_pruned_int8_convrot.safetensors',
    )

    if mode in ('local_edit','replace_background'):
        if choice=='fl2va':
            return pick(fl2va, preferred_fl2va)
        return (
            pick(ref2va, preferred_ref2va)
            or pick(fl2va, preferred_fl2va)
            or pick(h3, preferred_ref2va + preferred_fl2va)
        )

    return pick(ref2va, preferred_ref2va) or pick(h3, preferred_ref2va + preferred_fl2va)


def _apply_h3_model(graph, mode, selected):
    """Patch only Diffusion MODEL loader inputs in this isolated retouch graph."""
    if not selected:raise RuntimeError('Aucun modèle H3 compatible avec ce mode de retouche')
    updated=0
    for node in graph.values():
        if node.get('class_type')=='UNETLoader':
            inp=node.get('inputs') or {}
            current=str(inp.get('unet_name') or '').lower()
            # Avoid clobbering unrelated non-H3 UNETs that an author may add.
            if 'h3' in current or 'minimax' in current:
                inp['unet_name']=selected
                updated+=1
    if not updated:raise ValueError('Workflow sans chargeur UNETLoader H3 reconnu')
    return selected


def readiness():
    try:objinfo=comfy_json('/object_info')
    except Exception as exc:
        return {'comfy_connected':False,'detail':str(exc)[:220],
                'modes':{k:{'ready':False,'missing':['ComfyUI arrêté']} for k in WORKFLOWS}}
    names=set(_available_loras(objinfo));modes={}
    for mode,cfg in WORKFLOWS.items():
        missing=[]
        file=workflow_path(mode)
        # CrossView uses a native flat graph: no downloaded GUI subgraph required.
        missing += ['Node '+x for x in cfg['nodes'] if x not in objinfo] if mode=='move_camera' else []
        missing += ['LoRA '+x for x in cfg['loras'] if x not in names] if mode=='swap_person' else []
        if 'LoadVideo' not in objinfo:
            missing.append('LoadVideo (ComfyUI récent)')
        selected_model=_select_h3_model(objinfo,mode)
        if mode in ('remove_person','swap_person','move_camera') and not selected_model:
            missing.append('Modèle H3 Ref2VA requis (NVFP4, INT8 ou autre modèle Ref2VA disponible)')
        if mode=='move_camera':
            for t in ('LoadMoGeModel','MoGeInference','CrossViewWarp','GetVideoComponents',
                      'MiniMaxH3ReferenceToVideo','VAEDecode','GetImageSizeAndCount',
                      'LTXVSeparateAVLatent','CreateVideo','SaveVideo','CLIPLoader',
                      'VAELoader','UNETLoader','LoraLoaderModelOnly',
                      'BasicGuider','BasicScheduler','RandomNoise','KSamplerSelect','SamplerCustomAdvanced'):
                if t not in objinfo:missing.append('Node '+t)
            if not _find_moge(objinfo):missing.append('Modèle MoGe2 dans models/geometry_estimation (puis redémarrer ComfyUI)')
        if mode in MASK_MODES:
            # Native latent-mask engine as used in the Roycho / MVEx recipes.
            for typ in ('LoadVideo','GetVideoComponents','CheckpointLoaderSimple',
                        'CLIPTextEncode','SAM3_Detect','SAM3_VideoTrack','SAM3_TrackToMask',
                        'MaskToImage','SaveImage','MVEx_MaskCleanup','MVEx_MaskToLatentSpace',
                        'SetLatentNoiseMask','VAEEncode','VAEEncodeAudio','CLIPLoader',
                        'VAELoader','UNETLoader','GetImageSizeAndCount',
                        'MiniMaxH3ReferenceToVideo','BasicGuider','BasicScheduler',
                        'RandomNoise','KSamplerSelect','SamplerCustomAdvanced',
                        'LTXVConcatAVLatent','LTXVSeparateAVLatent','VAEDecode',
                        'CreateVideo','SaveVideo'):
                if typ not in objinfo:missing.append('Node '+typ)
            if mode=='swap_person' and 'ImageToMask' not in objinfo:
                missing.append('Node ImageToMask (ComfyUI natif)')
            if mode in ('remove_person','swap_person') and 'GrowMask' not in objinfo:
                missing.append('Node GrowMask (ComfyUI natif)')
            if mode!='replace_background':
                for typ in ('MVEx_SubjectCrop','MVEx_SubjectUncrop'):
                    if typ not in objinfo:missing.append('Node '+typ)
            if mode=='replace_background' and 'InvertMask' not in objinfo:
                missing.append('Node InvertMask')
            checkpoints=((((objinfo.get('CheckpointLoaderSimple') or {}).get('input') or {}).get('required') or {}).get('ckpt_name') or [[]])[0]
            if 'sam3.1_multiplex_fp16.safetensors' not in checkpoints:
                missing.append('SAM3.1 multiplex FP16')
            if mode=='replace_background' and not _select_h3_model(objinfo,mode,'fl2va'):
                warning='FL2VA non installé : avec Singularity, cette variante du moteur masqué reste expérimentale.'
        warning=''
        if mode in ('local_edit','replace_background') and selected_model and 'ref2va' in selected_model.lower():
            warning='Mode masqué Ref2VA expérimental. Privilégier un test de suivi avant tout rendu GPU.'
        modes[mode]={'ready':not missing,'missing':missing,'workflow':cfg['file'],
                     'base_model':selected_model or '', 'warning':warning}
    for newmode,oldmode in ELEMENT_BACKENDS.items():
        row=modes[oldmode].copy()
        row['workflow']=WORKFLOWS[newmode]['file']
        if 'ImageToMask' not in objinfo:
            row['ready']=False
            row['missing']=list(row['missing'])+['ImageToMask requis pour le suivi pixels']
        row['warning']=('Pipeline de personnage V10.73 appliqué aux objets, rendu à valider. '
                        'Encadrement = suivi par pixels indépendant de SAM3.')
        modes[newmode]=row
    return {'comfy_connected':True,'modes':modes,'detail':'ComfyUI connecté'}


def _input_name_for_api(node_type, name, allowed):
    """Map ComfyUI frontend sockets to API names without losing autogrow links.

    Modern ComfyUI Autogrow inputs use names like values.a and
    ref_images.ref_image_0, not a or ref_image_0. They are not listed
    individually in object_info, which only advertises the parent template.
    """
    if not isinstance(name,str) or not name:
        return None
    if name in allowed:
        return name
    if node_type=='ComfyMathExpression' and 'values' in allowed and re.fullmatch(r'values\.[a-z]',name):
        return name  # Native Autogrow dynamic value, not advertised individually.
    if '.' not in name:
        return None
    parent, child=name.split('.',1)
    # A declared expandable parent permits individually named socket keys.
    if parent in allowed and child and (parent in ('values','ref_images','ref_videos','ref_video_audios','ref_audios') or 'AUTOGROW' in str(allowed[parent]).upper()):
        return name
    alias=name.rsplit('.',1)[-1]
    return alias if alias in allowed else None


def _widget_inputs(node,spec):
    """Resolve UI widget values with live object_info; named values win."""
    allowed={**spec.get('input',{}).get('required',{}),**spec.get('input',{}).get('optional',{})}
    vals=node.get('widgets_values_named') or {}
    if isinstance(vals,dict) and vals:
        out={}
        for name,value in vals.items():
            converted=_input_name_for_api(str(node.get('type') or ''),name,allowed)
            if converted and value is not None and not isinstance(value,dict):
                out[converted]=value
    else:
        values=node.get('widgets_values') or []
        out={}
        if isinstance(values,list):
            keys=[k for k,v in allowed.items() if isinstance(v,(list,tuple)) and v
                  and (isinstance(v[0],list) or v[0] in ('STRING','INT','FLOAT','BOOLEAN','COMBO'))]
            for name,value in zip(keys,values):
                if value is not None and not isinstance(value,dict):out[name]=value
    return out


def _prune_graph(graph):
    """Drop unreferenced UI preview branches and ensure all actual links exist."""
    outputs={'SaveVideo','VHS_VideoCombine','SaveAnimatedWEBP','SaveWEBM','SaveMp4','VideoCombine'}
    roots=[k for k,n in graph.items() if n['class_type'] in outputs]
    if not roots:return graph
    # Prefer the full output and discard author previews without changing output.
    def score(k):
        n=graph[k]; prefix=str(n.get('inputs',{}).get('filename_prefix','')).lower()
        return (50 if 'final' in prefix or 'output' in prefix else 0) - (200 if any(x in prefix for x in ('mask-preview','preview','source','original')) else 0)
    root=max(roots,key=score)
    visited=set()
    def visit(k):
        if k in visited:return
        if k not in graph:raise RuntimeError('Lien ComfyUI manquant vers node '+str(k))
        visited.add(k)
        for value in graph[k].get('inputs',{}).values():
            if isinstance(value,list) and len(value)==2 and isinstance(value[0],(str,int)) and isinstance(value[1],int):
                visit(str(value[0]))
    visit(root)
    return {k:n for k,n in graph.items() if k in visited}


def convert_graph(workflow,objinfo):
    """Convert author UI workflow to ComfyUI API with autogrow sockets intact."""
    if 'nodes' not in workflow:
        return {str(k):copy.deepcopy(v) for k,v in workflow.items() if isinstance(v,dict) and 'class_type' in v}
    nodes=workflow['nodes']
    node_by_id={str(n['id']):n for n in nodes if 'id' in n}
    links={str(l[0]):l for l in workflow.get('links',[]) if isinstance(l,list) and len(l)>=5}
    excluded={'Note','MarkdownNote','Reroute','PrimitiveNode'}
    def passthrough(n):
        return n.get('mode')==4 or n.get('type')=='Reroute'
    def origin(link_id,trail=()):
        l=links.get(str(link_id))
        if not l:return None
        source=str(l[1]);slot=int(l[2]);n=node_by_id.get(source)
        if not n or source in trail:return None
        if passthrough(n):
            inputs=n.get('inputs') or []
            candidate=next((i for i in inputs if i.get('link') is not None and i.get('type')=='MODEL'),None)
            if candidate is None:candidate=next((i for i in inputs if i.get('link') is not None),None)
            return origin(candidate['link'],(*trail,source)) if candidate else None
        return [source,slot]
    graph={};missing=set()
    for n in nodes:
        t=str(n.get('type',''))
        if not t or n.get('mode')==4 or t in excluded:continue
        if t not in objinfo:
            missing.add(t);continue
        inputs=_widget_inputs(n,objinfo[t]);allowed={**objinfo[t].get('input',{}).get('required',{}),
                  **objinfo[t].get('input',{}).get('optional',{})}
        for i in n.get('inputs',[]):
            if i.get('link') is None:continue
            name=_input_name_for_api(t,i.get('name'),allowed)
            if name:
                resolved=origin(i['link'])
                if resolved:inputs[name]=resolved
        graph[str(n['id'])]={'class_type':t,'inputs':inputs}
    # Ignore disconnected optional author nodes; only the reachable output matters.
    if not graph:raise ValueError('Workflow vide ou non convertible')
    return _prune_graph(graph)

def _align_author_geometry(graph, source, mode):
    """Preserve source portrait/landscape instead of the author's 16:9 preset.

    ResolutionSelector outputs are config values, not diffusion tensors. Direct
    integer socket values are valid in the ComfyUI API. Keep every reference
    link and all other camera/sampler settings untouched.
    """
    meta=_video_metadata(source)
    width,height=meta['width'],meta['height']
    if width%32 or height%32:
        raise ValueError('Dimensions du plan préparé non multiples de 32')
    selectors={str(k) for k,v in graph.items() if v['class_type']=='ResolutionSelector'}
    for n in graph.values():
        inp=n.get('inputs',{})
        for k,v in list(inp.items()):
            if isinstance(v,list) and len(v)==2 and str(v[0]) in selectors:
                if k=='width' and v[1]==0:inp[k]=width
                elif k=='height' and v[1]==1:inp[k]=height
        if mode=='swap_person' and n['class_type']=='MiniMaxH3ReferenceToVideo':
            inp['width']=width;inp['height']=height
            inp['length']=meta['frames']
    for nid in selectors:
        # Not needed after the integer replacements; an unconnected primitive
        # should never consume user time or force landscape defaults.
        if not any(isinstance(v,list) and len(v)==2 and str(v[0])==nid
                   for n in graph.values() for v in n.get('inputs',{}).values()):
            graph.pop(nid,None)
    return (width,height)


def _copy_source_audio(source, rendered, mode):
    """Preserve the source soundtrack even when the author's export is silent.

    For visual retouches, audio should not be regenerated. This is an exact
    timeline audio remux (AAC) of the *prepared source*; video stays untouched.
    """
    info=subprocess.run(['ffprobe','-v','error','-select_streams','a:0',
        '-show_entries','stream=index','-of','csv=p=0',str(source)],capture_output=True,text=True,timeout=20)
    if not info.stdout.strip():return False
    tmp=rendered.with_name(rendered.stem+'_audio.mp4')
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(rendered),'-i',str(source),
         '-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k',
         '-af','apad','-shortest','-movflags','+faststart',str(tmp)]
    r=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
    if r.returncode!=0 or not tmp.is_file():
        raise RuntimeError('Fusion audio original échouée : '+r.stderr[-500:])
    tmp.replace(rendered)
    return True


def _require_source_orientation(src, video, mode):
    meta=_video_metadata(src);output=_video_metadata(video)
    if (meta['width']>meta['height'])!=(output['width']>output['height']):
        raise RuntimeError('Rendu '+mode+' rejeté : orientation source '+str(meta['width'])+'x'+str(meta['height'])+
            ' mais sortie '+str(output['width'])+'x'+str(output['height']))
    return True

def _validate_graph_requirements(graph, objinfo):
    """Spot required unconnected backend inputs before costly H3 sampling.

    This is a conservative object_info check, not a CUDA/runtime proof. The
    backend still validates the full prompt at /prompt before any render.
    """
    broken=[]
    for nid,node in graph.items():
        kind=node.get('class_type','')
        spec=objinfo.get(kind)
        if not spec:
            broken.append(f'{nid}: node {kind} absent');continue
        required=(spec.get('input') or {}).get('required') or {}
        inp=node.get('inputs') or {}
        for name,description in required.items():
            if name in inp:continue
            # Dynamic ComfyUI autogrow sockets are passed as values.a or
            # ref_images.ref_image_0, not as a plain parent 'values'.
            declared=str(description).upper()
            if 'AUTOGROW' in declared and any(k.startswith(str(name)+'.') for k in inp):
                continue
            # Some new backend builds put a tuple describing the autogrow
            # template in the schema without the literal AUTOGROW string.
            if name in ('values','ref_images','ref_videos','ref_video_audios','ref_audios') and \
               any(k.startswith(name+'.') for k in inp):
                continue
            broken.append(f'{nid} {kind}: entrée {name} non raccordée')
    if broken:
        raise RuntimeError('Graphe de retouche incomplet AVANT le rendu : '+'; '.join(broken[:7]))
    return True


def _mode_prompt(mode,p):
    note=str(p.get('instructions') or '').strip()
    target=str(p.get('target') or '').strip()
    if mode=='remove_person':return 'Remove the green-masked '+target+' and reconstruct the background. Preserve the rest of the video, including its camera motion and frame timing. '+note
    if mode=='swap_person':return 'Swap the '+target+' in <Video 1> with the person from <Picture 1>. Use the new person’s face, hair and clothing throughout. Preserve the camera, pose, motion and background. Do not show the reference image background. '+note
    if mode=='move_camera':return 'crossview. '+note
    if mode=='replace_background':return 'Replace the masked environment with '+str(p.get('background_prompt') or note)+'. Preserve the main actor unchanged, including gestures, position, outfit, face and timing.'
    return 'Inpaint only the masked area. '+note+' Preserve everything outside the mask.'


def _choose_image_nodes(graph):
    return [n for n in graph.values() if n['class_type']=='LoadImage']


def _check_mode_graph(graph,mode):
    types=[n['class_type'] for n in graph.values()]
    if mode=='remove_person' and not any('PersonRemover' in t for t in types):raise ValueError('Workflow Person Remover non conforme')
    if mode in ('local_edit','replace_background') and 'LanPaint_VideoMaskEditor' not in types:raise ValueError('Workflow LanPaint non conforme')
    if mode=='move_camera' and not any('CrossView' in t for t in types):raise ValueError('Workflow CrossView non conforme')
    if mode=='swap_person' and not any(t in types for t in ('MiniMaxH3Ref2Video','MiniMaxH3Ref2VA','MiniMaxH3ReferenceToVideo','MiniMaxH3Ref2VideoAudio','MiniMaxH3Ref2VAConditioning')):
        # Some author workflows encode via generic dedicated nodes: allow Ref2VA names.
        if not any('Ref' in t or 'H3' in t for t in types):raise ValueError('Workflow Character Swap non conforme')


def _stage_input(origin,comfy,job_id,suffix):
    dst=comfy/'input'/('retouches_'+job_id+'_'+suffix+origin.suffix.lower())
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(origin,dst)
    return dst.name


def _video_metadata(source):
    """Probe physical source topology, avoid misleading failures deep in H3."""
    try:
        result=subprocess.run(['ffprobe','-v','error','-select_streams','v:0',
          '-show_entries','stream=width,height,nb_frames,duration,avg_frame_rate',
          '-show_entries','format=duration', '-of','json',str(source)],
          capture_output=True,text=True,timeout=18)
    except (OSError,subprocess.TimeoutExpired) as exc:
        raise ValueError('FFmpeg/ffprobe introuvable : installe FFmpeg sur le PATH Windows.') from exc
    if result.returncode!=0:
        raise ValueError('FFprobe ne peut pas lire la vidéo. Utilise un MP4 H.264 valide.')
    data=json.loads(result.stdout or '{}')
    stream=(data.get('streams') or [{}])[0]
    width=int(stream.get('width') or 0);height=int(stream.get('height') or 0)
    rate=str(stream.get('avg_frame_rate') or '0/1')
    try:
        top,bottom=rate.split('/') if '/' in rate else (rate,'1')
        fps=float(top)/float(bottom)
    except (ValueError,ZeroDivisionError):fps=0
    duration=float(stream.get('duration') or data.get('format',{}).get('duration') or 0)
    frames=int(stream.get('nb_frames') or (round(duration*fps) if fps and duration else 0))
    if not (width and height and frames and fps):
        raise ValueError('Métadonnées MP4 incomplètes : dimensions, durée ou FPS indisponibles.')
    return {'width':width,'height':height,'frames':frames,'fps':fps,'duration':duration}




def _wait_for_prompt(pid, max_seconds=400):
    """Wait only for this Comfy prompt; never poll or stop other users' jobs."""
    deadline=time.monotonic()+max_seconds
    while time.monotonic()<deadline:
        time.sleep(2)
        row=comfy_json('/history/'+str(pid),timeout=20).get(str(pid))
        if row is None:continue
        status=row.get('status') or {}
        if status.get('status_str')=='error':
            raise RuntimeError('ComfyUI préparation image : '+str(status.get('messages') or '')[-1300:])
        if status.get('status_str') in ('success','completed') or row.get('outputs'):
            return row
    raise RuntimeError('Préparation image propre SAM3 trop longue. Vérifie la file ComfyUI avant de réessayer.')


def _auto_reference_frame(source, comfy, job_id, target, objinfo):
    """Build a real approximate clean plate using SAM3 + classical inpainting.

    Never pass the unedited first frame as a supposedly clean background.
    This plate is a rough anchor for H3 Relay; difficult occlusions can still
    require a manually retouched plate or a dedicated high-quality image model.
    """
    if not str(target or '').strip():
        raise ValueError('Décris le personnage à retirer pour SAM3')
    needed=('LoadImage','CheckpointLoaderSimple','CLIPTextEncode','SAM3_Detect','MaskToImage','SaveImage')
    missing=[t for t in needed if t not in objinfo]
    if missing:raise RuntimeError('Préparation automatique impossible : nodes SAM3 absents : '+', '.join(missing))
    from PIL import Image
    import numpy as np
    try:
        import cv2
    except ImportError as exc:
        raise RuntimeError('Préparation automatique : OpenCV (cv2) indisponible dans le Python ComfyUI. Installe opencv-python ou fournis une vraie première image propre.') from exc
    plate=comfy/'input'/('retouches_'+job_id+'_clean_plate.png')
    first=comfy/'input'/('retouches_'+job_id+'_first_frame.png')
    first.parent.mkdir(parents=True,exist_ok=True)
    command=['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(source),'-frames:v','1',str(first)]
    proc=subprocess.run(command,capture_output=True,text=True,timeout=60)
    if proc.returncode!=0 or not first.is_file():
        raise RuntimeError('Extraction du premier cadre échouée : '+proc.stderr[-400:])
    prefix='H3FilmSimple/retouches/'+job_id+'_sam3_mask'
    graph={
        '1':{'class_type':'LoadImage','inputs':{'image':first.name}},
        '2':{'class_type':'CheckpointLoaderSimple','inputs':{'ckpt_name':'sam3.1_multiplex_fp16.safetensors'}},
        '3':{'class_type':'CLIPTextEncode','inputs':{'clip':['2',1],'text':str(target)}},
        '4':{'class_type':'SAM3_Detect','inputs':{'model':['2',0], 'image':['1',0], 'conditioning':['3',0],
               'threshold':0.34,'refine_iterations':2,'individual_masks':False}},
        '5':{'class_type':'MaskToImage','inputs':{'mask':['4',0]}},
        '6':{'class_type':'SaveImage','inputs':{'images':['5',0],'filename_prefix':prefix}},
    }
    answer=comfy_json('/prompt',{'prompt':graph,'client_id':'studio_autoplate_'+job_id},timeout=60)
    pid=answer.get('prompt_id')
    if not pid:raise RuntimeError('SAM3 a refusé la préparation de première image : '+str(answer.get('node_errors') or answer)[:900])
    history=_wait_for_prompt(pid,500)
    candidates=[]
    for data in (history.get('outputs') or {}).values():
        if not isinstance(data,dict):continue
        for item in data.get('images',[]):
            if not isinstance(item,dict):continue
            name=Path(str(item.get('filename',''))).name
            sub=Path(str(item.get('subfolder','')).replace('\\','/'))
            if name.endswith('.png') and '..' not in sub.parts:
                path=(comfy/'output'/sub/name).resolve()
                if path.is_relative_to((comfy/'output').resolve()) and path.is_file():
                    candidates.append(path)
    if not candidates:raise RuntimeError('SAM3 n’a renvoyé aucun masque PNG pour créer l’image propre.')
    with Image.open(first) as f, Image.open(candidates[0]) as m:
        image=np.array(f.convert('RGB'))
        mask=np.array(m.convert('L').resize(f.size,Image.Resampling.NEAREST))
    binary=np.where(mask>100,255,0).astype(np.uint8)
    coverage=float(np.count_nonzero(binary))/float(binary.size)
    if coverage<0.001 or coverage>0.75:
        raise RuntimeError('SAM3 a sélectionné une zone incohérente (%.1f%%). Précise le personnage ciblé.'%(100*coverage))
    binary=cv2.dilate(binary,cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(13,13)))
    clean=cv2.inpaint(image,binary,7,cv2.INPAINT_TELEA)
    Image.fromarray(clean,'RGB').save(plate)
    return plate


def _repair_math_inputs(graph,objinfo):
    """Preserve Autogrow inputs (values.a), never fabricate a numerical input."""
    required=((objinfo.get('ComfyMathExpression') or {}).get('input',{}).get('required') or {})
    for node in graph.values():
        if node.get('class_type')!='ComfyMathExpression':continue
        inp=node.setdefault('inputs',{})
        if 'values' in required:
            # New ComfyUI: ComfyMathExpression expects values.a, values.b...
            for k in list(inp):
                if re.fullmatch(r'[a-z]',k) and 'values.'+k not in inp:
                    inp['values.'+k]=inp.pop(k)
            if 'values.a' not in inp and re.search(r'\ba\b',str(inp.get('expression') or '')):
                raise RuntimeError('ComfyMathExpression : valeurs dynamiques values.a manquantes dans le workflow auteur')
        else:
            # Legacy versions expose direct a, b... inputs.
            for k in list(inp):
                if k.startswith('values.') and k.rsplit('.',1)[-1] in required:
                    inp[k.rsplit('.',1)[-1]]=inp.pop(k)
    return graph


def _prepare_shot(source, settings, comfy, job_id):
    """Create a non-destructive, single-shot 24fps H3-compatible working MP4.

    Original HD or arbitrary frame counts are prepared as copies in retouch jobs;
    never patch the source/final film. Any selected range must be one shot.
    """
    info=_video_metadata(source)
    start=float(settings.get('shot_start') or 0)
    finish=float(settings.get('shot_end') or 0) or info['duration']
    if start>=info['duration']-0.01 or finish>info['duration']+0.06 or finish<=start:
        raise ValueError('Limites du plan hors de la vidéo. Ajuste début / fin dans le lecteur.')
    if settings.get('test_clip'):
        finish=min(finish,start+22/24)
    duration=finish-start
    if duration>16:
        raise ValueError('Sélectionne un plan continu de 16 secondes maximum.')
    aligned=5+17*max(0, -((5-int(round(duration*24)))//17))
    aligned=max(5,aligned)
    native=(abs(info['fps']-24)<0.08 and info['width']%32==0 and info['height']%32==0 and
            (info['frames']-5)%17==0 and not start and abs(finish-info['duration'])<0.08)
    cap_w,cap_h=((768,1344) if info['height']>info['width'] else (1344,768))
    if native and ((info['width']<=cap_w and info['height']<=cap_h) or
                   (settings.get('quality')=='quality' and settings['mode'] not in ('local_edit','replace_background'))):
        return source
    # Prepare downscaled native clip rather than rejecting a VISIBLE/HD video.
    max_w,max_h=((768,1344) if info['height']>info['width'] else (1344,768))
    scale=min(1.0,max_w/info['width'],max_h/info['height'])
    w=max(32,int(round(info['width']*scale/32))*32)
    h=max(32,int(round(info['height']*scale/32))*32)
    out=JOBS_ROOT.parent/'prepared'/f'{job_id}_shot.mp4'
    out.parent.mkdir(parents=True,exist_ok=True)
    has_audio=bool(subprocess.run(['ffprobe','-v','error','-select_streams','a:0',
               '-show_entries','stream=index','-of','csv=p=0',str(source)],
               capture_output=True,text=True,timeout=20).stdout.strip())
    command=['ffmpeg','-hide_banner','-loglevel','error','-y','-ss',str(start),'-i',str(source)]
    if not has_audio:
        command += ['-f','lavfi','-i','anullsrc=channel_layout=stereo:sample_rate=32000']
    command += ['-map','0:v:0','-map','0:a:0' if has_audio else '1:a:0',
                '-vf',f'fps=24,scale={w}:{h}:flags=lanczos,tpad=stop_mode=clone:stop_duration=10,trim=end_frame={aligned},setpts=N/(24*TB)',
                '-af',f'apad,atrim=0:{aligned/24:.9f},asetpts=PTS-STARTPTS',
                '-frames:v',str(aligned),
                '-c:v','libx264','-preset','fast','-crf','18','-pix_fmt','yuv420p',
                '-c:a','aac','-ar','32000','-ac','2','-movflags','+faststart',str(out)]
    proc=subprocess.run(command,capture_output=True,text=True,timeout=240)
    if proc.returncode or not out.is_file():
        raise RuntimeError('Préparation FFmpeg du plan échouée : '+proc.stderr[-600:])
    actual=_video_metadata(out)
    if actual['frames']!=aligned:
        raise RuntimeError('Préparation plan : '+str(actual['frames'])+' images au lieu de '+str(aligned))
    return out


def _restore_source_length(rendered, original_source, settings):
    """Discard only H3 17n+5 alignment padding on remove/swap final MP4.

    The V10.52 workflow duplicates the last frame on, for instance, a 120-frame
    source to feed 124 H3 frames. This must NOT become a longer deliverable.
    Never silently conceal a too-short H3 render by appending original frames.
    """
    if settings.get('mode') not in ('remove_person', 'swap_person'):
        return False
    src=_video_metadata(original_source)
    start=float(settings.get('shot_start') or 0)
    end=float(settings.get('shot_end') or 0) or src['duration']
    if settings.get('test_clip'):
        end=min(end,start+22/24)
    if not start and abs(end-src['duration'])<0.08 and abs(src['fps']-24)<0.08:
        wanted=src['frames']
    else:
        wanted=max(1,int(round((end-start)*24)))
    delivered=_video_metadata(rendered)
    if abs(delivered['fps']-24)>0.08:
        raise RuntimeError(f'Export H3: {delivered["fps"]:.3f} FPS au lieu de 24. Durée non fiable.')
    if delivered['frames']<wanted:
        raise RuntimeError(f'Export H3 incomplet : {delivered["frames"]} images pour {wanted} attendues. Aucune fin originale ajoutée artificiellement.')
    if delivered['frames']==wanted:
        return False
    temporary=rendered.with_name(rendered.stem+'_true_length.mp4')
    try:
        # Stream-copy first (lossless for the original H3 bitstream).
        cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(rendered),
             '-map','0:v:0','-an','-frames:v',str(wanted),'-c:v','copy',
             '-movflags','+faststart',str(temporary)]
        result=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
        copied=(result.returncode==0 and temporary.is_file())
        if copied:
            try:copied=_video_metadata(temporary)['frames']==wanted
            except Exception:copied=False
        if not copied:
            temporary.unlink(missing_ok=True)
            cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(rendered),
                 '-map','0:v:0','-an','-vf',f'trim=end_frame={wanted},setpts=PTS-STARTPTS',
                 '-c:v','libx264','-preset','medium','-crf','15','-pix_fmt','yuv420p',
                 '-movflags','+faststart',str(temporary)]
            result=subprocess.run(cmd,capture_output=True,text=True,timeout=240)
            if result.returncode or not temporary.is_file() or _video_metadata(temporary)['frames']!=wanted:
                raise RuntimeError('Découpe exacte des dernières images H3 échouée : '+result.stderr[-400:])
        temporary.replace(rendered)
        return True
    finally:
        temporary.unlink(missing_ok=True)


def _preflight_video(source,mode):
    info=_video_metadata(source)
    if abs(info['fps']-24)>0.08:
        raise ValueError(f"H3 attend 24 FPS : ce clip est à {info['fps']:.3f} FPS. Exporte-le à 24 FPS avant la retouche.")
    if info['width']%32 or info['height']%32:
        raise ValueError(f"H3 exige des dimensions multiples de 32 : clip actuel {info['width']} × {info['height']}. Prépare un MP4 en 960×544 ou 1344×768.")
    if mode in ('local_edit','replace_background') and (info['frames']-5)%17:
        raise ValueError(f"LanPaint H3 attend 17n+5 images : clip actuel {info['frames']} images. Utilise un clip natif H3 (exemple : 124 images).")
    if mode in ('local_edit','replace_background') and (info['width']>(768 if info['height']>info['width'] else 1344) or info['height']>(1344 if info['height']>info['width'] else 768)):
        raise ValueError('LanPaint H3 retouche actuellement au format natif : choisis le RAW du clip, pas son VISIBLE/HD 1920. Le rendu original reste intact.')
    if info['duration']>16:
        raise ValueError('Pour cette version, retouche un seul plan de 16 secondes maximum.')
    if mode in ('local_edit','replace_background'):
        # LanPaint AVEncode uses both native H3 streams, including an audio latent.
        chk=subprocess.run(['ffprobe','-v','error','-select_streams','a:0',
          '-show_entries','stream=codec_name','-of','csv=p=0',str(source)],
          capture_output=True,text=True,timeout=12)
        if not chk.stdout.strip():
            raise ValueError('LanPaint H3 nécessite une piste audio : ajoute une piste silencieuse stéréo au MP4 avant la retouche.')
    return info

def _native_lanpaint_graph(objinfo, mode, source, settings=None):
    """True API-format LanPaint H3 AV workflow, no ComfyUI subgraph dependency.

    The upstream example is a nested frontend graph. Its exact AVEncode ->
    sampler -> AVDecode mask contract is replicated here as flat API nodes.
    """
    # Source dimensions/FPS are read with ffprobe. Preflight checks H3 timing contract.
    settings=settings or {}
    width,height,frame_count=864,480,124
    try:
        process=subprocess.run(['ffprobe','-v','error','-select_streams','v:0',
          '-show_entries','stream=width,height,nb_frames,duration,r_frame_rate','-of','json',str(source)],
          capture_output=True,text=True,timeout=12)
        info=json.loads(process.stdout or '{}').get('streams',[{}])[0]
        width=int(info.get('width') or width);height=int(info.get('height') or height)
        frame_count=int(info.get('nb_frames') or 0)
        if frame_count<1:
            rat=info.get('r_frame_rate') or '24/1';num,den=map(float,rat.split('/'))
            frame_count=int(round(float(info.get('duration') or 5)*num/den))
    except (Exception):pass
    frame_count=max(5,frame_count)
    length=5+17*max(0,(frame_count-5+16)//17)
    # Native H3 supports 32-multiple sizes; the source video is merged again
    # by AVDecode, so retain original full-resolution geometry when possible.
    width=max(32,round(width/32)*32);height=max(32,round(height/32)*32)
    # Do not coerce large sources without warning: silently changing aspect
    # would be worse; ComfyUI may reject or OOM and report the real cause.
    def node(kind, **inputs):return {'class_type':kind,'inputs':inputs}
    g={
      '1':node('UNETLoader',unet_name='minimax_h3_fl2va_pruned_int8_convrot.safetensors',weight_dtype='default'),
      '2':node('CLIPLoader',clip_name='qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors',type='minimax',device='default'),
      '3':node('VAELoader',vae_name='minimax_h3_video_vae_fp16.safetensors'),
      '4':node('VAELoader',vae_name='minimax_h3_audio_vae_fp32.safetensors'),
      '5':node('LanPaint_VideoMaskEditor',video='__SOURCE__',keyframes='{}',audio_mask='[]'),
      '6':node('MiniMaxH3ImageToVideo',clip=['2',0],vae=['3',0],prompt='__PROMPT__',width=width,height=height,length=length),
      '7':node('LanPaint_AVEncode',video=['5',0],vae=['3',0],audio_vae=['4',0],mask=['5',1],audio_mask=['5',2]),
      '8':node('BasicGuider',model=['1',0],conditioning=['6',0]),
      '9':node('RandomNoise',noise_seed=904234),
      '10':node('BasicScheduler',model=['1',0],scheduler='simple',steps=8 if settings.get('quality')=='test' else 20,denoise=1.0),
      '11':node('KSamplerSelect',sampler_name='euler'),
      '12':node('LanPaint_SamplerCustomAdvanced',noise=['9',0],guider=['8',0],sampler=['11',0],sigmas=['10',0],latent_image=['7',0],LanPaint_NumSteps=1 if settings.get('quality')=='test' else 5,LanPaint_Lambda=5.0,LanPaint_StepSize=0.2,LanPaint_PromptMode='Image First',LanPaint_Info='H3 Film Studio Retouches'),
      '13':node('LanPaint_AVDecode',samples=['12',0],video=['5',0],vae=['3',0],audio_vae=['4',0],mask=['5',1],audio_mask=['5',2],blend_overlap=7,audio_crossfade=0.02),
      '14':node('SaveVideo',video=['13',0],filename_prefix='H3FilmSimple/retouches/__JOB__',format='mp4'),
    }
    # Detect once on the FIRST frame, then track this physical subject throughout
    # the entire continuous shot. Never reuse a single screen-space rectangle.
    region=settings.get('region')
    target=str(settings.get('target') or '').strip()
    if mode=='replace_background' and not target and not region:
        target='person'
    if not target and not region:
        raise ValueError('Décris le sujet à suivre ou encadre-le sur la première image du plan')
    if region is not None:
        x,y,w,h=[float(v) for v in region]
        point=json.dumps([{'x':round((x+w/2)*width),'y':round((y+h/2)*height)}])
    else:
        point=''
    g.update({
      '15':node('CheckpointLoaderSimple',ckpt_name='sam3.1_multiplex_fp16.safetensors'),
      '16':node('GetVideoComponents',video=['5',0]),
      '17':node('ImageFromBatch',image=['16',0],batch_index=0,length=1),
      '19':node('SAM3_Detect',model=['15',0],image=['17',0],threshold=0.4,refine_iterations=2,individual_masks=False),
      '20':node('SAM3_VideoTrack',images=['16',0],model=['15',0],initial_mask=['19',0],max_objects=16 if (mode=='replace_background' and not region and target=='person') else 1,detection_threshold=0.5,detect_interval=12),
      '21':node('SAM3_TrackToMask',track_data=['20',0],object_indices=''),
    })
    if target and not point:
        g['18']=node('CLIPTextEncode',clip=['15',1],text=target)
        if mode=='replace_background' and target=='person':
            g['19']['inputs']['individual_masks']=True
        g['19']['inputs']['conditioning']=['18',0]
        g['20']['inputs']['conditioning']=['18',0]
    if point:
        g['19']['inputs']['positive_coords']=point
    tracked=['21',0]
    if mode=='replace_background':
        g['22']=node('InvertMask',mask=tracked)
        tracked=['22',0]
    g['7']['inputs']['mask']=tracked
    g['13']['inputs']['mask']=tracked
    # Export exact tracked masks for pixel-lock compositing AFTER H3.
    # This prevents the actor or unselected surroundings from being rewritten.
    g['25']=node('MaskToImage',mask=['21',0])
    g['26']=node('SaveImage',images=['25',0],filename_prefix='H3FilmSimple/retouches/__JOB__mask')
    for nid,n in g.items():
        spec=(objinfo.get(n['class_type']) or {}).get('input',{})
        valid={**spec.get('required',{}),**spec.get('optional',{})}
        if not valid:raise ValueError('ComfyUI : node manquant '+n['class_type'])
        n['inputs']={k:v for k,v in n['inputs'].items() if k in valid}
        # ComfyUI may have renamed optional scalar fields. Leave their defaults.
        missing=[k for k in spec.get('required',{}) if k not in n['inputs']]
        for key in list(missing):
            entry=valid[key]
            if isinstance(entry,list) and len(entry)>1 and isinstance(entry[1],dict) and 'default' in entry[1]:
                n['inputs'][key]=entry[1]['default'];missing.remove(key)
        if missing:
            raise ValueError('Node '+n['class_type']+' : entrées non reconnues : '+', '.join(missing))
    return g


def _inject(graph,mode,p,comfy,job_id,source,reference):
    """Fill author workflows using only their installed, typed API inputs."""
    video_name=_stage_input(source,comfy,job_id,'video')
    ref_name=_stage_input(reference,comfy,job_id,'reference') if reference else None
    prompt=_mode_prompt(mode,p)
    masks=None
    # Local edits and décor now use SAM3 tracked masks, not static PNG rectangles.
    # LanPaint_VideoMaskEditor acts only as the source VIDEO and audio-mask provider.
    video_count=0; image_count=0; prompt_count=0; save_count=0;camera_count=0
    save_like={'SaveVideo','VHS_VideoCombine','SaveAnimatedWEBP','SaveWEBM','SaveMp4','VideoCombine'}
    for nid,node in graph.items():
        t=node['class_type'];inp=node['inputs'];tl=t.lower()
        if t=='LoadVideo' or t in ('VHS_LoadVideo','VHS_LoadVideoPath'):
            if 'file' in inp:inp['file']=video_name
            elif 'video' in inp:inp['video']=video_name
            elif 'video_path' in inp:inp['video_path']=str(comfy/'input'/video_name)
            video_count+=1
        elif t=='LanPaint_VideoMaskEditor':
            inp['video']=video_name;inp['keyframes']='{}';inp['audio_mask']='[]';video_count+=1
        elif t=='LoadImage' and ref_name:
            inp['image']=ref_name;image_count+=1
        elif t in ('PrimitiveStringMultiline','PrimitiveString') and mode in ('swap_person','move_camera'):
            if 'value' in inp and isinstance(inp['value'],str):
                if mode=='swap_person' or 'crossview' in inp['value'].lower():
                    inp['value']=prompt;prompt_count+=1
        elif t=='PrimitiveFloat' and mode=='swap_person':
            # Only replace the author duration node driving values.a. Other
            # PrimitiveFloat nodes may control camera or sampling parameters.
            duration_ids={str(v[0]) for each in graph.values() if each['class_type']=='ComfyMathExpression'
                          for k,v in each['inputs'].items() if k in ('a','values.a')
                          and isinstance(v,list) and len(v)==2}
            if nid in duration_ids and 'value' in inp:
                inp['value']=float(_video_metadata(source)['frames']/24.0)
        elif t in ('CLIPTextEncode','CLIPTextEncodeSDXL'):
            if 'text' in inp and isinstance(inp['text'],str):
                old=inp['text'].lower()
                # In Person Remover, SAM target is the short description; H3 text is the long prompt.
                if mode=='remove_person' and len(old)<110 and ('remove' not in old and 'background' not in old):
                    inp['text']=str(p.get('target') or '').strip()
                elif mode=='move_camera' and 'crossview' in old:inp['text']=prompt
                # For LanPaint, CLIPTextEncode is SAM3's DETECTION prompt.
                # Never overwrite the tracked subject with H3's edit instructions.
                elif mode in ('local_edit','replace_background'):pass
                elif mode=='swap_person' and ('negative' not in old):inp['text']=prompt
                elif mode=='remove_person' and ('negative' not in old):inp['text']=prompt
                prompt_count+=1
        elif t.startswith('MiniMaxH3') and 'prompt' in inp and mode in ('swap_person','move_camera'):
            inp['prompt']=prompt;prompt_count+=1
        elif t=='MiniMaxH3ImageToVideo' and mode in ('local_edit','replace_background'):
            if 'prompt' in inp:inp['prompt']=prompt;prompt_count+=1
        elif t=='H3RelayPersonRemover' and mode=='remove_person':
            if 'prompt' in inp:inp['prompt']=prompt
        elif t=='SaveImage' and mode in ('local_edit','replace_background'):
            if 'filename_prefix' in inp:
                inp['filename_prefix']='H3FilmSimple/retouches/'+job_id+'_actor_masks'
        elif t in save_like:
            if mode=='remove_person' and ('mask-preview' in str(inp.get('filename_prefix','')).lower() or 'preview' in tl):
                inp['_retouch_preview_only']=True
            for key in ('filename_prefix','filename','save_name'):
                if key in inp:inp[key]='H3FilmSimple/retouches/'+job_id
            if t=='VHS_VideoCombine' and 'format' in inp and not inp.get('format'):
                inp['format']='video/h264-mp4'
            save_count+=1
        elif 'crossview' in tl and mode=='move_camera':
            if 'azimuth' in inp:inp['azimuth']=float(p.get('azimuth',0))
            if 'elevation' in inp:inp['elevation']=float(p.get('elevation',0))
            camera_count+=1
        elif t=='LoraLoaderModelOnly':
            expected=WORKFLOWS[mode]['loras']
            current=str(inp.get('lora_name') or '').lower()
            if expected and (len([v for v in graph.values() if v['class_type']=='LoraLoaderModelOnly'])==1
                             or 'character_swap' in current or 'person-remover' in current
                             or 'crossview' in current):
                inp['lora_name']=expected[0]
                inp['strength_model']=0.8 if mode=='move_camera' else 1.0
    if mode=='remove_person':
        for nid, node in list(graph.items()):
            if node['inputs'].pop('_retouch_preview_only',False):
                del graph[nid]
                continue
        # Output previews are not part of this user's accepted clip.
    if not video_count:raise ValueError('Workflow sans chargeur vidéo reconnu')
    if not save_count:raise ValueError('Workflow sans export vidéo reconnu')
    if WORKFLOWS[mode]['requires_ref'] and not image_count:raise ValueError('Workflow sans LoadImage de référence')
    if mode=='move_camera' and not camera_count:raise ValueError('Workflow sans contrôles CrossViewWarp')
    if mode=='swap_person' and not any(v['class_type']=='LoraLoaderModelOnly' for v in graph.values()):
        raise ValueError('Workflow Character Swap : chargeur LoRA modèle introuvable')
    return video_name


def _extract_results(history,comfy,dst):
    for output in history.get('outputs',{}).values():
        if not isinstance(output,dict):continue
        for key in ('video','videos','gifs','images'):
            for row in output.get(key,[]) if isinstance(output.get(key),list) else []:
                if not isinstance(row,dict):continue
                filename=Path(str(row.get('filename',''))).name
                subfolder=str(row.get('subfolder','')).replace('\\','/')
                if '..' in Path(subfolder).parts or '/' in filename or not filename.lower().endswith('.mp4'):continue
                origin=(comfy/str(row.get('type') or 'output')/subfolder/filename).resolve()
                if origin.is_file() and origin.is_relative_to((comfy/'output').resolve()):
                    shutil.copy2(origin,dst)
                    return True
    return False

def _extract_results_fallback(comfy,dst,job_id):
    base=(comfy/'output').resolve()
    try:
        candidates=[p for p in base.rglob('*.mp4') if p.is_file() and job_id in str(p)]
    except Exception:
        candidates=[]
    if not candidates:
        try:
            branch=base/'H3FilmSimple'/'retouches'
            if branch.is_dir():
                candidates=[p for p in branch.rglob('*.mp4') if p.is_file()]
        except Exception:
            candidates=[]
    if not candidates:return False
    newest=max(candidates,key=lambda p:p.stat().st_mtime)
    shutil.copy2(newest,dst)
    return True


def _tracked_mask_files(history, comfy, output_id='26'):
    result=[]
    row=(history.get('outputs') or {}).get(str(output_id))
    if not isinstance(row,dict):return []
    base=(comfy/'output').resolve()
    for item in row.get('images',[]):
        if not isinstance(item,dict):continue
        name=Path(str(item.get('filename') or '')).name
        folder=Path(str(item.get('subfolder') or '').replace('\\','/'))
        path=(base/folder/name).resolve()
        if name.lower().endswith('.png') and path.is_relative_to(base) and path.is_file():
            result.append(path)
    return result


def _mask_precheck(graph, comfy, job_id, source, region, mask_root='26'):
    """Run only SAM3 tracking and SaveImage before starting expensive LanPaint.

    Same node ids and parameters used later so ComfyUI may reuse cached masks.
    Refuse empty/mismatched masks and a wrong initial region before any H3 step.
    """
    roots=[str(mask_root)]
    visited=set()
    def walk(nid):
        if nid in visited:return
        if nid not in graph:raise ValueError('Masque SAM3 : node introuvable '+nid)
        visited.add(nid)
        for val in graph[nid].get('inputs',{}).values():
            if isinstance(val,list) and len(val)==2 and str(val[0]) in graph:
                walk(str(val[0]))
    for root in roots:walk(root)
    small={key:graph[key] for key in visited}
    with LOCK:
        data=job(job_id);data['status']='checking_mask';_write_job(data)
    _abort_if_cancelled(job_id)
    answer=comfy_json('/prompt',{'prompt':small,'client_id':'studio_mask_'+job_id},timeout=60)
    pid=answer.get('prompt_id')
    if not pid:raise RuntimeError('SAM3 a refusé le graphe de suivi de masque')
    with LOCK:
        data=job(job_id);data['mask_prompt_id']=pid;_write_job(data)
    deadline=time.monotonic()+240
    history=None
    while time.monotonic()<deadline:
        _abort_if_cancelled(job_id)
        time.sleep(2)
        row=comfy_json('/history/'+str(pid),timeout=20).get(str(pid))
        if not row:continue
        if (row.get('status') or {}).get('status_str')=='error':
            raise RuntimeError('SAM3 a échoué pendant le suivi : '+str(row.get('status',{}).get('messages',[]))[-700:])
        if row.get('outputs'):
            history=row;break
    if history is None:raise RuntimeError('SAM3 : suivi non terminé après 4 minutes')
    masks=_tracked_mask_files(history,comfy,output_id=str(mask_root))
    from PIL import Image
    srcmeta=_video_metadata(source)
    if len(masks)!=srcmeta['frames']:
        raise RuntimeError('SAM3 : '+str(len(masks))+' masques au lieu de '+str(srcmeta['frames'])+' images. Rendu H3 non lancé.')
    import numpy as np
    coverage=[]
    for i in sorted(set([0,len(masks)//2,len(masks)-1])):
        with Image.open(masks[i]) as im:
            mask=np.array(im.convert('L'))>100
        frac=float(mask.mean());coverage.append(frac)
        if i==0 and region:
            x,y,w,h=map(float,region)
            yy,xx=np.where(mask)
            if len(xx):
                cx=float(xx.mean())/mask.shape[1];cy=float(yy.mean())/mask.shape[0]
                if not (x-0.08<=cx<=x+w+0.08 and y-0.08<=cy<=y+h+0.08):
                    raise RuntimeError('SAM3 ne suit pas le sujet encadré. Corrige la description ou le cadre ; H3 ne sera pas lancé.')
    # A microphone may occupy only 0.02% of the frame and can legitimately
    # leave the shot later. Require a credible FIRST mask, not coverage in
    # every sampled frame; never start H3 with an empty initial selection.
    if coverage[0]<0.0001 or max(coverage)>0.92:
        raise RuntimeError('SAM3 : premier masque vide ou sélection trop large ('+', '.join(f'{v*100:.2f}%' for v in coverage)+'). Retouche annulée avant H3.')
    return masks


def _build_green_mask_video(source, mask_paths, destination):
    """Loss-minimised 4:4:4 Akatz conditioning, avoiding green chroma bleed.

    The former OpenCV mp4v writer used chroma-subsampled lossy encoding;
    4:2:0 especially causes vivid green to leak into neighbouring dark pixels.
    Keep the original hard masks; only change how they are encoded.
    """
    try: import cv2
    except ImportError as e: raise RuntimeError('Conditionnement vert: OpenCV indisponible') from e
    import numpy as np
    if not mask_paths: raise RuntimeError('Aucun masque SAM3 pour la video verte.')
    cam=cv2.VideoCapture(str(source))
    w=int(cam.get(cv2.CAP_PROP_FRAME_WIDTH));h=int(cam.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps=float(cam.get(cv2.CAP_PROP_FPS) or 24)
    if w<=0 or h<=0:
        cam.release();raise RuntimeError('Video source illisible pour le conditionnement vert.')
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y',
         '-f','rawvideo','-pixel_format','bgr24','-video_size',f'{w}x{h}',
         '-framerate',f'{fps:.8f}','-i','pipe:0','-an','-c:v','libx264',
         '-preset','veryfast','-crf','8','-pix_fmt','yuv444p',
         '-movflags','+faststart',str(destination)]
    encoder=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    count=0
    try:
        for maskfile in mask_paths:
            ok,frame=cam.read()
            if not ok: raise RuntimeError('Masques SAM3 et video source desynchronises.')
            mask=cv2.imread(str(maskfile),cv2.IMREAD_GRAYSCALE)
            if mask is None:raise RuntimeError('Masque SAM3 illisible: '+str(maskfile))
            if mask.shape!=(h,w):mask=cv2.resize(mask,(w,h),interpolation=cv2.INTER_NEAREST)
            frame[mask>=127]=(0,255,0)  # BGR; exact pixels before encoding
            encoder.stdin.write(frame.tobytes())
            count+=1
        if cam.read()[0]:raise RuntimeError('Masques SAM3 insuffisants pour la video verte.')
        encoder.stdin.close()
        rc=encoder.wait(timeout=240)
        stderr=encoder.stderr.read().decode('utf-8','replace')
        if rc or not destination.is_file():
            raise RuntimeError('Encodage vert FFmpeg 4:4:4 echoue: '+stderr[-700:])
        if _video_metadata(destination)['frames']!=count:
            raise RuntimeError('Video verte: frames perdues lors du conditionnement.')
    except Exception:
        if encoder.poll() is None:encoder.kill()
        encoder.wait(timeout=10)
        destination.unlink(missing_ok=True)
        raise
    finally:
        cam.release()
        if encoder.stdin and not encoder.stdin.closed:encoder.stdin.close()
        if encoder.stderr:encoder.stderr.close()
    return destination


def _swap_windows(frames):
    """H3 17n+5 windows, 22-frame overlap, maximum 73 frames per render."""
    if frames<5 or (frames-5)%17:raise ValueError('Longueur H3 invalide')
    if frames<=73:return [(0,frames)]
    result=[];start=0
    while start+73<frames:
        result.append((start,start+73))
        start+=51
    result.append((start,frames))
    if any((b-a-5)%17 or b-a<22 or b-a>73 for a,b in result):
        raise RuntimeError('Decoupage H3 non aligne')
    return result


def _slice_h3_window(source,dst,start,end):
    """Exact 24 FPS video/audio extraction; never pad or borrow other frames."""
    src=_video_metadata(source)
    if start<0 or end>src['frames'] or end<=start:raise ValueError('Intervalle invalide')
    duration=(end-start)/24
    # trim video by INDEX, not -ss rounding; audio by timestamp on the same clock.
    proc=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y',
      '-i',str(source),'-filter_complex',
      f'[0:v]trim=start_frame={start}:end_frame={end},setpts=PTS-STARTPTS[v];'
      f'[0:a]atrim=start={start/24:.9f}:end={end/24:.9f},asetpts=PTS-STARTPTS[a]',
      '-map','[v]','-map','[a]','-frames:v',str(end-start),'-r','24',
      '-c:v','libx264','-preset','veryfast','-crf','17','-pix_fmt','yuv420p',
      '-c:a','aac','-ar','32000','-movflags','+faststart',str(dst)],
      capture_output=True,text=True,timeout=180)
    if proc.returncode or not dst.is_file():
        raise RuntimeError('Decoupe fenetre H3 echouee: '+proc.stderr[-600:])
    slice_meta=_video_metadata(dst)
    if slice_meta['frames']!=end-start or abs(slice_meta['fps']-24)>0.08:
        raise RuntimeError('Nombre d images ou FPS incorrect dans fenetre H3')
    return dst


def _seed_segment_mask(graph,maskfile,comfy,job_id,segment_index,objinfo,min_coverage=0.001):
    """Reinitialise SAME physical actor from the prechecked mask, not new text detection."""
    if 'ImageToMask' not in objinfo:raise RuntimeError('ImageToMask natif requis pour le suivi temporel')
    import numpy as np
    from PIL import Image
    with Image.open(maskfile) as im:
        m=np.array(im.convert('L'))
    frac=float(np.count_nonzero(m>100))/m.size
    if not min_coverage<=frac<=0.75:
        raise RuntimeError(f'Masque acteur absent a la reprise temporelle ({frac*100:.3f}%). Aucun nouveau personnage choisi arbitrairement.')
    staged=_stage_input(Path(maskfile),comfy,job_id,f'swap_anchor_{segment_index}')
    graph['48']={'class_type':'LoadImage','inputs':{'image':staged}}
    graph['49']={'class_type':'ImageToMask','inputs':{'image':['48',0],'channel':'red'}}
    # This mask belongs to the same person as the FIRST-window tracking.
    graph['7']['inputs']['initial_mask']=['49',0]
    graph.pop('6',None)
    return graph


def _stitch_h3_windows(windows, intervals, destination):
    """Blend the 22 shared frames and concatenate exact frame-index segments.

    Avoid xfade's off-by-one/timestamp drop (it exported 123 instead of 124).
    Each segment is decoded exactly once per pair. A hard check prevents loss.
    """
    if len(windows)!=len(intervals) or not windows:raise ValueError('Fenetres invalides')
    if len(windows)==1:
        shutil.copy2(windows[0],destination);return
    intermediate=None
    try:
        for i in range(1,len(windows)):
            left=Path(windows[0]) if i==1 else intermediate
            right=Path(windows[i])
            stop=intervals[i-1][1]
            start=intervals[i][0]
            overlap=stop-start
            if overlap!=22:raise RuntimeError('Chevauchement H3 inattendu')
            expected=intervals[i][1]
            target=destination if i==len(windows)-1 else destination.with_name(destination.stem+f'_join{i}.mp4')
            # First [0:start), blended [start:stop), last [overlap:end).
            # blend T is local to the 22-frame overlap, with endpoints 0 and 21/24.
            blend_seconds=(overlap-1)/24
            graph=(
              f'[0:v]fps=24,split=2[ap][ao];'
              f'[ap]trim=end_frame={start},setpts=PTS-STARTPTS[p];'
              f'[ao]trim=start_frame={start}:end_frame={stop},setpts=PTS-STARTPTS[a];'
              f'[1:v]fps=24,split=2[bo][bt];'
              f'[bo]trim=end_frame={overlap},setpts=PTS-STARTPTS[b];'
              f'[bt]trim=start_frame={overlap},setpts=PTS-STARTPTS[t];'
              f"[a][b]blend=all_expr='A*(1-T/{blend_seconds:.9f})+B*T/{blend_seconds:.9f}'[blend];"
              '[p][blend][t]concat=n=3:v=1:a=0,fps=24[out]')
            cmd=['ffmpeg','-hide_banner','-loglevel','error','-y',
                 '-i',str(left),'-i',str(right),'-filter_complex',graph,
                 '-map','[out]','-an','-c:v','libx264','-preset','fast',
                 '-crf','16','-pix_fmt','yuv420p','-movflags','+faststart',str(target)]
            proc=subprocess.run(cmd,capture_output=True,text=True,timeout=400)
            if proc.returncode or not target.is_file():
                raise RuntimeError('Raccord fenetres H3 echoue: '+proc.stderr[-900:])
            actual=_video_metadata(target)
            if actual['frames']!=expected or abs(actual['fps']-24)>0.08:
                raise RuntimeError(f'Raccord H3: {actual["frames"]} images / {actual["fps"]:.3f}fps pour {expected} images / 24fps attendues')
            if intermediate is not None:intermediate.unlink(missing_ok=True)
            intermediate=target if target!=destination else None
    finally:
        if intermediate is not None:intermediate.unlink(missing_ok=True)


def _run_continuous_remove(job_id,src,original_source,comfy,objinfo,meta,selected,
                           data,staged_ref,masks,green_full):
    """Continue 22-frame H3 removal in 17-frame increments with five CLEAN anchors.

    Never split the original into independent 73-frame generations. After the
    first segment all H3 video inputs are clean anchors + green NEW frames.
    Only the prechecked masks are used; SAM3 cannot select a new actor midway.
    """
    import retouches_remove_relay as relay
    if 'ImageToMask' not in objinfo:
        raise RuntimeError('Continuite H3: ImageToMask requis dans ComfyUI')
    windows=relay.intervals(meta['frames'])
    if len(windows)<2:raise ValueError('Continuite H3 inutile pour 22 images')
    folder=JOBS_ROOT/job_id
    folder.mkdir(parents=True,exist_ok=True)
    chunk_paths=[]
    previous=None
    for index,(start,end) in enumerate(windows):
        _abort_if_cancelled(job_id)
        with LOCK:
            record=job(job_id);record['status']='rendering'
            record['segments_total']=len(windows);record['segments_done']=index
            _write_job(record)
        original_window=relay.cut_window(src,folder/f'relay_original_{index+1:02d}.mp4',
                                         start,end)
        if index==0:
            source_window=original_window
            conditioned_window=relay.cut_window(green_full,
                folder/'relay_green_first.mp4',start,end,has_audio=False,green=True)
        else:
            source_window=relay.make_next_input_stable(previous,src,masks,start,end,
                                                folder/f'relay_conditioned_{index+1:02d}.mp4',
                                                width=meta['width'],height=meta['height'])
            conditioned_window=source_window
        masks_movie=(relay.build_stable_mask_movie(masks,folder/f'relay_mask_{index+1:02d}.mp4',
                                           start,width=meta['width'],height=meta['height'])
                     if index>0 else
                     relay.build_mask_movie(masks,folder/f'relay_mask_{index+1:02d}.mp4',
                                           start,anchored=False,
                                           width=meta['width'],height=meta['height']))
        if _video_metadata(source_window)['frames']!=22 or _video_metadata(masks_movie)['frames']!=22:
            raise RuntimeError('Continuite H3: les sources ne contiennent pas 22 images')
        staged_source=_stage_input(source_window,comfy,job_id,f'relay_video_{index+1:02d}')
        staged_green=_stage_input(conditioned_window,comfy,job_id,f'relay_green_{index+1:02d}')
        staged_mask=_stage_input(masks_movie,comfy,job_id,f'relay_mask_{index+1:02d}')
        graph=build_masked_graph(objinfo,'remove_person',staged_source,staged_ref,
              target_for_mode(data),str(data.get('instructions') or ''),
              selected,lora_name='H3-Person-Remover-V1.safetensors',
              frames=22,width=meta['width'],height=meta['height'],
              quality=data.get('quality','test'),job_id=job_id+f'_relay_{index+1}',
              region=data.get('region'),conditioned_video_filename=staged_green)
        apply_element_prompt(graph,data['mode'],data.get('target'),data.get('instructions'),
                             photo_reference=not data.get('auto_reference'))
        relay.attach_exact_mask(graph,staged_mask,objinfo,continuation=index>0)
        _validate_graph_requirements(graph,objinfo)
        response=comfy_json('/prompt',{'prompt':graph,
                            'client_id':'studio_remove_relay_'+job_id},timeout=65)
        pid=response.get('prompt_id')
        if not pid:
            raise RuntimeError('ComfyUI a refuse le bloc H3: '+str(response.get('node_errors') or response)[:800])
        with LOCK:
            record=job(job_id);record['prompt_id']=pid;_write_job(record)
        history=_wait_for_prompt(pid,60*90)
        previous=folder/f'relay_render_{index+1:02d}.mp4'
        if not _extract_results(history,comfy,previous):
            raise RuntimeError(f'Bloc H3 {index+1}: aucune video produite')
        _require_source_orientation(src,previous,'remove_person')
        if _video_metadata(previous)['frames']!=22:
            raise RuntimeError(f'Bloc H3 {index+1}: rendu incomplet (22 images attendues)')
        # Use V10.58's proven green cleanup on every 22-frame output BEFORE
        # the next block reads its 5 clean anchor frames.
        _remove_green_spill(original_window,previous,masks[start:end])
        chunk=relay.extract_new_frames(previous,folder/f'relay_chunk_{index+1:02d}.mp4',
                                      continuation=index>0)
        wanted=22 if index==0 else 17
        if _video_metadata(chunk)['frames']!=wanted:
            raise RuntimeError(f'Bloc H3 {index+1}: impossible d extraire {wanted} images')
        chunk_paths.append(chunk)
    _abort_if_cancelled(job_id)
    RESULTS.mkdir(parents=True,exist_ok=True)
    rendered=RESULTS/(job_id+'.mp4')
    with LOCK:
        record=job(job_id);record['status']='compositing'
        record['segments_done']=len(windows);_write_job(record)
    relay.join_chunks(chunk_paths,rendered)
    if _video_metadata(rendered)['frames']!=meta['frames']:
        raise RuntimeError('Continuite H3: la video assemblee a perdu des images')
    _restore_source_length(rendered,original_source,data)
    _copy_source_audio(src,rendered,'remove_person')
    with LOCK:
        record=job(job_id);record['status']='complete';record['finished_at']=time.time()
        record['url']='/api/retouches/output/'+job_id;_write_job(record)
    return rendered


def _run_windowed_swap(job_id,src,original_source,comfy,objinfo,meta,selected,
                       data,staged_ref,masks):
    intervals=_swap_windows(meta['frames'])
    if len(intervals)==1:raise ValueError('Decoupage inutile')
    output_dir=JOBS_ROOT/job_id
    output_dir.mkdir(parents=True,exist_ok=True)
    rendered_parts=[]
    for i,(start,end) in enumerate(intervals):
        _abort_if_cancelled(job_id)
        with LOCK:
            row=job(job_id);row['status']='rendering';row['segments_total']=len(intervals)
            row['segments_done']=i;_write_job(row)
        window=_slice_h3_window(src,output_dir/f'swap_window_{i+1}.mp4',start,end)
        staged_video=_stage_input(window,comfy,job_id,f'swap_window_{i+1}')
        graph=build_masked_graph(objinfo,'swap_person',staged_video,staged_ref,
              target_for_mode(data).strip(),str(data.get('instructions') or ''),
              selected,lora_name=(None if data.get('auto_reference') else 'h3_character_swap_pro4500_1000.safetensors'),
              frames=end-start,width=meta['width'],height=meta['height'],
              quality=data.get('quality','test'),job_id=job_id+f'_part{i+1}',
              region=data.get('region'))
        apply_element_prompt(graph,data['mode'],data.get('target'),data.get('instructions'),
                             photo_reference=not data.get('auto_reference'))
        if data['mode']=='replace_element' and data.get('region'):
            from retouches_pixel_tracker import encode_mask_movie, attach_mask_movie
            movie=encode_mask_movie(masks[start:end],output_dir/f'element_mask_window_{i+1}.mp4',
                                    width=meta['width'],height=meta['height'])
            staged_mask=_stage_input(movie,comfy,job_id,f'element_mask_window_{i+1}')
            attach_mask_movie(graph,staged_mask)
        else:
            _seed_segment_mask(graph,masks[start],comfy,job_id,i,objinfo,
                               min_coverage=0.0001 if data['mode']=='replace_element' else 0.001)
        _validate_graph_requirements(graph,objinfo)
        reply=comfy_json('/prompt',{'prompt':graph,'client_id':'studio_swap_window_'+job_id},timeout=65)
        pid=reply.get('prompt_id')
        if not pid:raise RuntimeError('ComfyUI a refuse fenetre swap: '+str(reply.get('node_errors') or reply)[:800])
        with LOCK:
            row=job(job_id);row['prompt_id']=pid;_write_job(row)
        history=_wait_for_prompt(pid,60*90)
        part=output_dir/f'swap_render_{i+1}.mp4'
        if not _extract_results(history,comfy,part):
            # Never borrow an unrelated previous output if Comfy failed.
            raise RuntimeError(f'Fenetre {i+1}: aucune video generee par SaveVideo')
        _require_source_orientation(window,part,'swap_person')
        got=_video_metadata(part)['frames']
        if got!=end-start:
            raise RuntimeError(f'Fenetre {i+1}: {got} images generees, {end-start} requises')
        rendered_parts.append(part)
    _abort_if_cancelled(job_id)
    RESULTS.mkdir(parents=True,exist_ok=True)
    rendered=RESULTS/(job_id+'.mp4')
    with LOCK:
        row=job(job_id);row['status']='compositing';row['segments_done']=len(intervals);_write_job(row)
    _stitch_h3_windows(rendered_parts,intervals,rendered)
    _restore_source_length(rendered,original_source,data)
    _copy_source_audio(src,rendered,'swap_person')
    with LOCK:
        row=job(job_id);row['status']='complete';row['finished_at']=time.time()
        row['url']='/api/retouches/output/'+job_id;_write_job(row)
    return rendered


def _green_spill_mask(original, generated, support, core):
    """Find new chroma-key traces; exclude genuine unchanged green background.

    `support` is the tracked silhouette's motion-aware edge neighborhood, `core`
    its safely reconstructed interior. This function never edits image pixels.
    """
    import numpy as np
    import cv2
    a=original.astype(np.int16)
    b=generated.astype(np.int16)
    # Real residue is often OLIVE-green, not neon: sample of the reported chair
    # edge was only ~10-14 G-over-R/B, beneath V10.57's fixed >24 threshold.
    b_excess=b[:,:,1]-np.maximum(b[:,:,0],b[:,:,2])
    a_excess=a[:,:,1]-np.maximum(a[:,:,0],a[:,:,2])
    green=(b[:,:,1]>=36)&(b_excess>=9)
    newly_green=(b_excess-a_excess>=9)&((b[:,:,1]-a[:,:,1]>=5)|(b_excess-a_excess>=17))
    suspect=green & newly_green & (support>0) & (core==0)
    if not suspect.any():
        return np.zeros(suspect.shape,dtype=np.uint8)
    # Avoid painting away a large intentional new green surface. Only small
    # spill fragments at the tracked subject's edge are eligible for repair.
    if np.count_nonzero(suspect)>max(1200, suspect.size*0.007):
        return np.zeros(suspect.shape,dtype=np.uint8)
    kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(5,5))
    fringe=cv2.dilate(suspect.astype(np.uint8),kernel)>0
    # One-pixel rim includes low-saturation compression halos, but neither
    # changes genuinely green original content nor crosses the tracked zone.
    repair=fringe & (support>0) & (core==0) & (a_excess<8)
    repair |= suspect
    return (repair.astype(np.uint8)*255)


def _remove_green_spill(source,rendered,mask_paths):
    """Clean late green flicker using the ORIGINAL video and moving SAM3 mask.

    Work only around the present/adjacent actor silhouettes. Two-pass scan
    preserves the MP4 untouched if no spill is detected; no extra H3 sampling.
    Only three tracked masks are kept in RAM (large clips remain affordable).
    """
    import cv2
    import numpy as np
    source_meta=_video_metadata(source)
    render_meta=_video_metadata(rendered)
    if render_meta['frames']!=source_meta['frames'] or len(mask_paths)!=render_meta['frames']:
        raise RuntimeError('Correction de vert impossible: masques et images pas alignes')
    if (source_meta['width'],source_meta['height']) != (render_meta['width'],render_meta['height']):
        raise RuntimeError('Correction de vert impossible: resolution de source differente')
    w,h=render_meta['width'],render_meta['height']
    # Scale the motion halo to footage resolution: a 42px ring on native H3,
    # but not an equally huge ring on tiny 128px inputs (nearby real scenery).
    halo_radius=max(24,min(64,int(round(min(w,h)*0.055))))
    halo_kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2*halo_radius+1,2*halo_radius+1))
    core_kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(31,31))

    def read_mask(i):
        mask=cv2.imread(str(mask_paths[i]),cv2.IMREAD_GRAYSCALE)
        if mask is None:raise RuntimeError('Masque SAM3 illisible: '+str(mask_paths[i]))
        if mask.shape!=(h,w):mask=cv2.resize(mask,(w,h),interpolation=cv2.INTER_NEAREST)
        subject=(mask>100).astype(np.uint8)
        return (cv2.dilate(subject,halo_kernel),cv2.erode(subject,core_kernel))

    def scan(writer=None):
        src=cv2.VideoCapture(str(source));gen=cv2.VideoCapture(str(rendered))
        if not src.isOpened() or not gen.isOpened():
            src.release();gen.release()
            raise RuntimeError('Nettoyage vert: impossible de lire les deux videos')
        n=0;spots=0
        previous=None
        current=read_mask(0)
        upcoming=read_mask(1) if len(mask_paths)>1 else None
        try:
            for i in range(len(mask_paths)):
                ok,a=src.read();got,b=gen.read()
                if not ok or not got:
                    raise RuntimeError('Fin de video inattendue pendant le nettoyage vert')
                support=current[0].copy()
                if previous is not None:cv2.bitwise_or(support,previous[0],dst=support)
                if upcoming is not None:cv2.bitwise_or(support,upcoming[0],dst=support)
                spill=_green_spill_mask(a,b,support,current[1])
                spots+=int(cv2.countNonZero(spill))
                if writer is not None:
                    if cv2.countNonZero(spill):
                        b=cv2.inpaint(b,spill,4,cv2.INPAINT_TELEA)
                    writer.stdin.write(b.tobytes())
                previous,current=current,upcoming
                upcoming=read_mask(i+2) if i+2<len(mask_paths) else None
                n+=1
            if src.read()[0] or gen.read()[0]:
                raise RuntimeError('Masques SAM3 insuffisants pour le nettoyage vert')
        finally:
            src.release();gen.release()
        if n!=render_meta['frames']:raise RuntimeError('Nettoyage vert incomplet')
        return spots

    detected=scan()
    if detected<3:return False
    result=rendered.with_name(rendered.stem+'_degreen.mp4')
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo',
         '-pixel_format','bgr24','-video_size',f'{w}x{h}',
         '-framerate','24','-i','pipe:0','-an',
         '-c:v','libx264','-preset','fast','-crf','14','-pix_fmt','yuv420p',
         '-movflags','+faststart',str(result)]
    encoder=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
    try:
        processed=scan(writer=encoder)
        if processed!=detected:
            raise RuntimeError('Nettoyage vert instable : source modifiee durant le travail')
        encoder.stdin.close()
        rc=encoder.wait(timeout=360)
        stderr=encoder.stderr.read().decode('utf-8','replace')
        if rc or not result.is_file():
            raise RuntimeError('Export retouche vert: '+stderr[-700:])
        if _video_metadata(result)['frames']!=render_meta['frames']:
            raise RuntimeError('Des images ont ete perdues au nettoyage du vert')
        result.replace(rendered)
    except Exception:
        if encoder.poll() is None:encoder.kill()
        encoder.wait(timeout=10)
        raise
    finally:
        if encoder.stdin and not encoder.stdin.closed:encoder.stdin.close()
        if encoder.stderr:encoder.stderr.close()
        result.unlink(missing_ok=True)
    return True


def _preview_tracked_masks(source, mask_paths, destination):
    """Fast CPU preview of the actual time-varying SAM3 selection.

    Red highlight = selected subject; the same masks feed latent editing and
    final pixel compositing. This is a preview, not an AI retouch result.
    """
    import cv2
    import numpy as np
    cam=cv2.VideoCapture(str(source))
    w=int(cam.get(cv2.CAP_PROP_FRAME_WIDTH))
    h=int(cam.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps=float(cam.get(cv2.CAP_PROP_FPS) or 24)
    if w<=0 or h<=0:raise RuntimeError('Prévisualisation : vidéo d’entrée illisible')
    raw=destination.with_name(destination.stem+'_masksilent.mp4')
    out=cv2.VideoWriter(str(raw),cv2.VideoWriter_fourcc(*'mp4v'),fps,(w,h))
    if not out.isOpened():
        cam.release()
        raise RuntimeError('Prévisualisation : impossible de démarrer l’encodeur MP4')
    try:
        for maskfile in mask_paths:
            ok,im=cam.read()
            if not ok:raise RuntimeError('Prévisualisation : masque et vidéo non synchronisés')
            mask=cv2.imread(str(maskfile),cv2.IMREAD_GRAYSCALE)
            if mask is None:raise RuntimeError('Masque SAM3 illisible : '+str(maskfile))
            if mask.shape[:2]!=(h,w):
                mask=cv2.resize(mask,(w,h),interpolation=cv2.INTER_NEAREST)
            alpha=(mask.astype(np.float32)/255.0*0.46)[...,None]
            overlay=np.empty_like(im)
            overlay[:]=(30,45,255)
            out.write(np.clip(im.astype(np.float32)*(1-alpha)+overlay*alpha,0,255).astype(np.uint8))
        if cam.read()[0]:raise RuntimeError('Prévisualisation : pas assez de masques SAM3')
    finally:
        out.release();cam.release()
    try:
        r=subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(raw),
           '-c:v','libx264','-preset','veryfast','-crf','21','-pix_fmt','yuv420p',str(destination)],
           capture_output=True,text=True,timeout=180)
        if r.returncode or not destination.is_file():
            raise RuntimeError('Prévisualisation masque FFmpeg échouée : '+r.stderr[-300:])
    finally:raw.unlink(missing_ok=True)


def _composite_tracked_pixels(source, rendered, mask_paths, mode):
    """Strict pixel preservation outside target (or inside actor, for décor)."""
    try:import cv2
    except ImportError as e:raise RuntimeError('Compositing vidéo nécessite opencv-python dans ComfyUI.') from e
    import numpy as np
    if not mask_paths:raise RuntimeError('SAM3 : aucun masque temporel exporté ; refus de modifier les pixels non sélectionnés.')
    src=cv2.VideoCapture(str(source));gen=cv2.VideoCapture(str(rendered))
    tmp=rendered.with_name(rendered.stem+'_silent_lock.mp4')
    output=rendered.with_name(rendered.stem+'_locked.mp4')
    writer=None;count=0
    try:
        fps=float(gen.get(cv2.CAP_PROP_FPS) or 24)
        w=int(gen.get(cv2.CAP_PROP_FRAME_WIDTH));h=int(gen.get(cv2.CAP_PROP_FRAME_HEIGHT))
        if w<=0 or h<=0:raise RuntimeError('Vidéo retouchée illisible pour le verrouillage pixels.')
        writer=cv2.VideoWriter(str(tmp),cv2.VideoWriter_fourcc(*'mp4v'),fps,(w,h))
        if not writer.isOpened():raise RuntimeError('Encodeur MP4 OpenCV indisponible pour le verrouillage pixels.')
        for maskfile in mask_paths:
            src_ok,orig=src.read();gen_ok,edit=gen.read()
            if not src_ok or not gen_ok:raise RuntimeError('Masques SAM3, source et rendu n’ont pas la même durée.')
            if (orig.shape[1],orig.shape[0])!=(w,h):
                orig=cv2.resize(orig,(w,h),interpolation=cv2.INTER_AREA)
            mask=cv2.imread(str(maskfile),cv2.IMREAD_GRAYSCALE)
            if mask is None:raise RuntimeError('Masque SAM3 illisible : '+maskfile.name)
            if (mask.shape[1],mask.shape[0])!=(w,h):
                mask=cv2.resize(mask,(w,h),interpolation=cv2.INTER_NEAREST)
            alpha=(mask.astype(np.float32)/255.0)
            # Alpha=1 within actor for background, within edited area for local edits.
            # Postprocess uses the original actor for décor and generated pixels for retouch.
            alpha=cv2.GaussianBlur(alpha,(5,5),0.8)
            if mode=='replace_background':
                output_frame=orig.astype(np.float32)*alpha[...,None]+edit.astype(np.float32)*(1-alpha[...,None])
            else:
                output_frame=edit.astype(np.float32)*alpha[...,None]+orig.astype(np.float32)*(1-alpha[...,None])
            writer.write(np.clip(output_frame,0,255).astype(np.uint8));count+=1
        if gen.read()[0] or src.read()[0]:
            raise RuntimeError('Nombre de masques SAM3 inférieur à celui des images vidéo.')
        if not count:raise RuntimeError('Aucun masque SAM3 pour le verrouillage.')
    finally:
        if writer:writer.release()
        src.release();gen.release()
    command=['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(tmp),'-i',str(rendered),
             '-map','0:v:0','-map','1:a:0?','-c:v','libx264','-preset','fast','-crf','18',
             '-pix_fmt','yuv420p','-c:a','copy','-shortest',str(output)]
    try:
        result=subprocess.run(command,capture_output=True,text=True,timeout=240)
        if result.returncode!=0 or not output.is_file():
            raise RuntimeError('Fusion des pixels originaux échouée : '+result.stderr[-450:])
        output.replace(rendered)
    finally:
        tmp.unlink(missing_ok=True)
        output.unlink(missing_ok=True)
    return count


def _run(job_id,resolve_source,resolve_comfy):
    with LOCK:
        data=job(job_id);data['status']='preparing';_write_job(data)
    try:
        mode=data['mode'];base=underlying_mode(mode);pixels=(mode in ELEMENT_BACKENDS and bool(data.get('region')))
        cfg=WORKFLOWS[base];src=resolve_source(data['source'])
        if not src or not src.is_file():raise ValueError('Source vidéo introuvable')
        if src.suffix.lower()!='.mp4':raise ValueError('Seuls les clips MP4 sont acceptés')
        original_source=src
        comfy=resolve_comfy().resolve();wf=workflow_path(base)
        src=_prepare_shot(src,data,comfy,job_id)
        _abort_if_cancelled(job_id)
        _preflight_video(src,base)
        info=comfy_json('/object_info',timeout=50)
        report=readiness()['modes'][mode]
        if not report['ready']:
            raise RuntimeError('Dépendances manquantes : '+' ; '.join(report['missing']))
        selected=_select_h3_model(info,base,data.get('model_choice','singularity'))
        if not selected:
            raise RuntimeError('Aucun modèle H3 compatible avec le mode choisi')
        if (base=='remove_person' or (mode=='replace_element' and not data.get('reference'))) and not data.get('mask_only'):
            from retouches_clean_plate import validate as validate_clean_plate
            validate_clean_plate(info)  # Refuse missing Krea2/LanPaint BEFORE SAM3/H3.
        masks=[]
        if base in MASK_MODES:
            reference=Path(data['reference']).resolve() if (data.get('reference') and base=='swap_person') else None
            meta=_video_metadata(src)
            staged_video=_stage_input(src,comfy,job_id,'video')
            staged_ref=_stage_input(reference,comfy,job_id,'reference') if reference else None
            graph=build_masked_graph(info,base,staged_video,staged_ref,
               target_for_mode(data).strip(),
               (str(data.get('background_prompt') or '') if base=='replace_background' else str(data.get('instructions') or '')),
               selected,lora_name=('h3_character_swap_pro4500_1000.safetensors' if base=='swap_person' else None),
               frames=meta['frames'],width=meta['width'],height=meta['height'],
               quality=data.get('quality','test'),job_id=job_id,region=data.get('region'),
               allow_missing_reference=(mode=='replace_element' and not staged_ref))
            apply_element_prompt(graph,mode,data.get('target'),data.get('instructions'),
                                 photo_reference=bool(data.get('reference')))
            _validate_graph_requirements(graph,info)
            if pixels:
                from retouches_pixel_tracker import track_pixel_region
                masks=track_pixel_region(src,data['region'],JOBS_ROOT/job_id/'pixel_masks',
                                         expand=12 if base=='remove_person' else 0)
            else:
                masks=_mask_precheck(graph,comfy,job_id,src,data.get('region'),mask_root='10')
            if data.get('mask_only'):
                RESULTS.mkdir(parents=True,exist_ok=True)
                rendered=RESULTS/(job_id+'.mp4')
                _preview_tracked_masks(src,masks,rendered)
                _copy_source_audio(src,rendered,base)
                with LOCK:
                    row=job(job_id);row['status']='complete';row['finished_at']=time.time();row['url']='/api/retouches/output/'+job_id;_write_job(row)
                return
            # Text-only replacement: prepare the requested new object in the FIRST frame
            # with the existing Krea2/LanPaint first-frame pipeline. Keep reference
            # optional to the user; the resulting image is generated automatically.
            if mode=='replace_element' and not staged_ref:
                from retouches_clean_plate import prepare as prepare_clean_plate
                with LOCK:
                    row=job(job_id);row['status']='preparing_clean_plate';_write_job(row)
                def _submit_element_ref(plate_graph):
                    _abort_if_cancelled(job_id)
                    reply=comfy_json('/prompt',{'prompt':plate_graph,
                                       'client_id':'studio_element_firstframe_'+job_id},timeout=65)
                    if reply.get('prompt_id'):
                        with LOCK:
                            row=job(job_id);row['prompt_id']=reply['prompt_id'];_write_job(row)
                    return reply
                def _await_element_ref(pid):
                    deadline=time.monotonic()+60*25
                    while time.monotonic()<deadline:
                        _abort_if_cancelled(job_id)
                        time.sleep(2)
                        result=comfy_json('/history/'+str(pid),timeout=20).get(str(pid))
                        if not result:continue
                        if (result.get('status') or {}).get('status_str')=='error':
                            raise RuntimeError('Krea2 image initiale remplacement : '+
                                               str(result.get('status',{}).get('messages',[]))[-900:])
                        if (result.get('outputs') or {}).get('11'):return result
                    raise RuntimeError('Krea2 : délai dépassé pour créer le nouvel objet dans la première image.')
                auto_plate=prepare_clean_plate(src,masks,job_id,comfy,info,target_for_mode(data),
                                               _submit_element_ref,_await_element_ref,
                                               replacement_prompt=data.get('instructions'))
                staged_ref=auto_plate.name
                with LOCK:
                    row=job(job_id);row['clean_plate_ready']=True;row['auto_reference']=True;_write_job(row)
                data=dict(data);data['auto_reference']=True
            conditioned_filename=None
            if base=='remove_person':
                with LOCK:
                    row=job(job_id);row['status']='preparing_clean_plate';_write_job(row)
                if not staged_ref:
                    from retouches_clean_plate import prepare as prepare_clean_plate
                    def _submit_plate(plate_graph):
                        _abort_if_cancelled(job_id)
                        reply=comfy_json('/prompt',{'prompt':plate_graph,'client_id':'studio_clean_plate_'+job_id},timeout=65)
                        if reply.get('prompt_id'):
                            with LOCK:
                                record=job(job_id);record['prompt_id']=reply['prompt_id'];_write_job(record)
                        return reply
                    def _await_plate(pid):
                        deadline=time.monotonic()+60*25
                        while time.monotonic()<deadline:
                            _abort_if_cancelled(job_id)
                            time.sleep(2)
                            record=comfy_json('/history/'+str(pid),timeout=20).get(str(pid))
                            if not record:continue
                            state=(record.get('status') or {}).get('status_str')
                            if state=='error':
                                raise RuntimeError('Krea2/LanPaint image propre : '+str(record.get('status',{}).get('messages',[]))[-900:])
                            if (record.get('outputs') or {}).get('11'):
                                return record
                        raise RuntimeError('Délai dépassé pour la création IA de la première image propre.')
                    plate=prepare_clean_plate(src,masks,job_id,comfy,info,
                           target_for_mode(data),_submit_plate,_await_plate)
                    staged_ref=plate.name
                    with LOCK:
                        record=job(job_id);record['clean_plate_ready']=True;_write_job(record)
                green_local=(JOBS_ROOT/job_id/'green_conditioned.mp4')
                green_local.parent.mkdir(parents=True,exist_ok=True)
                _build_green_mask_video(src,masks,green_local)
                staged_conditioned=_stage_input(green_local,comfy,job_id,'conditioned_video')
                graph=build_masked_graph(info,base,staged_video,staged_ref,
                   target_for_mode(data).strip(),
                   str(data.get('instructions') or ''),
                   selected,lora_name=('H3-Person-Remover-V1.safetensors'),
                   frames=meta['frames'],width=meta['width'],height=meta['height'],
                   quality=data.get('quality','test'),job_id=job_id,region=data.get('region'),
                   conditioned_video_filename=staged_conditioned)
                if meta['frames']>22 and not data.get('mask_only'):
                    _run_continuous_remove(job_id,src,original_source,comfy,info,meta,
                                           selected,data,staged_ref,masks,green_local)
                    return
            elif base=='swap_person':
                graph=build_masked_graph(info,base,staged_video,staged_ref,
                   target_for_mode(data).strip(),
                   str(data.get('instructions') or ''),
                   selected,lora_name=(None if data.get('auto_reference') else 'h3_character_swap_pro4500_1000.safetensors'),
                   frames=meta['frames'],width=meta['width'],height=meta['height'],
                   quality=data.get('quality','test'),job_id=job_id,region=data.get('region'))
            apply_element_prompt(graph,mode,data.get('target'),data.get('instructions'),
                                 photo_reference=not data.get('auto_reference'))
            if pixels and (base=='swap_person' or (base=='remove_person' and meta['frames']<=22)):
                from retouches_pixel_tracker import encode_mask_movie, attach_mask_movie
                movie=encode_mask_movie(masks,JOBS_ROOT/job_id/'pixel_full_mask.mp4',
                                        width=meta['width'],height=meta['height'])
                staged_mask=_stage_input(movie,comfy,job_id,'pixel_full_mask')
                if base=='remove_person':
                    import retouches_remove_relay as relay
                    relay.attach_exact_mask(graph,staged_mask,info,continuation=False)
                else:
                    attach_mask_movie(graph,staged_mask)
            _validate_graph_requirements(graph,info)
            if base=='swap_person' and meta['frames']>73 and not data.get('mask_only'):
                _run_windowed_swap(job_id,src,original_source,comfy,info,meta,selected,data,staged_ref,masks)
                return
        else:
            meta=_video_metadata(src)
            staged=_stage_input(src,comfy,job_id,'video')
            graph=build_crossview_graph(info,staged,selected,data.get('azimuth',0),
                 data.get('elevation',0),meta['frames'],meta['width'],meta['height'],
                 quality=data.get('quality','test'),job_id=job_id,
                 preview_only=bool(data.get('mask_only')))
            _validate_graph_requirements(graph,info)
        _abort_if_cancelled(job_id)
        with LOCK:
            data=job(job_id);data['status']='submitting';_write_job(data)
        _abort_if_cancelled(job_id)
        answer=comfy_json('/prompt',{'prompt':graph,'client_id':'studio_retouches_'+job_id},timeout=65)
        pid=answer.get('prompt_id')
        if not pid:
            raise RuntimeError('ComfyUI a refusé le graphe : '+str(answer.get('node_errors') or answer)[:900])
        with LOCK:
            data=job(job_id);data['status']='rendering';data['prompt_id']=pid;_write_job(data)
        if _cancelled(job_id):
            comfy_json('/interrupt',{'prompt_id':pid},timeout=10)
            raise InterruptedError('Retouche annulée')
        deadline=time.monotonic()+60*90
        while time.monotonic()<deadline:
            time.sleep(3)
            _abort_if_cancelled(job_id)
            record=comfy_json('/history/'+str(pid),timeout=20).get(str(pid))
            if not record:continue
            error=record.get('status',{}).get('status_str','')
            if error=='error':raise RuntimeError('ComfyUI : '+str(record.get('status',{}).get('messages',[]))[-1200:])
            if error in ('success','completed') or record.get('outputs'):
                RESULTS.mkdir(parents=True,exist_ok=True)
                rendered=RESULTS/(job_id+'.mp4')
                if not _extract_results(record,comfy,rendered):
                    if not _extract_results_fallback(comfy,rendered,job_id):
                        raise RuntimeError('ComfyUI a terminé sans vidéo MP4 publiée par SaveVideo')
                _require_source_orientation(src,rendered,base)
                if base in ('local_edit','replace_background'):
                    with LOCK:
                        data=job(job_id);data['status']='compositing';_write_job(data)
                    _composite_tracked_pixels(src,rendered,masks,base)
                _abort_if_cancelled(job_id)
                if base=='remove_person':
                    _remove_green_spill(src,rendered,masks)
                _restore_source_length(rendered,original_source,data)
                _copy_source_audio(src,rendered,base)
                with LOCK:
                    data=job(job_id);data['status']='complete';data['finished_at']=time.time();data['url']='/api/retouches/output/'+job_id;_write_job(data)
                return
        raise RuntimeError('Délai de surveillance dépassé : vérifier la file ComfyUI ; ne pas relancer sans vérifier.')
    except Exception as exc:
        import traceback
        trace=traceback.format_exc()
        diagnostic=(JOBS_ROOT/job_id/'diagnostic.txt')
        diagnostic.parent.mkdir(parents=True,exist_ok=True)
        diagnostic.write_text(trace,encoding='utf-8')
        with LOCK:
            data=job(job_id)
            previous_status=data.get('status','inconnu')
            data['status']='cancelled' if _cancelled(job_id) else 'error'
            data['error']=(previous_status+' : '+str(exc))[:1400]
            data['error_location']=next((line.strip() for line in reversed(trace.splitlines())
                                         if line.strip().startswith('File ')), '')[:500]
            data['finished_at']=time.time()
            _write_job(data)
    finally:
        with LOCK:RUNNING.discard(job_id);CANCELLED.discard(job_id)


def start(p,source,resolve_source,resolve_comfy,reference):
    if not isinstance(p,dict):raise ValueError('Retouche invalide')
    mode=str(p.get('mode') or '')
    if mode not in WORKFLOWS:raise ValueError('Mode inconnu')
    base=underlying_mode(mode)
    choice=str(p.get('model_choice') or 'singularity')
    if choice not in ('singularity','fl2va'):
        raise ValueError('Choix du modèle H3 invalide')
    if base not in ('local_edit','replace_background') and choice=='fl2va':
        raise ValueError('Le modèle FL2VA est réservé aux modes LanPaint')
    if not source:raise ValueError('Sélectionne un clip source')
    if base!='swap_person':
        reference=None
    if mode=='swap_person' and not reference:
        raise ValueError('Ajoute une image de référence du nouvel acteur')
    if mode=='replace_element' and not p.get('mask_only') and not str(p.get('instructions') or '').strip():
        raise ValueError('Décris le nouvel objet à créer/remplacer, même sans photo.')
    if base in ('remove_person','swap_person') and not str(p.get('target') or '').strip() and not (mode in ELEMENT_BACKENDS and p.get('region')):
        raise ValueError('Décris précisément le personnage ciblé')
    if mode=='local_edit' and not str(p.get('instructions') or '').strip():
        raise ValueError('Décris la retouche')
    if mode=='replace_background' and not str(p.get('background_prompt') or p.get('instructions') or '').strip():
        raise ValueError('Décris le nouveau décor')
    if mode=='replace_background' and not str(p.get('target') or '').strip() and not p.get('region'):
        p=dict(p); p['target']='person'
    if mode=='local_edit' and not (p.get('region') or str(p.get('target') or '').strip()):
        raise ValueError('Décris le sujet à suivre ou encadre-le sur la première image du plan')
    region=p.get('region')
    if region is not None:
        if not isinstance(region,(tuple,list)) or len(region)!=4:
            raise ValueError('Sélection de sujet invalide')
        try:x,y,w,h=[float(z) for z in region]
        except (TypeError,ValueError):raise ValueError('Sélection de sujet invalide')
        if not all(0<=z<=1 for z in (x,y,w,h)) or w<=0 or h<=0 or x+w>1.001 or y+h>1.001:
            raise ValueError('Sélection hors de la vidéo')
    try:
        shot_start=float(p.get('shot_start') or 0)
        shot_end=float(p.get('shot_end') or 0)
    except (TypeError,ValueError):raise ValueError('Début/fin de plan invalide')
    if not (0<=shot_start<36000 and 0<=shot_end<36000 and (shot_end==0 or shot_end>shot_start)):
        raise ValueError('Début/fin du plan invalide : la fin doit être après le début')
    if p.get('quality','test') not in ('test','quality'):
        raise ValueError('Profil de rendu inconnu')
    for fld in ('target','instructions','background_prompt'):
        if len(str(p.get(fld) or ''))>3000:raise ValueError('Instruction trop longue')
    for fld in ('azimuth','elevation'):
        try:value=float(p.get(fld) or 0)
        except (ValueError,TypeError):raise ValueError('Angle invalide')
        if abs(value)>(90 if fld=='azimuth' else 45):raise ValueError('Angle de caméra hors plage')
    with LOCK:
        if RUNNING:raise ValueError('Une retouche est déjà en cours dans cet onglet')
    job_id=uuid.uuid4().hex
    record={'id':job_id,'mode':mode,'source':source,'reference':str(reference) if reference else '',
            'target':str(p.get('target') or ''),'instructions':str(p.get('instructions') or ''),
            'background_prompt':str(p.get('background_prompt') or ''),'region':p.get('region'),
            'azimuth':float(p.get('azimuth') or 0),'elevation':float(p.get('elevation') or 0),
            'model_choice':choice,'quality':p.get('quality','test'),'mask_only':bool(p.get('mask_only')),'test_clip':bool(p.get('test_clip')), 'shot_start':shot_start, 'shot_end':shot_end,
            'status':'queued','created_at':time.time()}
    # Ensure worker resolution is server controlled, never accept arbitrary path from POST body.
    with LOCK:RUNNING.add(job_id);_write_job(record)
    thread=threading.Thread(target=_run,args=(job_id,resolve_source,resolve_comfy),daemon=True,name='retouche-'+job_id[:6])
    thread.start()
    return {'id':job_id,'status':'queued','message':'Retouche confiée au moteur ComfyUI isolé'}
