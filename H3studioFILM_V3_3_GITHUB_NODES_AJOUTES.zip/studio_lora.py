"""Opt-in model-only LoRA chain for Film Studio H3 RAW/HD.

Disabled: absolutely no mutation of the supplied graph. The original API graph and
H3 runtime stay identical. Enabled: chain ComfyUI core LoraLoaderModelOnly nodes
immediately after the base UNETLoader so RAW and HD model consumers see the same
adapted model. No dependence on a third-party loader's undocumented widget JSON.
"""
from __future__ import annotations
import copy

MAX_LORAS = 12


def normalize(selection):
    if selection is None or selection is False or selection == []:
        return []
    if not isinstance(selection, list) or len(selection) > MAX_LORAS:
        raise ValueError('LoRA : indique au maximum 12 modèles.')
    result=[]
    for row in selection:
        if not isinstance(row,dict):raise ValueError('LoRA : entrée incorrecte.')
        name=str(row.get('name') or '').strip()
        try:strength=float(row.get('strength',1.0))
        except (ValueError,TypeError):raise ValueError('LoRA : force incorrecte.')
        if not name or len(name)>255 or not 0 <= strength <= 2:
            raise ValueError('LoRA : nom requis et force comprise entre 0 et 2.')
        if any(r['name']==name for r in result):raise ValueError('LoRA déjà sélectionné : '+name)
        result.append({'name':name,'strength':strength})
    return result


def validate(selection, objinfo):
    rows=normalize(selection)
    if not rows:return []
    node=objinfo.get('LoraLoaderModelOnly') or {}
    specs=(node.get('input') or {}).get('required') or {}
    spec=specs.get('lora_name') or []
    names=spec[0] if spec and isinstance(spec[0],list) else []
    if not names:raise RuntimeError('ComfyUI : node LoraLoaderModelOnly ou modèles LoRA indisponibles.')
    for row in rows:
        if row['name'] not in names:
            raise ValueError('LoRA introuvable dans ComfyUI/models/loras : '+row['name'])
    return rows


def apply(graph, selection, objinfo):
    """Return original graph object unmodified when off, new graph only when on."""
    if not selection:return graph
    rows=validate(selection,objinfo)
    if not rows:return graph
    if not isinstance(graph,dict):raise ValueError('Graphe H3 invalide')
    source_ids=[k for k,v in graph.items() if v.get('class_type')=='UNETLoader']
    if len(source_ids)!=1:raise RuntimeError('LoRA : attendu un unique UNETLoader dans la phase H3.')
    source=str(source_ids[0])
    direct=[(nid,key) for nid,node in graph.items() for key,value in node.get('inputs',{}).items()
            if isinstance(value,list) and len(value)==2 and str(value[0])==source and value[1]==0]
    if not direct:raise RuntimeError('LoRA : aucune sortie MODEL connectée au UNETLoader.')
    patched=copy.deepcopy(graph)
    numeric=[int(x) for x in patched if str(x).isdigit()]
    next_id=max(numeric,default=0)+1
    upstream=source
    for row in rows:
        nid=str(next_id);next_id+=1
        patched[nid]={'class_type':'LoraLoaderModelOnly',
                      'inputs':{'model':[upstream,0], 'lora_name':row['name'], 'strength_model':row['strength']},
                      '_meta':{'title':'Studio LoRA • '+row['name']}}
        upstream=nid
    for nid,key in direct:
        patched[nid]['inputs'][key]=[upstream,0]
    return patched
