# Point d'entree Film Studio historique : redirige desormais vers le serveur
# UNIQUE Direction + Retouches. Aucun demarrage/arret automatique de ComfyUI.
$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'Start-H3Studio-UNIFIE-7861.ps1') @args
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
