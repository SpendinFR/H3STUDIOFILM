"""Class-agnostic, *pixel-only* boxed-region tracking for the two NEW element modes.

No SAM3 text classification, detection, or embedding is used in this path. We
track source pixels through optical flow and (when necessary) template matching,
then export exact frame-index masks to the existing H3 graphs. This is not a
semantic instance segmenter: a box can cover nearby pixels. The UI shows a
mask-only preview before expensive H3 sampling. Tracking failure stops a job.
"""
from __future__ import annotations
from pathlib import Path
import subprocess


def _box(region,width,height):
    if not isinstance(region,(list,tuple)) or len(region)!=4:
        raise ValueError('Encadrement requis pour le suivi pixels')
    x,y,w,h=[float(z) for z in region]
    if (min(x,y,w,h)<0 or x+w>1.001 or y+h>1.001 or w<=0 or h<=0):
        raise ValueError('Cadre en dehors de la vidéo')
    x0=max(0,int(round(x*width)));y0=max(0,int(round(y*height)))
    x1=min(width,int(round((x+w)*width)));y1=min(height,int(round((y+h)*height)))
    if min(x1-x0,y1-y0)<7:
        raise ValueError('Encadre un objet un peu plus grand (7 pixels minimum)')
    if (x1-x0)*(y1-y0)>0.7*width*height:
        raise ValueError('Cadre trop grand : encadre uniquement l’objet, pas toute l’image')
    return x0,y0,x1,y1


def _initial_mask(frame,box):
    """Try pixel/color segmentation with GrabCut; use the user's box as fallback.

    Independent of known object names; never fabricate a semantic silhouette.
    """
    import cv2,numpy as np
    height,width=frame.shape[:2];x0,y0,x1,y1=box
    mask=np.zeros((height,width),dtype=np.uint8)
    mask[y0:y1,x0:x1]=255
    # GrabCut helps remove plain background pixels within the box. It is only
    # trusted if it keeps the central region and a meaningful component.
    if min(x1-x0,y1-y0)<20 or x0<3 or y0<3 or x1>=width-3 or y1>=height-3:
        return mask
    try:
        gc=np.zeros((height,width),dtype=np.uint8)
        gc[y0:y1,x0:x1]=cv2.GC_PR_FGD
        inset=max(2,min(x1-x0,y1-y0)//6)
        gc[y0+inset:y1-inset,x0+inset:x1-inset]=cv2.GC_FGD
        gc[0:max(0,y0-2),:]=cv2.GC_BGD
        fg=np.zeros((1,65),np.float64);bg=np.zeros((1,65),np.float64)
        cv2.grabCut(frame,gc,None,bg,fg,3,cv2.GC_INIT_WITH_MASK)
        candidate=np.isin(gc,[cv2.GC_FGD,cv2.GC_PR_FGD]).astype(np.uint8)*255
        frac=float(candidate.sum())/255/((x1-x0)*(y1-y0))
        if 0.12<=frac<=0.96 and candidate[y0+inset:y1-inset,x0+inset:x1-inset].mean()>50:
            count_labels,labels,stats,centroids=cv2.connectedComponentsWithStats(candidate,connectivity=8)
            cx=(x0+x1)/2;cy=(y0+y1)/2
            centerlab=labels[min(height-1,int(cy)),min(width-1,int(cx))]
            if centerlab>0 and stats[centerlab,cv2.CC_STAT_AREA]>=0.12*((x1-x0)*(y1-y0)):
                mask[:]=np.where(labels==centerlab,255,0).astype(np.uint8)
    except (cv2.error,ValueError):
        pass
    return mask


def track_pixel_region(source, region, folder, expand=0):
    import cv2,numpy as np
    from PIL import Image
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    cap=cv2.VideoCapture(str(source))
    if not cap.isOpened():raise RuntimeError('Vidéo illisible pour le suivi pixels')
    count=int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    ok,frame=cap.read()
    if not ok or count<5:raise RuntimeError('Vidéo trop courte ou illisible')
    h,w=frame.shape[:2]
    x0,y0,x1,y1=_box(region,w,h)
    roi_w=x1-x0;roi_h=y1-y0
    refmask=_initial_mask(frame,(x0,y0,x1,y1))
    box=np.float32([[x0,y0],[x1,y0],[x1,y1],[x0,y1]])
    gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    prevgray=gray
    last_frame=frame
    last_box=box.copy()
    mask=refmask
    kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(2*expand+1,2*expand+1)) if expand else None
    files=[]
    def write(m,i):
        out=cv2.dilate(m,kernel) if kernel is not None else m
        area=float(np.count_nonzero(out))/out.size
        if area<0.00005 or area>0.82:
            raise RuntimeError(f'Suivi pixels : zone perdue ou trop large à l’image {i}. Revoir encadrement.')
        path=folder/f'pixel_mask_{i:04d}.png';Image.fromarray(out).save(path);files.append(path)
    try:
        write(mask,0)
        for i in range(1,count):
            ok,frame=cap.read()
            if not ok:raise RuntimeError('Suivi pixels : moins d’images que prévu')
            gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
            # Crop for corners from PREVIOUS tracked quadrilateral: no object class lookup.
            xlo=max(0,int(np.floor(last_box[:,0].min())));xhi=min(w,int(np.ceil(last_box[:,0].max())))
            ylo=max(0,int(np.floor(last_box[:,1].min())));yhi=min(h,int(np.ceil(last_box[:,1].max())))
            dx=dy=0.0
            M=None
            if xhi>xlo+6 and yhi>ylo+6:
                corners=cv2.goodFeaturesToTrack(prevgray[ylo:yhi,xlo:xhi],maxCorners=80,qualityLevel=0.012,minDistance=4,blockSize=5)
                if corners is not None and len(corners)>=4:
                    old=corners.reshape(-1,2).astype(np.float32)+np.float32([xlo,ylo])
                    new,st,err=cv2.calcOpticalFlowPyrLK(prevgray,gray,old.reshape(-1,1,2),None,winSize=(21,21),maxLevel=3)
                    good=(st.reshape(-1)>0)&(err.reshape(-1)<32)&np.isfinite(new.reshape(-1,2)).all(axis=1)
                    a=old[good];b=new.reshape(-1,2)[good]
                    if len(a)>=5:
                        predicted,inliers=cv2.estimateAffinePartial2D(a,b,method=cv2.RANSAC,ransacReprojThreshold=3.0,maxIters=500,confidence=0.98)
                        if predicted is not None and np.sum(inliers)>=4:
                            scale=np.linalg.norm(predicted[0,:2]);shift=np.linalg.norm(predicted[:,2])
                            if 0.92<=scale<=1.08 and shift<=max(14,0.085*max(w,h)):
                                M=predicted.astype(np.float32)
                    if M is None and len(a)>=3:
                        movement=np.median(b-a,axis=0)
                        if np.linalg.norm(movement)<=max(14,0.085*max(w,h)):
                            dx,dy=map(float,movement)
                            M=np.float32([[1,0,dx],[0,1,dy]])
            if M is None:
                # Featureless target: compare exact pixels inside a local search region.
                pad=max(13,int(max(roi_w,roi_h)*0.55))
                xx0=max(0,xlo-pad);xx1=min(w,xhi+pad)
                yy0=max(0,ylo-pad);yy1=min(h,yhi+pad)
                template=prevgray[ylo:yhi,xlo:xhi]
                patch=gray[yy0:yy1,xx0:xx1]
                if template.size<100 or patch.shape[0]<template.shape[0] or patch.shape[1]<template.shape[1]:
                    raise RuntimeError(f'Suivi pixels perdu à l’image {i} (région hors cadre).')
                score=cv2.matchTemplate(patch,template,cv2.TM_CCOEFF_NORMED)
                _,best,_,loc=cv2.minMaxLoc(score)
                if not np.isfinite(best) or best<0.52:
                    raise RuntimeError(f'Suivi pixels incertain à l’image {i} (corrélation {best:.2f}). Ajuste le cadre.')
                dx=float(xx0+loc[0]-xlo);dy=float(yy0+loc[1]-ylo)
                M=np.float32([[1,0,dx],[0,1,dy]])
            box_new=cv2.transform(last_box.reshape(1,-1,2),M).reshape(-1,2)
            if (box_new[:,0].max()<1 or box_new[:,1].max()<1 or
                box_new[:,0].min()>w-2 or box_new[:,1].min()>h-2):
                raise RuntimeError(f'Suivi pixels : objet sorti de l’image à {i}')
            mask=cv2.warpAffine(mask,M,(w,h),flags=cv2.INTER_NEAREST,borderMode=cv2.BORDER_CONSTANT,borderValue=0)
            write(mask,i)
            last_box=box_new;prevgray=gray;last_frame=frame
        if len(files)!=count or cap.read()[0]:
            raise RuntimeError('Suivi pixels : synchronisation des masques incomplète')
        return files
    finally:
        cap.release()


def encode_mask_movie(mask_paths,destination,width,height):
    """Encode 17n+5 mask images as true-luma, 4:4:4 lossless MP4."""
    import cv2,numpy as np
    dest=Path(destination);dest.parent.mkdir(parents=True,exist_ok=True)
    if not mask_paths:raise ValueError('No pixel masks')
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo',
         '-pixel_format','gray','-video_size',f'{width}x{height}',
         '-framerate','24','-i','pipe:0','-an','-c:v','libx264','-preset','fast',
         '-crf','0','-pix_fmt','yuv444p',str(dest)]
    proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=subprocess.PIPE,stdout=subprocess.DEVNULL)
    try:
        for path in mask_paths:
            arr=cv2.imread(str(path),cv2.IMREAD_GRAYSCALE)
            if arr is None:raise RuntimeError('Mask illisible : '+str(path))
            if arr.shape!=(height,width):raise ValueError('Dimensions incorrectes des masques pixels')
            proc.stdin.write(np.where(arr>100,255,0).astype(np.uint8).tobytes())
        proc.stdin.close()
        stderr=proc.stderr.read().decode('utf-8','replace')
        if proc.wait(timeout=180)!=0 or not dest.is_file():
            raise RuntimeError('Encodage des masques pixels : '+stderr[-600:])
    except BaseException:
        if proc.poll() is None:proc.kill()
        proc.wait(timeout=20);dest.unlink(missing_ok=True)
        raise
    finally:
        if proc.stdin and not proc.stdin.closed:proc.stdin.close()
        if proc.stderr:proc.stderr.close()
    return dest


def attach_mask_movie(graph,mask_video_staged):
    """Bypass SAM3 classification, retain V10.73 MVEx crop/cleanup/uncrop.

    Prechecked mask is decoded as a frame-accurate mask input to the ORIGINAL
    mode's node 11. All other H3/LoRA, latent, and compositing nodes unchanged.
    """
    for nid in ('70','71','72'):
        if nid in graph:raise ValueError('Pixel mask node collision')
    if '11' not in graph or '28' not in graph:
        raise RuntimeError('Expected V10.73 swap graph missing mask chain')
    graph['70']={'class_type':'LoadVideo','inputs':{'file':str(mask_video_staged)}}
    graph['71']={'class_type':'GetVideoComponents','inputs':{'video':['70',0]}}
    graph['72']={'class_type':'ImageToMask','inputs':{'image':['71',0],'channel':'red'}}
    graph['11']['inputs']['masks']=['72',0]
    for nid in ('3','4','5','6','7','8'):
        graph.pop(nid,None)
    return graph
