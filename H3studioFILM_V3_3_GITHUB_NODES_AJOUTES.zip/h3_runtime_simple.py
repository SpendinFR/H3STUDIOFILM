from __future__ import annotations
import ast
import base64
import copy
import json
import os
import random
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

# Minimal runtime extracted from V13.9.1R: H3Studio/Motion Context + VLM transport only.
# Public technical constants used by the simplified orchestrator.
CHAR_REF_STRENGTH = 1.0
DECOR_REF_STRENGTH = 0.75
MAX_REF_IMAGES = 8

COMFY_URL = "http://127.0.0.1:8188"

OLLAMA_URL = "http://127.0.0.1:11434"

WIDTH = 960

HEIGHT = 544

FPS = 24

REF_MEGAPIXELS = 0.0

OBSERVER_TAIL_IMAGES = 3

DIRECTOR_TAIL_SECONDS = 1.0

DIRECTOR_MAX_IMAGE_DIM = 768

DIRECTOR_CPU_SAFE = False

GPU_VRAM_MARGIN_MB = 768

GPU_VRAM_STABLE_POLLS = 3

GPU_VRAM_POLL_SECONDS = 1.5

MOTION_FRAMES = 22

MOTION_AUDIO_FRAMES = 22

MOTION_STRENGTH = 1.0

FIRST_FRAME_COUNT = 124
CONT_FRAME_COUNT = 141

MAX_H3_RENDER_SECONDS = 2400

V8_OBSERVER_IMAGES = 10

VIDEO_EXTS = {".mp4", ".webm", ".mkv", ".mov", ".m4v", ".avi"}

def http_json(url: str, method: str = "GET", data: Any | None = None, timeout: int = 30) -> Any:
    body = None
    headers = {"Accept": "application/json"}
    if data is not None:
        body = json.dumps(data).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read().decode("utf-8", errors="replace")
            return json.loads(raw) if raw.strip() else {}
    except urllib.error.HTTPError as e:
        text = e.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {e.code} {url}: {text[:3000]}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"Impossible de joindre {url}: {e}") from e

def find_comfy_dir() -> Path:
    env = os.environ.get("COMFYUI_DIR")
    candidates = [
        Path(env) if env else None,
        Path(r"C:\AI\ComfyUI_windows_portable\ComfyUI"),
        Path(r"C:\ComfyUI_windows_portable\ComfyUI"),
        Path.home() / "ComfyUI",
    ]
    for p in candidates:
        if p and (p / "models").is_dir() and (p / "custom_nodes").is_dir():
            return p
    # Last-resort shallow search in C:\AI only.
    ai = Path(r"C:\AI")
    if ai.is_dir():
        for p in ai.glob("**/ComfyUI"):
            if (p / "models").is_dir() and (p / "custom_nodes").is_dir():
                return p
    raise RuntimeError("ComfyUI introuvable. Attendu: C:\\AI\\ComfyUI_windows_portable\\ComfyUI")

def wait_for_comfy(max_wait: int = 180) -> None:
    """Wait for ComfyUI without repeatedly downloading its large node registry.

    /object_info can be slow when many custom nodes are loaded; the old 3-second
    timeout caused a *false* offline status, despite the unified launcher's
    longer /object_info check having succeeded. This light endpoint does not
    change queue state, loaded models, or any H3 render settings.
    """
    deadline = time.monotonic() + max_wait
    last_error = None
    attempts = 0
    while time.monotonic() < deadline:
        attempts += 1
        remaining = deadline - time.monotonic()
        try:
            http_json(COMFY_URL + "/system_stats", timeout=max(1, min(12, remaining)))
            print(f"[FILM][INIT] ComfyUI joignable sur 8188 (verification legere, essai {attempts}).", flush=True)
            return
        except Exception as exc:
            last_error = exc
            if attempts == 1 or attempts % 4 == 0:
                print(f"[FILM][INIT] /system_stats indisponible ({type(exc).__name__}: {exc}); repli sur /object_info.", flush=True)
            # Some older/custom builds expose /object_info but not /system_stats.
            # Unlike the former 3-second loop, allow this heavyweight endpoint
            # the same generous time budget as the launcher itself.
            remaining = deadline - time.monotonic()
            if remaining > 0:
                try:
                    http_json(COMFY_URL + "/object_info", timeout=max(1, min(45, remaining)))
                    print("[FILM][INIT] ComfyUI joignable par /object_info (repli).", flush=True)
                    return
                except Exception as backup_exc:
                    last_error = backup_exc
            if time.monotonic() >= deadline:
                break
            time.sleep(min(2, max(0, deadline - time.monotonic())))
    raise RuntimeError("ComfyUI ne repond pas sur " + COMFY_URL + "/system_stats apres "
                       + str(max_wait) + " secondes. Derniere erreur : " + str(last_error))

def choose_vision_model(tags: dict) -> str:
    names = []
    for m in tags.get("models", []):
        name = m.get("name") or m.get("model")
        if name:
            names.append(name)
    low = {n.lower(): n for n in names}
    # Prefer NON-THINKING vision directors for deterministic JSON specialist passes.
    # Qwen3-VL thinking tags can ignore think=false in some Ollama builds and consume the
    # whole context before emitting JSON; the official -instruct variants avoid that.
    prefs = [
        "qwen3-vl:2b-instruct", "qwen3-vl:4b-instruct", "qwen3-vl:8b-instruct",
        "qwen2.5vl:3b", "qwen2.5vl:7b", "llama3.2-vision:11b",
        "qwen3-vl:2b", "qwen3-vl:4b", "qwen3-vl:8b", "qwen3-vl:latest",
    ]
    for p in prefs:
        if p in low:
            chosen = low[p]
            cl = chosen.lower()
            if ("qwen3-vl" in cl or "qwen3vl" in cl) and "instruct" not in cl:
                print(f"  WARN VLM: {chosen} est une variante thinking; préférence recommandée: tag -instruct. Le runtime activera son fallback no-think si nécessaire.")
            return chosen
    for n in names:
        ln = n.lower()
        if "qwen3-vl" in ln or "qwen3vl" in ln or "vision" in ln or "vl" in ln:
            return n
    raise RuntimeError(
        "Aucun modèle vision Ollama détecté. V3 a besoin d'un VLM local, par exemple: "
        "ollama pull qwen3-vl:4b-instruct (ou qwen3-vl:8b-instruct)."
    )

def ollama_json_images(model: str, system: str, user: str, image_paths: list[Path],
                       *, cpu_safe: bool = True, timeout: int = 240, label: str = "VLM",
                       retry_system_suffixes: list[str] | None = None,
                       context_sequence: list[int] | None = None) -> dict:
    """Robust vision call. Same VLM selection as V4.8; retry transport/empty replies.

    IMPORTANT: retries never replace pixels with intended text. If all attempts fail,
    the caller receives an exception and must keep rendered state UNKNOWN.
    """
    # Project-wide invariant: never send more than three images to one VLM request.
    # Specialist callers deliberately choose the useful temporal window first.  Failing
    # loudly here prevents a future refactor from silently re-introducing 4/6/10-image calls.
    if len(image_paths) > 3:
        raise RuntimeError(f"VLM_IMAGE_LIMIT_EXCEEDED: {len(image_paths)} images (maximum 3)")

    images: list[str] = []
    for path in image_paths:
        raw = Path(path).read_bytes()
        images.append(base64.b64encode(raw).decode("ascii"))

    def parse_text(out: dict) -> dict:
        msg = out.get("message") if isinstance(out, dict) else None
        content = str((msg or {}).get("content") or "").strip() if isinstance(msg, dict) else ""
        if not content:
            reason = str(out.get("done_reason") or (msg or {}).get("done_reason") or "").strip() if isinstance(out, dict) else ""
            thinking = str((msg or {}).get("thinking") or "") if isinstance(msg, dict) else ""
            eval_count = out.get("eval_count") if isinstance(out, dict) else None
            prompt_eval_count = out.get("prompt_eval_count") if isinstance(out, dict) else None
            meta = []
            if reason: meta.append(f"done_reason={reason}")
            if thinking: meta.append(f"thinking_chars={len(thinking)}")
            if eval_count is not None: meta.append(f"eval_count={eval_count}")
            if prompt_eval_count is not None: meta.append(f"prompt_eval_count={prompt_eval_count}")
            raise RuntimeError("EMPTY_VLM_REPLY" + ((" " + " ".join(meta)) if meta else ""))
        try:
            obj = json.loads(content)
        except json.JSONDecodeError:
            m = re.search(r"\{.*\}", content, re.S)
            if not m:
                raise RuntimeError("Réponse VLM non JSON: " + content[:1200])
            obj = json.loads(m.group(0))
        if not isinstance(obj, dict):
            raise RuntimeError("Réponse VLM JSON invalide: racine non objet")
        return obj

    base_options: dict[str, Any] = {"temperature": 0.20, "num_ctx": 8192}
    if cpu_safe:
        base_options["num_gpu"] = 0
    model_low = str(model or "").lower()
    qwen3vl_thinking_only = ("qwen3-vl" in model_low or "qwen3vl" in model_low) and "instruct" not in model_low

    # Qwen3-VL thinking builds can ignore think=False and consume the whole context
    # in hidden reasoning before emitting JSON.  Our specialist tasks need tiny JSON,
    # not a chain of thought.  Keep context compact and output bounded; for thinking-only
    # Qwen3-VL tags the raw /no_think prefill is used from ATTEMPT 1, not only after a
    # guaranteed first failure.  A modest 12K context remains as the final transport
    # fallback for unusually large prompts, never as permission for more reasoning.
    ctxs=list(context_sequence or [8192,8192,12288])
    if not ctxs:
        ctxs=[8192,8192,12288]
    while len(ctxs)<3:
        ctxs.append(ctxs[-1])
    attempts = [
        {"temperature": 0.05, "num_ctx": int(ctxs[0]), "num_predict": 900},
        {"temperature": 0.02, "num_ctx": int(ctxs[1]), "num_predict": 1100},
        {"temperature": 0.01, "num_ctx": int(ctxs[2]), "num_predict": 1200},
    ]
    last_exc: Exception | None = None
    for attempt_no, opt_patch in enumerate(attempts, 1):
        options = dict(base_options)
        options.update(opt_patch)
        system_for_attempt = system
        if retry_system_suffixes:
            suffix = retry_system_suffixes[min(attempt_no - 1, len(retry_system_suffixes) - 1)] if retry_system_suffixes else ""
            if suffix:
                system_for_attempt = system + "\n" + suffix
        messages = [
            {"role": "system", "content": system_for_attempt},
            {"role": "user", "content": user, "images": images},
        ]
        payload = {
            "model": model,
            "stream": False,
            "think": False,
            "format": "json",
            "keep_alive": 0,
            "messages": messages,
            "options": options,
        }
        # Some Ollama Qwen3-VL thinking tags ignore think=false and end with empty content.
        # Use the proven no-think assistant-prefill workaround immediately for those tags.
        # Official -instruct tags keep the normal API path above.
        if qwen3vl_thinking_only:
            payload["raw"] = True
            payload["messages"] = [
                {"role": "system", "content": system_for_attempt},
                {"role": "user", "content": user + "\n/no_think\nReturn ONLY the requested JSON object now. No reasoning, no explanation.", "images": images},
                {"role": "assistant", "content": "<think>\n\n</think>\n\n"},
            ]
        try:
            out = http_json(OLLAMA_URL + "/api/chat", "POST", payload, timeout=timeout)
            return parse_text(out if isinstance(out, dict) else {})
        except Exception as exc:
            last_exc = exc
            print(f"    {label}: tentative vision {attempt_no}/3 échouée ({type(exc).__name__}: {exc})")
            # A stopped runner is safer to restart cleanly before the next try.
            if attempt_no < len(attempts):
                try:
                    http_json(OLLAMA_URL + "/api/generate", "POST", {"model": model, "prompt": "", "stream": False, "keep_alive": 0}, timeout=45)
                except Exception:
                    pass
                time.sleep(0.9)

    raise RuntimeError(f"{label}: VLM indisponible après 3 tentatives; aucune observation textuelle ne sera substituée ({last_exc}).")

def _model_matches(query: str, running_name: str) -> bool:
    q = (query or "").lower()
    r = (running_name or "").lower()
    return bool(q and r and (q == r or q.split(":")[0] == r.split(":")[0]))

def query_gpu_vram() -> dict[str, int] | None:
    try:
        out = subprocess.check_output([
            "nvidia-smi",
            "--query-gpu=memory.used,memory.total",
            "--format=csv,noheader,nounits",
        ], stderr=subprocess.DEVNULL, text=True, timeout=5)
    except Exception:
        return None
    lines = [ln.strip() for ln in (out or "").splitlines() if ln.strip()]
    if not lines:
        return None
    m = re.match(r"\s*(\d+)\s*,\s*(\d+)\s*$", lines[0])
    if not m:
        return None
    used = int(m.group(1))
    total = int(m.group(2))
    return {"used": used, "total": total, "free": max(0, total - used)}

def print_gpu_vram(prefix: str) -> None:
    v = query_gpu_vram()
    if not v:
        print(f"  {prefix}: VRAM nvidia-smi indisponible")
        return
    print(f"  {prefix}: VRAM {v['used']} / {v['total']} MiB (libre {v['free']} MiB)")

def wait_ollama_released(model: str | list[str], max_wait: int = 30, baseline_used_mb: int | None = None, label: str = "") -> None:
    """Attend qu'Ollama ait réellement rendu la VRAM avant de lancer H3."""
    models = [model] if isinstance(model, str) else list(model or [])
    models = [m for m in models if m]
    baseline_limit = (baseline_used_mb + GPU_VRAM_MARGIN_MB) if baseline_used_mb is not None else None
    if label:
        print_gpu_vram(f"{label} — avant attente de libération")
    deadline = time.time() + max_wait
    stable = 0
    while time.time() < deadline:
        try:
            ps = http_json(OLLAMA_URL + "/api/ps", timeout=3)
            running = []
            for m in ps.get("models", []):
                n = (m.get("name") or m.get("model") or "").lower()
                if n:
                    running.append(n)
            ps_clear = not any(any(_model_matches(q, n) for n in running) for q in models)
        except Exception:
            ps_clear = True

        v = query_gpu_vram()
        vram_clear = True
        if baseline_limit is not None and v is not None:
            vram_clear = v["used"] <= baseline_limit

        if ps_clear and vram_clear:
            stable += 1
            if stable >= GPU_VRAM_STABLE_POLLS:
                if label:
                    print_gpu_vram(f"{label} — libération confirmée")
                return
        else:
            stable = 0

        time.sleep(GPU_VRAM_POLL_SECONDS)

    print("  Attention: libération Ollama/VRAM non totalement confirmée avant H3.")
    if label:
        print_gpu_vram(f"{label} — état final après attente")
    time.sleep(3)

def abort_comfy_generation(label: str = "") -> None:
    """Immediately stop the active ComfyUI prompt and clear pending work.

    Used on Ctrl+C. Unlike comfy_hard_free this path intentionally avoids long
    sleeps: the priority is to stop GPU generation before the process exits.
    """
    if label:
        print(f"  {label}: envoi interrupt + clear queue + free à ComfyUI...")
    errors = []
    for url, payload in (
        (COMFY_URL + "/interrupt", {}),
        (COMFY_URL + "/queue", {"clear": True}),
        (COMFY_URL + "/free", {"unload_models": True, "free_memory": True}),
    ):
        try:
            http_json(url, "POST", payload, timeout=8)
        except Exception as exc:
            errors.append(f"{url.rsplit('/',1)[-1]}: {exc}")
    if errors:
        raise RuntimeError("; ".join(errors))
    if label:
        print(f"  {label}: ComfyUI interrompu et queue vidée.")


def comfy_hard_free(label: str = "") -> None:
    """Libération forte de ComfyUI entre les étapes lourdes.

    Reproduit la séquence PowerShell validée par l'utilisateur : interrupt,
    clear queue, /free, puis un second /free après un court délai.
    Cette fonction n'est appelée qu'en dehors d'un rendu actif.
    """
    if label:
        print_gpu_vram(f"{label} — avant nettoyage ComfyUI")

    # Stoppe toute exécution résiduelle et vide une éventuelle queue ancienne.
    for url, payload in (
        (COMFY_URL + "/interrupt", {}),
        (COMFY_URL + "/queue", {"clear": True}),
        (COMFY_URL + "/free", {"unload_models": True, "free_memory": True}),
    ):
        try:
            http_json(url, "POST", payload, timeout=15)
        except Exception as exc:
            print(f"  Attention nettoyage ComfyUI {url.rsplit('/',1)[-1]}: {exc}")

    time.sleep(2.0)

    # Deuxième passe : ComfyUI traite parfois /free de façon asynchrone.
    try:
        http_json(COMFY_URL + "/free", "POST", {"unload_models": True, "free_memory": True}, timeout=15)
    except Exception as exc:
        print("  Attention: seconde libération ComfyUI non confirmée:", exc)

    time.sleep(3.0)
    if label:
        print_gpu_vram(f"{label} — après nettoyage ComfyUI")

def _clean_sentence(text: str) -> str:
    text = re.sub(r"\s+", " ", (text or "").strip())
    return text.rstrip(" .")

def find_workflow(comfy: Path) -> Path:
    # This FilmMaker is locked to the exact workflow supplied for this project.
    # Never silently fall back to H3Studio Basic_usage.json: that would reintroduce
    # the obsolete renderer/settings the user explicitly replaced.
    local = Path(__file__).resolve().parent / "workflows" / "H3Studio_1920_API_CLEAN.json"
    if not local.is_file():
        raise RuntimeError(f"Workflow H3 FilmMaker obligatoire introuvable: {local}")
    return local

def input_schema(info: dict, class_type: str) -> tuple[dict, dict]:
    ci = info.get(class_type) or {}
    inp = ci.get("input") or {}
    return inp.get("required") or {}, inp.get("optional") or {}

def schema_default(spec: Any) -> Any:
    if not isinstance(spec, (list, tuple)) or len(spec) < 1:
        return None
    typ = spec[0]
    opts = spec[1] if len(spec) > 1 and isinstance(spec[1], dict) else {}
    if "default" in opts:
        return opts["default"]
    # A list of strings is a combo.
    if isinstance(typ, list) and typ:
        return typ[0]
    return None

def is_connection_type(spec: Any) -> bool:
    if not isinstance(spec, (list, tuple)) or not spec:
        return False
    typ = spec[0]
    if isinstance(typ, list):
        return False
    return str(typ).upper() not in {"STRING", "INT", "FLOAT", "BOOLEAN", "COMBO"}

def gui_to_api(gui: dict, objinfo: dict) -> dict:
    links = {int(x[0]): x for x in gui.get("links", []) if isinstance(x, list) and len(x) >= 5}
    api: dict[str, Any] = {}
    unresolved: list[str] = []

    for node in gui.get("nodes", []):
        if node.get("mode", 0) not in (0, None):
            continue
        nid = str(node.get("id"))
        ctype = node.get("type")
        if not ctype or ctype not in objinfo:
            # Notes/reroutes/UI-only nodes are safe to skip unless a real link depends on them.
            continue
        req, opt = input_schema(objinfo, ctype)
        valid = {**req, **opt}
        inputs: dict[str, Any] = {}

        # Graph links are unambiguous.
        for inp in node.get("inputs", []) or []:
            name = inp.get("name")
            lid = inp.get("link")
            if name in valid and lid is not None and int(lid) in links:
                lk = links[int(lid)]
                inputs[name] = [str(lk[1]), int(lk[2])]

        # Modern workflow JSON contains named widget values.
        named = dict(node.get("widgets_values_named") or {})
        # H3Studio intentionally keeps its raw API-safe values here.
        named.update((node.get("properties") or {}).get("h3_widget_values") or {})

        # MinimaxH3LatentUpscaler3D exposes conditional/dynamic widget names such as
        # mode.width / mode.height. On some ComfyUI builds they are required by /prompt
        # validation but omitted from /object_info, so the generic schema filter would
        # silently drop them. Preserve these exact UI values explicitly.
        if ctype == "MinimaxH3LatentUpscaler3D":
            for key in (
                "model_name", "mode", "mode.width", "mode.height", "align",
                "enable_temporal_chunking", "force_unload", "device", "precision",
            ):
                if key in named and key not in inputs:
                    inputs[key] = named[key]

        for name, value in named.items():
            if name in valid and name not in inputs:
                inputs[name] = value

        # Positional fallback for old/simple nodes lacking widgets_values_named.
        # Match by TYPE, not blindly by position: ComfyUI can insert new widgets
        # (e.g. CreateVideo.color_space before frame_rate) between versions.
        vals = list(node.get("widgets_values") or [])
        if vals:
            scalar_names = [n for n, s in valid.items() if n not in inputs and not is_connection_type(s)]

            def compatible(spec, value):
                if not isinstance(spec, (list, tuple)) or not spec:
                    return False
                typ = spec[0]
                if isinstance(typ, list):
                    return isinstance(value, str) and value in typ
                t = str(typ).upper()
                if t == "COMBO":
                    opts = spec[1] if len(spec) > 1 and isinstance(spec[1], dict) else {}
                    choices = opts.get("options") or []
                    return isinstance(value, str) and (not choices or value in choices)
                if t == "INT":
                    return isinstance(value, int) and not isinstance(value, bool)
                if t == "FLOAT":
                    return isinstance(value, (int, float)) and not isinstance(value, bool)
                if t == "BOOLEAN":
                    return isinstance(value, bool)
                if t == "STRING":
                    return isinstance(value, str)
                return False

            remaining = list(scalar_names)
            for v in vals:
                match = next((n for n in remaining if compatible(valid[n], v)), None)
                if match is not None:
                    inputs[match] = v
                    remaining.remove(match)

        # Fill backend defaults where available; report truly missing required inputs.
        for name, spec in req.items():
            if name in inputs:
                continue
            d = schema_default(spec)
            if d is not None:
                inputs[name] = d
            elif is_connection_type(spec):
                unresolved.append(f"node {nid} {ctype}: entrée liée manquante '{name}'")

        api[nid] = {
            "class_type": ctype,
            "inputs": inputs,
            "_meta": {"title": node.get("title") or (node.get("properties") or {}).get("Node name for S&R") or ctype},
        }

    # Remove entries whose upstream node was skipped, but only fail if execution really needs them.
    for nid, n in list(api.items()):
        for name, v in list(n["inputs"].items()):
            if isinstance(v, list) and len(v) == 2 and isinstance(v[0], str) and v[0].isdigit() and v[0] not in api:
                unresolved.append(f"node {nid} {n['class_type']}: source {v[0]} absente pour '{name}'")
    if unresolved:
        raise RuntimeError("Conversion workflow impossible:\n- " + "\n- ".join(unresolved[:20]))
    return api

def combo_values(objinfo: dict, ctype: str, input_name: str) -> list[str]:
    req, opt = input_schema(objinfo, ctype)
    spec = (req | opt).get(input_name)
    if not isinstance(spec, (list, tuple)) or not spec:
        return []
    vals = spec[0]
    return [str(x) for x in vals] if isinstance(vals, list) else []

def pick_best(values: list[str], contains: list[str], preferred: list[str] | None = None) -> str | None:
    if not values:
        return None
    candidates = [v for v in values if all(x.lower() in v.lower() for x in contains)]
    if not candidates:
        return None
    preferred = preferred or []
    def score(v: str) -> tuple[int, int]:
        s = sum(1 for p in preferred if p.lower() in v.lower())
        return (s, -len(v))
    return max(candidates, key=score)

def patch_models(api: dict, objinfo: dict) -> None:
    """Force the user's quality H3 stack. No Turbo fallback in V3."""
    for n in api.values():
        ctype, inp = n["class_type"], n["inputs"]
        if ctype == "UNETLoader":
            vals = combo_values(objinfo, ctype, "unet_name")
            exact = "Minimax-h3_Singularity_ref2va_Pruned_v1.3_int8.safetensors"
            pick = next((v for v in vals if v.lower() == exact.lower()), None)
            if not pick:
                pick = pick_best(vals, ["singularity", "ref2va"], ["v1.3", "int8"])
            if not pick:
                raise RuntimeError(
                    "Singularity Ref2VA introuvable. Attendu dans ComfyUI/models/diffusion_models: "
                    + exact
                )
            inp["unet_name"] = pick
        elif ctype == "CLIPLoader":
            vals = combo_values(objinfo, ctype, "clip_name")
            exact = "qwen3vl_32b_minimax_h3_nvfp4_awq.safetensors"
            pick = next((v for v in vals if v.lower() == exact.lower()), None)
            if not pick:
                pick = pick_best(vals, ["qwen3", "minimax", "h3"], ["nvfp4", "awq"])
            if not pick:
                raise RuntimeError("Text encoder Qwen3-VL MiniMax H3 introuvable.")
            inp["clip_name"] = pick
        elif ctype == "VAELoader":
            vals = combo_values(objinfo, ctype, "vae_name")
            cur = str(inp.get("vae_name") or "").lower()
            kind = "audio" if "audio" in cur else "video"
            pick = pick_best(vals, ["minimax", "h3", kind])
            if not pick:
                raise RuntimeError(f"VAE MiniMax H3 {kind} introuvable.")
            inp["vae_name"] = pick

def remove_turbo(api: dict) -> None:
    """Bypass MiniMaxH3TurboLoRA completely and restore base-quality sampling."""
    unet_id = next((nid for nid, n in api.items() if n.get("class_type") == "UNETLoader"), None)
    turbo_ids = [nid for nid, n in api.items() if n.get("class_type") == "MiniMaxH3TurboLoRA"]
    if not unet_id:
        raise RuntimeError("UNETLoader H3 introuvable dans le workflow.")

    for tid in turbo_ids:
        for n in api.values():
            for key, value in list(n.get("inputs", {}).items()):
                if isinstance(value, list) and len(value) == 2 and str(value[0]) == str(tid):
                    # Turbo's only useful output is MODEL at slot 0. Replace it with raw Singularity.
                    n["inputs"][key] = [str(unet_id), 0]
        api.pop(tid, None)

    # Official non-Turbo H3 baseline: res_multistep + simple + 20 steps.
    for n in api.values():
        if n.get("class_type") == "KSamplerSelect" and "sampler_name" in n.get("inputs", {}):
            n["inputs"]["sampler_name"] = "res_multistep"
        if n.get("class_type") == "H3BasicScheduler":
            if "scheduler" in n.get("inputs", {}):
                n["inputs"]["scheduler"] = "simple"
            if "steps" in n.get("inputs", {}):
                n["inputs"]["steps"] = 20

    # Fail early if any live input still points at a removed node.
    missing = []
    for nid, n in api.items():
        for key, value in n.get("inputs", {}).items():
            if isinstance(value, list) and len(value) == 2 and str(value[0]).isdigit() and str(value[0]) not in api:
                missing.append(f"{nid}:{key}->{value[0]}")
    if missing:
        raise RuntimeError("Bypass Turbo incomplet: " + ", ".join(missing[:10]))

def find_node(api: dict, ctype: str) -> tuple[str, dict]:
    for nid, n in api.items():
        if n.get("class_type") == ctype:
            return nid, n
    raise RuntimeError(f"Node {ctype} introuvable dans le workflow H3Studio.")

def _neutral_scalar_default(spec: Any) -> Any:
    """Return a safe schema-driven neutral/default value for an unlinked scalar."""
    d = schema_default(spec)
    if d is not None:
        return d
    if not isinstance(spec, (list, tuple)) or not spec:
        return None
    typ = spec[0]
    if isinstance(typ, list):
        return typ[0] if typ else None
    t = str(typ).upper()
    if t == "STRING":
        return ""
    if t == "BOOLEAN":
        return False
    if t == "INT":
        return 0
    if t == "FLOAT":
        return 0.0
    return None

def reset_h3_optional_inputs(h3: dict, objinfo: dict) -> None:
    """Erase ALL template/demo scalar values from H3Studio before V1 patches.

    Basic_usage.json is a GUI example and can legitimately contain example text
    (sound anchors, refs, crops, etc.). Those values must never leak into an API
    render. Connections (CLIP/VAE) are kept; every scalar is rebuilt from the
    runtime /object_info schema, then the V1 fields are applied explicitly.
    """
    req, opt = input_schema(objinfo, "H3StudioImageToVideo")
    schema = {**req, **opt}
    inputs = h3["inputs"]
    for name, spec in schema.items():
        if is_connection_type(spec):
            continue
        neutral = _neutral_scalar_default(spec)
        if neutral is not None:
            inputs[name] = neutral
        else:
            inputs.pop(name, None)

def assert_v2_h3_clean(inputs: dict) -> None:
    """Fail before GPU if stale demo/template sources survive.

    V3 intentionally allows first_frame_file, image references and runtime voice references.
    Everything else that can inject unrelated media/timed behavior remains forbidden.
    """
    forbidden = [
        "last_frame_file", "middle_frame_files", "middle_frame_spec", "middle_frame_crops",
        "ref_video_files", "ref_video_spec", "ref_video_crops",
        "v2v_video_file", "v2v_crop", "timed_text", "sound_anchors",
    ]
    dirty = []
    for key in forbidden:
        value = inputs.get(key)
        if value not in (None, "", [], {}):
            dirty.append(f"{key}={value!r}")
    if dirty:
        raise RuntimeError(
            "Sécurité V3: des valeurs d'exemple H3Studio ont survécu au nettoyage: "
            + ", ".join(dirty)
        )
    ff = str(inputs.get("first_frame_file") or "").strip()
    refs = [x.strip() for x in str(inputs.get("ref_image_files") or "").splitlines() if x.strip()]
    if ff and ff in refs:
        raise RuntimeError("Sécurité V3: une image de référence a été utilisée comme first frame.")

def clear_runtime_media(h3: dict) -> None:
    """Clear V3 runtime media fields between preview/clip graph copies."""
    for k in (
        "first_frame_file", "last_frame_file", "middle_frame_files", "middle_frame_spec",
        "middle_frame_crops", "ref_image_files", "ref_image_crops", "ref_spec",
        "ref_audio_files", "ref_video_files", "ref_video_spec", "ref_video_crops",
        "v2v_video_file", "v2v_crop", "timed_text", "sound_anchors",
        "motion_context_file"
    ):
        if k in h3:
            h3[k] = ""

def apply_reference_inputs(h3: dict, refs: list[dict[str, Any]], audio_refs: list[dict[str, Any]] | None = None) -> None:
    """Attach image/audio references as references ONLY; never as first-frame media."""
    audio_refs = audio_refs or []
    if not refs:
        if "ref_image_files" in h3: h3["ref_image_files"] = ""
        if "ref_spec" in h3: h3["ref_spec"] = ""
    else:
        h3["ref_image_files"] = "\n".join(str(r["annotated"]) for r in refs)
        h3["ref_spec"] = "\n".join(str(r["strength"]) for r in refs)
        if "ref_image_crops" in h3:
            h3["ref_image_crops"] = ""
        if "ref_image_size" in h3:
            # V9: references are authoritative only for RAW generation and use the
            # high-fidelity policy requested by the project. Visual refs are removed
            # from the separate 1920 refine conditioning downstream.
            h3["ref_image_size"] = "max"
        if "ref_megapixels" in h3:
            h3["ref_megapixels"] = REF_MEGAPIXELS

    # Voice references are attached only on clips where their character actually speaks.
    # Silent clips therefore pay zero audio-reference overhead.
    if audio_refs and "ref_audio_files" not in h3:
        raise RuntimeError("H3Studio ne possède pas l'entrée ref_audio_files requise pour les références de voix.")
    if "ref_audio_files" in h3:
        h3["ref_audio_files"] = "\n".join(str(r["annotated"]) for r in audio_refs) if audio_refs else ""


def prepare_base_graph(comfy: Path, objinfo: dict) -> tuple[dict, str, str]:
    wf_path = find_workflow(comfy)
    gui = json.loads(wf_path.read_text(encoding="utf-8-sig"))
    api = gui_to_api(gui, objinfo)
    patch_models(api, objinfo)

    # FilmMaker V9 uses a separate custom node for the exact RAW safety sidecar, refine conditioning, and
    # an automatic RAW-save gate. The normal RAW->HD path stays in ONE prompt and
    # never reloads the latent from disk. H3RefineBridge itself is intentionally untouched.
    missing_raw_bridge = [x for x in ("H3StoreRawLatentExact", "H3LoadRawLatentExact", "H3RawSavedAutoGate", "H3RefineResizeConditioningDropVisualRefs") if x not in objinfo]
    if missing_raw_bridge:
        raise RuntimeError(
            "H3RawLatentPersist n'est pas charge dans ComfyUI: " + ", ".join(missing_raw_bridge)
            + ". Le lanceur doit installer custom_nodes/H3RawLatentPersist puis redemarrer ComfyUI."
        )

    # ComfyUI video schema changed across versions. Force every CreateVideo node to the
    # same 24 fps/sRGB settings instead of trusting legacy widget positions.
    _cv_req, _cv_opt = input_schema(objinfo, "CreateVideo")
    _cv_schema = set(_cv_req) | set(_cv_opt)
    for _cv in (n for n in api.values() if n.get("class_type") == "CreateVideo"):
        if "color_space" in _cv_schema:
            _cv["inputs"]["color_space"] = "sRGB"
        if "frame_rate" in _cv_schema:
            _cv["inputs"]["frame_rate"] = FPS
        if "fps" in _cv_schema:
            _cv["inputs"]["fps"] = FPS

    # Ensure the dynamically populated LoadVideo scalar exists even when ComfyUI's current
    # input folder is empty and /object_info therefore exposes an empty file combo.
    for _lv in (n for n in api.values() if n.get("class_type") == "LoadVideo"):
        _lv_req, _lv_opt = input_schema(objinfo, "LoadVideo")
        _lv_schema = {**_lv_req, **_lv_opt}
        _key = next((k for k in ("video", "file", "filename", "video_file") if k in _lv_schema), None)
        if _key is None:
            _key = next((k for k in _lv_schema if "video" in k.lower() or "file" in k.lower()), None)
        if _key and _key not in _lv["inputs"]:
            _lv["inputs"][_key] = schema_default(_lv_schema[_key]) or ""

    h3_id, h3 = find_node(api, "H3StudioImageToVideo")

    def by_title(ctype: str, needle: str) -> tuple[str, dict]:
        needle_l = needle.lower()
        for nid, node in api.items():
            if node.get("class_type") == ctype and needle_l in str((node.get("_meta") or {}).get("title") or "").lower():
                return nid, node
        raise RuntimeError(f"Node {ctype} / {needle} introuvable dans le workflow H3 API CLEAN.")

    # Guardrail for the third-party latent upscaler's dynamic API widgets. The UI workflow
    # targets 1920x1080; the node may internally align the latent grid to 1920x1088.
    _up_id, _up = by_title("MinimaxH3LatentUpscaler3D", "Latent Upscaler 3D")
    _up["inputs"].update({
        "mode": "target dimensions",
        "mode.width": 1920,
        "mode.height": 1080,
        "align": 32,
        "enable_temporal_chunking": False,
        "force_unload": True,
        "device": "cuda",
        "precision": "fp16",
    })
    if "model_name" not in _up["inputs"]:
        _up["inputs"]["model_name"] = "minimax_h3_latent_upscaler_3d_fp16.safetensors"

    # Fail early if someone accidentally replaces the bundled graph with Basic_usage.json or
    # removes one of the exact quality/continuity stages this FilmMaker expects.
    for _ctype, _title in (
        ("ModelAttentionBackend", "Kitchen Attention"),
        ("BasicScheduler", "8 STEPS"),
        ("SamplerCustomAdvanced", "8 STEPS COMPLETS"),
        ("MinimaxH3LatentUpscaler3D", "Latent Upscaler 3D"),
        ("ManualSigmas", "Refine 4 Sigmas"),
        ("SamplerCustomAdvanced", "REFINE — 4 sigmas"),
        ("H3V15ProjectHardLock", "HARDLOCK HD"),
        ("H3V15ProjectStoreHDTail", ".PT HD"),
        ("SaveVideo", "RAW H3STUDIO"),
        ("SaveVideo", "VISIBLE COURANT 1920"),
        ("SaveVideo", "FINAL CUMULATIF 1920"),
    ):
        by_title(_ctype, _title)

    # The per-clip visible 1920 output is the one FilmMaker observes/assembles. RAW and
    # cumulative FINAL are handled separately by render_clip for continuity.
    save_id, save = by_title("SaveVideo", "VISIBLE COURANT 1920")

    # NEVER trust demo scalar values from Basic_usage.json for H3Studio.
    # Keep graph connections, reset everything else from this machine's live schema.
    reset_h3_optional_inputs(h3, objinfo)

    # Refuse an old H3Studio cleanly instead of queueing a half-compatible graph.
    h3_req, h3_opt = input_schema(objinfo, "H3StudioImageToVideo")
    h3_schema = set(h3_req) | set(h3_opt)
    critical_h3 = {
        "prompt", "width", "height", "length",
        "motion_context_file", "motion_context_end_seconds",
        "motion_context_frames", "motion_context_audio_frames",
        "motion_context_reuse_latent", "motion_context_anchor_brightness",
        "motion_context_strength",
    }
    missing_h3 = sorted(critical_h3 - h3_schema)
    if missing_h3:
        raise RuntimeError(
            "ComfyUI-H3Studio est trop ancien pour cette V3; entrées manquantes: "
            + ", ".join(missing_h3)
            + ". Mets H3Studio à jour puis relance."
        )

    # V3 explicit fields. Everything else already came from the live schema default.
    for k, v in {
        "prompt": "",
        "width": WIDTH, "height": HEIGHT, "length": FIRST_FRAME_COUNT,
        "motion_context_file": "", "motion_context_end_seconds": 0.0,
        "motion_context_frames": MOTION_FRAMES,
        "motion_context_audio_frames": MOTION_AUDIO_FRAMES,
        "motion_context_reuse_latent": True,
        "motion_context_anchor_brightness": True,
        "motion_context_strength": MOTION_STRENGTH,
        "motion_scale": 1.0,
    }.items():
        if k in h3_schema:
            h3["inputs"][k] = v

    assert_v2_h3_clean(h3["inputs"])

    # Keep the workflow's known-good per-clip visible SaveVideo settings. Only change fields that
    # actually exist in this ComfyUI build.
    if "format" in save["inputs"]:
        save["inputs"]["format"] = "auto"
    if "codec" in save["inputs"]:
        save["inputs"]["codec"] = "auto"
    if "filename_prefix" not in save["inputs"]:
        raise RuntimeError("SaveVideo ne possède pas l'entrée filename_prefix dans ce build ComfyUI.")
    return api, h3_id, save_id

def annotated_name(item: dict) -> str:
    filename = item.get("filename") or ""
    sub = item.get("subfolder") or ""
    typ = item.get("type") or "output"
    path = f"{sub}/{filename}" if sub else filename
    return f"{path.replace(os.sep, '/')} [{typ}]"

def iter_saved_files(obj: Any):
    if isinstance(obj, dict):
        if "filename" in obj and (Path(str(obj.get("filename"))).suffix.lower() in VIDEO_EXTS):
            yield obj
        for v in obj.values():
            yield from iter_saved_files(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from iter_saved_files(v)

def queue_graph(graph: dict, client_id: str) -> str:
    out = http_json(COMFY_URL + "/prompt", "POST", {"prompt": graph, "client_id": client_id}, timeout=30)
    if out.get("error"):
        raise RuntimeError("ComfyUI a refusé le workflow: " + json.dumps(out, ensure_ascii=False)[:3000])
    pid = out.get("prompt_id")
    if not pid:
        raise RuntimeError("ComfyUI n'a pas renvoyé de prompt_id: " + repr(out))
    return str(pid)

def _format_comfy_execution_error(messages: Any) -> str:
    """Keep the useful Comfy error fields and NEVER dump tensor-valued current_inputs."""
    records = []
    if isinstance(messages, list):
        for item in messages:
            if isinstance(item, (list, tuple)) and len(item) >= 2 and isinstance(item[1], dict):
                event, data = str(item[0]), item[1]
                if event == "execution_error" or any(k in data for k in ("exception_message", "exception_type", "node_id", "node_type")):
                    records.append((event, data))
            elif isinstance(item, dict):
                records.append(("error", item))
    if not records:
        try:
            return json.dumps(messages, ensure_ascii=False, indent=2)[:6000]
        except Exception:
            return repr(messages)[:6000]
    chunks=[]
    for event,data in records[-3:]:
        chunks.append(
            f"event={event}\n"
            f"node_id={data.get('node_id')}\n"
            f"node_type={data.get('node_type')}\n"
            f"exception_type={data.get('exception_type')}\n"
            f"exception_message={data.get('exception_message')}"
        )
        tb=data.get("traceback")
        if isinstance(tb,list) and tb:
            chunks.append("traceback:\n" + "".join(str(x) for x in tb[-12:])[-7000:])
        elif isinstance(tb,str) and tb:
            chunks.append("traceback:\n" + tb[-7000:])
        outs=data.get("current_outputs")
        if outs is not None:
            chunks.append("current_outputs=" + repr(outs)[:1200])
    return "\n---\n".join(chunks)


def wait_history(prompt_id: str, save_node_id: str | None = None, max_seconds: int = MAX_H3_RENDER_SECONDS) -> dict:
    started = time.time()
    next_notice = started + 30.0
    while True:
        hist = http_json(COMFY_URL + "/history/" + urllib.parse.quote(prompt_id), timeout=30)
        rec = hist.get(prompt_id)
        if rec:
            st = rec.get("status") or {}
            status_str = st.get("status_str")
            if status_str == "error":
                msgs = st.get("messages") or []
                raise RuntimeError("Erreur ComfyUI:\n" + _format_comfy_execution_error(msgs))
            outputs = rec.get("outputs") or {}
            source = outputs.get(str(save_node_id), {}) if save_node_id is not None else outputs
            vids = list(iter_saved_files(source))
            if vids:
                return {"record": rec, "video": vids[-1]}
            # With the newer multi-SaveVideo H3 graph, some ComfyUI builds do not expose
            # the saved file under the exact SaveVideo node id even though the prompt
            # completed and another output entry contains the file metadata.  Never fail
            # solely because a hard-coded node id has no history payload.
            if status_str == "success" or st.get("completed") is True:
                all_vids = list(iter_saved_files(outputs))
                if all_vids:
                    return {"record": rec, "video": all_vids[-1], "history_node_fallback": True}
                where = f" du node SaveVideo {save_node_id}" if save_node_id is not None else ""
                raise RuntimeError("Le rendu est terminé mais aucune vidéo" + where + " n'a été trouvée dans l'historique ComfyUI.")
        now = time.time()
        if max_seconds and (now - started) > max_seconds:
            try:
                http_json(COMFY_URL + "/interrupt", "POST", {}, timeout=10)
            except Exception:
                pass
            raise RuntimeError(
                f"Rendu H3 bloqué depuis plus de {max_seconds // 60} min. "
                "Interruption envoyée à ComfyUI pour éviter un blocage/OOM interminable."
            )
        if now >= next_notice:
            print(f"    ... ComfyUI calcule toujours ({int(now - started)} s écoulées)")
            next_notice = now + 30.0
        time.sleep(2)



def _prompt_is_still_queued(prompt_id: str) -> bool:
    """Return True while ComfyUI still owns the prompt (running or pending)."""
    try:
        q = http_json(COMFY_URL + "/queue", timeout=15)
    except Exception:
        return True  # fail safe: never free VRAM just because queue probing failed
    for key in ("queue_running", "queue_pending"):
        for item in q.get(key) or []:
            if isinstance(item, (list, tuple)) and any(str(x) == str(prompt_id) for x in item[:3]):
                return True
            if isinstance(item, dict) and str(item.get("prompt_id") or item.get("id") or "") == str(prompt_id):
                return True
    return False

def _fresh_video_candidates(directory: Path, prefix: str, not_before: float) -> list[Path]:
    if not directory.is_dir():
        return []
    out = []
    pref = prefix.lower()
    for path in directory.glob(prefix + "*"):
        if not path.is_file() or path.suffix.lower() not in VIDEO_EXTS:
            continue
        try:
            st = path.stat()
        except OSError:
            continue
        if not_before and st.st_mtime < (not_before - 3.0):
            continue
        if path.name.lower().startswith(pref):
            out.append(path)
    return sorted(out, key=lambda x: x.stat().st_mtime)

def wait_for_disk_video(prompt_id: str, directory: Path, prefix: str, not_before: float,
                        milestone: tuple[Path, str, str] | None = None,
                        max_seconds: int = MAX_H3_RENDER_SECONDS,
                        stop_signal_path: Path | None = None,
                        review_wait_path: Path | None = None,
                        abort_check=None) -> Path:
    """Wait for the REAL target file, not merely the first SaveVideo output.

    H3's RAW SaveVideo can finish long before latent upscale/refine. Some ComfyUI builds
    expose that partial output in /history while the same prompt is still running. The old
    code interpreted that as prompt completion and FilmMaker then freed ComfyUI VRAM,
    killing the 1920 refine. This waits for the exact file in the current film folder.
    """
    started = time.time()
    next_notice = started + 30.0
    finished_without_target_since = None
    milestone_printed = False
    stable_path: Path | None = None
    stable_size = -1
    stable_hits = 0
    review_held_seconds = 0.0
    review_started = None
    while True:
        if abort_check is not None:
            abort_check()
        now = time.time()
        if review_wait_path is not None and review_wait_path.is_file():
            if review_started is None:
                review_started = now
        elif review_started is not None:
            review_held_seconds += now - review_started
            review_started = None
        if stop_signal_path is not None and stop_signal_path.is_file() and not _prompt_is_still_queued(prompt_id):
            raise RuntimeError(f'RAW rejected by Studio: {stop_signal_path}')
        # Surface a real ComfyUI execution error immediately, but never treat a RAW output
        # or a premature history "success" as completion of the 1920 path.
        rec = None
        try:
            hist = http_json(COMFY_URL + "/history/" + urllib.parse.quote(prompt_id), timeout=20)
            rec = hist.get(prompt_id)
        except Exception:
            rec = None
        if rec:
            st = rec.get("status") or {}
            if st.get("status_str") == "error":
                msgs = st.get("messages") or []
                raise RuntimeError("Erreur ComfyUI:\n" + _format_comfy_execution_error(msgs))
            if st.get('status_str') in ('interrupted','cancelled','canceled') and not _prompt_is_still_queued(prompt_id):
                raise RuntimeError('ComfyUI: rendu interrompu avant création du clip HD')

        if milestone and not milestone_printed:
            mdir, mprefix, mlabel = milestone
            mcands = _fresh_video_candidates(mdir, mprefix, not_before)
            if mcands:
                next_part = 'validation humaine RAW en attente' if review_wait_path is not None else 'upscale/refine continue...'
                print(f"    {mlabel} terminé -> {mcands[-1].name} ; {next_part}")
                milestone_printed = True

        candidates = _fresh_video_candidates(directory, prefix, not_before)
        if candidates:
            cand = candidates[-1]
            try:
                size = cand.stat().st_size
            except OSError:
                size = -1
            if cand == stable_path and size > 0 and size == stable_size:
                stable_hits += 1
            else:
                stable_path, stable_size, stable_hits = cand, size, 0
            # Two observations (roughly 2 s apart) avoid handing an MP4 to PyAV while
            # SaveVideo is still finalizing its container metadata.
            if stable_hits >= 1 and not _prompt_is_still_queued(prompt_id):
                return cand

        now = time.time()
        queued = _prompt_is_still_queued(prompt_id)
        if rec:
            st = rec.get("status") or {}
            looks_finished = st.get("status_str") == "success" or st.get("completed") is True
            if looks_finished and not queued:
                if finished_without_target_since is None:
                    finished_without_target_since = now
                elif now - finished_without_target_since >= 12.0:
                    outputs = rec.get("outputs") or {}
                    ids = ", ".join(sorted(str(k) for k in outputs.keys())) or "aucun"
                    fresh = []
                    if directory.is_dir():
                        for f in sorted(directory.glob("*")):
                            if f.is_file():
                                fresh.append(f.name)
                    raise RuntimeError(
                        f"ComfyUI a réellement terminé mais la sortie attendue {prefix!r} n'a pas été créée "
                        f"dans {directory}. outputs={ids}; fichiers={fresh[-12:]}"
                    )
            else:
                finished_without_target_since = None

        human_wait = review_held_seconds + ((now-review_started) if review_started is not None else 0.0)
        active_elapsed = (now-started) - human_wait
        if max_seconds and active_elapsed > max_seconds:
            try:
                http_json(COMFY_URL + "/interrupt", "POST", {}, timeout=10)
            except Exception:
                pass
            raise RuntimeError(
                f"Rendu H3 bloqué depuis plus de {max_seconds // 60} min en attendant {prefix}. "
                "Interruption envoyée à ComfyUI."
            )
        if now >= next_notice:
            stage = f"attente {prefix}"
            if review_started is not None:
                stage = f"RAW en attente de validation Studio ({int(human_wait)} s attente humaine; aucun refine GPU)"
                print(f"    ... FilmMaker attend ton choix ({int(now-started)} s écoulées ; {stage})")
            else:
                if milestone_printed:
                    stage = "RAW validé, upscale/refine 1920 en cours"
                print(f"    ... ComfyUI calcule ({int(active_elapsed)} s de calcul/chargement ; {stage})")
            next_notice = now + 30.0
        time.sleep(2)

def find_ffmpeg_exe(comfy: Path) -> str:
    for name in ("ffmpeg", "ffmpeg.exe"):
        found = shutil.which(name)
        if found:
            return found
    try:
        import imageio_ffmpeg
        found = imageio_ffmpeg.get_ffmpeg_exe()
        if found and Path(found).is_file():
            return str(found)
    except Exception:
        pass
    portable = comfy.parent
    candidates = list((portable / "python_embeded" / "Lib" / "site-packages" / "imageio_ffmpeg" / "binaries").glob("*.exe"))
    for c in candidates:
        if "ffmpeg" in c.name.lower():
            return str(c)
    raise RuntimeError("FFmpeg introuvable. Installe ffmpeg ou imageio-ffmpeg dans le Python ComfyUI.")

def export_reel_lowram(comfy: Path, clips: list[str], motion_context_flags: list[bool], output_path: Path) -> Path:
    """Low-RAM streaming assembly: exact 22-frame MC trim, one final CPU encode, no giant H3Studio RAM allocation."""
    if not clips:
        raise RuntimeError("Aucun clip à assembler.")
    ffmpeg = find_ffmpeg_exe(comfy)
    sources = [annotated_to_path(comfy, x) for x in clips]
    missing = [str(x) for x in sources if not x.is_file()]
    if missing:
        raise RuntimeError("Clip(s) introuvable(s) pour assemblage: " + "; ".join(missing))
    flags = list(motion_context_flags or [])
    if len(flags) < len(sources):
        flags += [True] * (len(sources) - len(flags))
    flags = flags[:len(sources)]

    cmd = [ffmpeg, "-y", "-hide_banner", "-loglevel", "warning"]
    for src in sources:
        cmd += ["-i", str(src)]

    trim_s = MOTION_FRAMES / FPS
    filters: list[str] = []
    concat_inputs: list[str] = []
    for i, use_mc in enumerate(flags):
        if use_mc:
            filters.append(f"[{i}:v]trim=start_frame={MOTION_FRAMES},setpts=PTS-STARTPTS[v{i}]")
            filters.append(f"[{i}:a]atrim=start={trim_s:.9f},asetpts=PTS-STARTPTS[a{i}]")
        else:
            filters.append(f"[{i}:v]setpts=PTS-STARTPTS[v{i}]")
            filters.append(f"[{i}:a]asetpts=PTS-STARTPTS[a{i}]")
        concat_inputs.extend([f"[v{i}]", f"[a{i}]"])
    filters.append("".join(concat_inputs) + f"concat=n={len(sources)}:v=1:a=1[vout][aout]")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    cmd += [
        "-filter_complex", ";".join(filters),
        "-map", "[vout]", "-map", "[aout]",
        "-c:v", "libx264", "-preset", "fast", "-crf", "14", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "192k",
        "-movflags", "+faststart",
        str(output_path),
    ]
    print(f"  Assemblage low-RAM FFmpeg: {len(sources)} clips, trim MC = {MOTION_FRAMES} frames ({trim_s:.3f} s)")
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                          creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    if proc.returncode != 0 or not output_path.is_file():
        raise RuntimeError("Assemblage FFmpeg échoué:\n" + (proc.stderr or proc.stdout)[-5000:])
    return output_path

def annotated_to_path(comfy: Path, annotated: str) -> Path:
    m = re.match(r"^(.*?)\s*\[(input|output|temp)\]\s*$", annotated)
    rel, typ = (m.group(1), m.group(2)) if m else (annotated, "output")
    base = {"input": comfy / "input", "output": comfy / "output", "temp": comfy / "temp"}[typ]
    return base / Path(rel.replace("/", os.sep))

def set_seed(graph: dict) -> None:
    for n in graph.values():
        if n.get("class_type") == "RandomNoise" and "noise_seed" in n.get("inputs", {}):
            n["inputs"]["noise_seed"] = random.randint(1, 2**63 - 1)

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}

def _strip_drag_quotes(text: str) -> str:
    return (text or "").strip().strip('"').strip("'")

def collect_reference_groups(raw: str) -> list[list[Path]]:
    """One semicolon-separated entry = one subject group; a folder = multiple refs of that subject."""
    raw = (raw or "").strip()
    if not raw:
        return []
    groups: list[list[Path]] = []
    for chunk in [c.strip() for c in raw.split(";") if c.strip()]:
        p = Path(_strip_drag_quotes(chunk)).expanduser()
        if p.is_dir():
            files = sorted(x for x in p.iterdir() if x.is_file() and x.suffix.lower() in IMAGE_EXTS)
        elif p.is_file() and p.suffix.lower() in IMAGE_EXTS:
            files = [p]
        else:
            raise RuntimeError(f"Référence introuvable ou format non-image: {p}")
        if not files:
            raise RuntimeError(f"Aucune image trouvée dans: {p}")
        seen = set()
        unique = []
        for f in files:
            k = str(f.resolve()).lower()
            if k not in seen:
                seen.add(k)
                unique.append(f)
        groups.append(unique)
    return groups

def parse_subject_names(raw: str, count: int, prefix: str) -> list[str]:
    vals = [_clean_sentence(x) for x in (raw or "").split(";") if _clean_sentence(x)]
    out = []
    for i in range(count):
        out.append(vals[i] if i < len(vals) else f"{prefix}{i+1}")
    return out

def set_seed_value(graph: dict, seed: int) -> None:
    for n in graph.values():
        if n.get("class_type") == "RandomNoise" and "noise_seed" in n.get("inputs", {}):
            n["inputs"]["noise_seed"] = int(seed)

def extract_last_video_frame(video_path: Path, image_path: Path) -> None:
    """Extract the exact last decoded frame for a long-chain latent refresh."""
    try:
        import av
    except Exception as exc:
        raise RuntimeError("PyAV est introuvable; impossible d'extraire la dernière frame.") from exc
    image_path.parent.mkdir(parents=True, exist_ok=True)
    container = av.open(str(video_path))
    last = None
    try:
        for frame in container.decode(video=0):
            last = frame.to_image()
    finally:
        container.close()
    if last is None:
        raise RuntimeError(f"Aucune frame décodable dans {video_path}")
    last.save(str(image_path), format="PNG")

def extract_fullres_frame_at_seconds(video_path: Path, seconds: float, image_path: Path) -> None:
    """Extract the closest full-resolution rendered frame for a dynamic H3 reference.

    Observer/VLM frames may be downscaled for analysis speed, but references fed back to H3
    must come from the original rendered video at native resolution.
    """
    try:
        import av
    except Exception as exc:
        raise RuntimeError("PyAV introuvable; impossible d'extraire la frame full-res.") from exc
    image_path.parent.mkdir(parents=True, exist_ok=True)
    container = av.open(str(video_path))
    best = None
    best_delta = float("inf")
    try:
        stream = container.streams.video[0]
        for frame in container.decode(video=0):
            try:
                t = float(frame.time) if frame.time is not None else float(frame.pts * stream.time_base)
            except Exception:
                t = 0.0
            delta = abs(t - float(seconds))
            if delta < best_delta:
                best = frame.to_image().convert("RGB")
                best_delta = delta
            if t > float(seconds) and best is not None and delta > best_delta:
                break
    finally:
        container.close()
    if best is None:
        raise RuntimeError(f"Aucune frame décodable dans {video_path}")
    best.save(image_path, "JPEG", quality=97, subsampling=0)


def extract_observer_frames(video_path: Path, out_dir: Path, skip_frames: int = 0) -> list[Path]:
    """V8: extract a denser ordered visual strip from the useful material.

    The old observer sampled 8 frames and the specialist VLMs then reduced that to 3.
    V8 keeps the proven specialist passes, but also exposes 10 chronological frames to the
    render-reconstruction VLM so the next director can reason about what happened BETWEEN
    beginning/middle/end instead of only seeing three snapshots.
    """
    try:
        import av
        from PIL import Image
    except Exception as exc:
        raise RuntimeError("PyAV/Pillow introuvable; impossible d'extraire les images observateur.") from exc
    out_dir.mkdir(parents=True, exist_ok=True)
    container = av.open(str(video_path))
    frames = []
    fps = float(FPS)
    try:
        stream = container.streams.video[0]
        if stream.average_rate:
            try:
                fps = float(stream.average_rate)
            except Exception:
                pass
        for frame in container.decode(video=0):
            frames.append(frame.to_image().convert("RGB"))
    finally:
        container.close()
    if not frames:
        raise RuntimeError(f"Aucune frame décodable dans {video_path}")
    source_frame_offset = 0
    if skip_frames > 0 and len(frames) > skip_frames + V8_OBSERVER_IMAGES:
        source_frame_offset = skip_frames
        frames = frames[skip_frames:]
    total=len(frames)
    # Dense chronological strip + exact tail. The strip is deterministic and independent of story text.
    spread_count=max(2,V8_OBSERVER_IMAGES-2)
    idxs=[int(round((total-1)*(i/(spread_count-1)))) for i in range(spread_count)] if spread_count>1 else [0]
    tail_span=max(OBSERVER_TAIL_IMAGES,int(round(max(0.6,DIRECTOR_TAIL_SECONDS)*max(fps,1.0))))
    tail_start=max(0,total-tail_span)
    tail_mid=tail_start + max(0,(total-1-tail_start)//2)
    idxs += [tail_start,tail_mid,total-1]
    idxs=sorted(set(max(0,min(total-1,x)) for x in idxs))
    # If short clips/deduplication still reduce the count, split the largest temporal gaps
    # instead of biasing extra samples toward the beginning.
    target=min(V8_OBSERVER_IMAGES,total)
    while len(idxs)<target:
        ordered=sorted(idxs)
        gaps=[(b-a,a,b) for a,b in zip(ordered,ordered[1:]) if b-a>1]
        if not gaps: break
        _,a,b=max(gaps,key=lambda x:(x[0],-x[1]))
        mid=a+(b-a)//2
        if mid in idxs: break
        idxs.append(mid); idxs.sort()
    idxs=idxs[:V8_OBSERVER_IMAGES]
    paths=[]
    for i,idx in enumerate(idxs,1):
        img=frames[idx]
        if max(img.size)>DIRECTOR_MAX_IMAGE_DIM:
            img.thumbnail((DIRECTOR_MAX_IMAGE_DIM,DIRECTOR_MAX_IMAGE_DIM),Image.Resampling.LANCZOS)
        source_t = (idx + source_frame_offset) / max(fps, 1.0)
        dest=out_dir/f"obs_{i:02d}_t{source_t:.3f}s.jpg"
        img.save(dest,"JPEG",quality=90,optimize=True)
        paths.append(dest)
    return paths

def unload_ollama_model(model: str) -> None:
    """Force Ollama à retirer le modèle de la RAM/VRAM (keep_alive=0)."""
    if not model:
        return
    try:
        http_json(OLLAMA_URL + "/api/generate", "POST", {
            "model": model, "prompt": "", "stream": False, "keep_alive": 0
        }, timeout=60)
    except Exception:
        pass

def unload_all_ollama_models() -> None:
    """Décharge tous les modèles actuellement résidents dans Ollama."""
    try:
        ps = http_json(OLLAMA_URL + "/api/ps", timeout=5)
    except Exception:
        return
    seen = set()
    for row in ps.get("models", []) if isinstance(ps, dict) else []:
        name = str(row.get("name") or row.get("model") or "").strip()
        if name and name not in seen:
            seen.add(name)
            unload_ollama_model(name)
