$ErrorActionPreference='Stop'
$paths=@(
    'C:\AI\ComfyUI_windows_portable\python_embeded\python.exe',
    "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe",
    "$env:LOCALAPPDATA\H3RetouchDiffSynth\.venv\Scripts\python.exe"
)
foreach ($py in $paths) {
    if (!(Test-Path -LiteralPath $py)) { continue }
    Write-Host "`n--- $py ---" -ForegroundColor Cyan
    & $py -c "import sys, importlib.metadata as m; print('executable',sys.executable); print('python',sys.version.split()[0]); print('prefix',sys.prefix); print('base_prefix',sys.base_prefix); print('numpy',m.version('numpy') if m.packages_distributions().get('numpy') else '?'); print('torch',m.version('torch') if m.packages_distributions().get('torch') else '?')"
}
Write-Host '[OK] Lecture seule: aucune installation/commande pip.' -ForegroundColor Green
