$ErrorActionPreference = "Stop"
$Host.UI.RawUI.WindowTitle = "H3 Film STUDIO V3.7 - Preproduction + Canonical Refs"

$ComfyRoot = "C:\AI\ComfyUI_windows_portable"
$Comfy = Join-Path $ComfyRoot "ComfyUI"
$Py = Join-Path $ComfyRoot "python_embeded\python.exe"

if (-not (Test-Path $Comfy)) {
    $found = Get-ChildItem "C:\AI" -Directory -Recurse -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -eq "ComfyUI" -and (Test-Path (Join-Path $_.FullName "models")) } |
        Select-Object -First 1
    if (-not $found) { throw "ComfyUI introuvable. Attendu: C:\AI\ComfyUI_windows_portable\ComfyUI" }
    $Comfy = $found.FullName
    $ComfyRoot = Split-Path $Comfy -Parent
    $Py = Join-Path $ComfyRoot "python_embeded\python.exe"
}
if (-not (Test-Path $Py)) { $Py = (Get-Command python.exe -ErrorAction Stop).Source }

# Install the FilmMaker-only RAW latent bridge as a SEPARATE ComfyUI custom node.
# H3RefineBridge is deliberately never modified.
$BundledRawBridge = Join-Path $PSScriptRoot "custom_nodes\H3RawLatentPersist"
$InstalledRawBridge = Join-Path $Comfy "custom_nodes\H3RawLatentPersist"
$RawBridgeUpdated = $false
if (-not (Test-Path (Join-Path $BundledRawBridge "__init__.py"))) {
    throw "Bridge RAW latent embarque introuvable: $BundledRawBridge"
}
$srcHash = (Get-FileHash (Join-Path $BundledRawBridge "__init__.py") -Algorithm SHA256).Hash
$dstInit = Join-Path $InstalledRawBridge "__init__.py"
$dstHash = if (Test-Path $dstInit) { (Get-FileHash $dstInit -Algorithm SHA256).Hash } else { "" }
if ($srcHash -ne $dstHash) {
    New-Item -ItemType Directory -Force -Path $InstalledRawBridge | Out-Null
    Copy-Item -Path (Join-Path $BundledRawBridge "*") -Destination $InstalledRawBridge -Recurse -Force
    $RawBridgeUpdated = $true
    Write-Host "H3RawLatentPersist installe/mis a jour (H3RefineBridge intact)." -ForegroundColor Cyan
}

function Test-Comfy {
    try { Invoke-RestMethod "http://127.0.0.1:8188/object_info" -TimeoutSec 2 | Out-Null; return $true } catch { return $false }
}

# If the new custom node was installed while ComfyUI was already running, restart only
# that ComfyUI listener once so /object_info sees the new class types.
if ($RawBridgeUpdated -and (Test-Comfy)) {
    Write-Host "Redemarrage ComfyUI requis pour charger H3RawLatentPersist..." -ForegroundColor Cyan
    try { Invoke-RestMethod "http://127.0.0.1:8188/interrupt" -Method Post -ContentType "application/json" -Body "{}" -TimeoutSec 3 | Out-Null } catch {}
    try {
        $listener = Get-NetTCPConnection -LocalPort 8188 -State Listen -ErrorAction Stop | Select-Object -First 1
        if ($listener -and $listener.OwningProcess) { Stop-Process -Id $listener.OwningProcess -Force -ErrorAction Stop }
    } catch {
        throw "H3RawLatentPersist vient d'etre installe mais ComfyUI deja lance n'a pas pu etre redemarre automatiquement. Ferme ComfyUI puis relance ce .cmd."
    }
    for($i=0;$i -lt 20;$i++) { Start-Sleep -Milliseconds 500; if(-not (Test-Comfy)){break} }
}

if (-not (Test-Comfy)) {
    $bat = @(
        (Join-Path $ComfyRoot "run_nvidia_gpu.bat"),
        (Join-Path $ComfyRoot "run_nvidia_gpu_fast_fp16_accumulation.bat")
    ) | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $bat) { throw "Script de lancement ComfyUI introuvable dans $ComfyRoot" }
    Write-Host "Demarrage ComfyUI..." -ForegroundColor Cyan
    Start-Process -FilePath "$env:ComSpec" -ArgumentList @('/c', ('"' + $bat + '"')) -WorkingDirectory $ComfyRoot
    $ok=$false
    for($i=0;$i -lt 90;$i++) { Start-Sleep -Seconds 2; if(Test-Comfy){$ok=$true;break} }
    if(-not $ok){ throw "ComfyUI n'a pas demarre sur le port 8188." }
}

try {
    $oi = Invoke-RestMethod "http://127.0.0.1:8188/object_info" -TimeoutSec 10
    if (-not $oi.H3StoreRawLatentExact -or -not $oi.H3LoadRawLatentExact -or -not $oi.H3RawSavedAutoGate -or -not $oi.H3RefineResizeConditioningDropVisualRefs) {
        throw "nodes absents"
    }
} catch {
    throw "ComfyUI ne voit pas H3StoreRawLatentExact/H3LoadRawLatentExact/H3RawSavedAutoGate/H3RefineResizeConditioningDropVisualRefs. H3RefineBridge n'a pas ete modifie; verifie seulement custom_nodes\H3RawLatentPersist puis relance ComfyUI."
}

try { Invoke-RestMethod "http://127.0.0.1:11434/api/tags" -TimeoutSec 2 | Out-Null } catch {
    $ollama = Get-Command ollama.exe -ErrorAction SilentlyContinue
    if ($ollama) {
        Write-Host "Demarrage Ollama..." -ForegroundColor Cyan
        Start-Process -FilePath $ollama.Source -ArgumentList "serve" -WindowStyle Hidden
        Start-Sleep -Seconds 3
    } else {
        throw "Ollama n'est pas lance et ollama.exe est introuvable."
    }
}

$env:COMFYUI_DIR = $Comfy
$script = Join-Path $PSScriptRoot "h3film_studio_v3.py"
$runtime = Join-Path $PSScriptRoot "h3_runtime_simple.py"
if (-not (Test-Path $script)) { throw "Script principal manquant: $script" }
if (-not (Test-Path $runtime)) { throw "Runtime manquant: $runtime" }
# Helpful for normal Python builds; the Python script also loads the runtime by absolute path,
# so this does not depend on embedded Python honoring PYTHONPATH.
$env:PYTHONPATH = "$PSScriptRoot;$env:PYTHONPATH"
& $Py $script @args
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
