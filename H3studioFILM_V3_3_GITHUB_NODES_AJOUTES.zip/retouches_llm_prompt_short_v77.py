"""V10.77: prompt court type Dialogue pour Performance Action / Emotion.

Reutilise EXACTEMENT le backend Gemma4 Ollama et sa liberation FilmMaker,
sans installation, node ni nouveau parametre du sampler. L'original sert a
Gemma pour le contexte; H3 recoit le clip <Video 1> + un court changement,
non le script original et non une timeline de shots imposee.
"""
from __future__ import annotations
import re

import retouches_llm_prompt_v74 as stable


SYSTEM_SHORT = """Tu es un realisateur de retouches sur une video EXISTANTE. L'image
originale sera fournie a MiniMax H3 comme <Video 1>. Tu recois son PROMPT ORIGINAL
(historique, pas une transcription certifiee de la video) et la DEMANDE utilisateur.
Ecris un prompt COURT et VISUEL pour la NOUVELLE PRISE, pas un scenario complet.

OBJECTIF:
- ACTION: identifie ce qui doit apparaitre pendant le temps choisi, en gardant
  les mouvements originaux compatibles. Distingue une action ajoutee d'une
  modification d'un geste existant. Si l'utilisateur corrige un detail du geste,
  ne cree pas un deuxieme geste ni une nouvelle cible. Si 'remplace' est explicite,
  remplace le seul geste vise. Decris les mouvements observables sans forcer un
  nouveau decoupage de shots.
- EMOTION: l'emotion demandee commande le NOUVEAU JEU D'ACTEUR. Les anciennes
  mimiques, sourires, expressions, gestes expressifs ou tonalites incompatibles
  NE SONT PAS a conserver. Donne une description BREVE et perceptible du jeu
  demande (regard, visage, respiration, posture si pertinent), sans changer
  l'identite et le lieu. N'impose pas une emotion opposee pour garder l'ancienne
  performance. N'invente pas une reponse narrative independante.
- Utilise les secondes exactes demandees; la duree et le cadrage restent ceux
  du clip. H3 pourra generer le clip ENTIER pour la continuite. La plage de la
  demande n'est pas une limite technique de regeneration.
- Ne repete PAS les anciens [Shot], les dialogues historiques ou les balises
  de reference du prompt initial. Ne mens pas sur l'observation de la video.
- Aucun exemple d'action, d'emotion, de personnage ou de secondes predefini:
  adapte-toi uniquement au prompt du clip et a la demande.

SORTIE : exactement ces DEUX champs, en FRANCAIS, sans markdown ni commentaire:
SCENE_CONTEXT: 1 phrase (MAX 300 caracteres) identite visible, environnement,
  lumiere et cadrage, SANS raconter les actions originales.
CHANGE: 1 a 3 phrases (MAX 460 caracteres) expliquant UNIQUEMENT l'action
  nouvelle/modifiee ou la performance emotionnelle souhaitee. Actions
  observees de maniere physique, pas une simple etiquette emotive.
Ne genere ni [Shot N], ni CUT, ni script entier, ni second dialogue.
"""


def build_request(performance_type, request, source_prompt, start, end, duration):
    if performance_type not in ('action', 'emotion'):
        raise ValueError('Le nouveau prompt court concerne Action/Emotion uniquement')
    if not (0 <= float(start) < float(end) <= float(duration) + .03):
        raise ValueError('Fenetre Performance invalide')
    mode = 'GESTE / ACTION' if performance_type == 'action' else 'EMOTION / JEU D ACTEUR'
    return (
        'MODE: '+mode+'\n'
        'DEMANDE EXACTE (ne pas en changer le sens): '+str(request).strip()+'\n'
        f'INSTANT CIBLE: {start:.3f}–{end:.3f}s dans un clip de {duration:.3f}s.\n'
        'Ces secondes servent a PLACER le changement dans le nouveau jeu. '
        'Le moteur H3 pourra regenerer la video complete pour raccorder ce changement.\n'
        'PROMPT ORIGINAL (CONTEXTE pour toi UNIQUEMENT, NON transmis a H3):\n'
        +(str(source_prompt or '').strip() or
          '(Prompt source absent. Ne pas inventer les anciennes actions, utiliser la video reference.)')
    )


_LABEL = re.compile(r'(?im)^\s*(?:\*\*)?\s*(SCENE_CONTEXT|CHANGE)\s*:\s*(?:\*\*)?\s*')
_SHOTS = re.compile(r'\[\s*Shot\s+\d+\s*\]',re.I)


def parse_output(result: str):
    text = stable._strip_fences(str(result or '')).strip()
    matches=list(_LABEL.finditer(text))
    if len(matches)!=2 or [m.group(1).upper() for m in matches]!=['SCENE_CONTEXT','CHANGE']:
        raise ValueError('Gemma : réponse attendue avec SCENE_CONTEXT puis CHANGE, sans script entier')
    scene=text[matches[0].end():matches[1].start()].strip()
    change=text[matches[1].end():].strip()
    scene=re.sub(r'\s+',' ',scene).strip('* -\r\n')
    change=re.sub(r'\s+',' ',change).strip('* -\r\n')
    if not(12<=len(scene)<=300 and 20<=len(change)<=460):
        raise ValueError('Gemma : contexte ou modification non concis (300/460 caracteres maxi)')
    if _SHOTS.search(text) or '<d>' in text.lower() or 'CUT.' in text.upper():
        raise ValueError('Gemma : ancien script/dialogue ou decoupage artificiel interdit')
    return scene,change


def assemble(performance_type, request, result, start, end, duration):
    scene,change=parse_output(result)
    if performance_type=='action':
        intro='NEW TAKE — TARGETED ACTION:'
        direction=('Execute the requested visible action naturally within the moment specified. '
                   'It may coexist with the original ongoing motion, unless the request calls for replacement.')
    elif performance_type=='emotion':
        intro='NEW TAKE — EMOTIONAL PERFORMANCE:'
        direction=('This is a NEW emotional performance, not the original facial acting. '
                   'Facial expression, gaze, expressive gestures and posture may change freely '
                   'to convey the requested emotion. Preserve visual identity and environment.')
    else:
        raise ValueError('Gabarit Performance inconnu')
    return (
        '<Video 1> = REAL ORIGINAL VIDEO REFERENCE: same person, visual identity, room, '
        'camera and lighting. Reference the visual scene, not the original performance as a script.\n'
        'SCENE CONTEXT: '+scene+'\n'
        +intro+'\n'
        'At '+f'{start:.3f}–{end:.3f}s: '+change+'\n'
        +direction+'\n'
        f'Same clip duration {duration:.3f}s. H3 generation permitted over 0.000–{duration:.3f}s '
        'for natural motion continuity. One continuous new take.'
    )


def write_prompt(*, mode, performance_type, request, source_prompt, start, end, duration, gpu_prepare):
    if mode!='performance' or performance_type not in ('action','emotion'):
        raise ValueError('V10.77 : prompt court Performance Action/Emotion uniquement')
    import h3film_studio_v3 as film
    gpu_prepare()
    backend=stable.choose_backend(film)
    try:
        instruction=build_request(performance_type,request,source_prompt,start,end,duration)
        for attempt in range(2):
            result=film.director_text(backend,SYSTEM_SHORT,instruction,
                    label='PERFORMANCE COURTE GEMMA 4 26B / OLLAMA',
                    num_ctx=8192,num_predict=600)
            try:
                prompt=assemble(performance_type,request,result,start,end,duration)
                break
            except ValueError as exc:
                if attempt:
                    raise RuntimeError('Gemma : prompt court invalide apres 2 tentatives : '+str(exc)) from exc
                instruction += ('\nREESSAIE : '+str(exc)+'\n'
                    'Produis exactement SCENE_CONTEXT: puis CHANGE:, '
                    'sans ancien script, sans [Shot] et en restant concis.')
    finally:
        try:
            film.unload_text_backend(backend,label='Avant retouche H3')
        finally:
            film.release_all_text_models_for_h3(label='Retouches : H3 prend le GPU')
    return prompt,('Gemma 26B · prompt court type Dialogue · '
                   +performance_type+' · '+str(backend.get('display') or backend.get('model')))
