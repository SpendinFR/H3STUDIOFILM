"""V10.101: Hide the Krea keyframe *before* the original first video frame.

MiniMaxH3AddGuide pins the Krea still at generated frame zero. H3 gradually
integrates it over its first frames. We prepend 17 *technical* frames to the
source and to the mask's temporal grid, anchor Krea at technical frame zero,
then discard those frames after H3, keeping exactly the original video's length
and original soundtrack. No prompt or Krea/guide image changes.

Only used for normal (not Quick) insertion starting at original frame zero.
"""
from __future__ import annotations
from pathlib import Path
import copy,json,shutil,subprocess,os
import torch

LEAD_FRAMES=17
FPS=24


def _bin(comfy:Path,name:str)->str:
    return shutil.which(name) or str(comfy.parent/'ffmpeg'/'bin'/(name+'.exe'))


def frame_count(path:Path,comfy:Path)->int:
    cmd=[_bin(comfy,'ffprobe'),'-v','error','-select_streams','v:0','-count_frames',
         '-show_entries','stream=nb_frames,nb_read_frames','-of','json',str(path)]
    proc=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
    if proc.returncode:
        raise RuntimeError('Insertion : ffprobe impossible : '+proc.stderr[-600:])
    values=(json.loads(proc.stdout).get('streams') or [{}])[0]
    try:return int(values.get('nb_frames') or values.get('nb_read_frames'))
    except (TypeError,ValueError) as exc:
        raise RuntimeError('Insertion : compteur d’images indisponible') from exc


def _has_audio(source:Path,comfy:Path)->bool:
    proc=subprocess.run([_bin(comfy,'ffprobe'),'-v','error','-select_streams','a:0',
        '-show_entries','stream=index','-of','csv=p=0',str(source)],
        capture_output=True,text=True,timeout=30)
    if proc.returncode:
        raise RuntimeError('Insertion : impossible de vérifier la piste audio : '+proc.stderr[-450:])
    return bool(proc.stdout.strip())


def stage_source(source:Path,comfy:Path,ident:str,orig_frames:int)->tuple[Path,str]:
    """Create isolated padded video under output for Roycho tracking, input for LoadVideo."""
    if orig_frames<22 or (orig_frames-5)%17:
        raise ValueError('Insertion : cadence RAW originale H3 invalide')
    total=orig_frames+LEAD_FRAMES
    target=(comfy/'output'/'h3retouch_insert_preroll'/f'{ident}_working_17f.mp4').resolve()
    target.parent.mkdir(parents=True,exist_ok=True)
    inp=comfy/'input'/f'h3new_{ident}_insert_preroll.mp4'
    if _has_audio(source,comfy):
        audio_src='[0:a:0]'
        extra=[]
    else:
        audio_src='[1:a:0]'
        extra=['-f','lavfi','-i','anullsrc=channel_layout=stereo:sample_rate=44100']
    af=(f'{audio_src}adelay={round(1000*LEAD_FRAMES/FPS)}:all=1,'
        f'apad,atrim=duration={total/FPS:.9f},asetpts=PTS-STARTPTS[a]')
    vf=(f'[0:v:0]tpad=start={LEAD_FRAMES}:start_mode=clone,'
        f'trim=end_frame={total},setpts=N/({FPS}*TB)[v]')
    cmd=[_bin(comfy,'ffmpeg'),'-hide_banner','-loglevel','error','-y','-i',str(source)]+extra+[
        '-filter_complex',vf+';'+af,'-map','[v]','-map','[a]',
        '-frames:v',str(total),'-c:v','libx264','-preset','veryfast','-crf','17',
        '-pix_fmt','yuv420p','-c:a','aac','-ar','44100','-movflags','+faststart',str(target)]
    proc=subprocess.run(cmd,capture_output=True,text=True,timeout=300)
    if proc.returncode or not target.is_file():
        raise RuntimeError('Insertion : préparation vidéo amont échouée : '+proc.stderr[-950:])
    if frame_count(target,comfy)!=total:
        target.unlink(missing_ok=True)
        raise RuntimeError('Insertion : vidéo préparatoire mal alignée en images')
    inp.parent.mkdir(parents=True,exist_ok=True)
    try:os.link(target,inp)
    except OSError:shutil.copy2(target,inp)
    return target,inp.name


def stage_latent(original_pt:Path,latent_name:str,original_frames:int)->Path:
    """Extend *mask tracking* time axis only. Never send this latent to sampler."""
    try:saved=torch.load(original_pt,map_location='cpu',weights_only=True)
    except TypeError:saved=torch.load(original_pt,map_location='cpu')
    if not isinstance(saved,dict) or not isinstance(saved.get('samples'),dict):
        raise RuntimeError('Insertion : RAW H3 sauvegardé incompatible')
    parts=saved['samples'].get('members') or []
    if len(parts)<2:raise RuntimeError('Insertion : RAW H3 sans vidéo/audio')
    video,audio=parts[0].get('tensor'),parts[1].get('tensor')
    if not (isinstance(video,torch.Tensor) and video.ndim==5 and
            isinstance(audio,torch.Tensor) and audio.ndim==4):
        raise RuntimeError('Insertion : tenseurs du RAW H3 incompatibles')
    n=int(video.shape[2])
    if n<7 or (n-2)%5 or 5+17*((n-2)//5)!=original_frames:
        raise RuntimeError('Insertion : latent et MP4 originaux désynchronisés')
    # H3 temporal groups repeat every 5 tokens (17 frames). A duplicate group
    # exists only for the tracker to compute its 141-frame spatial mask.
    augmented=torch.cat((video[:,:,:5,:,:],video),dim=2).contiguous()
    output=copy.copy(saved)
    pack=dict(saved['samples'])
    members=[dict(x) for x in parts]
    members[0].update(tensor=augmented,shape=tuple(augmented.shape),device='cpu')
    pack['members']=members
    output.update(samples=pack,noise_mask=None)
    path=original_pt.with_name(latent_name+'.pt')
    torch.save(output,path)
    return path


def seconds_for_h3(normal:dict)->dict:
    """The padded edit begins at working frame zero so the object can emerge before t=0."""
    count=int(normal['frames'])+LEAD_FRAMES
    if not (int(normal['frames'])-5)%17==0:
        raise ValueError('Insertion : durée du clip non compatible avec 17 frames préparatoires')
    return {**normal,'start':0.0,'end':(LEAD_FRAMES/FPS)+float(normal['end']),
            'duration':count/FPS,'frames':count}


def strip_warmup(generated:Path,original:Path,target:Path,frames:int,comfy:Path)->Path:
    """Discard 17 technical frames and correct ONLY the final visible frame zero.

    MiniMaxH3AddGuide sometimes leaves a Krea keyframe remnant at first visible
    frame even after the 17f warm-up. The next decoded image is already clean in
    the successful V10.105 examples. Use that *same next image* at t=0, then
    preserve the complete generated sequence from t=1 onward. This changes
    exactly ONE visible video frame, with a single FFmpeg encode, and maps the
    untouched source audio, without modifying Krea, Roycho, Gemma or H3.
    """
    required=frames+LEAD_FRAMES
    if frames < 2:
        raise ValueError('Insertion : impossible de corriger frame 0 sur un clip de moins de 2 images')
    actual=frame_count(generated,comfy)
    if actual!=required:
        raise RuntimeError(f'Insertion : H3 a rendu {actual} images au lieu de {required}. Pas de décalage silencieux.')
    second=LEAD_FRAMES+1
    # Keep generated[18:] (the already-correct image sequence) and prepend ONE
    # clone of generated[18]. tpad duplicates the first selected image without
    # adding a second encoding pass, timestamps are rebuilt at 24 fps.
    # This also avoids concat boundary PTS ambiguity / accidental dropped frames.
    vf=(f'[0:v:0]trim=start_frame={second}:end_frame={required},'
        f'tpad=start=1:start_mode=clone,setpts=N/({FPS}*TB)[v]')
    cmd=[_bin(comfy,'ffmpeg'),'-hide_banner','-loglevel','error','-y',
         '-i',str(generated),'-i',str(original),'-filter_complex',vf,
         '-map','[v]','-map','1:a:0?', '-frames:v',str(frames),
         '-c:v','libx264','-preset','veryfast','-crf','17','-pix_fmt','yuv420p',
         '-c:a','aac','-ar','44100','-movflags','+faststart',str(target)]
    target.parent.mkdir(parents=True,exist_ok=True)
    proc=subprocess.run(cmd,capture_output=True,text=True,timeout=300)
    if proc.returncode or not target.is_file():
        raise RuntimeError('Insertion : retrait des images préparatoires échoué : '+proc.stderr[-950:])
    if frame_count(target,comfy)!=frames:
        target.unlink(missing_ok=True)
        raise RuntimeError('Insertion : retrait du pré-roll a modifié la durée finale')
    return target
