# Import the user's ten archives without changing Film Studio's official prompts.
# Execute from any location: powershell.exe -NoProfile -ExecutionPolicy Bypass -File <this file>
param([string]$Archives = "$env:USERPROFILE\Desktop\Prompt")
$ErrorActionPreference = 'Stop'
$targets = [ordered]@{
  'divertissement'   = 'H3_DIRECTORS_DIVERTISSEMENT_V1.zip'
  'publicite'        = 'PUBLICITE_H3_DIRECTORS.zip'
  'createur_facecam' = 'H3_DIRECTORS_CREATEUR_FACECAM_V1.zip'
  'reportage'        = 'REPORTAGE_H3_DIRECTORS.zip'
  'sport'            = 'SPORT_H3_DIRECTORS.zip'
  'musique'          = 'MUSIQUE_H3_DIRECTORS.zip'
  'actualites'       = 'ACTUALITES_H3_DIRECTORS.zip'
  'podcast'          = 'PODCAST_H3_DIRECTORS.zip'
  'education'        = 'EDUCATION_H3_DIRECTORS.zip'
  'reseaux_sociaux'  = 'RESEAUX_SOCIAUX_H3_DIRECTORS.zip'
}
$destination = Join-Path $PSScriptRoot 'director_teams'
New-Item -ItemType Directory -Force -Path $destination | Out-Null
foreach ($name in $targets.Keys) {
  $zip = Join-Path $Archives $targets[$name]
  if (-not (Test-Path -LiteralPath $zip)) { Write-Warning "Archive absente : $zip"; continue }
  $staging = Join-Path $env:TEMP ("studio_team_" + [guid]::NewGuid().ToString('N'))
  try {
    Expand-Archive -LiteralPath $zip -DestinationPath $staging -Force
    $roleFiles = @{}
    foreach ($role in @('CONTENT','SCENE','PLAN','CLIP')) {
      $rx = '(^|[_ .-])' + $role + '[_ .-]*DIRECTOR($|[_ .-])'
      $all = @(Get-ChildItem -LiteralPath $staging -Recurse -File | Where-Object { $_.Extension -in @('.txt','.md','.prompt') })
      $exact = @($all | Where-Object { $_.BaseName -ieq "${role}_DIRECTOR" })
      $matches = if ($exact.Count -eq 1) { $exact } else { @($all | Where-Object { $_.BaseName -match $rx }) }
      if ($matches.Count -ne 1) { throw "Pour $name : $role DIRECTOR attendu une fois (trouvé $($matches.Count))." }
      $roleFiles[$role] = $matches[0]
    }
    $output = Join-Path $destination $name
    New-Item -ItemType Directory -Force -Path $output | Out-Null
    foreach ($role in @('CONTENT','SCENE','PLAN','CLIP')) {
      Copy-Item -LiteralPath $roleFiles[$role].FullName -Destination (Join-Path $output "${role}_DIRECTOR.txt") -Force
    }
    Write-Host "OK $name : 4 Directors importés" -ForegroundColor Green
  } catch {
    Write-Warning "Équipe $name non importée : $_"
  } finally {
    if (Test-Path -LiteralPath $staging) { Remove-Item -LiteralPath $staging -Recurse -Force }
  }
}
Write-Host "Film original inchangé. Équipes disponibles sous $destination"
