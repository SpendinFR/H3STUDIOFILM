"""Explicit global emergency stop requested by the user (Stop and Ctrl+C).

WARNING: unlike pause/suspend/normal VRAM unloading, this stops *all*
llama-server/ollama processes and clears the *entire* ComfyUI queue on localhost.
Kept separate from renderer/continuity code; no other H3 workflow changes.
"""
from __future__ import annotations

import json
import os
import signal
from contextlib import contextmanager
import subprocess
import urllib.request

COMFY_BASE = 'http://127.0.0.1:8188'


@contextmanager
def _finish_cleanup_on_repeated_ctrl_c():
    """Ctrl+C caught by the caller must not interrupt its own emergency cleanup.

    On Windows Ctrl+C is also delivered to PowerShell subprocesses sharing the
    console. We still use the global stop semantics requested by the user;
    ignore subsequent SIGINT only during this short bounded cleanup.
    """
    prior = None
    try:
        prior = signal.getsignal(signal.SIGINT)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
    except (OSError, ValueError):  # e.g. HTTP request thread: not the main thread
        prior = None
    try:
        yield
    finally:
        if prior is not None:
            signal.signal(signal.SIGINT, prior)


def emergency_stop() -> list[str]:
    """Attempt each global cleanup action without an interrupt traceback."""
    with _finish_cleanup_on_repeated_ctrl_c():
        return _emergency_stop_impl()


def _emergency_stop_impl() -> list[str]:
    """Synchronously attempt all four steps, even if one fails; report failures."""
    problems = []
    if os.name == 'nt':
        # Exact semantics of: Get-Process llama-server / ollama | Stop-Process -Force
        # One shell command also avoids killing the server process by executable-name guess.
        command = ("Get-Process -Name 'llama-server','ollama' -ErrorAction SilentlyContinue "
                   "| Stop-Process -Force -ErrorAction Stop")
        try:
            proc = subprocess.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', command],
                                  capture_output=True, text=True, timeout=15,
                                  creationflags=(getattr(subprocess, 'CREATE_NO_WINDOW', 0) |
                                                 getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0)))
            if proc.returncode:
                problems.append('Arrêt llama-server/Ollama : '+(proc.stderr.strip() or str(proc.returncode)))
        except (OSError, subprocess.TimeoutExpired, KeyboardInterrupt) as exc:
            problems.append('Arrêt llama-server/Ollama : '+str(exc))
    for endpoint, payload in (('/interrupt', {}), ('/queue', {'clear': True})):
        try:
            req = urllib.request.Request(COMFY_BASE+endpoint,
                        data=json.dumps(payload).encode('utf-8'),
                        headers={'Content-Type':'application/json'}, method='POST')
            with urllib.request.urlopen(req, timeout=6):
                pass
        except (Exception, KeyboardInterrupt) as exc:
            problems.append('ComfyUI '+endpoint+' : '+str(exc))
    return problems
