"""V10.78 experimental Retake ONLY: one 39-frame RAW window, then splice.

Does not modify Essai début RAW, Performance, Dialogue, Insert, or FilmMaker.
All windows are generated from copies; source MP4 and saved RAW .pt remain read-only.
Middle latent slices are experimental: unlike the first 39 frames, their H3
initialization tokens are not a native independent-clip encoding. Visual quality
and motion continuity must be checked in ComfyUI rather than presumed.
"""
from __future__ import annotations
from pathlib import Path
import math, re, shutil, subprocess

FPS=24
FRAMES=39


def select_window(total_latent:int, total_frames:int, begin:float, end:float)->dict:
    if total_latent<12:
        raise ValueError('Retake local : le RAW a moins de 39 images de latent source')
    expected=round(5+17*(total_latent-2)/5)
    if expected != total_frames:
        raise ValueError(f'Retake local : durée MP4/RAW incohérente ({total_frames} images MP4, {expected} images déduites du RAW). Aucun rendu lancé.')
    first=max(0,min(total_frames-1,int(round(begin*FPS))))
    last=max(first+1,min(total_frames,int(round(end*FPS))))
    if last-first>FRAMES:
        raise ValueError('Retake local expérimental : intervalle supérieur à 39 images. Réduire la sélection à 1,625 s maximum.')
    options=[]
    for token in range(total_latent-12+1):
        origin=round(token*17/5)
        if origin<=first and last<=origin+FRAMES and origin+FRAMES<=total_frames:
            lead=first-origin; tail=origin+FRAMES-last
            options.append({'token':token,'origin':origin,'lead':lead,'tail':tail})
    if not options:
        raise ValueError('Retake local : aucune fenêtre H3 valide ne couvre la sélection sur ce RAW.')
    # V10.81: a single seam is more robust than a centered two-seam splice.
    # Prefer the earliest covering window for selections in the first half of
    # the clip (generated prefix + original suffix), or the latest covering
    # window for selections in the second half (original prefix + generated suffix).
    midpoint=(first+last)/2.0
    if midpoint <= total_frames/2.0:
        chosen=min(options,key=lambda x:(x['origin'],x['tail'],x['lead']))
        seam_mode='suffix_only'
    else:
        chosen=max(options,key=lambda x:(x['origin'],-x['lead'],-x['tail']))
        seam_mode='prefix_only'
    token,origin=chosen['token'],chosen['origin']
    return {'start_latent':token,'origin_frame':origin,'end_frame':origin+FRAMES,
            'first_frame':first,'last_frame':last,'local_first':first-origin,
            'local_last':last-origin,'duration':FRAMES/FPS,
            'start':(first-origin)/FPS,'end':(last-origin)/FPS,
            'global_offset':origin/FPS,'frames':FRAMES,
            'seam_mode':seam_mode}


def _seconds(s:str)->float:
    s=s.replace(',', '.').strip()
    if ':' in s:
        mm, ss = s.split(':',1)
        return float(mm)*60+float(ss)
    return float(s)

SHOT=re.compile(r'\[Shot\s+(\d+)\]\s*\*{0,2}\s*((?:\d+:)?\d+(?:[.,]\d+)?)\s*(?:s\b)?\s*[-–—]\s*((?:\d+:)?\d+(?:[.,]\d+)?)\s*(?:s\b)?', re.I)
INLINE=re.compile(r'(?i)Pendant\s+((?:\d+:)?\d+(?:[.,]\d+)?)\s*[-–—]\s*((?:\d+:)?\d+(?:[.,]\d+)?)\s*s?\s*:')


def local_prompt(full_prompt:str,window:dict)->str:
    """Convert the already validated Gemma complete NEW TAKE into a local timeline.

    Gemma STILL sees the original full-shot prompt and the true global edit times.
    H3 sees only the relevant shots, renumbered with 0..1.625s local times.
    No second Gemma invocation; no old source script sent to H3.
    """
    marker='NEW TAKE — THIS IS THE ONLY SHOT SCRIPT TO GENERATE:'
    if marker not in full_prompt or 'Preserve total duration' not in full_prompt:
        raise ValueError('Retake local : prompt NEW TAKE V74 incompatible; aucun rendu envoyé à H3')
    pre, rest=full_prompt.split(marker,1)
    script=rest.split('Preserve total duration',1)[0].strip()
    shots=list(SHOT.finditer(script))
    if not shots:
        raise ValueError('Retake local : aucun [Shot] Gemma utilisable')
    offset=window['global_offset']; stop=offset+window['duration']
    fragments=[]
    for i,m in enumerate(shots):
        a,b=_seconds(m.group(2)),_seconds(m.group(3))
        if b<=offset+1e-4 or a>=stop-1e-4:
            continue
        left=max(a,offset)-offset
        right=min(b,stop)-offset
        if right-left<.001:continue
        text=script[m.end():shots[i+1].start() if i+1<len(shots) else len(script)].strip()
        def translate(match):
            lo,hi=_seconds(match.group(1)),_seconds(match.group(2))
            return f'Pendant {max(0.,lo-offset):.3f}–{min(window["duration"],hi-offset):.3f}s :' if hi>offset and lo<stop else ''
        text=INLINE.sub(translate,text)
        fragments.append((left,right,text))
    if not fragments:
        raise ValueError('Retake local : aucune action Gemma dans la fenêtre choisie')
    # The first/last shot can be cropped in the middle of a beat. Clamp exactly
    # to the isolated reference-video window to avoid fake global timestamps.
    if fragments[0][0] > .09 or fragments[-1][1] < window['duration']-.09:
        raise ValueError('Retake local : la timeline Gemma ne couvre pas la portion RAW')
    pieces=[]
    for i,(a,b,body) in enumerate(fragments,1):
        pieces.append(f'[Shot {i}] {a:.3f}–{b:.3f}s {body}')
    txt=(pre.strip()+'\n'+marker+'\n'+'\n'.join(pieces)+'\n'
         f'LOCAL TAKE: exactly {window["duration"]:.3f}s, from the original source interval '
         f'{offset:.3f}–{stop:.3f}s. Requested change within the LOCAL take: '
         f'{window["start"]:.3f}–{window["end"]:.3f}s. '
         'Use <Video 1> only as visual and motion reference for THIS SHORT WINDOW; '
         'produce the requested NEW TAKE, not the original action. '
         'Retain the same person, camera, space, lighting and continuous movement.')
    return txt


def _bin(comfy:Path,name:str)->str:
    return shutil.which(name) or str(comfy.parent/'ffmpeg'/'bin'/(name+'.exe'))


def _frame_count(path:Path,comfy:Path)->int:
    import json
    cmd=[_bin(comfy,'ffprobe'),'-v','error','-select_streams','v:0',
         '-count_frames','-show_entries','stream=nb_frames,nb_read_frames',
         '-of','json',str(path)]
    proc=subprocess.run(cmd,capture_output=True,text=True,timeout=45)
    if proc.returncode:
        raise RuntimeError('Retake local : vérification ffprobe impossible : '+proc.stderr[-500:])
    try:
        data=(json.loads(proc.stdout).get('streams') or [{}])[0]
        return int(data.get('nb_frames') or data.get('nb_read_frames'))
    except (ValueError,TypeError,IndexError,KeyError) as exc:
        raise RuntimeError('Retake local : nombre d’images vidéo indisponible pour '+path.name) from exc


def stage_reference(source:Path,comfy:Path,ident:str,window:dict)->str:
    """Exactly 39 source frames as H3 <Video 1> for the isolated generation."""
    output=comfy/'input'/f'h3new_{ident}_precise_window.mp4'
    output.parent.mkdir(parents=True,exist_ok=True)
    filt=f'trim=start_frame={window["origin_frame"]}:end_frame={window["end_frame"]},setpts=PTS-STARTPTS'
    cmd=[_bin(comfy,'ffmpeg'),'-hide_banner','-loglevel','error','-y','-i',str(source),
         '-vf',filt,'-an','-frames:v','39','-c:v','libx264','-preset','veryfast',
         '-crf','17','-pix_fmt','yuv420p','-movflags','+faststart',str(output)]
    proc=subprocess.run(cmd,capture_output=True,text=True,timeout=120)
    if proc.returncode or not output.is_file():
        raise RuntimeError('Retake local : extraction des 39 images source échouée : '+proc.stderr[-700:])
    if _frame_count(output,comfy)!=39:
        raise RuntimeError('Retake local : la référence recadrée ne contient pas exactement 39 images')
    return output.name


def stitch(original:Path,generated:Path,target:Path,window:dict,total_frames:int,comfy:Path)->Path:
    """Preserve original frames outside user's exact range; retain original audio.

    A 4-frame linear boundary blend happens entirely INSIDE the selected region.
    No generated frames are permitted outside the requested selection.
    """
    if _frame_count(generated,comfy)!=FRAMES:
        raise RuntimeError('Retake local : H3 doit rendre exactement 39 images. Raccord annulé pour ne pas décaler le clip.')
    first,last=window['first_frame'],window['last_frame']
    local_a,local_b=window['local_first'],window['local_last']
    length=last-first
    if first<0 or last>total_frames or local_a<0 or local_b>FRAMES or length!=local_b-local_a:
        raise ValueError('Retake local : index de raccord hors limites')
    streams=[]
    if first:
        streams.append(f'[0:v]trim=start_frame=0:end_frame={first},setpts=PTS-STARTPTS,format=yuv420p[p]')
    streams.append(f'[0:v]trim=start_frame={first}:end_frame={last},setpts=PTS-STARTPTS,format=yuv420p[b]')
    streams.append(f'[1:v]trim=start_frame={local_a}:end_frame={local_b},setpts=PTS-STARTPTS,format=yuv420p[n]')
    fade_in=min(4,length) if first else 1
    fade_out=min(4,length) if last<total_frames else 1
    gain=f'min(1,(N+1)/{fade_in})*min(1,({length}-N)/{fade_out})'
    streams.append(f"[b][n]blend=all_expr='A*(1-({gain}))+B*({gain})'[edit]")
    labels=('[p]' if first else '')+'[edit]'
    if last<total_frames:
        streams.append(f'[0:v]trim=start_frame={last}:end_frame={total_frames},setpts=PTS-STARTPTS,format=yuv420p[s]')
        labels+='[s]'
    count=1+(1 if first else 0)+(1 if last<total_frames else 0)
    streams.append(labels+f'concat=n={count}:v=1:a=0[outv]')
    target.parent.mkdir(parents=True,exist_ok=True)
    cmd=[_bin(comfy,'ffmpeg'),'-hide_banner','-loglevel','error','-y','-i',str(original),
         '-i',str(generated),'-filter_complex',';'.join(streams),
         '-map','[outv]','-map','0:a:0?',
         '-c:v','libx264','-preset','veryfast','-crf','17','-pix_fmt','yuv420p',
         '-c:a','aac','-ar','44100','-frames:v',str(total_frames),str(target)]
    proc=subprocess.run(cmd,capture_output=True,text=True,timeout=360)
    if proc.returncode or not target.is_file():
        raise RuntimeError('Retake local : raccord ffmpeg échoué : '+proc.stderr[-1300:])
    if _frame_count(target,comfy)!=total_frames:
        target.unlink(missing_ok=True)
        raise RuntimeError('Retake local : le raccord a modifié le nombre d’images. Sortie refusée.')
    return target
