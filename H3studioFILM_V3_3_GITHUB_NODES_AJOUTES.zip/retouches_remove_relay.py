"""Rolling 22-frame H3 removal using already-cleaned frames as anchors.

Only used by remove_person, never by Film Studio or character swapping.
No original subject frames are fed back into continuation windows.
"""
from __future__ import annotations
import subprocess
from pathlib import Path

FPS=24
WINDOW=22
STRIDE=17
ANCHOR=5
STABLE_PAD=4


def intervals(count):
    if count < WINDOW or (count-5)%17:
        raise ValueError(f'Remove relay: expected H3 17n+5, at least 22 frames; got {count}')
    windows=[(start,start+WINDOW) for start in range(0,count-WINDOW+1,STRIDE)]
    if not windows or windows[-1][1]!=count:
        raise RuntimeError('Remove relay: incomplete coverage')
    return windows


def _run(command, label, target):
    result=subprocess.run(command,capture_output=True,text=True,timeout=240)
    if result.returncode or not Path(target).is_file():
        raise RuntimeError(f'{label}: '+result.stderr[-750:])
    return Path(target)


def _audio(source):
    p=subprocess.run(['ffprobe','-v','error','-select_streams','a:0',
                      '-show_entries','stream=index','-of','csv=p=0',str(source)],
                     capture_output=True,text=True,timeout=20)
    return bool(p.stdout.strip())


def cut_window(source, target, start, end, has_audio=None, green=False):
    """Frame-index video cut; audio optional (green Akatz clips have none)."""
    if end-start != WINDOW:
        raise ValueError('Remove relay expects 22-frame windows')
    source=Path(source);target=Path(target)
    has_audio=_audio(source) if has_audio is None else has_audio
    ff=['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(source)]
    vf=f'trim=start_frame={start}:end_frame={end},setpts=PTS-STARTPTS'
    ff+=['-map','0:v:0','-vf',vf,'-frames:v',str(WINDOW),'-r',str(FPS),
         '-c:v','libx264','-preset','fast','-crf','8' if green else '15',
         '-pix_fmt','yuv444p' if green else 'yuv420p']
    if has_audio:
        ff+=['-map','0:a:0','-af',f'atrim=start={start/FPS:.9f}:end={end/FPS:.9f},asetpts=PTS-STARTPTS',
             '-c:a','aac','-ar','32000']
    else:
        ff+=['-an']
    ff+=['-movflags','+faststart',str(target)]
    return _run(ff,'H3 relay window cut failed',target)


def build_mask_movie(mask_paths, target, start, anchored, width, height):
    """Lossless-ish 22-frame grayscale binary mask, with five clean anchors unmasked."""
    import cv2
    import numpy as np
    target=Path(target)
    if start+WINDOW>len(mask_paths):raise ValueError('Mask range beyond source')
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo',
         '-pixel_format','gray','-video_size',f'{width}x{height}',
         '-framerate',str(FPS),'-i','pipe:0','-an','-c:v','libx264',
         '-preset','fast','-crf','0','-pix_fmt','yuv444p',str(target)]
    proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=subprocess.PIPE,stdout=subprocess.DEVNULL)
    try:
        for j in range(WINDOW):
            if anchored and j<ANCHOR:
                frame=np.zeros((height,width),dtype=np.uint8)
            else:
                image=cv2.imread(str(mask_paths[start+j]),cv2.IMREAD_GRAYSCALE)
                if image is None:raise RuntimeError('Unreadable original SAM3 mask')
                if image.shape!=(height,width):
                    image=cv2.resize(image,(width,height),interpolation=cv2.INTER_NEAREST)
                frame=np.where(image>100,255,0).astype(np.uint8)
            proc.stdin.write(frame.tobytes())
        proc.stdin.close()
        err=proc.stderr.read().decode('utf-8','replace')
        if proc.wait(timeout=180) or not target.is_file():
            raise RuntimeError('Mask video failed: '+err[-650:])
    except Exception:
        if proc.poll() is None:proc.kill()
        proc.wait(timeout=15)
        target.unlink(missing_ok=True)
        raise
    finally:
        if proc.stdin and not proc.stdin.closed:proc.stdin.close()
        if proc.stderr:proc.stderr.close()
    return target


def make_next_input(previous_render,green_full,original_full,start,end,target):
    """Five clean frames from previous render, then seventeen green-masked NEW frames.

    Only the original soundtrack may be read from the source. Original subject
    video pixels never enter a continuation window.
    """
    if end-start!=WINDOW or start<STRIDE:
        raise ValueError('Invalid continuing window')
    prev=Path(previous_render);green=Path(green_full);orig=Path(original_full)
    target=Path(target)
    vfg=(f'[0:v]trim=start_frame={STRIDE}:end_frame={WINDOW},setpts=PTS-STARTPTS[old];'
         f'[1:v]trim=start_frame={start+ANCHOR}:end_frame={end},setpts=PTS-STARTPTS[new];'
         '[old][new]concat=n=2:v=1:a=0,fps=24[video]')
    args=['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(prev),'-i',str(green)]
    has_audio=_audio(orig)
    if has_audio:
        args+=['-i',str(orig)]
        vfg+=(f';[2:a]atrim=start={start/FPS:.9f}:end={end/FPS:.9f},'
               'asetpts=PTS-STARTPTS[audio]')
    args+=['-filter_complex',vfg,'-map','[video]','-frames:v',str(WINDOW),
           '-c:v','libx264','-preset','fast','-crf','8','-pix_fmt','yuv444p']
    if has_audio:
        args+=['-map','[audio]','-c:a','aac','-ar','32000']
    else:
        args+=['-an']
    args+=['-movflags','+faststart',str(target)]
    return _run(args,'H3 relay continuation preparation failed',target)




def _stable_union_mask(mask_paths,start,end,width,height):
    import cv2, numpy as np
    acc=None
    for idx in range(start,end):
        image=cv2.imread(str(mask_paths[idx]),cv2.IMREAD_GRAYSCALE)
        if image is None:
            raise RuntimeError('Unreadable original SAM3 mask')
        if image.shape!=(height,width):
            image=cv2.resize(image,(width,height),interpolation=cv2.INTER_NEAREST)
        binary=(image>100).astype(np.uint8)*255
        acc=binary if acc is None else np.maximum(acc,binary)
    if acc is None:
        raise RuntimeError('Stable union mask is empty')
    # Small spatial pad so the fixed continuation zone absorbs tiny edge motion
    # instead of exposing a dancing Krea/green frontier.
    if STABLE_PAD>0:
        kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(STABLE_PAD*2+1,STABLE_PAD*2+1))
        acc=cv2.dilate(acc,kernel,iterations=1)
    return acc

def build_stable_mask_movie(mask_paths,target,start,width,height):
    """22-frame mask video with fixed continuation zone to stop dancing edges."""
    import cv2, numpy as np
    target=Path(target)
    support=_stable_union_mask(mask_paths,start+ANCHOR,start+WINDOW,width,height)
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','rawvideo',
         '-pixel_format','gray','-video_size',f'{width}x{height}',
         '-framerate',str(FPS),'-i','pipe:0','-an','-c:v','libx264',
         '-preset','fast','-crf','0','-pix_fmt','yuv444p',str(target)]
    proc=subprocess.Popen(cmd,stdin=subprocess.PIPE,stderr=subprocess.PIPE,stdout=subprocess.DEVNULL)
    try:
        zero=np.zeros((height,width),dtype=np.uint8)
        for j in range(WINDOW):
            frame=zero if j<ANCHOR else support
            proc.stdin.write(frame.tobytes())
        proc.stdin.close()
        err=proc.stderr.read().decode('utf-8','replace')
        if proc.wait(timeout=180) or not target.is_file():
            raise RuntimeError('Stable mask video failed: '+err[-650:])
    except Exception:
        if proc.poll() is None: proc.kill()
        proc.wait(timeout=15)
        target.unlink(missing_ok=True)
        raise
    finally:
        if proc.stdin and not proc.stdin.closed: proc.stdin.close()
        if proc.stderr: proc.stderr.close()
    return target

def make_next_input_stable(previous_render,original_full,mask_paths,start,end,target,width,height):
    """Continuation input with five clean anchors + seventeen frames green-masked by one stable zone."""
    import cv2, numpy as np, tempfile, os
    if end-start!=WINDOW or start<STRIDE:
        raise ValueError('Invalid continuing window')
    prev=Path(previous_render); orig=Path(original_full); target=Path(target)
    target.parent.mkdir(parents=True,exist_ok=True)
    cap_prev=cv2.VideoCapture(str(prev))
    cap_orig=cv2.VideoCapture(str(orig))
    if not cap_prev.isOpened() or not cap_orig.isOpened():
        raise RuntimeError('Unable to open continuation sources')
    support=_stable_union_mask(mask_paths,start+ANCHOR,start+WINDOW,width,height)
    fourcc=cv2.VideoWriter_fourcc(*'mp4v')
    tmp=target.with_name(target.stem+'_silent.mp4')
    writer=cv2.VideoWriter(str(tmp),fourcc,float(FPS),(width,height))
    try:
        # advance previous to last 5 frames and original to start+ANCHOR
        prev_total=int(cap_prev.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        prev_start=max(0, prev_total-ANCHOR)
        cap_prev.set(cv2.CAP_PROP_POS_FRAMES, prev_start)
        for _ in range(ANCHOR):
            ok, frame=cap_prev.read()
            if not ok: raise RuntimeError('Continuation anchor frame missing')
            if frame.shape[:2]!=(height,width):
                frame=cv2.resize(frame,(width,height),interpolation=cv2.INTER_AREA)
            writer.write(frame)
        cap_orig.set(cv2.CAP_PROP_POS_FRAMES, start+ANCHOR)
        for _ in range(WINDOW-ANCHOR):
            ok, frame=cap_orig.read()
            if not ok: raise RuntimeError('Original continuation frame missing')
            if frame.shape[:2]!=(height,width):
                frame=cv2.resize(frame,(width,height),interpolation=cv2.INTER_AREA)
            out=frame.copy()
            out[support>=127]=(0,255,0)
            writer.write(out)
    finally:
        writer.release()
        cap_prev.release(); cap_orig.release()
    # mux original audio segment if present
    has_audio=_audio(orig)
    if has_audio:
        args=['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(tmp),'-i',str(orig),
              '-map','0:v:0','-map','1:a:0','-c:v','copy',
              '-af',f'atrim=start={start/FPS:.9f}:end={end/FPS:.9f},asetpts=PTS-STARTPTS',
              '-c:a','aac','-ar','32000','-movflags','+faststart',str(target)]
        _run(args,'H3 relay stable continuation mux failed',target)
        tmp.unlink(missing_ok=True)
        return target
    else:
        tmp.replace(target)
        return target

def attach_exact_mask(graph,mask_video_staged,objinfo,continuation=False):
    """Use one prechecked SAM3 mask for *both* green reference and latent mask.

    No second SAM3 detection, no cleanup or grow on an already-grown mask.
    Other modes never call this function.
    """
    for typename in ('LoadVideo','GetVideoComponents','ImageToMask'):
        if typename not in objinfo:
            raise RuntimeError(f'Remove relay: missing required ComfyUI node {typename}')
    graph['70']={'class_type':'LoadVideo','inputs':{'file':mask_video_staged}}
    graph['71']={'class_type':'GetVideoComponents','inputs':{'video':['70',0]}}
    graph['72']={'class_type':'ImageToMask','inputs':{'image':['71',0],'channel':'red'}}
    graph['28']['inputs']['masks']=['72',0]
    # Prechecked SAM3 masks are already grown by V10.58's 12-pixel GrowMask.
    # Avoid expanding into scenery again; protect all five clean anchor frames.
    graph['28']['inputs']['grow_spatial']=7 if continuation else 5
    graph['28']['inputs']['grow_temporal']=0 if continuation else 1
    for key in ('3','4','5','6','7','8','9','10','11','44'):
        graph.pop(key,None)
    return graph


def extract_new_frames(rendered,target,continuation):
    start=ANCHOR if continuation else 0
    target=Path(target)
    cmd=['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(rendered),
         '-map','0:v:0','-an','-vf',f'trim=start_frame={start}:end_frame={WINDOW},setpts=PTS-STARTPTS',
         '-frames:v',str(WINDOW-start),'-r',str(FPS),'-c:v','libx264',
         '-preset','fast','-crf','16','-pix_fmt','yuv420p',str(target)]
    return _run(cmd,'H3 relay extraction failed',target)


def join_chunks(chunks,target):
    import tempfile
    target=Path(target)
    list_file=target.with_suffix('.concat.txt')
    try:
        list_file.write_text(''.join("file '"+str(Path(p).resolve()).replace("'","'\\''")+"'\n" for p in chunks),encoding='utf-8')
        args=['ffmpeg','-hide_banner','-loglevel','error','-y','-f','concat','-safe','0',
              '-i',str(list_file),'-map','0:v:0','-an','-r',str(FPS),
              '-c:v','libx264','-preset','fast','-crf','16','-pix_fmt','yuv420p',
              '-movflags','+faststart',str(target)]
        return _run(args,'H3 relay final join failed',target)
    finally:
        list_file.unlink(missing_ok=True)
