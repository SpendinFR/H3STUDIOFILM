"""Lightweight filesystem IPC for FilmMaker V10; only loaded in web mode.
No CUDA, no third party dependencies. Atomic decisions; no network in the renderer.
"""
import json, os, time, uuid
from pathlib import Path

DIR = Path(os.environ['H3FILM_STUDIO_SESSION']).resolve() if os.environ.get('H3FILM_STUDIO_SESSION') else None

def enabled(): return bool(DIR)
def _write(name, item):
    if not DIR: return
    p = DIR/name; p.parent.mkdir(parents=True, exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(item,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(tmp,p)
def _get(name, fallback=None):
    if not DIR: return fallback
    try: return json.loads((DIR/name).read_text(encoding='utf-8'))
    except (OSError,ValueError): return fallback

def _event(kind, title, *, detail='', action='', key=''):
    """Tiny durable, human readable activity stream; no raw console output."""
    if not DIR: return
    event={'at':time.time(),'kind':str(kind),'title':str(title),'detail':str(detail)[:600],'action':str(action),'key':str(key)}
    paths=[DIR/'history.json']
    project=_get('active_project.json',{})
    if project.get('path'):
        paths.append(Path(project['path'])/'_studio'/'history.json')
    for path in paths:
        try:
            old=json.loads(path.read_text('utf-8')) if path.is_file() else []
            if not isinstance(old,list): old=[]
            if old and old[-1].get('kind')==kind and old[-1].get('title')==title and not action: continue
            old=(old+[event])[-300:]
            path.parent.mkdir(parents=True,exist_ok=True)
            tmp=path.with_suffix('.tmp')
            tmp.write_text(json.dumps(old,ensure_ascii=False),encoding='utf-8')
            os.replace(tmp,path)
        except (OSError, ValueError):pass

def publish(stage, title, payload=None):
    _write('stage.json', {'stage':stage,'title':title,'payload':payload or {},'updated':time.time()})
    _event(stage,title,key=(payload or {}).get('clip',''))

class StudioStop(BaseException):
    """User deliberately cancelled this running studio production."""

def raise_if_stopped():
    if DIR and (DIR/'stop.request').is_file():
        raise StudioStop()

def pause_boundary():
    if not DIR: return
    raise_if_stopped()
    if (DIR/'suspend.request').exists():
        _write('suspended.json', {'at': time.time()})
        raise StudioSuspend()
    announced=False
    while (DIR/'pause.request').exists():
        raise_if_stopped()
        if (DIR/'suspend.request').exists():
            _write('suspended.json', {'at': time.time()})
            raise StudioSuspend()
        if not announced:
            _write('paused.json', {'paused':True,'at':time.time()}); announced=True
        time.sleep(0.2)
    if announced:
        (DIR/'paused.json').unlink(missing_ok=True)

def ask_input(prompt='> ', *, context=None):
    if not DIR: return input(prompt)
    pause_boundary()
    config = _get('config.json', {})
    prefilled = config.get('initial_answers', [])
    idx=int(_get('input_index.json',{'index':0}).get('index',0))
    if idx < len(prefilled):
        _write('input_index.json', {'index':idx+1})
        return str(prefilled[idx])
    if config.get('auto_answers',False):
        return ''
    key=uuid.uuid4().hex
    _write('question.json',{'id':key, 'prompt':str(prompt), 'context':context or {},'at':time.time()})
    ans=DIR/'answers'/f'{key}.json'
    while True:
        raise_if_stopped()
        if (DIR/'suspend.request').exists():
            _write('suspended.json', {'at': time.time()})
            raise StudioSuspend()
        if ans.is_file():
            val=json.loads(ans.read_text(encoding='utf-8')).get('value','')
            ans.unlink(missing_ok=True)
            (DIR/'question.json').unlink(missing_ok=True)
            _event('answer',(context or {}).get('title') or 'Choix de préproduction',action='answered',detail=str(val)[:150])
            return str(val)
        time.sleep(.2)

def checkpoint(kind,title,payload=None, allow_revise=False, force=False, allow_redo=False):
    """Wait only if enabled for this checkpoint, otherwise just publish stage."""
    if not DIR: return {'action':'continue'}
    raise_if_stopped()
    publish(kind,title,payload)
    config=_get('config.json',{})
    if not force and not bool(config.get('reviews',{}).get(kind,False)):
        pause_boundary(); return {'action':'continue'}
    key=uuid.uuid4().hex
    _write('review.json', {'id':key,'kind':kind,'title':title,'payload':payload or {},'allow_revise':allow_revise,'allow_redo':kind=='content' or bool(allow_redo),'at':time.time()})
    ans=DIR/'answers'/f'{key}.json'
    while True:
        raise_if_stopped()
        if (DIR/'suspend.request').exists():
            _write('suspended.json', {'at': time.time()})
            raise StudioSuspend()
        if ans.is_file():
            item=json.loads(ans.read_text(encoding='utf-8'))
            ans.unlink(missing_ok=True); (DIR/'review.json').unlink(missing_ok=True)
            _event('decision',title,detail=str(item.get('feedback') or '')[:400],action=str(item.get('action') or 'continue'),key=kind)
            return item
        time.sleep(.2)

def snapshot_clip(project_dir, clip_num, info):
    if not DIR: return
    state=project_dir/'_studio'
    state.mkdir(parents=True,exist_ok=True)
    clips=state/'clips.json'
    try: data=json.loads(clips.read_text(encoding='utf-8'))
    except (OSError, ValueError): data={'clips':{}}
    data.setdefault('clips',{})[f'{clip_num:04d}']=info
    tmp=clips.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(tmp,clips)
    _write('active_project.json', {'path':str(project_dir),'name':project_dir.name})


class StudioSuspend(BaseException):
    """Cooperative stop only at safe boundaries, never while H3 is sampling."""


def save_resume_state(project_dir, info):
    if not DIR: return
    p=Path(project_dir)/'_studio'/'resume_state.json'
    p.parent.mkdir(parents=True,exist_ok=True)
    data=dict(info)
    data['updated']=time.time();data['completed']=False
    tmp=p.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(tmp,p)


def load_resume_state(project_dir):
    p=Path(project_dir)/'_studio'/'resume_state.json'
    return json.loads(p.read_text(encoding='utf-8'))


def mark_completed(project_dir):
    if not DIR:return
    info=load_resume_state(project_dir)
    info['completed']=True
    _path=Path(project_dir)/'_studio'/'resume_state.json'
    tmp=_path.with_suffix('.tmp')
    tmp.write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(tmp,_path)
