"""Isolated RAW H3 39-frame windows for long insertion edits.

The original clip/latents are read-only. New 39-frame AV payloads are stored under
unique temporary names and can be removed when the job finishes.
"""
from __future__ import annotations
from pathlib import Path
import torch
import copy
import subprocess
import shutil

WINDOW_LATENT_T=12 # 39 frames: 5 + (12-2)*17/5
WINDOW_FRAMES=39
FPS=24


def _video_members(saved):
    if not isinstance(saved,dict) or 'samples' not in saved:raise ValueError('Latent H3 RAW non chargé')
    members=(saved['samples'] or {}).get('members') or []
    if len(members)<2:raise ValueError('RAW vidéo/audio absent')
    v,a=members[0].get('tensor'),members[1].get('tensor')
    if not isinstance(v,torch.Tensor) or v.ndim!=5 or not isinstance(a,torch.Tensor) or a.ndim!=4:
        raise ValueError('Structure RAW H3 vidéo/audio incompatible')
    return members,v,a


def plan_windows(latent_t:int):
    if latent_t<WINDOW_LATENT_T:raise ValueError('RAW trop court pour découpage 39 images')
    stride=10
    starts=list(range(0,latent_t-WINDOW_LATENT_T+1,stride))
    last=latent_t-WINDOW_LATENT_T
    if starts[-1]!=last:starts.append(last)
    return starts


def latent_start_to_frame(index:int)->int:
    return round(index*17/5)


def cut_points(starts:list[int],source_frames:int):
    if not starts:raise ValueError('Aucune fenêtre RAW')
    origins=[latent_start_to_frame(x) for x in starts]
    ends=[x+WINDOW_FRAMES for x in origins]
    cuts=[0]
    for ix in range(len(starts)-1):
        overlap_start=origins[ix+1]; overlap_end=ends[ix]
        if overlap_end<=overlap_start:raise ValueError('Fenêtres RAW sans chevauchement')
        cuts.append((overlap_start+overlap_end)//2)
    cuts.append(source_frames)
    for a,b in zip(cuts,cuts[1:]):
        if b<=a:raise ValueError('Découpage RAW non croissant')
    return [(cuts[i]-origins[i],cuts[i+1]-origins[i]) for i in range(len(starts))]


def write_window(saved:dict,latent_path:Path,latent_name:str,start_latent:int):
    members,video,audio=_video_members(saved)
    total_t=int(video.shape[2]);first=int(start_latent)
    if first<0 or first+WINDOW_LATENT_T>total_t:raise ValueError('Fenêtre RAW hors clip')
    orig_frames=round(5+17*(total_t-2)/5)
    audio_size=int(audio.shape[-1])
    first_frame=latent_start_to_frame(first)
    audio_first=round(audio_size*first_frame/max(1,orig_frames))
    audio_frames=max(1,round(audio_size*WINDOW_FRAMES/max(1,orig_frames)))
    audio_first=min(audio_first,max(0,audio_size-audio_frames))
    v=video[:,:,first:first+WINDOW_LATENT_T,:,:].contiguous()
    a=audio[...,audio_first:audio_first+audio_frames].contiguous()
    out=copy.copy(saved)
    pack=dict(saved['samples'])
    parts=[dict(x) for x in members]
    parts[0].update(tensor=v,shape=tuple(v.shape),device='cpu')
    parts[1].update(tensor=a,shape=tuple(a.shape),device='cpu')
    pack['members']=parts
    out.update(samples=pack,noise_mask=None)
    dest=latent_path.with_name(latent_name+'.pt')
    torch.save(out,dest)
    return dest


def local_interval(start:float,end:float,window_start_latent:int):
    offset=latent_start_to_frame(window_start_latent)/FPS
    duration=WINDOW_FRAMES/FPS
    a=max(0.,min(duration,start-offset));b=max(0.,min(duration,end-offset))
    if b<=a: # Keep a valid zero-change mask at outside boundaries.
        return (max(0.,min(duration-0.02,a)), max(0.02,min(duration,a+0.02)),False)
    return (a,b,True)


def stitch_windows(videos:list[Path|None], starts:list[int], source:Path, target:Path, frames:int, comfy:Path):
    if not len(videos)==len(starts) or not videos:raise ValueError('Morceaux RAW incomplets')
    trims=cut_points(starts,frames)
    ffmpeg=shutil.which('ffmpeg') or str(comfy.parent/'ffmpeg'/'bin'/'ffmpeg.exe')
    cmd=[ffmpeg,'-hide_banner','-loglevel','error','-y']
    source_index=0
    for video in videos:
        if video is not None:
            cmd+=['-i',str(video)]
            source_index+=1
    cmd+=['-i',str(source)]
    filters=[]
    clip_index=0
    origins=[latent_start_to_frame(x) for x in starts]
    for i,(a,b) in enumerate(trims):
        if not 0<=a<b<=WINDOW_FRAMES:raise ValueError(f'Fenêtre RAW {i} incohérente: {a}:{b}')
        if videos[i] is None:
            source_stream=source_index
            first_frame=origins[i]+a; last_frame=origins[i]+b
        else:
            source_stream=clip_index;clip_index+=1
            first_frame=a;last_frame=b
        filters.append(f'[{source_stream}:v]trim=start_frame={first_frame}:end_frame={last_frame},setpts=PTS-STARTPTS[v{i}]')
    filters.append(''.join(f'[v{i}]' for i in range(len(videos)))+f'concat=n={len(videos)}:v=1:a=0[outv]')
    cmd+=['-filter_complex',';'.join(filters),'-map','[outv]', '-map',f'{source_index}:a:0?',
          '-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p',
          '-c:a','aac','-ar','44100','-t',str(frames/FPS),str(target)]
    proc=subprocess.run(cmd,capture_output=True,text=True,timeout=360)
    if proc.returncode or not target.is_file():raise RuntimeError('Assemblage fenêtres RAW : '+proc.stderr[-900:])
    return target
