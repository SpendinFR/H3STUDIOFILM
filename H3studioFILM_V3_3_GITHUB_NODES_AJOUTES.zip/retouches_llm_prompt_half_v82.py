"""V10.82 local prompt writer: half-clip local retake with local timing from 0.000s."""
from __future__ import annotations
import re
import retouches_llm_prompt_v74 as inherited

SYSTEM="""You are the MiniMax H3 HALF-CLIP local RETAKE DIRECTOR.
You write ONLY the isolated local segment that H3 will generate.
The local world ALWAYS starts at 0.000s. Never write global clip timestamps inside [Shot] headers.
Never rewrite the full clip. Use the original scenario excerpt only as continuity context.

Your job:
- Write ONLY the local generated segment.
- The requested action must happen inside the local ACTION [Shot].
- TRANSITION BEFORE and/or TRANSITION AFTER may exist as separate short [Shot]s if the exact beat grid provides them.
- Each [Shot] header MUST use the exact local times given by the beat grid.
- The segment must end at the local segment duration and must not continue beyond it.
- The output is in French.

OUTPUT ONLY:
SCENE_CONTEXT: 1-2 short French sentences about the visible scene.
NEW_TAKE:
[Shot 1] <exact local time> <visible action>
..."""


def _grid(window:dict)->list[tuple[str,float,float]]:
    frames=int(window['frames'])
    duration=frames/24.0
    a=int(window['local_first']); b=int(window['local_last'])
    if not 0<=a<b<=frames:
        raise ValueError('Fenêtre locale demi-clip invalide')
    out=[]
    if a>=3:
        out.append(('TRANSITION AVANT',0,a/24.0))
    out.append(('ACTION',(a/24.0 if a>=3 else 0.0),(b/24.0 if frames-b>=3 else duration)))
    if frames-b>=3:
        out.append(('TRANSITION APRÈS',b/24.0,duration))
    return out


def _source_excerpt(source_prompt:str,window:dict)->tuple[str,str]:
    source=source_prompt or ''
    headers=list(inherited.SHOT_HEADER.finditer(source))
    if not headers:
        return source[:3200] or '(source scenario unavailable)', ''
    lo=float(window['global_offset']); hi=lo+float(window['duration'])
    parts=[]; future=[]
    for i,h in enumerate(headers):
        a,b=inherited._seconds(h.group(2)),inherited._seconds(h.group(3))
        body=source[h.end(): headers[i+1].start() if i+1<len(headers) else len(source)].strip()
        if b>lo-0.03 and a<hi+0.03:
            parts.append(f'Original [Shot {h.group(1)}] {a:.3f}–{b:.3f}s : {body[:1450]}')
        if b>hi+0.04:
            future.append(b)
        if a>hi+0.04:
            future.append(a)
    nearest=min(future) if future else None
    anchor=(f'Prochain repère original après ce segment : {nearest:.3f}s. '
            'Le mouvement local peut y mener, mais ces secondes ne seront PAS générées.' if nearest is not None else
            'La suite originale commence immédiatement après cette portion.')
    return '\n'.join(parts)[:4100] or source[:2600], anchor


def _instruction(*,request:str,source_prompt:str,window:dict)->str:
    schedule=_grid(window)
    material,anchor=_source_excerpt(source_prompt,window)
    lines=[f'[Shot {idx}] {a:.3f}–{b:.3f}s — {role}' for idx,(role,a,b) in enumerate(schedule,1)]
    return ('USER CHANGE: '+str(request).strip()+'\n'
            f'LOCAL SOURCE WINDOW IN THE ORIGINAL CLIP: {float(window["global_offset"]):.3f}–{float(window["global_offset"])+float(window["duration"]):.3f}s.\n'
            f'USER EDIT TIME INSIDE THIS LOCAL WINDOW: {float(window["start"]):.3f}–{float(window["end"]):.3f}s.\n'
            'IMPORTANT: In your OUTPUT [Shot] headers, local time starts at 0.000s for this generated segment. Never use global clip times there.\n'
            'EXACT LOCAL BEAT GRID — reproduce each as its own [Shot], with no extra shots:\n'
            + '\n'.join(lines)+'\n'
            'The ACTION [Shot] must contain the requested visible action. Transitions, if present, are short preparation or release beats only.\n'
            'SOURCE EXCERPT — continuity context only, not a script to replay:\n'+material+'\n'
            'CONTINUITY TARGET: '+anchor+'\n'
            'Return only SCENE_CONTEXT and NEW_TAKE with the EXACT local beat grid above.')


def _extract(output:str,window:dict)->tuple[str,str]:
    src=inherited._strip_fences(output)
    m=re.search(r'(?im)^\s*(?:\*\*)?SCENE_CONTEXT\s*:\s*(?:\*\*)?',src)
    n=re.search(r'(?im)^\s*(?:\*\*)?NEW_TAKE\s*:\s*(?:\*\*)?',src)
    if not m or not n or n.start()<m.end():
        raise RuntimeError('Gemma demi-clip : SCENE_CONTEXT ou NEW_TAKE absent')
    context=re.sub(r'\s+',' ',src[m.end():n.start()]).strip()
    if not 15<=len(context)<=600 or '[Shot' in context or '<d>' in context.lower():
        raise RuntimeError('Gemma demi-clip : SCENE_CONTEXT invalide')
    text=src[n.end():].strip()
    headers=list(inherited.SHOT_HEADER.finditer(text))
    all_shots=list(inherited.SHOT_RE.finditer(text))
    schedule=_grid(window)
    if len(headers)!=len(schedule) or len(all_shots)!=len(schedule):
        raise RuntimeError(f'Gemma demi-clip : attendu {len(schedule)} shots, reçu {len(all_shots)}')
    pieces=[]
    for i,(_,first,last) in enumerate(schedule):
        h=headers[i]
        if int(h.group(1))!=i+1:
            raise RuntimeError('Gemma demi-clip : numérotation incorrecte')
        a,b=inherited._seconds(h.group(2)),inherited._seconds(h.group(3))
        if abs(a-first)>.045 or abs(b-last)>.045:
            raise RuntimeError(f'Gemma demi-clip : Shot {i+1} hors grille ({a:.3f}–{b:.3f}s au lieu de {first:.3f}–{last:.3f}s)')
        body=text[h.end():headers[i+1].start() if i+1<len(headers) else len(text)].strip()
        if not body or len(body)<14:
            raise RuntimeError(f'Gemma demi-clip : Shot {i+1} vide')
        body=re.sub(r'(?i)(Pendant\s+[\d:.,]+\s*[-–—]\s*[\d:.,]+s?\s*:\s*)\1+',r'\1',body)
        pieces.append(f'[Shot {i+1}] {first:.3f}–{last:.3f}s {body}')
    return context,'\n'.join(pieces)


def _assemble(context:str,shots:str,window:dict)->str:
    dur=float(window['duration'])
    offset=float(window['global_offset'])
    return ('<Video 1> = REAL SOURCE VIDEO, isolated HALF-CLIP visual reference. '
            'Same person, face, wardrobe, room, lighting and camera. Reference the visuals, NOT the original performance as a script.\n'
            'SCENE CONTEXT (local only): '+context+'\n'
            'NEW TAKE — ONLY THE LOCAL HALF-CLIP SHOTS TO GENERATE:\n'+shots+'\n'
            f'LOCAL TAKE: exactly {dur:.3f}s, from original {offset:.3f}–{offset+dur:.3f}s. '
            f'Action assigned within the local take at {float(window["start"]):.3f}–{float(window["end"]):.3f}s. '
            'Distinct [Shot]s are continuous motion beats, never camera cuts. '
            'Do not generate beyond the local take duration. Preserve visual identity and physical continuity.')


def write_prompt(*,mode,performance_type,request,source_prompt,window,gpu_prepare):
    if mode!='precise':
        raise ValueError('Gemma demi-clip V10.82 réservé au Retake précis')
    import h3film_studio_v3 as film
    gpu_prepare()
    backend=inherited.choose_backend(film)
    try:
        instruction=_instruction(request=request,source_prompt=source_prompt,window=window)
        for attempt in range(2):
            output=film.director_text(backend,SYSTEM,instruction,
                                      label='RETOUCH HALF-CLIP GEMMA 26B / OLLAMA',num_ctx=16384,num_predict=1700)
            try:
                context,shots=_extract(output,window)
                assembled=_assemble(context,shots,window)
                # Already enforced downstream, but downstream errors cannot
                # retry: include this very same check within Gemma's two tries.
                from retouches_precise_center_v90 import verify_gemma_descriptions
                verify_gemma_descriptions(assembled)
                return assembled, 'gemma4:26b-a4b-it-q4_K_M + Retake HALF-CLIP V10.82'
            except RuntimeError as exc:
                if attempt:
                    raise
                if str(exc).startswith('Gemma : Shot sans description de mouvement'):
                    instruction += '\nRefais : chaque [Shot] doit décrire un mouvement visible.'
                else:
                    instruction += ('\nCORRECTION OBLIGATOIRE: respecte exactement la grille locale. '
                                    'Les [Shot] headers doivent commencer à 0.000s local et rester dans cette portion uniquement.\n'
                                    'Erreur précédente : '+str(exc))
    finally:
        try:
            film.unload_text_backend(backend)
        except Exception:
            pass
