"""V10.72 timeline-bound prompt + short scene context: short scene context + NEW TAKE, no source script: reuses FilmMaker's established LLM
loading, chat and unloading functions. H3's original RAW video/latent (not this
text) is the visual reference. This module never runs pip or installs models.
"""
from __future__ import annotations
import os
import re
import shutil
import subprocess
import time
from pathlib import Path

SYSTEM = """You are the shot director rewriting a COMPLETE existing MiniMax H3 clip.
You have the FULL ORIGINAL H3 PROMPT and a USER CHANGE. The real footage is
provided to the VIDEO GENERATOR as <Video 1> (you do not see frames yourself).
Your task is to author a NEW complete shot-by-shot prompt, not summarize the
existing one or append a little phrase inside an unchanged old shot.

INTERPRET THE USER REQUEST CORRECTLY:
- ADD / 'ajoute' / default non-destructive change: the NEW action must happen
  IN ADDITION TO the ORIGINAL actions. Make it simultaneous / overlapping with
  the filmed performance WHEN PHYSICALLY POSSIBLE (e.g. she looks into the camera
  WHILE raising her arm). Keep the original laughter, dialogue, interaction,
  camera movement and actions. Do not automatically move the new action into
  a separate earlier or later shot. Re-time, merge or split beats only when
  continuity requires it. Do not secretly delete an original beat to make room.
- REPLACE / 'remplace' / 'au lieu de': remove ONLY the specific targeted action
  and write its replacement in the same narrative context. Keep all unaffected
  original events. If intent is ambiguous, prefer additive rather than destructive.
- EMOTION: layer the new emotional acting on the existing action/dialogue,
  unless the user explicitly requests replacement.
- The ORIGINAL PROMPT may ALREADY MENTION the desired gesture (e.g. raising
  the right hand). That historical phrase is NOT proof you created a NEW
  requested change. Rewrite the target beat so the new performance is visibly
  distinguishable, e.g. a clear raised arm maintained while she continues her
  original address to camera; retain the original action too. Do not merely
  paste or re-label an old sentence as the new action.

TIMELINE CONTRACT — MANDATORY, NOT OPTIONAL:
- The USER EDIT WINDOW is an exact interval [start, end] supplied in the request.
  If it is a PARTIAL interval, create shot/beat boundaries at EXACTLY its start
  and end, even if these split an original shot. A [Shot N] here is a continuous
  chronological BEAT, NOT necessarily a camera cut. Do not invent CUTs.
- The REQUESTED NEW ACTION or EMOTION happens ONLY inside that interval, visibly,
  with its start and finish and physical return inside the interval.
  Outside, continue the original scene and dialogue exactly as possible.
- If the new action can overlap the original laugh, gesture or speech, show both
  SIMULTANEOUSLY. Never silently replace an original action unless asked.
- Every [Shot N] MUST have explicit numeric START–END timestamps in seconds,
  with at most 3 decimals, continuous from 0.000s to full clip duration.
  For a window 0.000–1.293s in a 5.167s clip, the relevant beat ends at 1.293s,
  not at an old shot boundary of 2.500s. Renumber shots if you split them.
- If a selected interval is too short for a large motion, make the most plausible
  short motion possible; never move the requested edit outside the interval.

SHOT AUTHORING:
- Return ONLY a NEW, FULL MiniMax H3 prompt, with [Shot 1], [Shot 2] ... in
  chronological order, each with realistic timestamp ranges covering the
  original clip duration. YOU MAY change shot COUNT, boundaries and numbering
  to incorporate the request: an original [Shot 2] may become [Shot 3], or the
  new motion may occur DURING an existing shot. Never add a needless camera cut.
  '[Shot N]' can designate consecutive chronological beats of a continuous
  camera take, without a hard cut.
- Show the new behavior through observable body mechanics, spatial relations,
  gaze, actual hand/arm trajectories, reaction timing, and interactions.
  Include sensible transitions into and out of the added or replaced beat,
  reconnecting to the original action at the end of the editable time window.
  If the window is the entire clip, you may adapt the whole sequence instead.
- Preserve the same actor, identities, costumes, spatial setting, camera,
  soundscape, original spoken <d> tags / language and physical continuity
  unless explicitly changed. Preserve all original concurrent events where
  physically possible. Do not duplicate conflicting dialogue.
- The NEW shot script is the authority for the retake. The old prompt is only
  the blueprint from which to preserve unaffected beats. <Video 1> represents
  the source imagery in H3; never assert you have inspected unseen footage.
- Output EXACTLY TWO labeled sections, both in FRENCH:
  SCENE_CONTEXT: 1-3 short sentences (MAXIMUM 500 characters) describing ONLY
  identity, place, costume, background, camera, light, sound of <Video 1>.
  NO chronology, no plot beats, no old [Shot] text, no restatement of the user's
  requested motion. This context is forwarded to H3 instead of the old prompt.
  NEW_TAKE: your NEW complete H3 [Shot 1], [Shot 2]... script with revised
  timings, original concurrent actions, physical transitions, original dialogue.
- No separate comparison, no original script repeated, no explanations or JSON.
- A successful retake must make the requested additional action VISIBLY NEW,
  not recycle a sentence from the original prompt.
"""


def ensure_ollama_running(film, *, timeout=28.0):
    """Use the same `ollama serve` startup method as FilmMaker's PowerShell.

    Does NOT install software, pull a model, change CUDA, or replace Python.
    Leaves the daemon running just like FilmMaker. The specific Gemma model is
    explicitly unloaded by FilmMaker after writing the prompt.
    """
    url = film.rt.OLLAMA_URL + '/api/tags'
    try:
        return film.rt.http_json(url, timeout=3)
    except Exception as exc:
        start_exc = exc
    exe=shutil.which('ollama.exe') or shutil.which('ollama')
    if not exe and os.name=='nt':
        candidates=[Path(os.environ.get('LOCALAPPDATA',''))/'Programs'/'Ollama'/'ollama.exe',
                    Path(os.environ.get('PROGRAMFILES','C:/Program Files'))/'Ollama'/'ollama.exe']
        exe=next((str(p) for p in candidates if p.is_file()),None)
    if not exe:
        raise RuntimeError('Retouches : Ollama est indisponible : ollama.exe introuvable. '
                           'Aucun modèle ni logiciel ne sera installé.') from start_exc
    kwargs={'stdin':subprocess.DEVNULL,'stdout':subprocess.DEVNULL,
            'stderr':subprocess.DEVNULL,'cwd':str(Path(exe).resolve().parent)}
    if os.name=='nt':
        kwargs['creationflags']=getattr(subprocess,'CREATE_NO_WINDOW',0)
    print('[RETOUCHES] Ollama arrêté : lancement automatique de ollama serve...',flush=True)
    try:
        proc=subprocess.Popen([exe,'serve'],**kwargs)
    except OSError as exc:
        raise RuntimeError('Impossible de lancer Ollama automatiquement : '+str(exc)) from exc
    end=time.monotonic()+float(timeout)
    last=None
    while time.monotonic()<end:
        try:
            tags=film.rt.http_json(url,timeout=3)
            print('[RETOUCHES] Ollama prêt, modèle non encore chargé.',flush=True)
            return tags
        except Exception as exc:
            last=exc
        if proc.poll() is not None:
            # It can exit because an existing Ollama instance took the port.
            # Try one more time; never terminate external processes.
            try:return film.rt.http_json(url,timeout=3)
            except Exception:break
        time.sleep(1)
    raise RuntimeError('Ollama ne répond pas après démarrage automatique : '
                       +str(last or 'processus terminé'))


def choose_backend(film):
    """Select ONLY the pre-installed Gemma 4 26B in Ollama (FilmMaker backend).

    Never fallback to Qwen3.8 27B / llama-server; no installation or download.
    Fail closed if Ollama or Gemma 26B is unavailable.
    """
    # The FilmMaker's actual model naming from select_text_backend():
    #   gemma4:26b-a4b-it-q4_K_M
    tags = ensure_ollama_running(film)
    names = film.installed_model_names(tags)
    # Prefer the exact GGUF/quant used by the existing Film Studio; accept
    # alternate 26B tags if a compatible variant is already installed.
    preferred = 'gemma4:26b-a4b-it-q4_k_m'
    model = next((n for n in names if n.casefold() == preferred), None)
    if model is None:
        model = next((n for n in names if n.casefold().startswith('gemma4:26b')), None)
    if not model:
        raise RuntimeError(
            'Retouches : Gemma 4 26B Ollama introuvable. '
            'Modele attendu : gemma4:26b-a4b-it-q4_K_M. '
            'Modeles Ollama presents : ' + (', '.join(names) or '(aucun)') + '. '
            'Qwen 27B interdit pour ce mode, rien ne sera telecharge.'
        )
    backend = film._ollama_backend(model)
    if backend.get('provider') != 'ollama':
        raise RuntimeError('Retouches : backend Ollama attendu, generation annulee.')
    print('[RETOUCHES] Modele de prompt : ' + model + ' | Ollama | PAS de Qwen 27B', flush=True)
    return backend


# ``[Shot N]`` is H3's real authoring format. Do not manufacture shot cuts.
SHOT_RE = re.compile(r"\[Shot\s+(\d+)\]", re.IGNORECASE)
# Timestamp grammar: 0.000, 0, 0:02.500, French commas; range dash/en-dash.
_TIME = r'(?:\d+:)?\d+(?:[.,]\d+)?'
SHOT_HEADER = re.compile(r'\[Shot\s+(\d+)\]\s*\*{0,2}\s*('
                         + _TIME + r')\s*(?:s\b)?\s*[-–—]\s*('
                         + _TIME + r')\s*(?:s\b)?', re.I)


def _seconds(stamp: str) -> float:
    stamp=stamp.strip().replace(',', '.')
    if ':' in stamp:
        mins,sec=stamp.split(':',1)
        return int(mins)*60+float(sec)
    return float(stamp)


def validate_edit_timeline(shot_text: str,start:float,end:float,duration:float) -> list[tuple[float,float]]:
    """Fail BEFORE H3 if Gemma misplaced a selected retake interval.

    A beat boundary is not a hard scene CUT: it represents physical choreography
    while H3 remains free to keep the original continuous camera movement.
    The semantic correctness of the new action is not provable from timestamps.
    """
    headers=list(SHOT_HEADER.finditer(shot_text))
    all_shots=list(SHOT_RE.finditer(shot_text))
    if len(headers)!=len(all_shots) or not headers:
        raise RuntimeError('Gemma : chaque [Shot N] doit porter son intervalle précis, ex. [Shot 1] 0.000–1.293s')
    intervals=[]
    tolerance=0.075  # approx 2 frames at 24fps; no invented shifts of seconds
    for i,m in enumerate(headers,1):
        if int(m.group(1))!=i:
            raise RuntimeError('Gemma : numérotation des shots non consécutive')
        a,b=_seconds(m.group(2)),_seconds(m.group(3))
        if not (0 <= a < b <= duration+tolerance):
            raise RuntimeError(f'Gemma : intervalle du Shot {i} invalide : {a}–{b}s')
        if intervals and abs(a-intervals[-1][1])>tolerance:
            raise RuntimeError(f'Gemma : trou ou chevauchement entre Shot {i-1} et Shot {i}')
        intervals.append((a,b))
    if abs(intervals[0][0])>tolerance or abs(intervals[-1][1]-duration)>tolerance:
        raise RuntimeError('Gemma : la nouvelle timeline ne couvre pas précisément toute la vidéo')
    boundaries=[a for a,b in intervals]+[intervals[-1][1]]
    for label,value in [('début',start),('fin',end)]:
        # clip extremities are already part of the complete timeline
        if min(abs(value),abs(value-duration)) <= tolerance:
            continue
        if not any(abs(v-value)<=tolerance for v in boundaries):
            raise RuntimeError('Gemma : '+label+' de la fenêtre sélectionnée ('
                +f'{value:.3f}s) non respecté dans les bornes des [Shot]. '
                 'Scinde le shot au bon moment sans créer de coupe caméra.')
    return intervals



def original_shots(source_prompt: str) -> list[int]:
    identifiers = [int(m.group(1)) for m in SHOT_RE.finditer(source_prompt or '')]
    # Some approved clips have no explicit markers; they are one continuous shot.
    return list(dict.fromkeys(identifiers)) or [1]


def requested_operation(request: str) -> str:
    """Only explicitly destructive wording warrants removing an original action."""
    text = ' '.join(str(request).casefold().split())
    # Explicit replacement remains valid for precision retake too, regardless
    # of whether the UI button says Action, Emotion or Retake.
    if re.search(r'\b(remplace[rz]?|remplacement|supprime[rz]?|retire[rz]?|efface[rz]?|au lieu de|instead of|replace|remove|delete)\b', text):
        return 'replace'
    return 'add'


def build_request(mode,performance_type,request,source_prompt,start,end,duration):
    kind = 'Retake précis' if mode=='precise' else ('Performance Action' if performance_type=='action' else 'Performance Émotion')
    original=(source_prompt or '').strip() or '(Le prompt original du clip est absent. Référence visuelle: <Video 1>. Ne prétends pas connaître les actions inconnues.)'
    operation=requested_operation(request)
    semantics = (
        'ADDITION / SUPERPOSITION: maintenir et faire coexister les actions et dialogues originaux; le geste demandé peut se produire EN MEME TEMPS. ' 
        'Adapte les bornes et les shots sans sacrifier des actions existantes.'
        if operation=='add' else
        'REMPLACEMENT EXPLICITE: ne retirer QUE le comportement ciblé, préserver toutes les autres actions.'
    )
    limit=('La fenêtre explicitement modifiable vaut '+f'{start:.3f}–{end:.3f}s. '           +'Toutes les actions hors de la fenêtre doivent rester identiques au clip source. '
           +'Intègre gestes et transitions dans la fenêtre, sans modifier la durée totale. '
           if start>.001 or end<duration-.015 else
           'La prise entière est modifiable pour réorganiser les beats sans changer la durée totale. ')
    return (
        'Tu prépares une NOUVELLE PRISE COMPLETE H3 basée sur une vidéo existante.\n'
        'La vidéo VRAIE à modifier est raccordée à H3 sous <Video 1>. '
        'Elle a été créée à partir du PROMPT ORIGINAL fourni plus bas. '
        'Le texte source est un historique, non une preuve que toutes ses actions furent visiblement réalisées.\n'
        f'MODE: {kind}\n'
        f'OPERATION: {operation.upper()} — {semantics}\n'
        f'CONSIGNE EXACTE UTILISATEUR: {request.strip()}\n'
        f'DUREE TOTALE: 0.000–{duration:.3f}s, vidéo H3 entière de même durée.\n'
        f'ZONE TEMPORELLE DU CHANGEMENT: {start:.3f}–{end:.3f}s. {limit}\n'
        'CONTRAINTE STRICTE DE TIMELINE : les bornes de la zone modifiable '
        f'sont {start:.3f}s et {end:.3f}s. Si elles tombent AU MILIEU des shots '
        'originaux, SCINDE ces shots en beats consécutifs aux bornes EXACTES; '
        'renumérote-les, sans CUT caméra inventé. Le geste/émotion ajouté(e) '
        'et son retour physique doivent être intégralement dans la zone '
        'choisie. Ne laisse surtout pas la nouvelle action non localisée '
        'dans un grand shot qui dépasse cette zone. Exemple: si 0–1.293s '
        'est sélectionné dans [Shot 1] 0–2.5s, écris un nouveau [Shot 1] '
        '0–1.293s avec le changement, puis [Shot 2] 1.293–2.5s pour la '
        'continuation. Même principe pour les bornes intérieures. '
        'Chaque [Shot N] doit posséder un début ET une fin numérique en secondes. '
        'Tous les shots couvrent 0–durée totale sans trou ni chevauchement.\n'
        'REECRIS TOUTE LA TIMELINE. Tu peux ajouter un nouveau [Shot N], scinder '
        'un shot, fusionner deux beats, ou superposer le nouveau geste à une '
        'action existante. Réattribue les numéros [Shot 1], [Shot 2], etc. '
        'et les timings sur l’ensemble de la durée, dans l’ordre. '
        'La nouvelle action doit être VISIBLE et CONCRETE, pas seulement citée. '
        'Prévois une transition physique cohérente avant et après. '
        'Si le geste demandé existe déjà en texte dans le PROMPT ORIGINAL, '
        'ne le recopie pas comme s’il était nouveau: intègre une réalisation '
        'visuellement distincte qui satisfera la nouvelle consigne. '
        'Ne transforme pas une ADDITION en remplacement automatique.\n'
        'PROMPT ORIGINAL COMPLET — SCRIPT HISTORIQUE DU <Video 1> :\n'
        +original+'\n\n'
        'RENVOIE UNIQUEMENT SCENE_CONTEXT: (resume global court, aucun ancien shot) '
        'puis NEW_TAKE: suivi de [Shot 1], [Shot 2] ... avec timings réadaptés. Aucun commentaire.'
    )


def _normalise(value):
    return re.sub(r'\s+',' ',str(value or '')).strip().casefold()


def _fallback_scene_context(source_prompt: str) -> str:
    """Safe minimal context when Gemma omits the header; NEVER pass old shots.

    Only take environment/look/sound fields from the source authoring text.
    Narrative chronology from the original shots is deliberately excluded.
    """
    original=str(source_prompt or '')
    snippets=[]
    for pattern in (
        r'(?im)^\*\*World ambience[^\n]*?:\*\*\s*([^\n]+)',
        r'(?im)^\*\*look_cam[ée]ra_et_lumi[èe]re\s*:\*\*\s*([^\n]+)',
        r'(?im)^\*\*soundscape_global\s*:\*\*\s*([^\n]+)',
    ):
        m=re.search(pattern,original)
        if m:
            val=m.group(1).strip()
            # No [Shot] header, no dialogue. Skip any accidental instruction.
            val=re.sub(r'<d>.*?</d>','',val,flags=re.I)
            if '[Shot' not in val:
                snippets.append(val)
    if not snippets:
        return ('Mêmes personnages, identité visuelle, lieu, accessoires, éclairage, '
                'cadrage et ambiance sonore que la vidéo de référence <Video 1>.')
    text=' '.join(snippets)
    if len(text)>500:
        text=text[:497].rsplit(' ',1)[0]+'...'
    return text


def _strip_fences(value):
    return re.sub(r'^```(?:[\w-]+)?\s*|\s*```$', '', str(value or '').strip()).strip()


def _split_scene_and_new_take(result,source_prompt):
    """Prefer Gemma's two sections; accept ordinary [Shot 1] output safely.

    The H3-facing prompt contains *exactly one* new shot sequence. The original
    prompt remains available to Gemma only, never to H3.
    """
    text=_strip_fences(result)
    header_context=re.search(r'(?im)^\s*(?:#{1,4}\s*)?(?:\*\*)?SCENE_CONTEXT\s*:\s*(?:\*\*)?\s*',text)
    header_take=re.search(r'(?im)^\s*(?:#{1,4}\s*)?(?:\*\*)?NEW_TAKE\s*:\s*(?:\*\*)?\s*',text)
    first_shot=SHOT_RE.search(text)
    if not first_shot:
        raise RuntimeError('Gemma Retake : aucune nouvelle timeline [Shot 1] produite ; H3 non lancé')
    if header_take and header_take.start()<first_shot.start():
        script=text[header_take.end():].strip()
    else:
        script=text[first_shot.start():].strip()
    context=None
    if header_context and header_context.end()<first_shot.start():
        ctx_end=header_take.start() if header_take and header_take.start()>header_context.end() else first_shot.start()
        context=text[header_context.end():ctx_end].strip()
    if not context:
        context=_fallback_scene_context(source_prompt)
    # A scene summary may never contain original shot actions, dialogue or
    # chronology. Fail closed if Gemma ignored the required context format.
    if SHOT_RE.search(context) or '<d>' in context.lower():
        context=_fallback_scene_context(source_prompt)
    context=re.sub(r'\s+',' ',context).strip()[:500]
    return context,script


def assemble(original_request,result,start,end,duration,source_prompt=''):
    """V10.71 H3-facing prompt: visual reference + SHORT scene + ONE new script.

    The detailed original prompt is used to instruct Gemma, *not* H3.
    Nothing here changes ComfyUI's RAW mask, denoise, video ref or sampler.
    """
    summary,new_shots=_split_scene_and_new_take(result,source_prompt)
    if len(new_shots)<80 or len(new_shots)>14000:
        raise RuntimeError('Gemma Retake : nouvelle timeline trop courte/longue ; H3 non lancé')
    shot_ids=[int(m.group(1)) for m in SHOT_RE.finditer(new_shots)]
    if shot_ids!=list(range(1,len(shot_ids)+1)):
        raise RuntimeError('Gemma Retake : shots non consécutifs [Shot 1], [Shot 2]... H3 non lancé')
    original=(source_prompt or '').strip()
    validate_edit_timeline(new_shots,start,end,duration)
    if original and _normalise(new_shots)==_normalise(original):
        raise RuntimeError('Gemma a renvoyé le script original inchangé : H3 non lancé')
    return (
        '<Video 1> = REAL SOURCE VIDEO. Visual reference for the same people, faces, '
        'wardrobe, room, lighting, camera and ambient sound. The video is the '
        'reference, not an extra written script to replay.\n'
        'SCENE CONTEXT (short visual description, no original timeline):\n'
        +summary+'\n\n'
        'NEW TAKE — THIS IS THE ONLY SHOT SCRIPT TO GENERATE:\n'
        +new_shots+'\n'
        f'Preserve total duration {duration:.3f}s, with requested edit interval '
        f'{start:.3f}–{end:.3f}s. Keep unaffected actions and dialogue. '
        'Use the real <Video 1> for continuity, with physically plausible motions and transitions.'
    )


def write_prompt(*,mode,performance_type,request,source_prompt,start,end,duration,gpu_prepare):
    if mode!='precise' and (mode!='performance' or performance_type not in ('action','emotion')):
        raise ValueError('Retake LLM réservé aux retouches visuelles, pas au dialogue')
    if not(0<=start<end<=duration+.03):raise ValueError('Intervalle retake invalide')
    import h3film_studio_v3 as film  # reuse *existing* FilmMaker LLM backend
    gpu_prepare()                     # release H3 memory before loading Gemma 4 26B
    backend=choose_backend(film)
    output=None
    try:
        instruction=build_request(mode,performance_type,request,source_prompt,start,end,duration)
        for attempt in range(2):
            output=film.director_text(backend,SYSTEM,instruction,
                                     label='RETOUCH DIRECTOR GEMMA 4 26B / OLLAMA',num_ctx=16384,num_predict=2000)
            try:
                final=assemble(request,output,start,end,duration,source_prompt)
                break
            except RuntimeError as exc:
                if attempt:
                    raise RuntimeError('Gemma : seconde tentative également invalide. '+str(exc)) from exc
                # One correction in same loaded LLM session, BEFORE any H3 work.
                instruction += ('\n\nCORRECTION OBLIGATOIRE : la précédente timeline '
                    'ne respectait pas le contrat : '+str(exc)+'\n'
                    'Reprends le clip COMPLET et réponds à nouveau en deux sections '
                    'SCENE_CONTEXT et NEW_TAKE, sans conserver ce découpage faux. '
                    f'Bornes obligatoires : {start:.3f}s et {end:.3f}s. '
                    'Toute la timeline doit couvrir exactement 0.000–'
                    f'{duration:.3f}s. Aucun CUT caméra ajouté.')
                print('[RETOUCHES] Gemma : correction des bornes de shots avant H3 : '+str(exc),flush=True)
    finally:
        # H3 must not coexist with Gemma 26B loaded on a 16GB card.
        # FilmMaker owns/knows its own process; never kill external PIDs.
        try:
            film.unload_text_backend(backend,label='Avant retouche H3')
        finally:
            film.release_all_text_models_for_h3(label='Retouches : H3 prend le GPU')
    return final,'Gemma 26B · fenêtre vérifiée + NEW TAKE unique · '+str(backend.get('display') or backend.get('model'))
